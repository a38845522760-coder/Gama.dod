import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { IronYardApp } from "@/game/IronYardApp";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const [on, setOn] = useState(false);
  useEffect(() => setOn(true), []);
  if (!on) {
    return (
      <main className="game-root">
        <section className="overlay">
          <div className="sheet">
            <p className="kicker">Iron Yard</p>
            <h1 className="text-5xl">Gate check</h1>
            <div className="bar">
              <span style={{ width: "12%" }} />
            </div>
          </div>
        </section>
      </main>
    );
  }
  return <IronYardApp />;
}

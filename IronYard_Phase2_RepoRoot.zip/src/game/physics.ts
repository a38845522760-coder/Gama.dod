import type { AABB, PathPoint, PhysBody } from "./types";

export const YARD = 32;

export function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

export function pointInSolid(x: number, y: number, z: number, boxes: AABB[]) {
  for (const b of boxes) {
    if (x > b.minX && x < b.maxX && y > b.minY && y < b.maxY && z > b.minZ && z < b.maxZ) return true;
  }
  return false;
}

export function blocked(x: number, feet: number, z: number, r: number, h: number, boxes: AABB[]) {
  const y0 = feet + 0.08;
  const y1 = feet + h - 0.06;
  for (const b of boxes) {
    if (y1 < b.minY || y0 > b.maxY) continue;
    const cx = clamp(x, b.minX, b.maxX);
    const cz = clamp(z, b.minZ, b.maxZ);
    const dx = x - cx;
    const dz = z - cz;
    if (dx * dx + dz * dz < r * r) return true;
  }
  return false;
}

export function highestSurface(x: number, z: number, maxY: number, boxes: AABB[]) {
  let best = -999;
  if (!pointInSolid(x, 0.08, z, boxes) && 0 <= maxY) best = 0;
  for (const b of boxes) {
    if (x < b.minX - 0.05 || x > b.maxX + 0.05 || z < b.minZ - 0.05 || z > b.maxZ + 0.05) continue;
    if (b.maxY <= maxY + 0.001 && b.maxY > best && !pointInSolid(x, b.maxY + 0.08, z, boxes)) best = b.maxY;
  }
  return best;
}

export function moveHorizontal(b: PhysBody, dx: number, dz: number, boxes: AABB[]) {
  const step = 0.62;
  const attempt = (nx: number, nz: number) => {
    if (!blocked(nx, b.y, nz, b.r, b.h, boxes)) return b.y;
    const top = highestSurface(nx, nz, b.y + step, boxes);
    if (top > b.y + 0.03 && top - b.y <= step && !blocked(nx, top + 0.01, nz, b.r, b.h, boxes)) return top;
    return null;
  };
  const yx = attempt(b.x + dx, b.z);
  if (yx !== null) {
    b.x += dx;
    b.y = yx;
  }
  const yz = attempt(b.x, b.z + dz);
  if (yz !== null) {
    b.z += dz;
    b.y = Math.max(b.y, yz);
  }
  b.x = clamp(b.x, -YARD + 0.4, YARD - 0.4);
  b.z = clamp(b.z, -YARD + 0.4, YARD - 0.4);
}

export function gravity(b: PhysBody, dt: number, boxes: AABB[]) {
  const prevY = b.y;
  const was = b.onGround;
  b.vy -= 23 * dt;
  if (b.vy < -32) b.vy = -32;
  b.y += b.vy * dt;
  const fl = highestSurface(b.x, b.z, Math.max(prevY, b.y) + 0.45, boxes);
  if (b.vy <= 0 && b.y <= fl && prevY + 0.08 >= fl) {
    const hard = !was && b.vy < -7;
    b.y = fl;
    b.vy = 0;
    b.onGround = true;
    return hard;
  }
  b.onGround = false;
  if (b.y < -6) {
    b.y = 0;
    b.vy = 0;
    b.onGround = true;
  }
  return false;
}

export function rayAABB(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  b: AABB,
  maxT: number,
) {
  let tmin = 0;
  let tmax = maxT;
  const dims: [number, number, number, number][] = [
    [ox, dx, b.minX, b.maxX],
    [oy, dy, b.minY, b.maxY],
    [oz, dz, b.minZ, b.maxZ],
  ];
  for (const [o, d, min, max] of dims) {
    if (Math.abs(d) < 1e-8) {
      if (o < min || o > max) return null;
    } else {
      let t1 = (min - o) / d;
      let t2 = (max - o) / d;
      if (t1 > t2) {
        const s = t1;
        t1 = t2;
        t2 = s;
      }
      if (t1 > tmin) tmin = t1;
      if (t2 < tmax) tmax = t2;
      if (tmax < tmin) return null;
    }
  }
  const t = tmin >= 0 ? tmin : tmax;
  if (t < 0 || t > maxT) return null;
  return t;
}

export function rayWorld(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  boxes: AABB[],
  maxT: number,
) {
  let best: number | null = null;
  let box: AABB | null = null;
  for (const b of boxes) {
    const t = rayAABB(ox, oy, oz, dx, dy, dz, b, maxT);
    if (t !== null && (best === null || t < best)) {
      best = t;
      box = b;
    }
  }
  return best === null || !box ? null : { t: best, box };
}

export function raySphere(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  cx: number,
  cy: number,
  cz: number,
  r: number,
) {
  const lx = ox - cx;
  const ly = oy - cy;
  const lz = oz - cz;
  const b = lx * dx + ly * dy + lz * dz;
  const c = lx * lx + ly * ly + lz * lz - r * r;
  const disc = b * b - c;
  if (disc < 0) return null;
  const t = -b - Math.sqrt(disc);
  return t > 0.02 ? t : null;
}

export function rayCapsule(
  ox: number,
  oy: number,
  oz: number,
  dx: number,
  dy: number,
  dz: number,
  x: number,
  z: number,
  y0: number,
  y1: number,
  r: number,
) {
  let best: number | null = null;
  const a = dx * dx + dz * dz;
  const oxz = ox - x;
  const ozz = oz - z;
  const b = 2 * (oxz * dx + ozz * dz);
  const c = oxz * oxz + ozz * ozz - r * r;
  if (a > 1e-6) {
    const disc = b * b - 4 * a * c;
    if (disc >= 0) {
      const t = (-b - Math.sqrt(disc)) / (2 * a);
      if (t > 0.02) {
        const hy = oy + dy * t;
        if (hy >= y0 && hy <= y1) best = t;
      }
    }
  }
  const t0 = raySphere(ox, oy, oz, dx, dy, dz, x, y0, z, r);
  const t1 = raySphere(ox, oy, oz, dx, dy, dz, x, y1, z, r);
  for (const t of [t0, t1]) if (t !== null && (best === null || t < best)) best = t;
  return best;
}

export type Nav = {
  path: (x: number, z: number, tx: number, tz: number) => PathPoint[];
  cover: PathPoint[];
  floorAt: (x: number, z: number) => number;
};

export function buildNav(boxes: AABB[]): Nav {
  const n = 64;
  const origin = -32;
  const cell = 1;
  const walk = new Uint8Array(n * n);
  const h = new Float32Array(n * n);
  const idx = (i: number, j: number) => j * n + i;
  const world = (i: number, j: number) => ({ x: origin + (i + 0.5) * cell, z: origin + (j + 0.5) * cell });

  for (let j = 0; j < n; j++) {
    for (let i = 0; i < n; i++) {
      const { x, z } = world(i, j);
      const floor = highestSurface(x, z, 8, boxes);
      if (floor < -1) continue;
      if (blocked(x, floor + 0.02, z, 0.34, 1.6, boxes)) continue;
      walk[idx(i, j)] = 1;
      h[idx(i, j)] = floor;
    }
  }

  const nearest = (x: number, z: number) => {
    let i = clamp(Math.floor((x - origin) / cell), 0, n - 1);
    let j = clamp(Math.floor((z - origin) / cell), 0, n - 1);
    if (walk[idx(i, j)]) return { i, j };
    for (let rad = 1; rad < 8; rad++) {
      for (let dj = -rad; dj <= rad; dj++) {
        for (let di = -rad; di <= rad; di++) {
          const ii = i + di;
          const jj = j + dj;
          if (ii < 0 || jj < 0 || ii >= n || jj >= n) continue;
          if (walk[idx(ii, jj)]) return { i: ii, j: jj };
        }
      }
    }
    return { i, j };
  };

  const cover: PathPoint[] = [];
  for (const b of boxes) {
    const height = b.maxY - b.minY;
    if (height < 0.7 || height > 1.45) continue;
    const spots = [
      { x: (b.minX + b.maxX) / 2, z: b.minZ - 1.1 },
      { x: (b.minX + b.maxX) / 2, z: b.maxZ + 1.1 },
      { x: b.minX - 1.1, z: (b.minZ + b.maxZ) / 2 },
      { x: b.maxX + 1.1, z: (b.minZ + b.maxZ) / 2 },
    ];
    for (const s of spots) {
      const p = nearest(s.x, s.z);
      if (!walk[idx(p.i, p.j)]) continue;
      const w = world(p.i, p.j);
      cover.push({ x: w.x, y: h[idx(p.i, p.j)], z: w.z });
    }
  }

  function path(x: number, z: number, tx: number, tz: number): PathPoint[] {
    const s = nearest(x, z);
    const g = nearest(tx, tz);
    const si = idx(s.i, s.j);
    const gi = idx(g.i, g.j);
    if (!walk[si] || !walk[gi]) return [];
    if (si === gi) {
      const w = world(g.i, g.j);
      return [{ x: w.x, y: h[gi], z: w.z }];
    }
    const open: number[] = [si];
    const gScore = new Float32Array(n * n);
    const fScore = new Float32Array(n * n);
    const prev = new Int32Array(n * n);
    gScore.fill(1e9);
    fScore.fill(1e9);
    prev.fill(-1);
    gScore[si] = 0;
    fScore[si] = Math.abs(g.i - s.i) + Math.abs(g.j - s.j);
    const inOpen = new Uint8Array(n * n);
    inOpen[si] = 1;
    const dirs = [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
      [1, 1],
      [1, -1],
      [-1, 1],
      [-1, -1],
    ];
    let guard = 0;
    while (open.length && guard++ < 2500) {
      let bi = 0;
      for (let k = 1; k < open.length; k++) if (fScore[open[k]] < fScore[open[bi]]) bi = k;
      const cur = open[bi];
      open.splice(bi, 1);
      inOpen[cur] = 0;
      if (cur === gi) break;
      const ci = cur % n;
      const cj = (cur / n) | 0;
      for (const [di, dj] of dirs) {
        const ni = ci + di;
        const nj = cj + dj;
        if (ni < 0 || nj < 0 || ni >= n || nj >= n) continue;
        const nidx = idx(ni, nj);
        if (!walk[nidx]) continue;
        if (Math.abs(h[nidx] - h[cur]) > 0.62) continue;
        if (di !== 0 && dj !== 0) {
          if (!walk[idx(ci + di, cj)] || !walk[idx(ci, cj + dj)]) continue;
        }
        const stepCost = di !== 0 && dj !== 0 ? 1.41 : 1;
        const tent = gScore[cur] + stepCost;
        if (tent >= gScore[nidx]) continue;
        prev[nidx] = cur;
        gScore[nidx] = tent;
        fScore[nidx] = tent + Math.abs(g.i - ni) + Math.abs(g.j - nj);
        if (!inOpen[nidx]) {
          open.push(nidx);
          inOpen[nidx] = 1;
        }
      }
    }
    if (prev[gi] === -1 && si !== gi) return [];
    const out: PathPoint[] = [];
    let c = gi;
    let safety = 0;
    while (c !== -1 && safety++ < n * n) {
      const i = c % n;
      const j = (c / n) | 0;
      const w = world(i, j);
      out.push({ x: w.x, y: h[c], z: w.z });
      if (c === si) break;
      c = prev[c];
    }
    out.reverse();
    if (out.length > 2) {
      const slim: PathPoint[] = [out[0]];
      for (let i = 1; i < out.length - 1; i += 2) slim.push(out[i]);
      slim.push(out[out.length - 1]);
      return slim;
    }
    return out;
  }

  return {
    path,
    cover,
    floorAt: (x, z) => {
      const p = nearest(x, z);
      return h[idx(p.i, p.j)] || 0;
    },
  };
}

export function yawToward(x: number, z: number, tx: number, tz: number) {
  return Math.atan2(-(tx - x), -(tz - z));
}

export function dampAngle(current: number, target: number, rate: number) {
  let d = target - current;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return current + d * clamp(rate, 0, 1);
}

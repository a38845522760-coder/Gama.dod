import { KIND_INFO } from "./catalog";
import type { Nav } from "./physics";
import { dampAngle, yawToward } from "./physics";
import type { ActorKind, ModeId, PathPoint, TeamId, WeaponId } from "./types";

export type Soldier = {
  id: number;
  name: string;
  kind: ActorKind;
  team: TeamId;
  weapon: WeaponId | "melee" | "acid";
  x: number;
  y: number;
  z: number;
  yaw: number;
  vy: number;
  r: number;
  h: number;
  onGround: boolean;
  hp: number;
  maxHp: number;
  alive: boolean;
  speed: number;
  acc: number;
  prefer: number;
  aggression: number;
  reactLeft: number;
  burstLeft: number;
  burstCool: number;
  reload: number;
  fireCd: number;
  mag: number;
  reserve: number;
  meleeCd: number;
  specialT: number;
  path: PathPoint[];
  pathI: number;
  repath: number;
  strafe: number;
  strafeT: number;
  deadFor: number;
  respawnIn: number;
  kills: number;
  deaths: number;
  score: number;
  spawn: PathPoint;
  flash: number;
  gait: number;
  seenX: number;
  seenZ: number;
  seen: number;
  invuln: number;
  target: number;
  goalX: number;
  goalZ: number;
  aimX: number;
  aimY: number;
  aimZ: number;
  wantFire: boolean;
  wantMelee: boolean;
  sprint: boolean;
  hurt: number;
};

export type MindCtx = {
  dt: number;
  time: number;
  mode: ModeId;
  nav: Nav;
  zone: { x: number; z: number; r: number };
  player: { id: number; x: number; y: number; z: number; h: number; alive: boolean; team: TeamId; invuln: number };
  bots: Soldier[];
  los: (x: number, y: number, z: number, tx: number, ty: number, tz: number) => boolean;
};

function hostile(mode: ModeId, a: TeamId, b: TeamId) {
  if (mode === "ffa" || mode === "king") return a !== b || true;
  if (mode === "zombie") return (a === "zombie") !== (b === "zombie");
  return a !== b;
}

// ffa/king: the `a !== b || true` is always true. Everyone is hostile, including same label.
// Keep the function honest:
function isHostile(mode: ModeId, a: TeamId, b: TeamId) {
  if (mode === "ffa" || mode === "king") return true;
  if (mode === "zombie") return (a === "zombie") !== (b === "zombie");
  return a !== b;
}

export function makeSoldier(partial: Pick<Soldier, "id" | "name" | "kind" | "team" | "spawn"> & { wave?: number }): Soldier {
  const info = KIND_INFO[partial.kind];
  const scale = 1 + Math.max(0, (partial.wave ?? 1) - 1) * 0.14;
  const weapon = info.weapon;
  const mag = weapon === "melee" || weapon === "acid" ? 99 : info.burst + 8;
  return {
    id: partial.id,
    name: partial.name,
    kind: partial.kind,
    team: partial.team,
    weapon,
    x: partial.spawn.x,
    y: partial.spawn.y,
    z: partial.spawn.z,
    yaw: 0,
    vy: 0,
    r: partial.kind === "brute" ? 0.52 : partial.kind === "bloater" ? 0.48 : 0.38,
    h: partial.kind === "screamer" ? 1.9 : partial.kind === "brute" ? 1.85 : 1.7,
    onGround: true,
    hp: Math.round(info.hp * (partial.team === "zombie" ? scale : 1)),
    maxHp: Math.round(info.hp * (partial.team === "zombie" ? scale : 1)),
    alive: true,
    speed: info.speed * (partial.team === "zombie" ? Math.min(1.22, 1 + ((partial.wave ?? 1) - 1) * 0.02) : 1),
    acc: info.acc,
    prefer: info.prefer,
    aggression: info.aggression,
    reactLeft: info.reaction,
    burstLeft: info.burst,
    burstCool: 0,
    reload: 0,
    fireCd: 0,
    mag,
    reserve: weapon === "melee" ? 0 : 180,
    meleeCd: 0.4,
    specialT: 2 + Math.random() * 3,
    path: [],
    pathI: 0,
    repath: 0,
    strafe: Math.random() < 0.5 ? -1 : 1,
    strafeT: 0.8,
    deadFor: 0,
    respawnIn: 0,
    kills: 0,
    deaths: 0,
    score: 0,
    spawn: partial.spawn,
    flash: 0,
    gait: Math.random() * 4,
    seenX: partial.spawn.x,
    seenZ: partial.spawn.z,
    seen: -10,
    invuln: 0,
    target: -1,
    goalX: partial.spawn.x,
    goalZ: partial.spawn.z,
    aimX: partial.spawn.x,
    aimY: 1.4,
    aimZ: partial.spawn.z - 1,
    wantFire: false,
    wantMelee: false,
    sprint: false,
    hurt: 0,
  };
}

type Unit = { id: number; x: number; y: number; z: number; h: number; alive: boolean; team: TeamId; invuln: number };

export function think(bot: Soldier, ctx: MindCtx) {
  const info = KIND_INFO[bot.kind];
  bot.wantFire = false;
  bot.wantMelee = false;
  bot.sprint = false;
  if (!bot.alive) return;

  const units: Unit[] = [ctx.player, ...ctx.bots.filter((b) => b.id !== bot.id)];
  let best: Unit | null = null;
  let bestD = 1e9;
  for (const u of units) {
    if (!u.alive || u.invuln > 0) continue;
    if (!isHostile(ctx.mode, bot.team, u.team)) continue;
    const d = Math.hypot(u.x - bot.x, u.z - bot.z);
    const eye = bot.y + bot.h * 0.82;
    const sees = ctx.los(bot.x, eye, bot.z, u.x, u.y + u.h * 0.7, u.z);
    const score = d + (sees ? 0 : 18);
    if (score < bestD) {
      bestD = score;
      best = u;
    }
  }

  if (best && best.id !== bot.target) bot.reactLeft = info.reaction * (0.75 + Math.random() * 0.5);
  bot.target = best ? best.id : -1;

  const dist = best ? Math.hypot(best.x - bot.x, best.z - bot.z) : 999;
  const eye = bot.y + bot.h * 0.82;
  const sees =
    !!best && ctx.los(bot.x, eye, bot.z, best.x, best.y + best.h * 0.7, best.z) && dist < (bot.weapon === "melee" ? 30 : 60);

  if (best && sees) {
    bot.seenX = best.x;
    bot.seenZ = best.z;
    bot.seen = ctx.time;
    bot.aimX = best.x;
    bot.aimY = best.y + best.h * (bot.kind === "marksman" ? 0.72 : 0.62);
    bot.aimZ = best.z;
    bot.reactLeft = Math.max(0, bot.reactLeft - ctx.dt);
  } else if (best) {
    bot.aimX = bot.seenX;
    bot.aimY = 1.3;
    bot.aimZ = bot.seenZ;
  }

  bot.strafeT -= ctx.dt;
  if (bot.strafeT <= 0) {
    bot.strafe = Math.random() < 0.5 ? -1 : 1;
    bot.strafeT = 0.55 + Math.random() * 1.1;
  }

  let gx = bot.seenX;
  let gz = bot.seenZ;
  if (!best) {
    if (ctx.mode === "king") {
      gx = ctx.zone.x + Math.sin(ctx.time * 0.4 + bot.id) * 2;
      gz = ctx.zone.z + Math.cos(ctx.time * 0.3 + bot.id) * 2;
    } else if (ctx.mode === "tdm") {
      gx = bot.team === "steel" ? 0 : 0;
      gz = bot.team === "steel" ? -4 : 16;
    } else {
      gx = Math.cos(ctx.time * 0.15 + bot.id) * 10;
      gz = Math.sin(ctx.time * 0.12 + bot.id) * 10;
    }
  } else if (bot.kind === "marksman" && dist < 12) {
    gx = bot.x + (bot.x - best.x);
    gz = bot.z + (bot.z - best.z);
  } else if (bot.kind === "spitter" || bot.kind === "screamer") {
    if (dist < bot.prefer - 2) {
      gx = bot.x + (bot.x - best.x);
      gz = bot.z + (bot.z - best.z);
    } else if (dist > bot.prefer + 3) {
      gx = best.x;
      gz = best.z;
    } else {
      const yaw = yawToward(bot.x, bot.z, best.x, best.z);
      gx = bot.x + Math.cos(yaw) * bot.strafe * 3;
      gz = bot.z - Math.sin(yaw) * bot.strafe * 3;
    }
  } else if (dist > bot.prefer + 2) {
    gx = best.x;
    gz = best.z;
    bot.sprint = bot.aggression > 0.6 || bot.kind === "breacher" || bot.kind === "runner";
  } else if (dist < bot.prefer - 3 && bot.weapon !== "melee") {
    gx = bot.x + (bot.x - best.x) * 0.5;
    gz = bot.z + (bot.z - best.z) * 0.5;
  } else if (bot.weapon !== "melee") {
    const yaw = yawToward(bot.x, bot.z, best.x, best.z);
    const rx = Math.cos(yaw);
    const rz = -Math.sin(yaw);
    gx = best.x * 0.15 + bot.x * 0.85 + rx * bot.strafe * 2.4;
    gz = best.z * 0.15 + bot.z * 0.85 + rz * bot.strafe * 2.4;
  } else {
    gx = best.x;
    gz = best.z;
    bot.sprint = true;
  }

  if (bot.hp < bot.maxHp * 0.35 && bot.weapon !== "melee" && ctx.nav.cover.length && Math.random() < 0.02) {
    let cbest = ctx.nav.cover[0];
    let cd = 1e9;
    for (const c of ctx.nav.cover) {
      const d = Math.hypot(c.x - bot.x, c.z - bot.z) + (best ? Math.hypot(c.x - best.x, c.z - best.z) * 0.2 : 0);
      if (d < cd) {
        cd = d;
        cbest = c;
      }
    }
    gx = cbest.x;
    gz = cbest.z;
  }

  if (bot.kind === "marksman") {
    const high = ctx.nav.cover.find((c) => c.y > 2);
    if (high && dist > 14 && Math.random() < 0.01) {
      gx = high.x;
      gz = high.z;
    }
  }

  bot.repath -= ctx.dt;
  const movedGoal = Math.hypot(gx - bot.goalX, gz - bot.goalZ) > 3;
  if (bot.repath <= 0 || movedGoal || bot.pathI >= bot.path.length) {
    bot.goalX = gx;
    bot.goalZ = gz;
    bot.path = ctx.nav.path(bot.x, bot.z, gx, gz);
    bot.pathI = 0;
    bot.repath = 0.65 + Math.random() * 0.4;
  }

  let tx = gx;
  let tz = gz;
  if (bot.pathI < bot.path.length) {
    const p = bot.path[bot.pathI];
    if (Math.hypot(p.x - bot.x, p.z - bot.z) < 0.85) bot.pathI += 1;
    const n = bot.path[Math.min(bot.pathI, bot.path.length - 1)];
    if (n) {
      tx = n.x;
      tz = n.z;
    }
  }

  if (bot.kind === "runner") {
    tx += Math.sin(ctx.time * 7 + bot.id) * 0.8;
    tz += Math.cos(ctx.time * 6 + bot.id) * 0.8;
  }

  const face = best && (sees || dist < 20) ? yawToward(bot.x, bot.z, best.x, best.z) : yawToward(bot.x, bot.z, tx, tz);
  bot.yaw = dampAngle(bot.yaw, face, 1 - Math.exp(-6 * ctx.dt));

  // stash wish direction in goal fields temporarily? Engine reads a direction from tx/tz via seen? 
  // Store immediate steer target in aim unused? Use goalX as steer only when pathing — engine will recompute.
  bot.goalX = tx;
  bot.goalZ = tz;

  const inBand = !!best && sees && dist < bot.prefer * 1.55 + 6 && dist > 0.8;
  if (bot.weapon !== "melee" && bot.weapon !== "acid" && inBand && bot.reactLeft <= 0 && bot.reload <= 0 && bot.mag > 0) {
    if (bot.burstCool > 0) bot.burstCool -= ctx.dt;
    else bot.wantFire = true;
  }
  if (bot.weapon === "acid" && best && sees && dist < 22 && dist > 4 && bot.meleeCd <= 0 && bot.reactLeft <= 0) {
    bot.wantFire = true;
  }
  if ((bot.weapon === "melee" || dist < info.meleeRange + 0.3) && best && dist < info.meleeRange + 0.15 && bot.meleeCd <= 0) {
    if (info.melee > 0) bot.wantMelee = true;
  }

  if (bot.kind === "gunner" && bot.wantFire) bot.sprint = false;
}

export { hostile, isHostile };

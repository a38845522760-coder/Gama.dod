export function createAudio() {
  let ctx: AudioContext | null = null;
  let noise: AudioBuffer | null = null;
  let volume = 0.7;
  let voices = 0;

  function context() {
    if (!ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      ctx = new AC();
      const len = ctx.sampleRate * 1;
      noise = ctx.createBuffer(1, len, ctx.sampleRate);
      const data = noise.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    }
    return ctx;
  }

  function unlock() {
    const c = context();
    if (c.state === "suspended") void c.resume();
  }

  function envGain(duration: number, peak: number) {
    const c = context();
    const g = c.createGain();
    const now = c.currentTime;
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(Math.max(0.001, peak * volume), now + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    g.connect(c.destination);
    voices += 1;
    window.setTimeout(() => {
      voices = Math.max(0, voices - 1);
      g.disconnect();
    }, duration * 1000 + 40);
    return { c, g, now };
  }

  function burst(freq: number, q: number, duration: number, peak: number, kind: "noise" | "tone" = "noise") {
    if (voices > 10 || volume <= 0.01) return;
    const { c, g, now } = envGain(duration, peak);
    if (kind === "noise" && noise) {
      const src = c.createBufferSource();
      src.buffer = noise;
      const filter = c.createBiquadFilter();
      filter.type = "bandpass";
      filter.frequency.value = freq;
      filter.Q.value = q;
      src.connect(filter);
      filter.connect(g);
      src.start(now);
      src.stop(now + duration);
    } else {
      const osc = c.createOscillator();
      osc.type = "square";
      osc.frequency.setValueAtTime(freq, now);
      osc.frequency.exponentialRampToValueAtTime(Math.max(40, freq * 0.5), now + duration);
      osc.connect(g);
      osc.start(now);
      osc.stop(now + duration);
    }
  }

  function shot(kind: string) {
    switch (kind) {
      case "pistol":
        burst(1400, 0.7, 0.12, 0.35);
        break;
      case "smg":
        burst(1800, 0.8, 0.07, 0.22);
        break;
      case "rifle":
        burst(900, 0.6, 0.14, 0.32);
        break;
      case "shotgun":
        burst(420, 0.4, 0.22, 0.45);
        break;
      case "sniper":
        burst(320, 0.5, 0.28, 0.4);
        break;
      case "lmg":
        burst(700, 0.55, 0.1, 0.28);
        break;
      case "energy":
        burst(2400, 4, 0.06, 0.12, "tone");
        break;
      default:
        burst(180, 0.5, 0.18, 0.3);
    }
  }

  return {
    unlock,
    setVolume: (v: number) => {
      volume = v;
    },
    shot,
    hit: () => burst(2200, 2, 0.05, 0.15, "tone"),
    hurt: () => burst(140, 0.6, 0.2, 0.3),
    empty: () => burst(900, 6, 0.04, 0.12, "tone"),
    reload: () => burst(600, 1.2, 0.08, 0.16),
    foot: () => burst(180, 0.7, 0.05, 0.08),
    ui: () => burst(880, 3, 0.05, 0.08, "tone"),
    groan: () => burst(90, 2, 0.25, 0.12, "tone"),
    boom: () => burst(90, 0.4, 0.35, 0.4),
    wave: () => burst(520, 1, 0.2, 0.16, "tone"),
  };
}

export type AudioBus = ReturnType<typeof createAudio>;

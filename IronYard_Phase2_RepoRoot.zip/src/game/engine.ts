import * as THREE from "three";
import { makeSoldier, think, type Soldier } from "./ai";
import { buildActor, buildWorldGun, gunKindFor, type ActorVisual } from "./actors";
import { createAudio, type AudioBus } from "./audio";
import { KIND_INFO, modeById, tuned, WEAPONS } from "./catalog";
import {
  buildNav,
  dampAngle,
  gravity,
  moveHorizontal,
  rayCapsule,
  rayWorld,
  yawToward,
  type Nav,
} from "./physics";
import { bump, commit, modsFor, noteCombat, profile, recordMatch } from "./save";
import type { ActorKind, Hud, MatchResult, ModeId, TeamId, TouchState, WeaponId } from "./types";
import { buildViewmodels, type ViewWeapon } from "./viewmodels";
import { buildWorld, type World } from "./world";

type Gun = {
  id: WeaponId;
  mag: number;
  reserve: number;
  reload: number;
  bloom: number;
  cd: number;
};

type Bot = Soldier & { visual: ActorVisual; gun: THREE.Group | null };

type Proj = {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  dmg: number;
  splash: number;
  team: TeamId;
  owner: number;
  life: number;
  mesh: THREE.Mesh;
};

type Spark = { mesh: THREE.Mesh; life: number; max: number };

const NAMES = [
  "Holt",
  "Voss",
  "Keller",
  "Briggs",
  "Sato",
  "Okoye",
  "Marlow",
  "Diaz",
  "Nguyen",
  "Ibarra",
  "Crowe",
  "Pavel",
  "Quin",
  "Adeyemi",
  "Frost",
  "Berg",
];

export type GameHooks = {
  onProgress: (value: number, label: string) => void;
  onReady: () => void;
  onHud: (hud: Hud) => void;
  onToast: (text: string) => void;
};

export type GameHandle = {
  start: (mode: ModeId, team: TeamId) => void;
  pause: () => void;
  resume: () => void;
  leave: () => void;
  skipIntermission: () => void;
  refreshLoadout: () => void;
  dispose: () => void;
};

const tmp = new THREE.Vector3();
const tmp2 = new THREE.Vector3();
const aim = new THREE.Vector3();

export function createGame(canvas: HTMLCanvasElement, touch: TouchState, hooks: GameHooks): GameHandle {
  let disposed = false;
  const quality = profile.settings.quality;
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: quality === "high",
    powerPreference: "high-performance",
    alpha: false,
  });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = quality !== "performance";
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.autoClear = false;
  renderer.setClearColor(0x1c262e, 1);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x1c262e);
  scene.fog = new THREE.Fog(0x1c262e, 28, 78);

  const camera = new THREE.PerspectiveCamera(78, 1, 0.08, 160);
  camera.rotation.order = "YXZ";
  const vmCamera = new THREE.PerspectiveCamera(78, 1, 0.05, 12);
  vmCamera.layers.set(1);

  const hemi = new THREE.HemisphereLight(0xffe0c4, 0x243036, 0.95);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xffd7ae, 1.55);
  sun.position.set(26, 38, 12);
  sun.castShadow = quality !== "performance";
  const shadowSize = quality === "high" ? 48 : 36;
  sun.shadow.mapSize.set(quality === "high" ? 1024 : 512, quality === "high" ? 1024 : 512);
  sun.shadow.camera.near = 8;
  sun.shadow.camera.far = 90;
  sun.shadow.camera.left = -shadowSize;
  sun.shadow.camera.right = shadowSize;
  sun.shadow.camera.top = shadowSize;
  sun.shadow.camera.bottom = -shadowSize;
  sun.shadow.bias = -0.00035;
  scene.add(sun);

  const rig = new THREE.Group();
  scene.add(rig);

  let world: World | null = null;
  let nav: Nav | null = null;
  let audio: AudioBus | null = null;
  let views: ReturnType<typeof buildViewmodels> | null = null;
  let currentView: ViewWeapon | null = null;
  const muzzleFlash = new THREE.PointLight(0xffc56a, 0, 3.5, 2);
  muzzleFlash.layers.set(1);
  rig.add(muzzleFlash);

  const bots: Bot[] = [];
  const projs: Proj[] = [];
  const sparks: Spark[] = [];
  const sparkGeo = new THREE.SphereGeometry(0.08, 5, 4);
  let mannequin: ActorVisual | null = null;

  let phase: Hud["phase"] = "boot";
  let mode: ModeId | null = null;
  let team: TeamId = "steel";
  let yaw = 0;
  let pitch = 0;
  let x = 0;
  let y = 0;
  let z = 22;
  let vy = 0;
  let onGround = true;
  let vx = 0;
  let vz = 0;
  const radius = 0.38;
  let crouch = false;
  let hp = 100;
  let armor = 0;
  let alive = true;
  let invuln = 0;
  let stim = 0;
  let hurt = 0;
  let kills = 0;
  let deaths = 0;
  let score = 0;
  let steel = 0;
  let ember = 0;
  let wave = 0;
  let queue: ActorKind[] = [];
  let intermission = 0;
  let countdown = 0;
  let timer = 0;
  let banner = "";
  let shake = 0;
  let recoil = 0;
  let bob = 0;
  let foot = 0;
  let ads = 0;
  let swapAnim = 0;
  let slot = 0;
  let guns: (Gun | null)[] = [null, null];
  let result: MatchResult | null = null;
  let ended = false;
  let feedId = 1;
  const feed: Hud["feed"] = [];
  let hudAcc = 0;
  let simAcc = 0;
  let last = performance.now();
  let raf = 0;
  let shotLatch = false;
  let jumpLatch = false;
  let reloadLatch = false;
  let swapLatch = false;
  let medLatch = false;
  let plateLatch = false;
  let stimLatch = false;
  let prevFire = false;
  let mouseDX = 0;
  let mouseDY = 0;
  let mouseFire = false;
  let mouseAds = false;
  let pointerLocked = false;
  let dragging = false;
  let injectOn = false;
  const injected = new Set<string>();
  const keys = new Set<string>();
  let swapTo = -1;
  let crouchToggle = false;
  let nextBot = 1;
  let nameI = 0;
  let healFor = 0;
  let healHp = 100;
  let shoveX = 0;
  let shoveZ = 0;
  let coyote = 0;
  let attract = 0;
  let hitPulse = 0;
  let boardLatch = false;

  const dustGeo = new THREE.BufferGeometry();
  const dustCount = 80;
  const dustArr = new Float32Array(dustCount * 3);
  for (let i = 0; i < dustCount; i++) {
    dustArr[i * 3] = (Math.random() - 0.5) * 60;
    dustArr[i * 3 + 1] = 0.4 + Math.random() * 6;
    dustArr[i * 3 + 2] = (Math.random() - 0.5) * 60;
  }
  dustGeo.setAttribute("position", new THREE.BufferAttribute(dustArr, 3));
  const dust = new THREE.Points(
    dustGeo,
    new THREE.PointsMaterial({ color: 0xc8b8a2, size: 0.06, transparent: true, opacity: 0.45 }),
  );
  scene.add(dust);

  function wait(ms: number) {
    return new Promise((r) => setTimeout(r, ms));
  }

  function toast(text: string) {
    hooks.onToast(text);
  }

  function pushFeed(text: string, tone: Hud["feed"][number]["tone"]) {
    feed.unshift({ id: feedId++, text, tone });
    feed.splice(5);
  }

  function bodyH() {
    return crouch ? 1.12 : 1.68;
  }
  function eyeH() {
    return crouch ? 0.98 : 1.56;
  }

  function resize() {
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    const cap = profile.settings.quality === "high" ? 1.6 : profile.settings.quality === "balanced" ? 1.25 : 1;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, cap));
    renderer.setSize(w, h, false);
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
    vmCamera.aspect = camera.aspect;
  }

  function syncAmmo(gun: Gun) {
    profile.ammo[gun.id] = gun.mag + gun.reserve;
  }

  function makeGun(id: WeaponId): Gun {
    const spec = tuned(id, modsFor(id));
    const pool = profile.ammo[id] ?? 0;
    const mag = Math.min(spec.mag, pool);
    const gun: Gun = { id, mag, reserve: Math.max(0, pool - mag), reload: 0, bloom: 0, cd: 0 };
    syncAmmo(gun);
    return gun;
  }

  function refreshLoadout() {
    views?.applySkin(profile.skin);
    if (phase === "boot" || phase === "attract") return;
    guns = [profile.loadout[0] ? makeGun(profile.loadout[0]) : null, profile.loadout[1] ? makeGun(profile.loadout[1]) : null];
    if (!guns[slot]) slot = guns[0] ? 0 : guns[1] ? 1 : 0;
    showWeapon();
  }

  function showWeapon() {
    if (!views) return;
    const gun = guns[slot];
    views.models.forEach((model) => {
      model.group.visible = !!gun && model.id === gun.id;
      if (model.group.visible) currentView = model;
    });
    if (!gun) currentView = null;
  }

  function activeSpec() {
    const gun = guns[slot];
    if (!gun) return null;
    return tuned(gun.id, modsFor(gun.id));
  }

  function hostile(a: TeamId, b: TeamId) {
    if (!mode) return false;
    if (mode === "ffa" || mode === "king") return true;
    if (mode === "zombie") return (a === "zombie") !== (b === "zombie");
    return a !== b;
  }

  function nearOfficer(px: number, pz: number, side: TeamId) {
    if (mode !== "tdm") return false;
    return bots.some((b) => b.alive && b.kind === "officer" && b.team === side && Math.hypot(b.x - px, b.z - pz) < 8);
  }

  function spreadDir(dir: THREE.Vector3, amount: number, out: THREE.Vector3) {
    const up = Math.abs(dir.y) < 0.98 ? tmp2.set(0, 1, 0) : tmp2.set(1, 0, 0);
    const tangent = new THREE.Vector3().crossVectors(up, dir).normalize();
    const bit = new THREE.Vector3().crossVectors(dir, tangent);
    const r = amount * Math.sqrt(Math.random());
    const a = Math.random() * Math.PI * 2;
    out.copy(dir).addScaledVector(tangent, Math.cos(a) * r).addScaledVector(bit, Math.sin(a) * r).normalize();
  }

  function rayHit(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, maxDist: number, ignore: number) {
    if (!world) return null;
    let best = maxDist;
    let kind: "world" | "body" = "world";
    let id = -1;
    let hx = ox + dx * maxDist;
    let hy = oy + dy * maxDist;
    let hz = oz + dz * maxDist;
    let head = false;
    const worldHit = rayWorld(ox, oy, oz, dx, dy, dz, world.colliders, maxDist);
    if (worldHit) {
      best = worldHit.t;
      hx = ox + dx * best;
      hy = oy + dy * best;
      hz = oz + dz * best;
    }
    const check = (uid: number, ux: number, uy: number, uz: number, uh: number, ur: number, ualive: boolean) => {
      if (!ualive || uid === ignore) return;
      const t = rayCapsule(ox, oy, oz, dx, dy, dz, ux, uz, uy + ur * 0.2, uy + uh - ur * 0.15, ur);
      if (t !== null && t < best) {
        best = t;
        kind = "body";
        id = uid;
        hx = ox + dx * t;
        hy = oy + dy * t;
        hz = oz + dz * t;
        head = hy > uy + uh * 0.78;
      }
    };
    check(0, x, y, z, bodyH(), radius, alive);
    for (const b of bots) check(b.id, b.x, b.y, b.z, b.h, b.r, b.alive);
    if (kind === "world" && !worldHit) return null;
    return { kind, id, x: hx, y: hy, z: hz, t: best, head };
  }

  function los(ax: number, ay: number, az: number, bx: number, by: number, bz: number) {
    const dx = bx - ax;
    const dy = by - ay;
    const dz = bz - az;
    const len = Math.hypot(dx, dy, dz) || 1;
    if (!world) return true;
    const hit = rayWorld(ax, ay, az, dx / len, dy / len, dz / len, world.colliders, len);
    return !hit || hit.t > len - 0.4;
  }

  function sparkAt(px: number, py: number, pz: number, color: number) {
    const mesh = new THREE.Mesh(
      sparkGeo,
      new THREE.MeshBasicMaterial({ color, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }),
    );
    mesh.position.set(px, py, pz);
    scene.add(mesh);
    sparks.push({ mesh, life: 0.22, max: 0.22 });
  }

  function hurtBot(bot: Bot, amount: number, attacker: number, head: boolean) {
    if (!bot.alive || bot.invuln > 0 || amount <= 0) return;
    if (attacker === 0 && !hostile(team, bot.team)) return;
    if (attacker > 0) {
      const src = bots.find((b) => b.id === attacker);
      if (src && !hostile(src.team, bot.team)) return;
      if (src && nearOfficer(src.x, src.z, src.team)) amount *= 1.15;
    } else if (nearOfficer(x, z, team)) amount *= 1.15;
    if (head) amount *= 1.55;
    bot.hp -= amount;
    bot.flash = 1;
    bot.hurt = 0.2;
    sparkAt(bot.x, bot.y + bot.h * 0.6, bot.z, bot.team === "zombie" ? 0x9abf62 : 0xfff1d2);
    if (attacker === 0) {
      hitPulse = 0.12;
      audio?.hit();
      noteCombat(0, head, amount);
    }
    if (bot.hp <= 0) killBot(bot, attacker, head);
  }

  function hurtPlayer(amount: number, attacker: number, head = false) {
    if (!alive || invuln > 0 || phase !== "live" || amount <= 0) return;
    if (attacker > 0) {
      const src = bots.find((b) => b.id === attacker);
      if (src && !hostile(src.team, team)) return;
      if (src && nearOfficer(src.x, src.z, src.team)) amount *= 1.15;
    }
    let rest = head ? amount * 1.4 : amount;
    if (armor > 0) {
      const absorbed = Math.min(armor, rest * 0.7);
      armor -= absorbed;
      rest -= absorbed;
    }
    hp = Math.max(0, hp - rest);
    hurt = 0.45;
    shake = Math.min(1, shake + 0.35);
    audio?.hurt();
    healFor = 0;
    if (hp <= 0) downPlayer(attacker);
  }

  function killBot(bot: Bot, attacker: number, head: boolean) {
    bot.alive = false;
    bot.hp = 0;
    bot.deaths += 1;
    bot.deadFor = 0;
    bot.respawnIn = mode === "zombie" ? 999 : 4.2;
    const attackerName = attacker === 0 ? profile.name : (bots.find((b) => b.id === attacker)?.name ?? "Yard");
    pushFeed(`${attackerName} dropped ${bot.name}`, attacker === 0 ? "kill" : "info");
    if (bot.kind === "bloater") explode(bot.x, bot.y + 0.8, bot.z, 58, 4.4, bot.team, bot.id);
    if (attacker === 0) {
      kills += 1;
      const gun = guns[slot];
      noteCombat(1, head, 0, gun?.id);
      if (mode === "tdm") {
        if (team === "steel") steel += 1;
        else ember += 1;
        score = team === "steel" ? steel : ember;
      } else if (mode === "king") score += 6;
      else score += 1;
      audio?.ui();
    } else if (attacker > 0) {
      const src = bots.find((b) => b.id === attacker);
      if (src) {
        src.kills += 1;
        if (mode === "tdm") {
          if (src.team === "steel") steel += 1;
          else if (src.team === "ember") ember += 1;
        } else if (mode === "king") src.score += 6;
        else src.score += 1;
      }
    }
    checkWin();
  }

  function downPlayer(attacker: number) {
    alive = false;
    hp = 0;
    deaths += 1;
    const name = attacker > 0 ? bots.find((b) => b.id === attacker)?.name : "The yard";
    pushFeed(`${name ?? "The yard"} dropped ${profile.name}`, "die");
    if (mode === "zombie" || mode === null) {
      endMatch(false, "The infected took the bay.");
      return;
    }
    if (attacker > 0) {
      const src = bots.find((b) => b.id === attacker);
      if (src) {
        src.kills += 1;
        if (mode === "tdm") {
          if (src.team === "steel") steel += 1;
          else ember += 1;
        } else if (mode === "ffa") src.score += 1;
        else if (mode === "king") src.score += 6;
      }
    }
    checkWin();
  }

  function explode(px: number, py: number, pz: number, dmg: number, splash: number, side: TeamId, owner: number) {
    audio?.boom();
    sparkAt(px, py, pz, 0xe8943a);
    shake = Math.min(1, shake + 0.25);
    const hitOne = (id: number, ux: number, uy: number, uz: number, ualive: boolean, apply: (d: number) => void) => {
      if (!ualive) return;
      const d = Math.hypot(ux - px, uy + 0.8 - py, uz - pz);
      if (d > splash) return;
      if (!los(px, py, pz, ux, uy + 0.8, uz)) return;
      apply(dmg * (1 - d / splash) * (id === owner ? 0.35 : 1));
    };
    hitOne(0, x, y, z, alive, (d) => hurtPlayer(d, owner));
    for (const b of bots) hitOne(b.id, b.x, b.y, b.z, b.alive, (d) => hurtBot(b, d, owner, false));
  }

  function checkWin() {
    if (!mode || ended || phase === "results") return;
    const def = modeById(mode);
    if (mode === "tdm" && (steel >= def.goal || ember >= def.goal)) {
      const mine = team === "steel" ? steel : ember;
      const theirs = team === "steel" ? ember : steel;
      endMatch(mine >= theirs, mine >= theirs ? "Your crew closed the contract." : "The other crew holds the yard.");
    } else if (mode === "ffa") {
      const bestBot = bots.reduce((m, b) => Math.max(m, b.score || b.kills), 0);
      if (kills >= def.goal || bestBot >= def.goal) {
        endMatch(kills >= bestBot, kills >= bestBot ? "Last contract standing." : "Someone else cleared the board.");
      }
    } else if (mode === "king") {
      const bestBot = bots.reduce((m, b) => Math.max(m, b.score), 0);
      if (score >= def.goal || bestBot >= def.goal) {
        endMatch(score >= bestBot, score >= bestBot ? "The circle is yours." : "Another crew held the paint longer.");
      }
    }
  }

  function endMatch(victory: boolean, subtitle: string) {
    if (ended || !mode) return;
    ended = true;
    phase = "results";
    const def = modeById(mode);
    const xp = kills * 28 + (victory ? 140 : 40) + (mode === "zombie" ? wave * 36 : 0);
    const credits = kills * 18 + (victory ? 90 : 25) + (mode === "zombie" ? wave * 22 : 0);
    const leveled = recordMatch({
      mode,
      result: victory ? "Win" : mode === "zombie" ? `Wave ${wave}` : "Loss",
      victory,
      kills,
      deaths,
      score: mode === "tdm" ? (team === "steel" ? steel : ember) : score,
      credits,
      xp,
      wave,
    });
    result = {
      title: victory ? "Contract closed" : "Shift over",
      subtitle,
      victory,
      kills,
      deaths,
      score: mode === "tdm" ? (team === "steel" ? steel : ember) : score,
      credits,
      xp,
      wave,
      leveled: leveled.leveled,
      newLevel: leveled.newLevel,
    };
    banner = result.title;
    if (leveled.leveled) toast(`Level ${leveled.newLevel}`);
    pushHud();
    void def;
  }

  function clearBots() {
    for (const b of bots) {
      b.gun?.removeFromParent();
      scene.remove(b.visual.root);
      b.visual.bodyMat.dispose();
      b.visual.eyeMat.dispose();
    }
    bots.length = 0;
    for (const p of projs) scene.remove(p.mesh);
    projs.length = 0;
    queue = [];
  }

  function attach(bot: Bot) {
    const visual = buildActor(bot.kind, bot.team);
    let gun: THREE.Group | null = null;
    if (bot.weapon !== "melee" && bot.weapon !== "acid") {
      gun = buildWorldGun(gunKindFor(bot.weapon));
      gun.position.set(0, -0.58, 0.04);
      visual.armR.add(gun);
    }
    scene.add(visual.root);
    const full = bot as Bot;
    full.visual = visual;
    full.gun = gun;
    bots.push(full);
    poseBot(full, 0.016);
  }

  function spawnKind(kind: ActorKind, side: TeamId, at: { x: number; y: number; z: number }, waveN = 1) {
    const bot = makeSoldier({
      id: nextBot++,
      name: side === "zombie" ? KIND_INFO[kind].title : NAMES[nameI++ % NAMES.length],
      kind,
      team: side,
      spawn: at,
      wave: waveN,
    }) as Bot;
    bot.yaw = yawToward(at.x, at.z, 0, 0);
    attach(bot);
    return bot;
  }

  function wavePlan(n: number): ActorKind[] {
    const list: ActorKind[] = [];
    const runners = Math.min(10, 4 + n);
    for (let i = 0; i < runners; i++) list.push("runner");
    if (n >= 2) for (let i = 0; i < Math.min(4, n - 1); i++) list.push("spitter");
    if (n >= 3) for (let i = 0; i < Math.min(3, Math.floor(n / 2)); i++) list.push("brute");
    if (n >= 4) list.push("screamer");
    if (n >= 5) for (let i = 0; i < Math.min(3, n - 4); i++) list.push("bloater");
    return list;
  }

  function reapDead() {
    for (let i = bots.length - 1; i >= 0; i--) {
      if (!bots[i].alive) {
        scene.remove(bots[i].visual.root);
        bots[i].visual.bodyMat.dispose();
        bots[i].visual.eyeMat.dispose();
        bots.splice(i, 1);
      }
    }
  }

  function startWave(n: number) {
    reapDead();
    wave = n;
    queue = wavePlan(n);
    banner = `Wave ${n}`;
    audio?.wave();
    pushFeed(`Wave ${n} incoming`, "info");
    phase = "live";
  }

  function pumpZombies() {
    if (mode !== "zombie" || phase !== "live") return;
    let living = bots.filter((b) => b.alive).length;
    const spots = world?.spawns.zombie ?? [];
    while (queue.length && living < 9) {
      const kind = queue.shift()!;
      const at = spots[Math.floor(Math.random() * spots.length)] ?? { x: 0, y: 0, z: -12 };
      const jitter = { x: at.x + (Math.random() - 0.5) * 2, y: at.y, z: at.z + (Math.random() - 0.5) * 2 };
      spawnKind(kind, "zombie", jitter, wave);
      living += 1;
    }
    if (!queue.length && bots.every((b) => !b.alive)) {
      const rewardC = 40 + wave * 18;
      const rewardX = 30 + wave * 12;
      profile.credits += rewardC;
      profile.xp += rewardX;
      bump("waves", 1);
      if (wave > profile.stats.bestWave) profile.stats.bestWave = wave;
      commit();
      phase = "intermission";
      intermission = 16;
      banner = `Wave ${wave} clear  +${rewardC} credits`;
      toast(banner);
      audio?.wave();
    }
  }

  function poseBot(bot: Bot, dt: number) {
    const v = bot.visual;
    if (!v) return;
    v.root.position.set(bot.x, bot.y - Math.min(0.4, bot.deadFor * 0.25), bot.z);
    v.root.visible = bot.deadFor < 3.2;
    v.yaw.rotation.y = bot.yaw + Math.PI;
    v.fall.rotation.x = bot.alive ? 0 : Math.min(1.25, bot.deadFor * 2.2);
    const moving = bot.alive && (Math.abs(bot.goalX - bot.x) > 0.4 || Math.abs(bot.goalZ - bot.z) > 0.4);
    bot.gait += dt * (moving ? 8.5 : 1.4);
    const swing = moving ? 0.65 : 0.04;
    v.legL.rotation.x = Math.sin(bot.gait) * swing;
    v.legR.rotation.x = -v.legL.rotation.x;
    if (bot.weapon === "melee") {
      v.armL.rotation.x = -0.5 + Math.sin(bot.gait) * (moving ? 0.9 : 0.1);
      v.armR.rotation.x = -0.5 - Math.sin(bot.gait) * (moving ? 0.9 : 0.1);
      if (bot.kind === "screamer") {
        v.armL.rotation.x = -2.3;
        v.armR.rotation.x = -2.3;
      }
    } else {
      v.armR.rotation.x = -1.28;
      v.armL.rotation.x = moving ? Math.sin(bot.gait) * 0.45 : -0.15;
    }
    if (bot.kind === "runner") v.torso.rotation.x = 0.4 + Math.sin(bot.gait) * 0.05;
    v.bodyMat.emissive.setHex(0xfff0dc);
    v.bodyMat.emissiveIntensity = bot.flash;
    bot.flash = Math.max(0, bot.flash - dt * 3.5);
    if (bot.kind === "bloater") {
      v.eyeMat.emissiveIntensity = 0.45 + Math.sin(performance.now() * 0.008 + bot.id) * 0.4;
    }
  }

  function fireHitscan(
    ox: number,
    oy: number,
    oz: number,
    dir: THREE.Vector3,
    spec: ReturnType<typeof tuned>,
    owner: number,
    ownerTeam: TeamId,
  ) {
    const pellets = spec.pellets;
    for (let i = 0; i < pellets; i++) {
      const shot = new THREE.Vector3();
      spreadDir(dir, spec.spread + (owner === 0 ? guns[slot]?.bloom ?? 0 : (1 - 0.5) * 0), shot);
      if (owner !== 0) {
        const src = bots.find((b) => b.id === owner);
        const err = src ? (1 - src.acc) * 0.09 : 0.04;
        spreadDir(shot, err, shot);
      }
      const hit = rayHit(ox, oy, oz, shot.x, shot.y, shot.z, spec.range, owner);
      const end = hit ?? {
        x: ox + shot.x * Math.min(spec.range, 40),
        y: oy + shot.y * Math.min(spec.range, 40),
        z: oz + shot.z * Math.min(spec.range, 40),
        kind: "world" as const,
        id: -1,
        t: spec.range,
        head: false,
      };
      sparkAt(end.x, end.y, end.z, spec.tracer);
      if (hit && hit.kind === "body") {
        const dist = hit.t;
        const fall = dist <= spec.falloffStart ? 1 : dist >= spec.falloffEnd ? spec.minMult : 1 + ((spec.minMult - 1) * (dist - spec.falloffStart)) / (spec.falloffEnd - spec.falloffStart);
        const dmg = spec.damage * fall;
        if (hit.id === 0) hurtPlayer(dmg, owner, hit.head);
        else {
          const bot = bots.find((b) => b.id === hit.id);
          if (bot) hurtBot(bot, dmg, owner, hit.head);
        }
      }
      void ownerTeam;
    }
  }

  function botAttack(bot: Bot, dt: number) {
    const info = KIND_INFO[bot.kind];
    bot.fireCd = Math.max(0, bot.fireCd - dt);
    bot.meleeCd = Math.max(0, bot.meleeCd - dt);
    bot.reload = Math.max(0, bot.reload - dt);
    if (bot.reload > 0) return;
    if (bot.wantMelee && bot.meleeCd <= 0) {
      bot.meleeCd = info.meleeCd;
      const targetId = bot.target;
      audio?.groan();
      if (targetId === 0) {
        hurtPlayer(info.melee, bot.id);
        if (bot.kind === "brute") {
          const len = Math.hypot(x - bot.x, z - bot.z) || 1;
          shoveX += ((x - bot.x) / len) * 9;
          shoveZ += ((z - bot.z) / len) * 9;
        }
      } else {
        const victim = bots.find((b) => b.id === targetId);
        if (victim) hurtBot(victim, info.melee, bot.id, false);
      }
    }
    if (!bot.wantFire) return;
    if (bot.weapon === "acid") {
      bot.meleeCd = info.meleeCd;
      spawnProjectile(bot.x, bot.y + bot.h * 0.7, bot.z, bot.aimX, bot.aimY, bot.aimZ, {
        dmg: 22,
        splash: 1.8,
        speed: 15,
        gravity: 7,
        team: bot.team,
        owner: bot.id,
        color: 0xb6e25a,
      });
      return;
    }
    if (bot.weapon === "melee") return;
    if (bot.mag <= 0) {
      if (bot.reserve > 0) {
        bot.reload = WEAPONS[bot.weapon].reload;
        const spec = WEAPONS[bot.weapon];
        const need = spec.mag;
        const take = Math.min(need, bot.reserve);
        bot.mag = take;
        bot.reserve -= take;
      }
      return;
    }
    if (bot.fireCd > 0) return;
    const spec = tuned(bot.weapon, { barrel: 0, magazine: 0, stock: 0 });
    bot.fireCd = 60 / spec.rpm;
    bot.mag -= 1;
    bot.burstLeft -= 1;
    if (bot.burstLeft <= 0) {
      bot.burstLeft = info.burst;
      bot.burstCool = info.pause;
    }
    const origin = tmp.set(bot.x, bot.y + bot.h * 0.8, bot.z);
    const dir = aim.set(bot.aimX - origin.x, bot.aimY - origin.y, bot.aimZ - origin.z).normalize();
    audio?.shot(spec.sound);
    fireHitscan(origin.x, origin.y, origin.z, dir, spec, bot.id, bot.team);
    muzzleAt(bot.x, bot.y + 1.3, bot.z);
  }

  function muzzleAt(px: number, py: number, pz: number) {
    sparkAt(px, py, pz, 0xffe2a8);
  }

  function spawnProjectile(
    ox: number,
    oy: number,
    oz: number,
    tx: number,
    ty: number,
    tz: number,
    spec: { dmg: number; splash: number; speed: number; gravity: number; team: TeamId; owner: number; color: number },
  ) {
    const dx = tx - ox;
    const dy = ty - oy;
    const dz = tz - oz;
    const len = Math.hypot(dx, dy, dz) || 1;
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(spec.splash > 3 ? 0.16 : 0.1, 8, 6),
      new THREE.MeshStandardMaterial({ color: spec.color, emissive: spec.color, emissiveIntensity: 0.7, roughness: 0.4 }),
    );
    mesh.position.set(ox, oy, oz);
    scene.add(mesh);
    projs.push({
      x: ox,
      y: oy,
      z: oz,
      vx: (dx / len) * spec.speed,
      vy: (dy / len) * spec.speed,
      vz: (dz / len) * spec.speed,
      dmg: spec.dmg,
      splash: spec.splash,
      team: spec.team,
      owner: spec.owner,
      life: 4,
      mesh,
    });
  }

  function playerFire() {
    const gun = guns[slot];
    const spec = activeSpec();
    if (!gun || !spec || !alive || phase !== "live") return;
    if (gun.reload > 0 || swapAnim > 0) return;
    if (gun.mag <= 0) {
      audio?.empty();
      if (gun.reserve > 0) beginReload(gun);
      return;
    }
    if (gun.cd > 0) return;
    gun.cd = 60 / spec.rpm;
    gun.mag -= 1;
    gun.bloom = Math.min(spec.bloomMax, gun.bloom + spec.bloom);
    syncAmmo(gun);
    recoil += spec.recoil;
    pitch += spec.recoil * 0.35;
    shake = Math.min(0.8, shake + spec.recoil * 8);
    audio?.shot(spec.sound);
    const cp = camera.position;
    const dir = new THREE.Vector3();
    camera.getWorldDirection(dir);
    if (spec.kind === "projectile") {
      const forward = dir.clone();
      spawnProjectile(cp.x + forward.x, cp.y + forward.y, cp.z + forward.z, cp.x + forward.x * 12, cp.y + forward.y * 12 - 1.5, cp.z + forward.z * 12, {
        dmg: spec.damage,
        splash: spec.splash,
        speed: spec.projSpeed,
        gravity: spec.projGravity,
        team,
        owner: 0,
        color: spec.tracer,
      });
    } else {
      fireHitscan(cp.x, cp.y, cp.z, dir, spec, 0, team);
    }
    if (currentView) {
      currentView.muzzle.getWorldPosition(tmp);
      muzzleFlash.position.copy(rig.worldToLocal(tmp.clone()));
      muzzleFlash.intensity = spec.kind === "beam" ? 4 : 8;
    }
  }

  function beginReload(gun: Gun) {
    const spec = tuned(gun.id, modsFor(gun.id));
    if (gun.reload > 0 || gun.mag >= spec.mag || gun.reserve <= 0) return;
    gun.reload = spec.reload;
    audio?.reload();
  }

  function keyDown(code: string) {
    return injectOn ? injected.has(code) : keys.has(code);
  }

  function readEdges() {
    const fireHeld = injectOn ? injected.has("Mouse0") : mouseFire || touch.fire;
    if (fireHeld && !prevFire) shotLatch = true;
    prevFire = fireHeld;
    if (touch.jump) {
      jumpLatch = true;
      touch.jump = false;
    }
    if (touch.reload || keyDown("KeyR")) {
      if (touch.reload) {
        reloadLatch = true;
        touch.reload = false;
      }
    }
    if (touch.swap) {
      swapLatch = true;
      swapTo = -1;
      touch.swap = false;
    }
    if (touch.useMed) {
      medLatch = true;
      touch.useMed = false;
    }
    if (touch.usePlate) {
      plateLatch = true;
      touch.usePlate = false;
    }
    if (touch.useStim) {
      stimLatch = true;
      touch.useStim = false;
    }
  }

  function sim(dt: number) {
    if (!world || !nav) return;
    const playing = phase === "live" || phase === "countdown";
    stim = Math.max(0, stim - dt);
    invuln = Math.max(0, invuln - dt);
    hurt = Math.max(0, hurt - dt);
    hitPulse = Math.max(0, hitPulse - dt);
    shoveX *= Math.max(0, 1 - dt * 3);
    shoveZ *= Math.max(0, 1 - dt * 3);
    if (world) {
      world.fan.rotation.z += dt * 2.4;
      world.beacon.intensity = 4 + Math.sin(performance.now() * 0.006) * 2.4;
      const ringMat = world.ring.material as THREE.MeshBasicMaterial;
      const inZone = Math.hypot(x - world.zone.x, z - world.zone.z) < world.zone.r;
      ringMat.color.setHex(inZone ? 0x3ec7c2 : 0xe8943a);
    }

    if (!playing) {
      for (const b of bots) poseBot(b, dt);
      return;
    }

    const spec = activeSpec();
    const gun = guns[slot];
    if (gun && spec) {
      gun.cd = Math.max(0, gun.cd - dt);
      gun.bloom = Math.max(0, gun.bloom - spec.recovery * dt);
      if (gun.reload > 0) {
        gun.reload -= dt;
        if (gun.reload <= 0) {
          const need = spec.mag - gun.mag;
          const take = Math.min(need, gun.reserve);
          gun.mag += take;
          gun.reserve -= take;
          syncAmmo(gun);
          audio?.reload();
        }
      }
    }

    const wishReload = reloadLatch || (keyDown("KeyR") && !injectOn);
    reloadLatch = false;
    if (wishReload && gun) beginReload(gun);
    if (swapLatch && swapAnim <= 0) {
      const want = swapTo < 0 ? (slot === 0 ? 1 : 0) : swapTo;
      if (guns[want]) {
        slot = want;
        swapAnim = 0.28;
        showWeapon();
      }
    }
    swapLatch = false;
    swapTo = -1;
    swapAnim = Math.max(0, swapAnim - dt);

    if (medLatch) {
      medLatch = false;
      if (profile.gear.medkit > 0 && hp < 100 && hp > 0 && healFor <= 0) {
        healFor = 0.65;
        healHp = hp;
      }
    }
    if (healFor > 0) {
      healFor -= dt;
      if (hp < healHp) healFor = 0;
      else if (healFor <= 0) {
        profile.gear.medkit -= 1;
        hp = Math.min(100, hp + 45);
        commit();
        toast("Trauma kit used");
      }
    }
    if (plateLatch) {
      plateLatch = false;
      if (profile.gear.plate > 0 && armor < 100 && alive) {
        profile.gear.plate -= 1;
        armor = Math.min(100, armor + 25);
        commit();
        toast("Plate seated");
      }
    }
    if (stimLatch) {
      stimLatch = false;
      if (profile.gear.stim > 0 && stim <= 0 && alive) {
        profile.gear.stim -= 1;
        stim = 8;
        commit();
        toast("Stim online");
      }
    }

    const forward = keyDown("KeyW") || keyDown("ArrowUp") ? 1 : 0;
    const back = keyDown("KeyS") || keyDown("ArrowDown") ? 1 : 0;
    const left = keyDown("KeyA") || keyDown("ArrowLeft") ? 1 : 0;
    const right = keyDown("KeyD") || keyDown("ArrowRight") ? 1 : 0;
    let inputF = forward - back + touch.moveY;
    let inputR = right - left + touch.moveX;
    const mag = Math.hypot(inputF, inputR);
    if (mag > 1) {
      inputF /= mag;
      inputR /= mag;
    }
    const sprint = (keyDown("ShiftLeft") || touch.sprint) && inputF > 0.2 && !crouch && ads < 0.4;
    const adsHeld = mouseAds || touch.ads || keyDown("Mouse2");
    const wantAds = !!adsHeld && !!spec?.scope === false ? !!adsHeld : !!adsHeld;
    const aiming = wantAds && !sprint && alive;
    ads += ((aiming ? 1 : 0) - ads) * (1 - Math.exp(-10 * dt));

    if (phase === "countdown") {
      inputF = 0;
      inputR = 0;
    }

    let speed = 4.75 * (spec?.move ?? 1);
    if (crouch) speed = 2.35;
    else if (sprint) speed = 7.2 * (spec?.move ?? 1);
    if (stim > 0) speed *= 1.22;
    if (healFor > 0) speed *= 0.55;
    if (gun?.id === "lmg") speed *= gun && spec ? 1 : 1;
    const fx = -Math.sin(yaw);
    const fz = -Math.cos(yaw);
    const rx = Math.cos(yaw);
    const rz = -Math.sin(yaw);
    const wishX = (fx * inputF + rx * inputR) * (alive ? speed : 0) + shoveX;
    const wishZ = (fz * inputF + rz * inputR) * (alive ? speed : 0) + shoveZ;
    const k = 1 - Math.exp(-(onGround ? 14 : 4) * dt);
    vx += (wishX - vx) * k;
    vz += (wishZ - vz) * k;
    const body = { x, y, z, vy, r: radius, h: bodyH(), onGround };
    if (alive && phase !== "countdown") moveHorizontal(body, vx * dt, vz * dt, world.colliders);
    if (onGround) coyote = 0.12;
    else coyote -= dt;
    if (jumpLatch && coyote > 0 && alive && !crouch && phase !== "countdown") {
      body.vy = 7.35;
      body.onGround = false;
      coyote = 0;
    }
    jumpLatch = false;
    const landed = gravity(body, dt, world.colliders);
    if (landed) shake = Math.min(0.5, shake + 0.15);
    x = body.x;
    y = body.y;
    z = body.z;
    vy = body.vy;
    onGround = body.onGround;

    const moving = Math.hypot(vx, vz);
    if (onGround && moving > 1.2 && alive) {
      foot -= dt;
      if (foot <= 0) {
        foot = crouch ? 0.62 : sprint ? 0.32 : 0.46;
        audio?.foot();
      }
      bob += dt * moving * 1.5;
    }

    const fireHeld = injectOn ? injected.has("Mouse0") : mouseFire || touch.fire;
    const auto = !!spec?.auto;
    if (alive && phase === "live" && spec && (auto ? fireHeld : shotLatch)) playerFire();
    shotLatch = false;

    if (phase === "countdown") {
      countdown -= dt;
      banner = countdown > 0 ? `Deploy ${Math.ceil(countdown)}` : "Contact";
      if (countdown <= 0) {
        phase = "live";
        banner = mode === "zombie" ? "Wave 1" : "Contact";
        if (mode === "zombie") startWave(1);
      }
    }

    if (phase === "live") {
      timer += dt;
      const ctx = {
        dt,
        time: timer,
        mode: mode!,
        nav,
        zone: world.zone,
        player: { id: 0, x, y, z, h: bodyH(), alive, team, invuln },
        bots,
        los,
      };
      for (const bot of bots) {
        if (!bot.alive) {
          bot.deadFor += dt;
          bot.respawnIn -= dt;
          if (mode !== "zombie" && bot.respawnIn <= 0 && !ended) {
            bot.alive = true;
            bot.hp = bot.maxHp;
            bot.x = bot.spawn.x;
            bot.y = bot.spawn.y;
            bot.z = bot.spawn.z;
            bot.deadFor = 0;
            bot.invuln = 1.5;
            bot.mag = 20;
          }
          poseBot(bot, dt);
          continue;
        }
        bot.invuln = Math.max(0, bot.invuln - dt);
        think(bot, ctx);
        const dirX = bot.goalX - bot.x;
        const dirZ = bot.goalZ - bot.z;
        const len = Math.hypot(dirX, dirZ) || 1;
        let sp = bot.speed * (bot.sprint ? 1.18 : 1);
        if (bot.kind === "gunner" && bot.wantFire) sp *= 0.25;
        const bbody = { x: bot.x, y: bot.y, z: bot.z, vy: bot.vy, r: bot.r, h: bot.h, onGround: bot.onGround };
        moveHorizontal(bbody, (dirX / len) * sp * dt, (dirZ / len) * sp * dt, world.colliders);
        gravity(bbody, dt, world.colliders);
        bot.x = bbody.x;
        bot.y = bbody.y;
        bot.z = bbody.z;
        bot.vy = bbody.vy;
        bot.onGround = bbody.onGround;
        botAttack(bot, dt);
        if (bot.kind === "screamer" && bot.alive) {
          bot.specialT -= dt;
          if (bot.specialT <= 0) {
            bot.specialT = 10;
            if (bots.filter((b) => b.alive && b.team === "zombie").length < 10) {
              queue.push("runner");
              pushFeed("Screamer called a runner", "info");
              audio?.groan();
            }
          }
        }
        poseBot(bot, dt);
      }
      pumpZombies();
      for (let i = projs.length - 1; i >= 0; i--) {
        const p = projs[i];
        p.life -= dt;
        p.vy -= (p.splash > 3 ? 13 : 7) * dt;
        const nx = p.x + p.vx * dt;
        const ny = p.y + p.vy * dt;
        const nz = p.z + p.vz * dt;
        const dx = nx - p.x;
        const dy = ny - p.y;
        const dz = nz - p.z;
        const dist = Math.hypot(dx, dy, dz) || 0.0001;
        const hit = rayHit(p.x, p.y, p.z, dx / dist, dy / dist, dz / dist, dist, p.owner);
        if (hit || p.life <= 0 || ny < 0) {
          const ex = hit ? hit.x : nx;
          const ey = hit ? hit.y : Math.max(0, ny);
          const ez = hit ? hit.z : nz;
          explode(ex, ey, ez, p.dmg, p.splash, p.team, p.owner);
          scene.remove(p.mesh);
          projs.splice(i, 1);
        } else {
          p.x = nx;
          p.y = ny;
          p.z = nz;
          p.mesh.position.set(nx, ny, nz);
        }
      }
      if (mode === "king" && world) {
        const rate = 8 * dt;
        if (alive && Math.hypot(x - world.zone.x, z - world.zone.z) < world.zone.r) score += rate;
        for (const b of bots) {
          if (b.alive && Math.hypot(b.x - world.zone.x, b.z - world.zone.z) < world.zone.r) b.score += rate;
        }
      }
      const def = mode ? modeById(mode) : null;
      if (def && def.time > 0 && timer >= def.time) {
        if (mode === "tdm") {
          const mine = team === "steel" ? steel : ember;
          const theirs = team === "steel" ? ember : steel;
          endMatch(mine >= theirs, "Time called on the bay.");
        } else if (mode === "ffa") {
          const bestBot = bots.reduce((m, b) => Math.max(m, b.kills), 0);
          endMatch(kills >= bestBot, "Time called on the bay.");
        } else if (mode === "king") {
          const bestBot = bots.reduce((m, b) => Math.max(m, b.score), 0);
          endMatch(score >= bestBot, "The paint dried.");
        }
      }
      if (!alive && mode !== "zombie" && !ended) {
        countdown -= 0;
        banner = "Respawning";
        invuln -= 0;
        // reuse dead timer stored in coyote? use healFor negative no
      }
    }

    if (!alive && mode !== "zombie" && phase === "live" && !ended) {
      // respawn countdown stored in bot-like field: reuse intermission as player delay once
    }
  }

  let deadTimer = 0;
  function simDeath(dt: number) {
    if (alive || ended || mode === "zombie" || phase !== "live") {
      if (alive) deadTimer = 0;
      return;
    }
    deadTimer += dt;
    banner = `Respawn ${Math.max(0, Math.ceil(4.2 - deadTimer))}`;
    if (deadTimer >= 4.2 && world) {
      const spots = mode === "tdm" ? world.spawns[team === "ember" ? "ember" : "steel"] : world.spawns.ffa;
      const spot = spots[Math.floor(Math.random() * spots.length)];
      x = spot.x;
      y = spot.y;
      z = spot.z;
      vy = 0;
      hp = 100;
      alive = true;
      invuln = 1.8;
      deadTimer = 0;
      banner = "Back in";
    }
  }

  function render(dt: number) {
    recoil = Math.max(0, recoil - dt * 1.8);
    shake = Math.max(0, shake - dt * 1.6);
    const spec = activeSpec();
    const baseFov = profile.settings.fov;
    const scope = spec?.scope && ads > 0.65;
    const targetFov = scope ? 36 : baseFov - ads * 8 + (keyDown("ShiftLeft") || touch.sprint ? 3 : 0);
    camera.fov += (targetFov - camera.fov) * (1 - Math.exp(-8 * dt));
    camera.updateProjectionMatrix();

    if (phase === "attract" || phase === "boot" || phase === "results") {
      attract += dt;
      const a = attract * 0.18;
      camera.position.set(Math.sin(a) * 20, 8.5 + Math.sin(a * 0.8) * 1.2, Math.cos(a) * 18);
      camera.lookAt(0, 1.2, 0);
      rig.visible = false;
      if (mannequin) {
        mannequin.yaw.rotation.y = attract * 0.35;
        mannequin.legL.rotation.x = Math.sin(attract * 2) * 0.15;
        mannequin.legR.rotation.x = -mannequin.legL.rotation.x;
      }
    } else {
      rig.visible = phase === "live" || phase === "countdown" || phase === "pause";
      const bobY = Math.sin(bob) * (Math.hypot(vx, vz) > 1 ? 0.035 : 0.006);
      const bobX = Math.cos(bob * 0.5) * 0.015;
      camera.position.set(x + Math.sin(attract) * shake * 0.05, y + eyeH() + bobY, z);
      camera.rotation.order = "YXZ";
      camera.rotation.y = yaw + Math.sin(attract * 2) * shake * 0.01;
      camera.rotation.x = pitch - recoil + (crouch ? -0.02 : 0);
      camera.rotation.z = bobX * 0.4;
      if (currentView) {
        const hip = scope ? 0 : 1;
        const gx = 0.26 * hip;
        const gy = -0.24 - (1 - hip) * 0.04 - (swapAnim > 0 ? Math.sin((0.28 - swapAnim) * 12) * 0.12 : 0);
        const gz = -0.48 - ads * 0.08;
        currentView.group.position.set(gx + mouseDX * 0.00005, gy + bobY, gz);
        currentView.group.rotation.set(recoil * 1.4, 0, 0);
      }
    }

    const positions = dust.geometry.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < dustCount; i++) {
      let py = positions.getY(i) + dt * 0.15;
      if (py > 7) py = 0.3;
      positions.setY(i, py);
    }
    positions.needsUpdate = true;

    for (let i = sparks.length - 1; i >= 0; i--) {
      const s = sparks[i];
      s.life -= dt;
      const k = Math.max(0, s.life / s.max);
      s.mesh.scale.setScalar(0.4 + (1 - k) * 2.2);
      (s.mesh.material as THREE.MeshBasicMaterial).opacity = k;
      if (s.life <= 0) {
        scene.remove(s.mesh);
        sparks.splice(i, 1);
      }
    }
    muzzleFlash.intensity = Math.max(0, muzzleFlash.intensity - dt * 40);

    vmCamera.position.copy(camera.position);
    vmCamera.quaternion.copy(camera.quaternion);
    vmCamera.fov = camera.fov;
    vmCamera.updateProjectionMatrix();
    renderer.clear();
    renderer.render(scene, camera);
    if (rig.visible) {
      renderer.clearDepth();
      renderer.render(scene, vmCamera);
    }

    const cross = document.getElementById("iy-cross");
    if (cross) {
      const spreadPx = 8 + (guns[slot]?.bloom ?? 0) * 420 + (spec ? spec.spread * 280 : 0) + (Math.hypot(vx, vz) > 3 ? 6 : 0);
      cross.style.setProperty("--gap", `${spreadPx}px`);
      cross.classList.toggle("on", phase === "live" || phase === "countdown");
      cross.classList.toggle("scoped", !!scope);
      cross.classList.toggle("hit", hitPulse > 0);
    }
    const plate = document.getElementById("iy-aim");
    if (plate && (phase === "live" || phase === "countdown")) {
      const dir = new THREE.Vector3();
      camera.getWorldDirection(dir);
      const hit = rayHit(camera.position.x, camera.position.y, camera.position.z, dir.x, dir.y, dir.z, 80, 0);
      const bot = hit && hit.kind === "body" ? bots.find((b) => b.id === hit.id && b.alive) : null;
      if (bot) {
        tmp.set(bot.x, bot.y + bot.h + 0.25, bot.z).project(camera);
        if (tmp.z < 1) {
          plate.style.display = "block";
          plate.style.left = `${(tmp.x * 0.5 + 0.5) * canvas.clientWidth}px`;
          plate.style.top = `${(-tmp.y * 0.5 + 0.5) * canvas.clientHeight}px`;
          plate.innerHTML = `<b>${bot.name}</b><i style="width:${Math.max(0, (bot.hp / bot.maxHp) * 100)}%"></i>`;
        } else plate.style.display = "none";
      } else plate.style.display = "none";
    } else if (plate) plate.style.display = "none";

    const map = document.getElementById("iy-map") as HTMLCanvasElement | null;
    if (map && world && (phase === "live" || phase === "countdown" || phase === "pause")) {
      const ctx2 = map.getContext("2d");
      if (ctx2) {
        const w = map.width;
        ctx2.clearRect(0, 0, w, w);
        ctx2.fillStyle = "rgba(16,20,24,0.72)";
        ctx2.fillRect(0, 0, w, w);
        const project = (wx: number, wz: number) => ({ px: ((wx + 34) / 68) * w, py: ((wz + 34) / 68) * w });
        if (mode === "king") {
          const c = project(world.zone.x, world.zone.z);
          ctx2.strokeStyle = "#e8943a";
          ctx2.beginPath();
          ctx2.arc(c.px, c.py, (world.zone.r / 68) * w, 0, Math.PI * 2);
          ctx2.stroke();
        }
        for (const b of bots) {
          if (!b.alive) continue;
          const p = project(b.x, b.z);
          ctx2.fillStyle = !hostile(team, b.team) ? "#3ec7c2" : "#e8943a";
          ctx2.fillRect(p.px - 2, p.py - 2, 4, 4);
        }
        const me = project(x, z);
        ctx2.save();
        ctx2.translate(me.px, me.py);
        ctx2.rotate(yaw);
        ctx2.fillStyle = "#e7eef3";
        ctx2.beginPath();
        ctx2.moveTo(0, -5);
        ctx2.lineTo(4, 4);
        ctx2.lineTo(-4, 4);
        ctx2.fill();
        ctx2.restore();
      }
    }
  }

  function scoreboard(): Hud["scoreboard"] {
    const rows: Hud["scoreboard"] = [
      {
        name: profile.name,
        team: team === "ffa" ? "Solo" : team === "zombie" ? "Crew" : team === "steel" ? "Steel" : "Ember",
        kills,
        deaths,
        score: mode === "tdm" ? kills : Math.round(score),
        self: true,
      },
    ];
    for (const b of bots) {
      rows.push({
        name: b.name,
        team: b.team === "ffa" ? "Solo" : b.team === "zombie" ? "Infected" : b.team === "steel" ? "Steel" : "Ember",
        kills: b.kills,
        deaths: b.deaths,
        score: mode === "tdm" ? b.kills : Math.round(b.score || b.kills),
      });
    }
    rows.sort((a, b) => b.score - a.score);
    return rows.slice(0, 10);
  }

  function pushHud() {
    const gun = guns[slot];
    const spec = activeSpec();
    const hud: Hud = {
      phase,
      mode,
      modeName: mode ? modeById(mode).name : "",
      health: Math.ceil(hp),
      armor: Math.ceil(armor),
      weaponName: spec?.name ?? "Unarmed",
      mag: gun?.mag ?? 0,
      reserve: gun?.reserve ?? 0,
      reloading: gun?.reload ?? 0,
      ads,
      spread: gun?.bloom ?? 0,
      slot,
      slots: [guns[0]?.id ?? "", guns[1]?.id ?? ""],
      timer: mode ? Math.max(0, modeById(mode).time - timer) : 0,
      team,
      steel,
      ember,
      kills,
      deaths,
      wave,
      zombiesLeft: bots.filter((b) => b.alive && b.team === "zombie").length + queue.length,
      score: mode === "tdm" ? (team === "steel" ? steel : ember) : Math.round(score),
      goal: mode ? modeById(mode).goal : 0,
      inZone: !!world && Math.hypot(x - world.zone.x, z - world.zone.z) < (world?.zone.r ?? 1),
      feed: feed.slice(),
      scoreboard: scoreboard(),
      banner,
      intermission,
      invuln,
      stim,
      hurt,
      gear: { ...profile.gear },
      result,
      showBoard: boardLatch || touch.board || keyDown("Tab"),
    };
    hooks.onHud(hud);
  }

  function frame(now: number) {
    if (disposed) return;
    raf = requestAnimationFrame(frame);
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    const lookScale = 0.00235 * profile.settings.sensitivity * (ads > 0.5 ? 0.62 : 1);
    const invert = profile.settings.invertY ? -1 : 1;
    const lx = mouseDX + touch.lookX;
    const ly = mouseDY + touch.lookY;
    mouseDX = 0;
    mouseDY = 0;
    touch.lookX = 0;
    touch.lookY = 0;
    if (phase === "live" || phase === "countdown") {
      const touchBoost = widthTouch() ? profile.settings.touch : 1;
      yaw -= lx * lookScale * touchBoost;
      pitch -= ly * lookScale * touchBoost * invert;
      const lim = Math.PI / 2 - 0.08;
      pitch = Math.max(-lim, Math.min(lim, pitch));
    }

    readEdges();
    if (phase === "live" && !alive) simDeath(dt);
    if (phase === "intermission") {
      intermission -= dt;
      banner = `Armory ${Math.ceil(Math.max(0, intermission))}`;
      if (intermission <= 0) startWave(wave + 1);
    }
    simAcc += dt;
    let steps = 0;
    while (simAcc >= 1 / 60 && steps < 4) {
      if (phase !== "pause") sim(1 / 60);
      simAcc -= 1 / 60;
      steps += 1;
    }
    audio?.setVolume(profile.settings.volume);
    render(dt);
    hudAcc += dt;
    if (hudAcc > 0.1) {
      hudAcc = 0;
      pushHud();
    }
    const pos = dust.position;
    void pos;
  }

  function widthTouch() {
    return window.innerWidth < 1024 || window.matchMedia("(pointer: coarse)").matches;
  }

  function resetMatch(nextMode: ModeId, nextTeam: TeamId) {
    clearBots();
    mode = nextMode;
    team = nextMode === "ffa" || nextMode === "king" ? "ffa" : nextMode === "zombie" ? "steel" : nextTeam;
    ended = false;
    result = null;
    kills = 0;
    deaths = 0;
    score = 0;
    steel = 0;
    ember = 0;
    wave = 0;
    timer = 0;
    hp = 100;
    armor = 0;
    alive = true;
    invuln = 1.2;
    stim = 0;
    crouch = false;
    crouchToggle = false;
    feed.splice(0);
    guns = [profile.loadout[0] ? makeGun(profile.loadout[0]) : null, profile.loadout[1] ? makeGun(profile.loadout[1]) : null];
    slot = guns[0] ? 0 : 1;
    showWeapon();
    const spots =
      nextMode === "tdm"
        ? world!.spawns[team === "ember" ? "ember" : "steel"]
        : nextMode === "zombie"
          ? world!.spawns.steel
          : world!.spawns.ffa;
    const spot = spots[0];
    x = spot.x;
    y = spot.y + 0.1;
    z = spot.z;
    yaw = yawToward(x, z, 0, 8);
    pitch = 0;
    vy = 0;
    vx = 0;
    vz = 0;
    if (nextMode === "tdm") {
      const mine = team === "ember" ? "ember" : "steel";
      const other = mine === "steel" ? "ember" : "steel";
      const allies: ActorKind[] = ["rifleman", "grunt", "officer"];
      const foes: ActorKind[] = ["marksman", "breacher", "gunner", "rifleman"];
      allies.forEach((k, i) => spawnKind(k, mine, world!.spawns[mine][i + 1] ?? world!.spawns[mine][0]));
      foes.forEach((k, i) => spawnKind(k, other, world!.spawns[other][i] ?? world!.spawns[other][0]));
    } else if (nextMode === "ffa" || nextMode === "king") {
      const mix: ActorKind[] = ["grunt", "rifleman", "marksman", "breacher", "gunner", "officer", "rifleman"];
      mix.forEach((k, i) => spawnKind(k, "ffa", world!.spawns.ffa[(i + 1) % world!.spawns.ffa.length]));
    }
    const qa = new URLSearchParams(window.location.search).has("qa");
    deadTimer = 0;
    if (qa) {
      phase = "live";
      banner = "Contact";
      if (nextMode === "zombie") startWave(1);
    } else {
      countdown = 2.4;
      phase = "countdown";
      banner = "Deploy";
    }
    if (mannequin) mannequin.root.visible = false;
    pushHud();
  }

  function onKeyDown(e: KeyboardEvent) {
    injectOn = false;
    keys.add(e.code);
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
    if (e.code === "KeyC") crouchToggle = !crouchToggle;
    if (e.code === "Digit1") {
      swapLatch = true;
      swapTo = 0;
    } else if (e.code === "Digit2") {
      swapLatch = true;
      swapTo = 1;
    } else if (e.code === "KeyQ") {
      swapLatch = true;
      swapTo = -1;
    }
    if (e.code === "KeyR") reloadLatch = true;
    if (e.code === "KeyF") medLatch = true;
    if (e.code === "KeyG") plateLatch = true;
    if (e.code === "KeyV") stimLatch = true;
    if (e.code === "Space") jumpLatch = true;
    if (e.code === "Escape" && phase === "live") {
      phase = "pause";
      document.exitPointerLock?.();
      pushHud();
    }
    if (e.code === "Tab") {
      boardLatch = true;
      e.preventDefault();
    }
  }
  function onKeyUp(e: KeyboardEvent) {
    keys.delete(e.code);
    if (e.code === "Tab") boardLatch = false;
  }
  function onMouseDown(e: MouseEvent) {
    if (phase !== "live" && phase !== "countdown") return;
    if (e.button === 0) mouseFire = true;
    if (e.button === 2) mouseAds = true;
  }
  function onMouseUp(e: MouseEvent) {
    if (e.button === 0) mouseFire = false;
    if (e.button === 2) mouseAds = false;
  }
  function onMouseMove(e: MouseEvent) {
    if (!pointerLocked) return;
    mouseDX += e.movementX;
    mouseDY += e.movementY;
  }
  function onLockChange() {
    pointerLocked = document.pointerLockElement === canvas;
    if (!pointerLocked && phase === "live" && !widthTouch()) {
      phase = "pause";
      mouseFire = false;
      pushHud();
    }
  }
  function onPointerDown(e: PointerEvent) {
    audio?.unlock();
    if (phase !== "live" && phase !== "countdown") return;
    if (e.button !== 0) return;
    if (!widthTouch()) {
      canvas.requestPointerLock?.();
    }
    dragging = true;
  }
  function onPointerMove(e: PointerEvent) {
    if (pointerLocked || !dragging) return;
    if (phase !== "live" && phase !== "countdown") return;
    mouseDX += e.movementX;
    mouseDY += e.movementY;
  }
  function onPointerUp() {
    dragging = false;
    if (!pointerLocked) mouseFire = false;
  }
  function onBlur() {
    keys.clear();
    mouseFire = false;
    dragging = false;
  }
  function onContext(e: Event) {
    e.preventDefault();
  }

  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("mousemove", onMouseMove);
  window.addEventListener("mousedown", onMouseDown);
  window.addEventListener("mouseup", onMouseUp);
  window.addEventListener("resize", resize);
  document.addEventListener("pointerlockchange", onLockChange);
  canvas.addEventListener("pointerdown", onPointerDown);
  canvas.addEventListener("pointermove", onPointerMove);
  window.addEventListener("pointerup", onPointerUp);
  window.addEventListener("blur", onBlur);
  canvas.addEventListener("contextmenu", onContext);

  const loopCrouch = () => {
    crouch = crouchToggle || keys.has("ControlLeft") || touch.crouch;
  };
  const crouchTimer = window.setInterval(loopCrouch, 32);

  window.__controlsTest = {
    getYaw: () => yaw,
    getSpeed: () => Math.hypot(vx, vz),
    getPos: () => ({ x, y, z }),
    setKeys: (codes: string[]) => {
      injectOn = true;
      injected.clear();
      codes.forEach((c) => injected.add(c));
      if (codes.includes("Mouse0")) mouseFire = false;
    },
  };
  window.__ironYard = {
    start: (m: ModeId, t?: TeamId) => resetMatch(m, t ?? "steel"),
    phase: () => phase,
    dump: () => ({ hp, kills, bots: bots.filter((b) => b.alive).length, mode, phase, x, y, z, yaw }),
  };

  async function boot() {
    hooks.onProgress(10, "Powering the bay lights");
    await wait(40);
    if (disposed) return;
    world = buildWorld(scene, profile.settings.quality);
    nav = buildNav(world.colliders);
    hooks.onProgress(48, "Setting containers and cover");
    await wait(40);
    if (disposed) return;
    views = buildViewmodels(profile.skin);
    views.models.forEach((model) => rig.add(model.group));
    mannequin = buildActor("rifleman", "steel");
    const prop = buildWorldGun("rifle");
    prop.position.set(0, -0.58, 0.04);
    mannequin.armR.rotation.x = -1.2;
    mannequin.armR.add(prop);
    mannequin.root.position.set(0, 0, 0);
    scene.add(mannequin.root);
    hooks.onProgress(78, "Machining the rack");
    await wait(40);
    if (disposed) return;
    audio = createAudio();
    resize();
    hooks.onProgress(100, "The yard is live");
    phase = "attract";
    hooks.onReady();
    pushHud();
    last = performance.now();
    raf = requestAnimationFrame(frame);
  }
  void boot();

  return {
    start: (next, nextTeam) => {
      if (!world) return;
      audio?.unlock();
      resetMatch(next, nextTeam);
    },
    pause: () => {
      if (phase === "live" || phase === "countdown") {
        phase = "pause";
        document.exitPointerLock?.();
        pushHud();
      }
    },
    resume: () => {
      if (phase === "pause") {
        phase = "live";
        if (!widthTouch()) canvas.requestPointerLock?.();
        pushHud();
      }
    },
    leave: () => {
      document.exitPointerLock?.();
      if ((phase === "live" || phase === "pause" || phase === "countdown" || phase === "intermission") && !ended) {
        endMatch(false, "You left the yard.");
        return;
      }
      clearBots();
      phase = "attract";
      mode = null;
      ended = false;
      result = null;
      rig.visible = false;
      if (mannequin) mannequin.root.visible = true;
      banner = "";
      pushHud();
    },
    skipIntermission: () => {
      if (phase === "intermission") intermission = 0.05;
    },
    refreshLoadout,
    dispose: () => {
      disposed = true;
      cancelAnimationFrame(raf);
      window.clearInterval(crouchTimer);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mousedown", onMouseDown);
      window.removeEventListener("mouseup", onMouseUp);
      window.removeEventListener("resize", resize);
      document.removeEventListener("pointerlockchange", onLockChange);
      canvas.removeEventListener("pointerdown", onPointerDown);
      canvas.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("blur", onBlur);
      canvas.removeEventListener("contextmenu", onContext);
      clearBots();
      world?.disposables.forEach((d) => d.dispose());
      views?.dispose();
      renderer.dispose();
      delete window.__controlsTest;
      delete window.__ironYard;
    },
  };
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      getPos: () => { x: number; y: number; z: number };
      setKeys: (codes: string[]) => void;
    };
    __ironYard?: {
      start: (mode: ModeId, team?: TeamId) => void;
      phase: () => string;
      dump: () => unknown;
    };
  }
}

export type ModeId = "tdm" | "zombie" | "ffa" | "king";

export type TeamId = "steel" | "ember" | "zombie" | "ffa";

export type WeaponId =
  | "sidearm"
  | "compact"
  | "smg"
  | "shotgun"
  | "rifle"
  | "dmr"
  | "lmg"
  | "welder"
  | "lobber";

export type ActorKind =
  | "grunt"
  | "rifleman"
  | "marksman"
  | "breacher"
  | "gunner"
  | "officer"
  | "runner"
  | "brute"
  | "spitter"
  | "screamer"
  | "bloater";

export type UpgradeTrack = "barrel" | "magazine" | "stock";

export type GearId = "medkit" | "plate" | "stim";

export type SkinId = "standard" | "night" | "hazard" | "oxide" | "frost";

export type ShopCategory = "weapon" | "ammo" | "gear" | "upgrade" | "skin";

export type WeaponKind = "hitscan" | "projectile" | "beam";

export type WeaponDef = {
  id: WeaponId;
  name: string;
  clazz: string;
  blurb: string;
  auto: boolean;
  pellets: number;
  damage: number;
  rpm: number;
  mag: number;
  reload: number;
  spread: number;
  spreadMove: number;
  bloom: number;
  bloomMax: number;
  recovery: number;
  recoil: number;
  range: number;
  falloffStart: number;
  falloffEnd: number;
  minMult: number;
  price: number;
  level: number;
  ammoPack: number;
  ammoPrice: number;
  move: number;
  scope: boolean;
  kind: WeaponKind;
  projSpeed: number;
  projGravity: number;
  splash: number;
  sound: "pistol" | "smg" | "rifle" | "shotgun" | "sniper" | "lmg" | "energy" | "thump";
  tracer: number;
};

export type Mods = Record<UpgradeTrack, number>;

export type ShopItem = {
  id: string;
  category: ShopCategory;
  name: string;
  blurb: string;
  price: number;
  level: number;
  weaponId?: WeaponId;
  track?: UpgradeTrack;
  gear?: GearId;
  skin?: SkinId;
  rounds?: number;
};

export type AABB = {
  minX: number;
  minY: number;
  minZ: number;
  maxX: number;
  maxY: number;
  maxZ: number;
};

export type PhysBody = {
  x: number;
  y: number;
  z: number;
  vy: number;
  r: number;
  h: number;
  onGround: boolean;
};

export type PathPoint = { x: number; y: number; z: number };

export type MatchResult = {
  title: string;
  subtitle: string;
  victory: boolean;
  kills: number;
  deaths: number;
  score: number;
  credits: number;
  xp: number;
  wave: number;
  leveled: boolean;
  newLevel: number;
};

export type FeedLine = { id: number; text: string; tone: "kill" | "die" | "info" };

export type BoardRow = {
  name: string;
  team: string;
  kills: number;
  deaths: number;
  score: number;
  self?: boolean;
};

export type Hud = {
  phase: "boot" | "attract" | "countdown" | "live" | "pause" | "intermission" | "results";
  mode: ModeId | null;
  modeName: string;
  health: number;
  armor: number;
  weaponName: string;
  mag: number;
  reserve: number;
  reloading: number;
  ads: number;
  spread: number;
  slot: number;
  slots: [string, string];
  timer: number;
  team: TeamId | null;
  steel: number;
  ember: number;
  kills: number;
  deaths: number;
  wave: number;
  zombiesLeft: number;
  score: number;
  goal: number;
  inZone: boolean;
  feed: FeedLine[];
  scoreboard: BoardRow[];
  banner: string;
  intermission: number;
  invuln: number;
  stim: number;
  hurt: number;
  gear: { medkit: number; plate: number; stim: number };
  result: MatchResult | null;
  showBoard: boolean;
};

export type TouchState = {
  moveX: number;
  moveY: number;
  lookX: number;
  lookY: number;
  fire: boolean;
  ads: boolean;
  jump: boolean;
  sprint: boolean;
  crouch: boolean;
  reload: boolean;
  swap: boolean;
  useMed: boolean;
  usePlate: boolean;
  useStim: boolean;
  board: boolean;
};

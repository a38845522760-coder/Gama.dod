import type {
  ActorKind,
  ModeId,
  Mods,
  ShopItem,
  SkinId,
  WeaponDef,
  WeaponId,
} from "./types";

export const WEAPONS: Record<WeaponId, WeaponDef> = {
  sidearm: {
    id: "sidearm",
    name: "IY-2 Service",
    clazz: "Pistol",
    blurb: "Issued sidearm. Steady, short recoil, reliable when the yard goes quiet.",
    auto: false,
    pellets: 1,
    damage: 28,
    rpm: 380,
    mag: 12,
    reload: 1.35,
    spread: 0.006,
    spreadMove: 0.012,
    bloom: 0.004,
    bloomMax: 0.04,
    recovery: 0.05,
    recoil: 0.012,
    range: 55,
    falloffStart: 18,
    falloffEnd: 48,
    minMult: 0.55,
    price: 0,
    level: 1,
    ammoPack: 36,
    ammoPrice: 80,
    move: 1,
    scope: false,
    kind: "hitscan",
    projSpeed: 0,
    projGravity: 0,
    splash: 0,
    sound: "pistol",
    tracer: 0xf2d2a2,
  },
  compact: {
    id: "compact",
    name: "Yard Compact",
    clazz: "Pistol",
    blurb: "Machine pistol cadence in a sidearm frame. Burns a magazine if you let it.",
    auto: false,
    pellets: 1,
    damage: 18,
    rpm: 560,
    mag: 16,
    reload: 1.25,
    spread: 0.012,
    spreadMove: 0.02,
    bloom: 0.006,
    bloomMax: 0.06,
    recovery: 0.07,
    recoil: 0.009,
    range: 40,
    falloffStart: 12,
    falloffEnd: 36,
    minMult: 0.45,
    price: 450,
    level: 1,
    ammoPack: 48,
    ammoPrice: 90,
    move: 1.02,
    scope: false,
    kind: "hitscan",
    projSpeed: 0,
    projGravity: 0,
    splash: 0,
    sound: "pistol",
    tracer: 0xf0e2c0,
  },
  smg: {
    id: "smg",
    name: "Lane SMG",
    clazz: "Submachine gun",
    blurb: "Close-lane hose. Weak past the containers, vicious inside them.",
    auto: true,
    pellets: 1,
    damage: 13,
    rpm: 920,
    mag: 32,
    reload: 1.65,
    spread: 0.02,
    spreadMove: 0.028,
    bloom: 0.0035,
    bloomMax: 0.07,
    recovery: 0.045,
    recoil: 0.0065,
    range: 36,
    falloffStart: 10,
    falloffEnd: 30,
    minMult: 0.35,
    price: 800,
    level: 1,
    ammoPack: 96,
    ammoPrice: 140,
    move: 1.04,
    scope: false,
    kind: "hitscan",
    projSpeed: 0,
    projGravity: 0,
    splash: 0,
    sound: "smg",
    tracer: 0xffe08a,
  },
  shotgun: {
    id: "shotgun",
    name: "Breaker-12",
    clazz: "Shotgun",
    blurb: "Eight-pellet breach gun. One clean shot ends a runner. Miss, and you are late.",
    auto: false,
    pellets: 8,
    damage: 11,
    rpm: 78,
    mag: 6,
    reload: 2.35,
    spread: 0.075,
    spreadMove: 0.04,
    bloom: 0.01,
    bloomMax: 0.12,
    recovery: 0.08,
    recoil: 0.028,
    range: 18,
    falloffStart: 5,
    falloffEnd: 16,
    minMult: 0.22,
    price: 1100,
    level: 2,
    ammoPack: 18,
    ammoPrice: 160,
    move: 0.96,
    scope: false,
    kind: "hitscan",
    projSpeed: 0,
    projGravity: 0,
    splash: 0,
    sound: "shotgun",
    tracer: 0xffb060,
  },
  rifle: {
    id: "rifle",
    name: "IY-7 Rifle",
    clazz: "Assault rifle",
    blurb: "The yard standard. Controllable burst, honest damage, the gun contracts are written around.",
    auto: true,
    pellets: 1,
    damage: 22,
    rpm: 640,
    mag: 30,
    reload: 1.95,
    spread: 0.008,
    spreadMove: 0.016,
    bloom: 0.0028,
    bloomMax: 0.045,
    recovery: 0.03,
    recoil: 0.0085,
    range: 90,
    falloffStart: 28,
    falloffEnd: 78,
    minMult: 0.55,
    price: 1500,
    level: 2,
    ammoPack: 90,
    ammoPrice: 180,
    move: 1,
    scope: false,
    kind: "hitscan",
    projSpeed: 0,
    projGravity: 0,
    splash: 0,
    sound: "rifle",
    tracer: 0xffd27a,
  },
  dmr: {
    id: "dmr",
    name: "Longshot DMR",
    clazz: "Sniper rifle",
    blurb: "Marksman rifle with a true glass. Still, crouched, and scoped it does not forgive.",
    auto: false,
    pellets: 1,
    damage: 86,
    rpm: 62,
    mag: 8,
    reload: 2.25,
    spread: 0.004,
    spreadMove: 0.03,
    bloom: 0.008,
    bloomMax: 0.05,
    recovery: 0.04,
    recoil: 0.02,
    range: 140,
    falloffStart: 50,
    falloffEnd: 120,
    minMult: 0.82,
    price: 2400,
    level: 4,
    ammoPack: 24,
    ammoPrice: 220,
    move: 0.92,
    scope: true,
    kind: "hitscan",
    projSpeed: 0,
    projGravity: 0,
    splash: 0,
    sound: "sniper",
    tracer: 0xfff2cf,
  },
  lmg: {
    id: "lmg",
    name: "Yard SAW",
    clazz: "Light machine gun",
    blurb: "Belt-fed suppression. You walk slower so the lane stays shut.",
    auto: true,
    pellets: 1,
    damage: 18,
    rpm: 720,
    mag: 80,
    reload: 3.25,
    spread: 0.016,
    spreadMove: 0.02,
    bloom: 0.0022,
    bloomMax: 0.055,
    recovery: 0.02,
    recoil: 0.007,
    range: 80,
    falloffStart: 24,
    falloffEnd: 70,
    minMult: 0.6,
    price: 2800,
    level: 6,
    ammoPack: 160,
    ammoPrice: 260,
    move: 0.8,
    scope: false,
    kind: "hitscan",
    projSpeed: 0,
    projGravity: 0,
    splash: 0,
    sound: "lmg",
    tracer: 0xffc56a,
  },
  welder: {
    id: "welder",
    name: "Arc Welder",
    clazz: "Special",
    blurb: "Yard-cutter turned weapon. A short cyan arc that chews armor if they stay in the spray.",
    auto: true,
    pellets: 1,
    damage: 8,
    rpm: 1100,
    mag: 50,
    reload: 2.15,
    spread: 0.02,
    spreadMove: 0.01,
    bloom: 0.001,
    bloomMax: 0.03,
    recovery: 0.08,
    recoil: 0.002,
    range: 13,
    falloffStart: 4,
    falloffEnd: 13,
    minMult: 0.25,
    price: 3600,
    level: 8,
    ammoPack: 100,
    ammoPrice: 240,
    move: 0.94,
    scope: false,
    kind: "beam",
    projSpeed: 0,
    projGravity: 0,
    splash: 0,
    sound: "energy",
    tracer: 0x7ef0ea,
  },
  lobber: {
    id: "lobber",
    name: "Canister Lobber",
    clazz: "Special",
    blurb: "Lobs a charged scrap canister. Splash clears a pack. Direct hits delete one.",
    auto: false,
    pellets: 1,
    damage: 110,
    rpm: 48,
    mag: 1,
    reload: 1.7,
    spread: 0.01,
    spreadMove: 0.02,
    bloom: 0,
    bloomMax: 0.02,
    recovery: 0.05,
    recoil: 0.03,
    range: 70,
    falloffStart: 40,
    falloffEnd: 70,
    minMult: 1,
    price: 4200,
    level: 10,
    ammoPack: 6,
    ammoPrice: 280,
    move: 0.9,
    scope: false,
    kind: "projectile",
    projSpeed: 24,
    projGravity: 13,
    splash: 4.2,
    sound: "thump",
    tracer: 0xe8943a,
  },
};

export const SKINS: Record<
  SkinId,
  { id: SkinId; name: string; blurb: string; price: number; level: number; metal: number; accent: number }
> = {
  standard: {
    id: "standard",
    name: "Yard Issue",
    blurb: "Stock phosphate and a hazard pin. What the gate issues on day one.",
    price: 0,
    level: 1,
    metal: 0x9aa3ab,
    accent: 0xe8943a,
  },
  night: {
    id: "night",
    name: "Night Shift",
    blurb: "Blacked furniture with a signal-cyan bead. For crews who work the dark bays.",
    price: 600,
    level: 2,
    metal: 0x2a3138,
    accent: 0x3ec7c2,
  },
  hazard: {
    id: "hazard",
    name: "Hazard Cut",
    blurb: "Safety yellow receivers. They see you. That is the point.",
    price: 900,
    level: 3,
    metal: 0xd7a441,
    accent: 0x171b1f,
  },
  oxide: {
    id: "oxide",
    name: "Oxide",
    blurb: "Heat-stained metal pulled off the furnace line.",
    price: 900,
    level: 3,
    metal: 0x8a4b32,
    accent: 0xe7d3bc,
  },
  frost: {
    id: "frost",
    name: "Frost Line",
    blurb: "Pale works-steel with a cold lamp. Contract reward for crews who stay.",
    price: 1400,
    level: 5,
    metal: 0xc5d0d6,
    accent: 0x3ec7c2,
  },
};

export const UPGRADES: { track: "barrel" | "magazine" | "stock"; name: string; blurb: string }[] = [
  { track: "barrel", name: "Barrel", blurb: "+8% damage per tier." },
  { track: "magazine", name: "Magazine", blurb: "+25% capacity per tier." },
  { track: "stock", name: "Stock", blurb: "−12% recoil and spread per tier." },
];

export const UPGRADE_COST = [300, 700, 1400];

export const GEAR = {
  medkit: { name: "Trauma kit", blurb: "Restores 45 health. Use it or carry it (max 5).", price: 100, max: 5 },
  plate: { name: "Armor plate", blurb: "Adds 25 armor, cap 100. Stops most of the next hits.", price: 140, max: 5 },
  stim: { name: "Shift stim", blurb: "Eight seconds of faster movement and handling.", price: 160, max: 3 },
} as const;

export const MODES: {
  id: ModeId;
  name: string;
  time: number;
  goal: number;
  summary: string;
  rules: string;
}[] = [
  {
    id: "tdm",
    name: "Team Deathmatch",
    time: 180,
    goal: 25,
    summary: "Steel versus Ember. Respawn until the score or the clock.",
    rules: "Pick a crew. Allies share your color and will not shoot you. First crew to 25 kills, or the leader when three minutes expire.",
  },
  {
    id: "zombie",
    name: "Zombie Survival",
    time: 0,
    goal: 0,
    summary: "Waves of infected. Buy between waves. Dying ends the shift.",
    rules: "Five infected classes get faster and tougher each wave. Clear a wave, get paid, then the armory opens. No respawns.",
  },
  {
    id: "ffa",
    name: "Free-for-All",
    time: 180,
    goal: 20,
    summary: "No crews. Every gun in the yard is pointed at everyone.",
    rules: "Seven mercenaries, all hostile, including each other. First to 20 kills or the highest count at three minutes.",
  },
  {
    id: "king",
    name: "King of the Yard",
    time: 180,
    goal: 150,
    summary: "Hold the painted circle. Kills help. Presence wins.",
    rules: "The center bay scores 8 points a second while you stand in it. Kills add 6. First to 150, or the leader at the clock.",
  },
];

export const KIND_INFO: Record<
  ActorKind,
  {
    title: string;
    role: string;
    weapon: WeaponId | "melee" | "acid";
    hp: number;
    speed: number;
    acc: number;
    prefer: number;
    aggression: number;
    reaction: number;
    burst: number;
    pause: number;
    melee: number;
    meleeCd: number;
    meleeRange: number;
    aura?: boolean;
    special?: "scream" | "explode";
  }
> = {
  grunt: {
    title: "Grunt",
    role: "Rushes lanes with an SMG and wide, panicked bursts.",
    weapon: "smg",
    hp: 78,
    speed: 5.5,
    acc: 0.4,
    prefer: 8,
    aggression: 0.95,
    reaction: 0.2,
    burst: 10,
    pause: 0.38,
    melee: 0,
    meleeCd: 1,
    meleeRange: 1.4,
  },
  rifleman: {
    title: "Rifleman",
    role: "Holds mid-range, strafes, and falls back to cover when hurt.",
    weapon: "rifle",
    hp: 110,
    speed: 4.6,
    acc: 0.64,
    prefer: 18,
    aggression: 0.5,
    reaction: 0.28,
    burst: 5,
    pause: 0.55,
    melee: 0,
    meleeCd: 1,
    meleeRange: 1.4,
  },
  marksman: {
    title: "Marksman",
    role: "Posts on the dock. One careful shot, then a relocate.",
    weapon: "dmr",
    hp: 84,
    speed: 3.7,
    acc: 0.88,
    prefer: 26,
    aggression: 0.22,
    reaction: 0.42,
    burst: 1,
    pause: 1.15,
    melee: 0,
    meleeCd: 1,
    meleeRange: 1.4,
  },
  breacher: {
    title: "Breacher",
    role: "Closes the gap and dumps a shotgun. Does not respect your cover.",
    weapon: "shotgun",
    hp: 140,
    speed: 5.15,
    acc: 0.52,
    prefer: 5.5,
    aggression: 1,
    reaction: 0.16,
    burst: 2,
    pause: 0.65,
    melee: 0,
    meleeCd: 1,
    meleeRange: 1.5,
  },
  gunner: {
    title: "Gunner",
    role: "Plants the SAW and suppresses. Slow to turn, hard to trade.",
    weapon: "lmg",
    hp: 190,
    speed: 3.25,
    acc: 0.56,
    prefer: 16,
    aggression: 0.38,
    reaction: 0.34,
    burst: 16,
    pause: 0.85,
    melee: 0,
    meleeCd: 1,
    meleeRange: 1.6,
  },
  officer: {
    title: "Officer",
    role: "Hangs behind the crew. Nearby allies hit 15% harder.",
    weapon: "compact",
    hp: 96,
    speed: 4.35,
    acc: 0.72,
    prefer: 14,
    aggression: 0.32,
    reaction: 0.24,
    burst: 3,
    pause: 0.6,
    melee: 0,
    meleeCd: 1,
    meleeRange: 1.4,
    aura: true,
  },
  runner: {
    title: "Runner",
    role: "Fast infected. Zigzags and claws anything living.",
    weapon: "melee",
    hp: 64,
    speed: 6.7,
    acc: 1,
    prefer: 1.1,
    aggression: 1,
    reaction: 0.05,
    burst: 1,
    pause: 0.2,
    melee: 13,
    meleeCd: 0.62,
    meleeRange: 1.5,
  },
  brute: {
    title: "Brute",
    role: "Slow mass. A slam that chunks health and shoves you off line.",
    weapon: "melee",
    hp: 300,
    speed: 3.35,
    acc: 1,
    prefer: 1.5,
    aggression: 1,
    reaction: 0.1,
    burst: 1,
    pause: 0.3,
    melee: 34,
    meleeCd: 1.28,
    meleeRange: 2,
  },
  spitter: {
    title: "Spitter",
    role: "Keeps distance and lobs acid. Do not stand in the splash.",
    weapon: "acid",
    hp: 96,
    speed: 4.15,
    acc: 0.75,
    prefer: 13,
    aggression: 0.4,
    reaction: 0.35,
    burst: 1,
    pause: 0.4,
    melee: 8,
    meleeCd: 1.7,
    meleeRange: 1.4,
  },
  screamer: {
    title: "Screamer",
    role: "Calls a fresh runner into the yard, then tries to keep away.",
    weapon: "melee",
    hp: 86,
    speed: 4.9,
    acc: 1,
    prefer: 11,
    aggression: 0.45,
    reaction: 0.2,
    burst: 1,
    pause: 0.4,
    melee: 11,
    meleeCd: 0.9,
    meleeRange: 1.45,
    special: "scream",
  },
  bloater: {
    title: "Bloater",
    role: "Waddles in and bursts on death. Finish it from outside the radius.",
    weapon: "melee",
    hp: 170,
    speed: 3.5,
    acc: 1,
    prefer: 1.3,
    aggression: 1,
    reaction: 0.1,
    burst: 1,
    pause: 0.3,
    melee: 18,
    meleeCd: 1.05,
    meleeRange: 1.7,
    special: "explode",
  },
};

export const ACHIEVEMENTS: { id: string; name: string; blurb: string }[] = [
  { id: "first_blood", name: "First Blood", blurb: "Confirm a kill in any mode." },
  { id: "team_player", name: "Crew Paid", blurb: "Win a Team Deathmatch." },
  { id: "lone_wolf", name: "Lone Contract", blurb: "Win a Free-for-All." },
  { id: "king", name: "Yard King", blurb: "Win King of the Yard." },
  { id: "survivor", name: "Shift Lead", blurb: "Clear zombie wave 5." },
  { id: "wave_10", name: "Night Shift", blurb: "Clear zombie wave 10." },
  { id: "arsenal", name: "Full Rack", blurb: "Own six weapons." },
  { id: "veteran", name: "Yard Veteran", blurb: "Reach level 5." },
  { id: "untouchable", name: "Clean Bay", blurb: "Finish a match with 8 kills and no deaths." },
  { id: "spender", name: "Quartermaster", blurb: "Spend 5,000 credits in the armory." },
];

export function emptyMods(): Mods {
  return { barrel: 0, magazine: 0, stock: 0 };
}

export function tuned(id: WeaponId, mods: Mods | undefined): WeaponDef {
  const w = { ...WEAPONS[id] };
  const m = mods ?? emptyMods();
  w.damage = +(w.damage * (1 + 0.08 * m.barrel)).toFixed(2);
  w.mag = Math.max(1, Math.round(w.mag * (1 + 0.25 * m.magazine)));
  const stock = 1 - 0.12 * m.stock;
  w.spread *= stock;
  w.recoil *= stock;
  w.bloom *= stock;
  return w;
}

export function shopItems(): ShopItem[] {
  const items: ShopItem[] = [];
  (Object.keys(WEAPONS) as WeaponId[]).forEach((id) => {
    const w = WEAPONS[id];
    items.push({
      id: `w:${id}`,
      category: "weapon",
      name: w.name,
      blurb: w.blurb,
      price: w.price,
      level: w.level,
      weaponId: id,
    });
    items.push({
      id: `a:${id}`,
      category: "ammo",
      name: `${w.name} rounds`,
      blurb: `${w.ammoPack} rounds for the ${w.clazz.toLowerCase()}.`,
      price: w.ammoPrice,
      level: 1,
      weaponId: id,
      rounds: w.ammoPack,
    });
    for (const up of UPGRADES) {
      items.push({
        id: `u:${id}:${up.track}`,
        category: "upgrade",
        name: `${w.name} ${up.name}`,
        blurb: up.blurb,
        price: 0,
        level: w.level,
        weaponId: id,
        track: up.track,
      });
    }
  });
  (Object.keys(GEAR) as (keyof typeof GEAR)[]).forEach((gear) => {
    const g = GEAR[gear];
    items.push({
      id: `g:${gear}`,
      category: "gear",
      name: g.name,
      blurb: g.blurb,
      price: g.price,
      level: 1,
      gear,
    });
  });
  (Object.keys(SKINS) as SkinId[]).forEach((skin) => {
    const s = SKINS[skin];
    items.push({
      id: `s:${skin}`,
      category: "skin",
      name: s.name,
      blurb: s.blurb,
      price: s.price,
      level: s.level,
      skin,
    });
  });
  return items;
}

export const SHOP = shopItems();

export function findShop(id: string): ShopItem | undefined {
  return SHOP.find((s) => s.id === id);
}

export function modeById(id: ModeId) {
  return MODES.find((m) => m.id === id)!;
}

export function xpBand(level: number) {
  return Math.floor(180 * Math.pow(1.22, level - 1));
}

export function levelState(xp: number) {
  let level = 1;
  let rest = xp;
  let need = xpBand(level);
  while (rest >= need && level < 40) {
    rest -= need;
    level += 1;
    need = xpBand(level);
  }
  return { level, into: rest, need };
}

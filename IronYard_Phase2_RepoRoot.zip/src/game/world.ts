import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import type { AABB, PathPoint } from "./types";

function canvasTex(draw: (g: CanvasRenderingContext2D, s: number) => void, repeat = 1) {
  const s = 512;
  const c = document.createElement("canvas");
  c.width = c.height = s;
  const g = c.getContext("2d");
  if (!g) throw new Error("canvas");
  draw(g, s);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  tex.anisotropy = 4;
  return tex;
}

function noise(g: CanvasRenderingContext2D, s: number, n: number, alpha: number) {
  for (let i = 0; i < n; i++) {
    const v = 40 + Math.random() * 80;
    g.fillStyle = `rgba(${v},${v},${v},${alpha})`;
    g.fillRect(Math.random() * s, Math.random() * s, 1 + Math.random() * 3, 1 + Math.random() * 3);
  }
}

export type World = {
  colliders: AABB[];
  spawns: Record<"steel" | "ember" | "ffa" | "zombie", PathPoint[]>;
  zone: { x: number; z: number; r: number };
  fan: THREE.Group;
  beacon: THREE.PointLight;
  ring: THREE.Mesh;
  disposables: { dispose: () => void }[];
};

function boxOf(x: number, y: number, z: number, w: number, h: number, d: number): AABB {
  return {
    minX: x - w / 2,
    maxX: x + w / 2,
    minY: y - h / 2,
    maxY: y + h / 2,
    minZ: z - d / 2,
    maxZ: z + d / 2,
  };
}

export function buildWorld(scene: THREE.Scene, _quality: "performance" | "balanced" | "high" = "balanced"): World {
  const colliders: AABB[] = [];
  const disposables: { dispose: () => void }[] = [];
  const concrete = canvasTex((g, s) => {
    g.fillStyle = "#66706b";
    g.fillRect(0, 0, s, s);
    noise(g, s, 7000, 0.16);
    g.strokeStyle = "rgba(232,148,58,0.9)";
    g.lineWidth = 14;
    g.strokeRect(28, 28, s - 56, s - 56);
    g.strokeStyle = "rgba(255,255,255,0.25)";
    g.lineWidth = 4;
    g.beginPath();
    g.moveTo(s / 2, 0);
    g.lineTo(s / 2, s);
    g.stroke();
  }, 5);
  const corr = canvasTex((g, s) => {
    g.fillStyle = "#7d5a3e";
    g.fillRect(0, 0, s, s);
    for (let x = 0; x < s; x += 12) {
      const v = 90 + Math.sin(x * 0.5) * 50;
      g.fillStyle = `rgb(${v},${v * 0.72},${v * 0.48})`;
      g.fillRect(x, 0, 6, s);
    }
    g.fillStyle = "#1b140f";
    for (let y = 20; y < s; y += 64) for (let x = 18; x < s; x += 40) g.fillRect(x, y, 3, 3);
  });
  const concWall = canvasTex((g, s) => {
    g.fillStyle = "#3c444c";
    g.fillRect(0, 0, s, s);
    noise(g, s, 2500, 0.2);
    g.fillStyle = "rgba(0,0,0,0.25)";
    for (let y = 0; y < s; y += 64) g.fillRect(0, y, s, 3);
  }, 2);
  const hazard = canvasTex((g, s) => {
    g.fillStyle = "#14181c";
    g.fillRect(0, 0, s, s);
    g.fillStyle = "#e8943a";
    for (let i = -s; i < s * 2; i += 40) {
      g.beginPath();
      g.moveTo(i, 0);
      g.lineTo(i + 20, 0);
      g.lineTo(i + s + 20, s);
      g.lineTo(i + s, s);
      g.fill();
    }
  });
  disposables.push(concrete, corr, concWall, hazard);

  const groundMat = new THREE.MeshStandardMaterial({ map: concrete, roughness: 0.94, metalness: 0.03 });
  const wallMat = new THREE.MeshStandardMaterial({ map: concWall, roughness: 0.84, metalness: 0.06 });
  const boxMat = new THREE.MeshStandardMaterial({ map: corr, roughness: 0.58, metalness: 0.46 });
  const steel = new THREE.MeshStandardMaterial({ color: 0x9aa3ab, roughness: 0.38, metalness: 0.74 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x23282e, roughness: 0.55, metalness: 0.4 });
  const hazardMat = new THREE.MeshStandardMaterial({ map: hazard, roughness: 0.55, metalness: 0.18 });
  const lampMat = new THREE.MeshStandardMaterial({
    color: 0xffe2b8,
    emissive: 0xffb15a,
    emissiveIntensity: 1.2,
    roughness: 0.35,
  });
  const cyanMat = new THREE.MeshStandardMaterial({
    color: 0x143836,
    emissive: 0x3ec7c2,
    emissiveIntensity: 0.7,
    roughness: 0.3,
  });
  for (const m of [groundMat, wallMat, boxMat, steel, dark, hazardMat, lampMat, cyanMat]) disposables.push(m);

  const ground = new THREE.Mesh(new THREE.PlaneGeometry(80, 80), groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);

  const put = (mesh: THREE.Mesh, x: number, y: number, z: number, collide?: AABB) => {
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    scene.add(mesh);
    if (collide) colliders.push(collide);
    return mesh;
  };

  const solid = (w: number, h: number, d: number, material: THREE.Material, x: number, y: number, z: number) => {
    const geo = new THREE.BoxGeometry(w, h, d);
    disposables.push(geo);
    put(new THREE.Mesh(geo, material), x, y, z, boxOf(x, y, z, w, h, d));
  };

  solid(68, 5.5, 1.2, wallMat, 0, 2.75, -33);
  solid(68, 5.5, 1.2, wallMat, 0, 2.75, 33);
  solid(1.2, 5.5, 64, wallMat, -33, 2.75, 0);
  solid(1.2, 5.5, 64, wallMat, 33, 2.75, 0);

  // Warehouse shell with a south door.
  solid(30, 5.6, 0.5, wallMat, 0, 2.8, -28);
  solid(0.5, 5.6, 14, wallMat, -15, 2.8, -21);
  solid(0.5, 5.6, 14, wallMat, 15, 2.8, -21);
  solid(10, 5.6, 0.5, wallMat, -9.5, 2.8, -14);
  solid(10, 5.6, 0.5, wallMat, 9.5, 2.8, -14);
  solid(8, 2.2, 0.5, wallMat, 0, 4.5, -14);

  // Dock
  solid(14, 3, 16, dark, 22, 1.5, 4);
  for (let i = 0; i < 8; i++) {
    const top = (i + 1) * 0.375;
    solid(3.2, top, 0.72, steel, 13.4, top / 2, 1.2 + i * 0.74);
  }

  // Containers
  const spots: [number, number, number][] = [
    [-24, 1.3, -6],
    [-24, 1.3, 2],
    [-24, 1.3, 10],
    [-20, 1.3, -18],
    [-26, 1.3, 18],
    [-24, 3.9, 2],
  ];
  const cgeo = new RoundedBoxGeometry(2.5, 2.6, 6.05, 2, 0.06);
  disposables.push(cgeo);
  for (const [x, y, z] of spots) {
    const mesh = new THREE.Mesh(cgeo, boxMat);
    mesh.rotation.y = Math.abs(x + 22) < 0.1 && y > 3 ? 0.04 : 0;
    put(mesh, x, y, z, boxOf(x, y, z, 2.5, 2.6, 6.05));
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(2.52, 0.28, 6.08), hazardMat);
    stripe.position.set(x, y + 0.7, z);
    stripe.castShadow = true;
    scene.add(stripe);
  }

  // Cover barriers
  const barriers: [number, number][] = [
    [-4, 2],
    [3, -2],
    [-2, 8],
    [6, 6],
    [0, -8],
    [8, -10],
    [-8, -4],
  ];
  const bgeo = new RoundedBoxGeometry(2.4, 1.15, 0.45, 2, 0.05);
  disposables.push(bgeo);
  for (const [x, z] of barriers) {
    const mesh = new THREE.Mesh(bgeo, Math.random() > 0.5 ? hazardMat : steel);
    mesh.rotation.y = Math.random() * 0.4 - 0.2;
    put(mesh, x, 0.58, z, boxOf(x, 0.58, z, 2.2, 1.15, 0.7));
  }

  // Barrels
  const barrel = new THREE.CylinderGeometry(0.38, 0.38, 0.9, 10);
  disposables.push(barrel);
  const barrelSpots = [
    [-6, 4],
    [-5.3, 4.5],
    [10, 12],
    [10.6, 12.4],
    [-12, -12],
    [4, 16],
    [-8, 16],
  ];
  for (const [x, z] of barrelSpots) {
    put(new THREE.Mesh(barrel, dark), x, 0.45, z, boxOf(x, 0.45, z, 0.76, 0.9, 0.76));
  }

  // Truck
  solid(2.3, 1.5, 5.2, dark, -8, 1.35, 20);
  solid(2.5, 1.3, 2.1, steel, -8, 1.55, 23.2);
  const wheel = new THREE.CylinderGeometry(0.38, 0.38, 0.28, 10);
  disposables.push(wheel);
  for (const [wx, wz] of [
    [-9.1, 18.2],
    [-6.9, 18.2],
    [-9.1, 21.6],
    [-6.9, 21.6],
  ] as [number, number][]) {
    const m = new THREE.Mesh(wheel, dark);
    m.rotation.z = Math.PI / 2;
    put(m, wx, 0.38, wz);
  }

  // Light poles
  const poles: [number, number][] = [
    [-28, -28],
    [28, -28],
    [-28, 28],
    [28, 28],
    [0, -12],
  ];
  for (const [x, z] of poles) {
    solid(0.18, 6.2, 0.18, steel, x, 3.1, z);
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.18, 0.35), lampMat);
    head.position.set(x, 6.2, z);
    scene.add(head);
  }

  const beacon = new THREE.PointLight(0xffb15a, 6, 22, 2);
  beacon.position.set(0, 5.2, -12);
  scene.add(beacon);

  // Pipes along warehouse
  const curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-16, 4.6, -27.6),
    new THREE.Vector3(-6, 5.1, -27.6),
    new THREE.Vector3(6, 4.7, -27.6),
    new THREE.Vector3(16, 5, -27.6),
  ]);
  const pipe = new THREE.Mesh(new THREE.TubeGeometry(curve, 20, 0.12, 6, false), steel);
  pipe.castShadow = true;
  scene.add(pipe);

  // Fan
  const fan = new THREE.Group();
  fan.position.set(-15.2, 3.4, -20);
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.2, 8), dark);
  hub.rotation.x = Math.PI / 2;
  fan.add(hub);
  for (let i = 0; i < 4; i++) {
    const blade = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.9, 0.04), steel);
    blade.position.y = 0.55;
    const pivot = new THREE.Group();
    pivot.rotation.z = (i * Math.PI) / 2;
    pivot.add(blade);
    fan.add(pivot);
  }
  scene.add(fan);

  // Sign
  const signCanvas = document.createElement("canvas");
  signCanvas.width = 512;
  signCanvas.height = 256;
  const sg = signCanvas.getContext("2d");
  if (sg) {
    sg.fillStyle = "#14181c";
    sg.fillRect(0, 0, 512, 256);
    sg.fillStyle = "#e8943a";
    sg.fillRect(0, 0, 512, 10);
    sg.fillRect(0, 246, 512, 10);
    sg.fillStyle = "#e7eef3";
    sg.font = "700 84px Rajdhani, sans-serif";
    sg.fillText("IRON YARD", 36, 120);
    sg.fillStyle = "#3ec7c2";
    sg.font = "600 32px Rajdhani, sans-serif";
    sg.fillText("BAY 04  ·  CREWS ONLY", 40, 180);
  }
  const signTex = new THREE.CanvasTexture(signCanvas);
  signTex.colorSpace = THREE.SRGBColorSpace;
  disposables.push(signTex);
  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(6.2, 3.1),
    new THREE.MeshStandardMaterial({ map: signTex, roughness: 0.6, metalness: 0.2 }),
  );
  sign.position.set(0, 3.3, -27.7);
  scene.add(sign);

  // Zone ring
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(6.2, 7.2, 48),
    new THREE.MeshBasicMaterial({ color: 0xe8943a, transparent: true, opacity: 0.55, side: THREE.DoubleSide }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.04;
  scene.add(ring);
  const zoneDisc = new THREE.Mesh(
    new THREE.CircleGeometry(6.2, 40),
    new THREE.MeshBasicMaterial({ color: 0xe8943a, transparent: true, opacity: 0.08, side: THREE.DoubleSide }),
  );
  zoneDisc.rotation.x = -Math.PI / 2;
  zoneDisc.position.y = 0.03;
  scene.add(zoneDisc);

  // Crane silhouette beyond the north wall (visual only)
  solid(0.4, 10, 0.4, dark, -20, 5, -36);
  const boom = new THREE.Mesh(new THREE.BoxGeometry(16, 0.28, 0.28), steel);
  boom.position.set(-12, 10, -36);
  scene.add(boom);

  // Cyan guide lamps on the dock edge
  for (const z of [-2, 4, 10]) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.5, 0.2), cyanMat);
    m.position.set(15.2, 3.3, z);
    scene.add(m);
  }

  const spawns: World["spawns"] = {
    steel: [
      { x: 0, y: 0, z: 24 },
      { x: -6, y: 0, z: 22 },
      { x: 6, y: 0, z: 22 },
      { x: 2, y: 0, z: 27 },
    ],
    ember: [
      { x: 0, y: 0, z: -8 },
      { x: -8, y: 0, z: -6 },
      { x: 8, y: 0, z: -6 },
      { x: 22, y: 3, z: 4 },
    ],
    ffa: [
      { x: 0, y: 0, z: 24 },
      { x: -24, y: 0, z: -16 },
      { x: 10, y: 0, z: -20 },
      { x: 22, y: 3, z: 8 },
      { x: -10, y: 0, z: 12 },
      { x: 12, y: 0, z: 18 },
      { x: -18, y: 0, z: 20 },
      { x: 0, y: 0, z: -10 },
    ],
    zombie: [
      { x: -16, y: 0, z: -6 },
      { x: 8, y: 0, z: -18 },
      { x: 20, y: 0, z: -8 },
      { x: -8, y: 0, z: 8 },
      { x: 14, y: 0, z: 10 },
      { x: -22, y: 0, z: 6 },
      { x: 0, y: 0, z: -16 },
      { x: 24, y: 3, z: 2 },
    ],
  };

  return {
    colliders,
    spawns,
    zone: { x: 0, z: 0, r: 7 },
    fan,
    beacon,
    ring,
    disposables,
  };
}

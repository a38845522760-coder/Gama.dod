import {
  ACHIEVEMENTS,
  emptyMods,
  findShop,
  GEAR,
  levelState,
  SKINS,
  UPGRADE_COST,
  WEAPONS,
} from "./catalog";
import type { GearId, ModeId, Mods, SkinId, WeaponId } from "./types";

export type Settings = {
  sensitivity: number;
  touch: number;
  fov: number;
  volume: number;
  invertY: boolean;
  quality: "performance" | "balanced" | "high";
  leftHand: boolean;
};

export type HistoryRow = {
  id: number;
  at: number;
  mode: ModeId;
  result: string;
  victory: boolean;
  kills: number;
  deaths: number;
  score: number;
  credits: number;
  xp: number;
  wave: number;
};

export type Challenge = {
  id: "kills" | "wins" | "waves" | "damage" | "purchases";
  name: string;
  goal: number;
  progress: number;
  claimed: boolean;
};

export type SaveData = {
  version: 1;
  name: string;
  credits: number;
  spent: number;
  xp: number;
  owned: WeaponId[];
  mods: Partial<Record<WeaponId, Mods>>;
  ammo: Partial<Record<WeaponId, number>>;
  loadout: [WeaponId | "", WeaponId | ""];
  gear: Record<GearId, number>;
  skins: SkinId[];
  skin: SkinId;
  stats: {
    kills: number;
    deaths: number;
    wins: number;
    matches: number;
    headshots: number;
    damage: number;
    bestWave: number;
    weaponKills: Partial<Record<WeaponId, number>>;
  };
  wins: Partial<Record<ModeId, number>>;
  achievements: Record<string, boolean>;
  challenges: { date: string; items: Challenge[] };
  history: HistoryRow[];
  settings: Settings;
  cleanFlag: boolean;
};

const KEY = "iron-yard-profile-v1";
const listeners = new Set<() => void>();

function today() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
}

const CHALLENGE_POOL: Omit<Challenge, "progress" | "claimed">[] = [
  { id: "kills", name: "Confirm 12 kills", goal: 12 },
  { id: "kills", name: "Confirm 25 kills", goal: 25 },
  { id: "wins", name: "Win a match", goal: 1 },
  { id: "waves", name: "Clear 4 zombie waves", goal: 4 },
  { id: "waves", name: "Clear 8 zombie waves", goal: 8 },
  { id: "damage", name: "Deal 700 damage", goal: 700 },
  { id: "damage", name: "Deal 1500 damage", goal: 1500 },
  { id: "purchases", name: "Buy from the armory", goal: 1 },
  { id: "purchases", name: "Make 3 armory purchases", goal: 3 },
];

function rollChallenges(date: string): Challenge[] {
  const start = hash(date) % CHALLENGE_POOL.length;
  const picked: Challenge[] = [];
  const used = new Set<string>();
  for (let i = 0; i < CHALLENGE_POOL.length && picked.length < 3; i++) {
    const src = CHALLENGE_POOL[(start + i * 3) % CHALLENGE_POOL.length];
    const key = `${src.id}:${src.goal}`;
    if (used.has(key)) continue;
    used.add(key);
    picked.push({ ...src, progress: 0, claimed: false });
  }
  return picked;
}

export function defaultSave(): SaveData {
  return {
    version: 1,
    name: "Yardhand",
    credits: 1600,
    spent: 0,
    xp: 0,
    owned: ["sidearm"],
    mods: {},
    ammo: { sidearm: 96 },
    loadout: ["sidearm", ""],
    gear: { medkit: 1, plate: 0, stim: 0 },
    skins: ["standard"],
    skin: "standard",
    stats: {
      kills: 0,
      deaths: 0,
      wins: 0,
      matches: 0,
      headshots: 0,
      damage: 0,
      bestWave: 0,
      weaponKills: {},
    },
    wins: {},
    achievements: {},
    challenges: { date: today(), items: rollChallenges(today()) },
    history: [],
    settings: {
      sensitivity: 1,
      touch: 1.25,
      fov: 78,
      volume: 0.7,
      invertY: false,
      quality: "balanced",
      leftHand: false,
    },
    cleanFlag: false,
  };
}

function merge(raw: Partial<SaveData> | null): SaveData {
  const base = defaultSave();
  if (!raw || raw.version !== 1) return base;
  return {
    ...base,
    ...raw,
    mods: { ...base.mods, ...raw.mods },
    ammo: { ...base.ammo, ...raw.ammo },
    gear: { ...base.gear, ...raw.gear },
    stats: { ...base.stats, ...raw.stats, weaponKills: { ...base.stats.weaponKills, ...raw.stats?.weaponKills } },
    wins: { ...base.wins, ...raw.wins },
    achievements: { ...base.achievements, ...raw.achievements },
    settings: { ...base.settings, ...raw.settings },
    loadout: raw.loadout?.length === 2 ? raw.loadout : base.loadout,
    challenges: raw.challenges?.date ? raw.challenges : base.challenges,
    history: Array.isArray(raw.history) ? raw.history.slice(0, 12) : [],
  };
}

function load(): SaveData {
  try {
    if (typeof localStorage === "undefined") return defaultSave();
    const data = merge(JSON.parse(localStorage.getItem(KEY) || "null"));
    refreshChallenges(data);
    return data;
  } catch {
    return defaultSave();
  }
}

function refreshChallenges(data: SaveData) {
  const date = today();
  if (data.challenges.date !== date) {
    data.challenges = { date, items: rollChallenges(date) };
  }
}

export const profile = load();

export function subscribe(fn: () => void) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function commit() {
  refreshChallenges(profile);
  try {
    localStorage.setItem(KEY, JSON.stringify(profile));
  } catch {
    /* private mode */
  }
  evaluate();
  listeners.forEach((fn) => fn());
}

export function playerLevel() {
  return levelState(profile.xp);
}

export function modsFor(id: WeaponId): Mods {
  return { ...emptyMods(), ...profile.mods[id] };
}

export function bump(id: Challenge["id"], amount: number) {
  refreshChallenges(profile);
  for (const c of profile.challenges.items) {
    if (c.id === id && !c.claimed) c.progress = Math.min(c.goal, c.progress + amount);
  }
}

export function claimChallenge(index: number) {
  const c = profile.challenges.items[index];
  if (!c || c.claimed || c.progress < c.goal) return false;
  c.claimed = true;
  profile.credits += 180;
  profile.xp += 60;
  commit();
  return true;
}

export type BuyResult = { ok: boolean; reason: string };

export function tryBuy(id: string): BuyResult {
  const item = findShop(id);
  if (!item) return { ok: false, reason: "Unknown item." };
  const level = playerLevel().level;
  if (level < item.level) return { ok: false, reason: `Requires level ${item.level}.` };

  if (item.category === "weapon" && item.weaponId) {
    if (profile.owned.includes(item.weaponId)) return { ok: false, reason: "Already in the rack." };
    if (item.price > 0 && profile.credits < item.price) return { ok: false, reason: "Not enough credits." };
    profile.credits -= item.price;
    profile.spent += item.price;
    profile.owned.push(item.weaponId);
    const w = WEAPONS[item.weaponId];
    profile.ammo[item.weaponId] = (profile.ammo[item.weaponId] ?? 0) + w.mag * 3;
    if (!profile.loadout[1]) profile.loadout[1] = item.weaponId;
    bump("purchases", 1);
    commit();
    return { ok: true, reason: `${w.name} added to the rack.` };
  }

  if (item.category === "ammo" && item.weaponId && item.rounds) {
    if (!profile.owned.includes(item.weaponId)) return { ok: false, reason: "Buy the weapon first." };
    if (profile.credits < item.price) return { ok: false, reason: "Not enough credits." };
    profile.credits -= item.price;
    profile.spent += item.price;
    profile.ammo[item.weaponId] = (profile.ammo[item.weaponId] ?? 0) + item.rounds;
    bump("purchases", 1);
    commit();
    return { ok: true, reason: `+${item.rounds} rounds.` };
  }

  if (item.category === "gear" && item.gear) {
    const spec = GEAR[item.gear];
    if (profile.gear[item.gear] >= spec.max) return { ok: false, reason: "Carrying the maximum." };
    if (profile.credits < item.price) return { ok: false, reason: "Not enough credits." };
    profile.credits -= item.price;
    profile.spent += item.price;
    profile.gear[item.gear] += 1;
    bump("purchases", 1);
    commit();
    return { ok: true, reason: `${spec.name} packed.` };
  }

  if (item.category === "upgrade" && item.weaponId && item.track) {
    if (!profile.owned.includes(item.weaponId)) return { ok: false, reason: "Own the weapon first." };
    const mods = modsFor(item.weaponId);
    const tier = mods[item.track];
    if (tier >= 3) return { ok: false, reason: "That track is maxed." };
    const price = UPGRADE_COST[tier];
    if (profile.credits < price) return { ok: false, reason: `Tier ${tier + 1} costs ${price}.` };
    profile.credits -= price;
    profile.spent += price;
    mods[item.track] = tier + 1;
    profile.mods[item.weaponId] = mods;
    bump("purchases", 1);
    commit();
    return { ok: true, reason: `${WEAPONS[item.weaponId].name} upgraded.` };
  }

  if (item.category === "skin" && item.skin) {
    if (profile.skins.includes(item.skin)) {
      profile.skin = item.skin;
      commit();
      return { ok: true, reason: `${SKINS[item.skin].name} equipped.` };
    }
    if (profile.credits < item.price) return { ok: false, reason: "Not enough credits." };
    profile.credits -= item.price;
    profile.spent += item.price;
    profile.skins.push(item.skin);
    profile.skin = item.skin;
    bump("purchases", 1);
    commit();
    return { ok: true, reason: `${SKINS[item.skin].name} equipped.` };
  }

  return { ok: false, reason: "Cannot buy that." };
}

export function equip(slot: 0 | 1, id: WeaponId) {
  if (!profile.owned.includes(id)) return false;
  const other = slot === 0 ? 1 : 0;
  if (profile.loadout[other] === id) profile.loadout[other] = profile.loadout[slot];
  profile.loadout[slot] = id;
  commit();
  return true;
}

export function setName(name: string) {
  const clean = name.replace(/\s+/g, " ").trim().slice(0, 16);
  if (!clean) return;
  profile.name = clean;
  commit();
}

export function patchSettings(partial: Partial<Settings>) {
  Object.assign(profile.settings, partial);
  commit();
}

function evaluate() {
  const lv = playerLevel().level;
  const unlock = (id: string, ok: boolean) => {
    if (ok && !profile.achievements[id]) {
      profile.achievements[id] = true;
      return true;
    }
    return false;
  };
  let changed = false;
  changed = unlock("first_blood", profile.stats.kills >= 1) || changed;
  changed = unlock("team_player", (profile.wins.tdm ?? 0) >= 1) || changed;
  changed = unlock("lone_wolf", (profile.wins.ffa ?? 0) >= 1) || changed;
  changed = unlock("king", (profile.wins.king ?? 0) >= 1) || changed;
  changed = unlock("survivor", profile.stats.bestWave >= 5) || changed;
  changed = unlock("wave_10", profile.stats.bestWave >= 10) || changed;
  changed = unlock("arsenal", profile.owned.length >= 6) || changed;
  changed = unlock("veteran", lv >= 5) || changed;
  changed = unlock("untouchable", profile.cleanFlag) || changed;
  changed = unlock("spender", profile.spent >= 5000) || changed;
  if (changed) {
    try {
      localStorage.setItem(KEY, JSON.stringify(profile));
    } catch {
      /* ignore */
    }
  }
}

export function recordMatch(row: Omit<HistoryRow, "id" | "at"> & { bestWave?: number }) {
  const before = playerLevel().level;
  profile.xp += row.xp;
  profile.credits += row.credits;
  profile.stats.kills += row.kills;
  profile.stats.deaths += row.deaths;
  profile.stats.matches += 1;
  if (row.victory) {
    profile.stats.wins += 1;
    profile.wins[row.mode] = (profile.wins[row.mode] ?? 0) + 1;
    bump("wins", 1);
  }
  if (row.wave > profile.stats.bestWave) profile.stats.bestWave = row.wave;
  if (row.kills >= 8 && row.deaths === 0) profile.cleanFlag = true;
  profile.history.unshift({
    id: Date.now(),
    at: Date.now(),
    mode: row.mode,
    result: row.result,
    victory: row.victory,
    kills: row.kills,
    deaths: row.deaths,
    score: row.score,
    credits: row.credits,
    xp: row.xp,
    wave: row.wave,
  });
  profile.history = profile.history.slice(0, 12);
  commit();
  const after = playerLevel().level;
  return { leveled: after > before, newLevel: after };
}

export function noteCombat(kills: number, headshot: boolean, damage: number, weapon?: WeaponId) {
  if (kills) {
    profile.stats.kills += 0;
    bump("kills", kills);
  }
  if (headshot) profile.stats.headshots += 1;
  if (damage > 0) {
    profile.stats.damage += damage;
    bump("damage", damage);
  }
  if (weapon && kills) {
    profile.stats.weaponKills[weapon] = (profile.stats.weaponKills[weapon] ?? 0) + kills;
  }
}

export const achievementList = ACHIEVEMENTS;

export function resetProfile() {
  const fresh = defaultSave();
  Object.assign(profile, fresh);
  profile.mods = {};
  profile.ammo = { sidearm: 96 };
  profile.gear = { medkit: 1, plate: 0, stim: 0 };
  profile.stats = fresh.stats;
  profile.history = [];
  profile.achievements = {};
  profile.challenges = fresh.challenges;
  commit();
}

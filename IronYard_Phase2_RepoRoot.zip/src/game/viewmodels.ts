import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import { SKINS } from "./catalog";
import type { SkinId, WeaponId } from "./types";

export type ViewWeapon = {
  id: WeaponId;
  group: THREE.Group;
  metal: THREE.MeshStandardMaterial;
  accent: THREE.MeshStandardMaterial;
  muzzle: THREE.Object3D;
};

function paint(metalHex: number, accentHex: number) {
  const metal = new THREE.MeshStandardMaterial({ color: metalHex, roughness: 0.38, metalness: 0.78 });
  const accent = new THREE.MeshStandardMaterial({ color: accentHex, roughness: 0.42, metalness: 0.45 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x171b20, roughness: 0.5, metalness: 0.55 });
  const wood = new THREE.MeshStandardMaterial({ color: 0x6d4a30, roughness: 0.82, metalness: 0.04 });
  const glow = new THREE.MeshStandardMaterial({
    color: 0x9ff7f3,
    emissive: 0x3ec7c2,
    emissiveIntensity: 0.8,
    roughness: 0.3,
  });
  return { metal, accent, dark, wood, glow };
}

export function buildViewmodels(skin: SkinId) {
  const s = SKINS[skin];
  const lib = paint(s.metal, s.accent);
  const geos = {
    slide: new RoundedBoxGeometry(0.045, 0.055, 0.2, 2, 0.01),
    grip: new RoundedBoxGeometry(0.04, 0.12, 0.05, 2, 0.012),
    barrel: new THREE.CylinderGeometry(0.012, 0.012, 0.18, 8),
    body: new RoundedBoxGeometry(0.07, 0.09, 0.36, 2, 0.012),
    mag: new RoundedBoxGeometry(0.04, 0.14, 0.05, 2, 0.008),
    tube: new THREE.CylinderGeometry(0.014, 0.016, 0.42, 8),
    scope: new THREE.CylinderGeometry(0.022, 0.022, 0.18, 10),
    hand: new RoundedBoxGeometry(0.06, 0.05, 0.08, 2, 0.015),
  };

  function finish(group: THREE.Group, muzzleZ: number): { group: THREE.Group; muzzle: THREE.Object3D } {
    const muzzle = new THREE.Object3D();
    muzzle.position.set(0, 0.02, muzzleZ);
    group.add(muzzle);
    group.traverse((obj) => {
      obj.layers.set(1);
    });
    return { group, muzzle };
  }

  function add(group: THREE.Group, geo: THREE.BufferGeometry, material: THREE.Material, x: number, y: number, z: number, rx = 0) {
    const m = new THREE.Mesh(geo, material);
    m.position.set(x, y, z);
    m.rotation.x = rx;
    m.layers.set(1);
    group.add(m);
    return m;
  }

  const models = new Map<WeaponId, ViewWeapon>();

  const make = (id: WeaponId, muzzleZ: number, build: (g: THREE.Group) => void) => {
    const group = new THREE.Group();
    build(group);
    add(group, geos.hand, lib.dark, 0.02, -0.06, -0.12);
    const packed = finish(group, muzzleZ);
    packed.group.visible = false;
    models.set(id, { id, group: packed.group, metal: lib.metal, accent: lib.accent, muzzle: packed.muzzle });
  };

  make("sidearm", -0.42, (g) => {
    add(g, geos.grip, lib.dark, 0, -0.08, -0.16);
    add(g, geos.slide, lib.metal, 0, 0.01, -0.24);
    add(g, geos.barrel, lib.metal, 0, 0.015, -0.36, Math.PI / 2);
    add(g, new RoundedBoxGeometry(0.05, 0.02, 0.08, 2, 0.005), lib.accent, 0, 0.04, -0.2);
  });
  make("compact", -0.4, (g) => {
    add(g, geos.grip, lib.dark, 0, -0.07, -0.14);
    add(g, new RoundedBoxGeometry(0.05, 0.06, 0.16, 2, 0.01), lib.metal, 0, 0.01, -0.22);
    add(g, geos.barrel, lib.dark, 0, 0.01, -0.32, Math.PI / 2);
  });
  make("smg", -0.62, (g) => {
    add(g, geos.body, lib.dark, 0, 0, -0.28);
    add(g, geos.mag, lib.metal, 0, -0.12, -0.24);
    add(g, geos.tube, lib.metal, 0, 0.035, -0.42, Math.PI / 2);
    add(g, new RoundedBoxGeometry(0.05, 0.08, 0.1, 2, 0.01), lib.accent, 0, -0.02, -0.12);
  });
  make("shotgun", -0.78, (g) => {
    add(g, new RoundedBoxGeometry(0.07, 0.08, 0.34, 2, 0.012), lib.wood ?? lib.dark, 0, -0.01, -0.18);
    add(g, new THREE.CylinderGeometry(0.018, 0.02, 0.48, 8), lib.metal, 0, 0.03, -0.48, Math.PI / 2);
    add(g, new THREE.CylinderGeometry(0.012, 0.012, 0.46, 8), lib.dark, 0.028, 0.03, -0.46, Math.PI / 2);
    add(g, new RoundedBoxGeometry(0.06, 0.04, 0.1, 2, 0.01), lib.wood ?? lib.accent, 0, -0.02, -0.34);
  });
  make("rifle", -0.86, (g) => {
    add(g, new RoundedBoxGeometry(0.065, 0.09, 0.46, 2, 0.012), lib.dark, 0, 0, -0.28);
    add(g, geos.mag, lib.metal, 0, -0.1, -0.22);
    add(g, new THREE.CylinderGeometry(0.013, 0.014, 0.5, 8), lib.metal, 0, 0.04, -0.58, Math.PI / 2);
    add(g, new RoundedBoxGeometry(0.02, 0.06, 0.02, 1, 0.004), lib.accent, 0, 0.09, -0.42);
    add(g, new RoundedBoxGeometry(0.07, 0.08, 0.16, 2, 0.012), lib.dark, 0, -0.01, -0.08);
  });
  make("dmr", -1.05, (g) => {
    add(g, new RoundedBoxGeometry(0.06, 0.08, 0.62, 2, 0.01), lib.dark, 0, 0, -0.32);
    add(g, new THREE.CylinderGeometry(0.012, 0.014, 0.62, 8), lib.metal, 0, 0.035, -0.7, Math.PI / 2);
    add(g, geos.scope, lib.dark, 0, 0.09, -0.34, Math.PI / 2);
    add(g, new THREE.CylinderGeometry(0.02, 0.02, 0.04, 8), lib.glow, 0, 0.09, -0.22, Math.PI / 2);
    add(g, geos.mag, lib.metal, 0, -0.08, -0.24);
  });
  make("lmg", -0.95, (g) => {
    add(g, new RoundedBoxGeometry(0.09, 0.12, 0.5, 2, 0.014), lib.dark, 0, 0, -0.28);
    add(g, new THREE.CylinderGeometry(0.016, 0.018, 0.58, 8), lib.metal, 0, 0.05, -0.62, Math.PI / 2);
    add(g, new RoundedBoxGeometry(0.1, 0.16, 0.14, 2, 0.01), lib.metal, 0, -0.12, -0.2);
    add(g, new THREE.CylinderGeometry(0.008, 0.008, 0.16, 5), lib.accent, -0.04, -0.02, -0.7);
    add(g, new THREE.CylinderGeometry(0.008, 0.008, 0.16, 5), lib.accent, 0.04, -0.02, -0.7);
  });
  make("welder", -0.58, (g) => {
    add(g, new RoundedBoxGeometry(0.1, 0.12, 0.28, 3, 0.02), lib.metal, 0, 0, -0.22);
    add(g, new THREE.TorusGeometry(0.05, 0.012, 6, 10), lib.glow, 0, 0.02, -0.36);
    add(g, new THREE.CylinderGeometry(0.03, 0.05, 0.12, 8), lib.dark, 0, 0.01, -0.46, Math.PI / 2);
    add(g, new THREE.CylinderGeometry(0.04, 0.04, 0.16, 8), lib.accent, 0.08, -0.02, -0.16, Math.PI / 2);
  });
  make("lobber", -0.7, (g) => {
    add(g, new THREE.CylinderGeometry(0.05, 0.06, 0.36, 10), lib.metal, 0, 0.02, -0.4, Math.PI / 2);
    add(g, new THREE.CylinderGeometry(0.07, 0.07, 0.12, 10), lib.dark, 0, -0.02, -0.28, Math.PI / 2);
    add(g, new RoundedBoxGeometry(0.08, 0.1, 0.16, 2, 0.015), lib.accent, 0, -0.06, -0.16);
    add(g, new THREE.SphereGeometry(0.045, 8, 6), lib.glow, 0, 0.02, -0.58);
  });

  // wood alias used above via optional - ensure shotgun wood exists
  return {
    models,
    applySkin(next: SkinId) {
      const look = SKINS[next];
      lib.metal.color.setHex(look.metal);
      lib.accent.color.setHex(look.accent);
    },
    dispose() {
      lib.metal.dispose();
      lib.accent.dispose();
      lib.dark.dispose();
      lib.wood.dispose();
      lib.glow.dispose();
      Object.values(geos).forEach((g) => g.dispose());
    },
  };
}

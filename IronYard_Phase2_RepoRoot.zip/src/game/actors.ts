import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import type { ActorKind, TeamId } from "./types";

const capsule = new THREE.CapsuleGeometry(0.09, 0.46, 2, 6);
const shinGeo = new THREE.CapsuleGeometry(0.07, 0.36, 2, 6);
const armGeo = new THREE.CapsuleGeometry(0.055, 0.28, 2, 5);
const forearmGeo = new THREE.CapsuleGeometry(0.05, 0.26, 2, 5);
const headGeo = new THREE.SphereGeometry(0.16, 10, 8);
const jointGeo = new THREE.SphereGeometry(0.07, 8, 6);
const visorGeo = new RoundedBoxGeometry(0.2, 0.06, 0.04, 2, 0.02);
const pouchGeo = new RoundedBoxGeometry(0.1, 0.14, 0.06, 2, 0.02);

export type ActorVisual = {
  root: THREE.Group;
  yaw: THREE.Group;
  fall: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  bodyMat: THREE.MeshStandardMaterial;
  eyeMat: THREE.MeshStandardMaterial;
};

function mat(color: number, rough = 0.55, metal = 0.35) {
  return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
}

function mesh(geo: THREE.BufferGeometry, material: THREE.Material, x: number, y: number, z: number, parent: THREE.Object3D) {
  const m = new THREE.Mesh(geo, material);
  m.position.set(x, y, z);
  m.castShadow = true;
  m.receiveShadow = true;
  parent.add(m);
  return m;
}

function partBox(w: number, h: number, d: number, material: THREE.Material, x: number, y: number, z: number, parent: THREE.Object3D) {
  const g = new RoundedBoxGeometry(w, h, d, 2, Math.min(w, h, d) * 0.18);
  return mesh(g, material, x, y, z, parent);
}

export function buildActor(kind: ActorKind, team: TeamId): ActorVisual {
  const zombie = team === "zombie";
  const teamColor = team === "ember" ? 0xe8943a : team === "zombie" ? 0x6d8a55 : 0x3ec7c2;
  const clothColor = zombie
    ? kind === "bloater"
      ? 0x8ea15c
      : kind === "brute"
        ? 0x4d6244
        : 0x6a7d58
    : kind === "marksman"
      ? 0x3e5344
      : kind === "breacher"
        ? 0x4a4038
        : 0x3c4650;
  const metalColor = zombie ? 0x2a3328 : kind === "gunner" ? 0x2e3842 : 0x8b949c;
  const skinColor = zombie ? 0x7d8f62 : 0xc4a48a;

  const bodyMat = mat(clothColor, zombie ? 0.8 : 0.62, zombie ? 0.04 : 0.25);
  const metalMat = mat(metalColor, 0.4, 0.72);
  const skinMat = mat(skinColor, 0.72, 0.02);
  const darkMat = mat(0x1a1e22, 0.5, 0.4);
  const bootMat = mat(0x16191c, 0.7, 0.2);
  const teamMat = mat(teamColor, 0.45, 0.4);
  const eyeMat = new THREE.MeshStandardMaterial({
    color: zombie ? 0xc6f27a : 0x0c1014,
    emissive: zombie ? 0xc6f27a : teamColor,
    emissiveIntensity: zombie ? 0.9 : 0.55,
    roughness: 0.25,
    metalness: 0.2,
  });

  const root = new THREE.Group();
  const fall = new THREE.Group();
  const yaw = new THREE.Group();
  root.add(fall);
  fall.add(yaw);

  const hips = new THREE.Group();
  hips.position.y = zombie && kind === "runner" ? 0.86 : 0.96;
  yaw.add(hips);

  const legL = new THREE.Group();
  const legR = new THREE.Group();
  legL.position.set(-0.12, 0, 0);
  legR.position.set(0.12, 0, 0);
  hips.add(legL, legR);
  for (const leg of [legL, legR]) {
    mesh(capsule, bodyMat, 0, -0.28, 0, leg);
    mesh(shinGeo, darkMat, 0, -0.62, 0.02, leg);
    partBox(0.12, 0.08, 0.2, bootMat, 0, -0.86, 0.04, leg);
    mesh(jointGeo, darkMat, 0, -0.5, 0, leg);
  }

  const torso = new THREE.Group();
  hips.add(torso);
  const chestW = kind === "brute" || kind === "gunner" ? 0.58 : kind === "screamer" ? 0.32 : kind === "bloater" ? 0.62 : 0.46;
  const chestH = kind === "bloater" ? 0.62 : 0.48;
  partBox(chestW, chestH, kind === "bloater" ? 0.42 : 0.28, kind === "officer" ? metalMat : bodyMat, 0, 0.32, 0, torso);
  partBox(chestW * 0.7, 0.16, 0.08, metalMat, 0, 0.34, 0.16, torso);
  if (!zombie) {
    mesh(pouchGeo, darkMat, -0.12, 0.16, 0.16, torso);
    mesh(pouchGeo, darkMat, 0.12, 0.16, 0.16, torso);
    partBox(0.16, 0.08, 0.16, teamMat, chestW * 0.42, 0.48, 0, torso);
    partBox(0.16, 0.08, 0.16, metalMat, -chestW * 0.42, 0.48, 0, torso);
  }

  if (kind === "marksman") {
    partBox(0.5, 0.7, 0.22, mat(0x2f4636, 0.9, 0.02), 0, 0.15, -0.08, torso);
  }
  if (kind === "gunner" || kind === "breacher") {
    partBox(0.28, 0.32, 0.16, darkMat, 0, 0.34, -0.18, torso);
  }
  if (kind === "bloater") {
    const belly = mesh(new THREE.SphereGeometry(0.28, 10, 8), eyeMat, 0, 0.22, 0.16, torso);
    belly.scale.set(1, 0.85, 0.9);
  }
  if (kind === "spitter") {
    mesh(new THREE.SphereGeometry(0.22, 10, 8), mat(0x9aaa62, 0.6, 0.08), 0, 0.18, 0.18, torso);
    mesh(new THREE.CylinderGeometry(0.05, 0.08, 0.2, 6), darkMat, 0, 0.42, 0.2, torso);
  }
  if (kind === "brute") {
    partBox(0.34, 0.2, 0.24, metalMat, 0.28, 0.42, 0, torso);
  }

  const head = new THREE.Group();
  head.position.y = 0.66;
  torso.add(head);
  mesh(headGeo, zombie ? skinMat : metalMat, 0, 0.12, 0, head);
  if (zombie) {
    mesh(new THREE.SphereGeometry(0.035, 6, 6), eyeMat, -0.06, 0.14, 0.12, head);
    mesh(new THREE.SphereGeometry(0.035, 6, 6), eyeMat, 0.06, 0.14, 0.12, head);
  } else {
    mesh(visorGeo, eyeMat, 0, 0.1, 0.15, head);
    if (kind === "officer") {
      partBox(0.22, 0.05, 0.22, teamMat, 0, 0.3, 0, head);
    } else {
      mesh(new THREE.SphereGeometry(0.17, 10, 8), metalMat, 0, 0.16, -0.01, head);
    }
  }
  if (kind === "screamer") {
    head.position.y = 0.78;
    mesh(new THREE.SphereGeometry(0.05, 6, 6), darkMat, 0, 0.08, 0.14, head);
  }

  const armL = new THREE.Group();
  const armR = new THREE.Group();
  armL.position.set(-chestW * 0.62, 0.48, 0);
  armR.position.set(chestW * 0.62, 0.48, 0);
  torso.add(armL, armR);
  for (const arm of [armL, armR]) {
    mesh(jointGeo, darkMat, 0, 0, 0, arm);
    mesh(armGeo, bodyMat, 0, -0.2, 0, arm);
    const fore = new THREE.Group();
    fore.position.y = -0.38;
    arm.add(fore);
    mesh(forearmGeo, zombie ? skinMat : darkMat, 0, -0.16, 0, fore);
    partBox(0.08, 0.08, 0.1, zombie ? skinMat : bootMat, 0, -0.34, 0.02, fore);
    arm.userData.fore = fore;
  }

  if (kind === "runner") torso.rotation.x = 0.35;
  if (kind === "screamer") {
    armL.rotation.x = -2.2;
    armR.rotation.x = -2.2;
    yaw.scale.set(0.86, 1.18, 0.86);
  }
  if (kind === "brute") yaw.scale.set(1.18, 1.12, 1.18);
  if (kind === "bloater") yaw.scale.set(1.12, 1.02, 1.12);
  if (kind === "gunner") yaw.scale.set(1.08, 1.05, 1.08);

  root.traverse((obj) => {
    const meshObj = obj as THREE.Mesh;
    if (meshObj.isMesh) {
      meshObj.castShadow = true;
      meshObj.receiveShadow = true;
    }
  });

  return { root, yaw, fall, torso, head, legL, legR, armL, armR, bodyMat, eyeMat };
}

export function buildWorldGun(kind: "smg" | "rifle" | "dmr" | "shotgun" | "lmg" | "pistol") {
  const g = new THREE.Group();
  const metal = mat(0x8e979f, 0.35, 0.8);
  const dark = mat(0x1b1f24, 0.45, 0.5);
  const wood = mat(0x6a4630, 0.8, 0.05);
  const add = (geo: THREE.BufferGeometry, material: THREE.Material, x: number, y: number, z: number) => {
    const m = new THREE.Mesh(geo, material);
    m.position.set(x, y, z);
    m.castShadow = true;
    g.add(m);
  };
  if (kind === "pistol") {
    add(new RoundedBoxGeometry(0.05, 0.14, 0.18, 2, 0.01), dark, 0, -0.05, 0.02);
    add(new THREE.CylinderGeometry(0.018, 0.018, 0.16, 6), metal, 0, 0.02, 0.1);
  } else if (kind === "shotgun") {
    add(new RoundedBoxGeometry(0.07, 0.08, 0.34, 2, 0.015), wood, 0, 0, -0.08);
    add(new THREE.CylinderGeometry(0.02, 0.02, 0.46, 6), metal, 0, 0.03, 0.16);
  } else if (kind === "dmr") {
    add(new RoundedBoxGeometry(0.06, 0.08, 0.7, 2, 0.012), dark, 0, 0, 0.05);
    add(new THREE.CylinderGeometry(0.022, 0.022, 0.42, 6), metal, 0, 0.045, 0.28);
    add(new THREE.CylinderGeometry(0.03, 0.03, 0.16, 8), mat(0x22262b, 0.2, 0.7), 0, 0.09, 0.02);
  } else if (kind === "lmg") {
    add(new RoundedBoxGeometry(0.09, 0.12, 0.55, 2, 0.015), dark, 0, 0, 0);
    add(new THREE.CylinderGeometry(0.02, 0.02, 0.5, 6), metal, 0, 0.04, 0.28);
    add(new RoundedBoxGeometry(0.1, 0.14, 0.12, 2, 0.01), metal, 0, -0.1, 0.02);
  } else if (kind === "smg") {
    add(new RoundedBoxGeometry(0.06, 0.1, 0.28, 2, 0.012), dark, 0, 0, 0.02);
    add(new THREE.CylinderGeometry(0.016, 0.016, 0.2, 6), metal, 0, 0.03, 0.16);
    add(new RoundedBoxGeometry(0.05, 0.16, 0.06, 2, 0.01), metal, 0, -0.1, 0.02);
  } else {
    add(new RoundedBoxGeometry(0.07, 0.1, 0.48, 2, 0.014), dark, 0, 0, 0.02);
    add(new THREE.CylinderGeometry(0.016, 0.016, 0.36, 6), metal, 0, 0.035, 0.22);
    add(new RoundedBoxGeometry(0.05, 0.14, 0.07, 2, 0.01), metal, 0, -0.1, -0.02);
  }
  g.rotation.x = Math.PI / 2;
  return g;
}

export function gunKindFor(weapon: string): "smg" | "rifle" | "dmr" | "shotgun" | "lmg" | "pistol" {
  if (weapon === "smg") return "smg";
  if (weapon === "dmr") return "dmr";
  if (weapon === "shotgun") return "shotgun";
  if (weapon === "lmg") return "lmg";
  if (weapon === "rifle") return "rifle";
  return "pistol";
}

extends SceneTree

## Plays the zombie map for a while at high time scale (player invulnerable) and checks that waves
## spawn, allies fight and no script errors occur. Run:
## godot --headless --path . --script res://tests/zombie_soak_test.gd

func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    root.get_node("AppState").set("pending_mode", "zombie")
    var map = (load("res://scenes/world/zombie_map.tscn") as PackedScene).instantiate()
    root.add_child(map)
    for i in range(30):
        await physics_frame
    var player = map.get_node("Player")
    player.get_node("HealthComponent").damage_scale = 0.0
    var manager = map.get_node("ModeManager")
    Engine.time_scale = 4.0
    var peak: int = 0
    var elapsed: float = 0.0
    while elapsed < 45.0:
        await create_timer(1.0, true, false, true).timeout
        elapsed += 1.0
        peak = maxi(peak, get_nodes_in_group("bots").size())
    Engine.time_scale = 1.0
    print("soak: wave %d, peak bots %d" % [int(manager.get("_wave")), peak])
    var ok: bool = int(manager.get("_wave")) >= 1 and peak >= 10
    print("ZOMBIE_SOAK: " + ("PASS" if ok else "FAIL"))
    quit(0 if ok else 1)

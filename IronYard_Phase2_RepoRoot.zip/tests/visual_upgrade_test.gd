extends SceneTree

## Headless checks for the shared visual upgrade.
## Run: godot --headless --path . --script res://tests/visual_upgrade_test.gd

func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    var failures: Array[String] = []
    var texture_sets: Array[String] = [
        "concrete", "painted_steel", "rubber", "asphalt", "wood",
        "dirt", "brick", "fabric", "skin", "gunmetal",
        "zombie_skin", "zombie_cloth", "zombie_leather",
    ]
    for surface in texture_sets:
        for channel in ["albedo", "normal", "roughness"]:
            var path := "res://assets/textures/%s_%s.png" % [surface, channel]
            if not ResourceLoader.exists(path):
                failures.append("Missing PBR map: %s" % path)

    var renderer := str(ProjectSettings.get_setting("rendering/renderer/rendering_method", ""))
    if renderer != "mobile":
        failures.append("Expected mobile renderer for the mobile visual profile; got %s" % renderer)

    var map_kit := MapKit.new(Callable())
    var pbr_materials := ["concrete", "asphalt", "dirt", "steel", "brick", "rubber", "wood"]
    if int(SettingsManager.get_quality_profile().get("texture_tier", 1)) > 0:
        for key in pbr_materials:
            var material := map_kit.mat(key) as StandardMaterial3D
            if material == null or material.albedo_texture == null or material.normal_texture == null or material.roughness_texture == null:
                failures.append("Surface '%s' is missing an albedo/normal/roughness map" % key)

    if failures.is_empty():
        print("IRON_YARD_VISUAL_UPGRADE: PASS")
        quit(0)
    else:
        for failure in failures:
            push_error(failure)
        quit(1)

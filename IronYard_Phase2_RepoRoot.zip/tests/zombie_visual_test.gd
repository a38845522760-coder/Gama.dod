extends SceneTree

## Headless visual-structure check for the dedicated zombie character model.
## Run: godot --headless --path . --script res://tests/zombie_visual_test.gd

func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    var failures: Array[String] = []
    var model := SoldierModel.new()
    model.name = "ZombieVisualTest"
    root.add_child(model)
    model.build({
        "kind": "zombie",
        "primary": Color("#4b4538"),
        "secondary": Color("#2a2a2a"),
        "skin": Color("#7f9468"),
        "headgear": "none",
        "bulk": 1.0,
        "scale": 1.0,
        "zombie_variant": 2,
    })
    await process_frame

    if model.get_node_or_null("Torso") == null:
        failures.append("Zombie torso root is missing")
    if model.get_node_or_null("Torso/Head") == null:
        failures.append("Zombie head rig is missing")
    var meshes := model.find_children("*", "MeshInstance3D", true, false)
    # This model is built from articulated sub-meshes. Keep a lower bound so accidental
    # removal of the new anatomy/gear is caught, but do not impose the old 10-18 range:
    # the detailed zombie rig intentionally contains more separate animated components.
    if meshes.size() < 40:
        failures.append("Zombie model is missing its upgraded anatomical/detail components: %d" % meshes.size())
    var pbr_surfaces := 0
    for node in meshes:
        var mesh_node := node as MeshInstance3D
        if mesh_node.mesh == null:
            continue
        var override_material := mesh_node.material_override as StandardMaterial3D
        if override_material != null and override_material.albedo_texture != null and override_material.normal_enabled and override_material.normal_texture != null and override_material.roughness_texture != null:
            pbr_surfaces += 1
        else:
            for surface_index in range(mesh_node.mesh.get_surface_count()):
                var surface_material := mesh_node.mesh.surface_get_material(surface_index) as StandardMaterial3D
                if surface_material != null and surface_material.albedo_texture != null and surface_material.normal_enabled and surface_material.normal_texture != null and surface_material.roughness_texture != null:
                    pbr_surfaces += 1
    if pbr_surfaces < 8:
        failures.append("Zombie skin/workwear PBR materials are not assigned broadly enough: %d" % pbr_surfaces)
    for texture_path in [
        "res://assets/textures/zombie_skin_albedo.png",
        "res://assets/textures/zombie_skin_normal.png",
        "res://assets/textures/zombie_skin_roughness.png",
        "res://assets/textures/zombie_cloth_albedo.png",
        "res://assets/textures/zombie_cloth_normal.png",
        "res://assets/textures/zombie_cloth_roughness.png",
        "res://assets/textures/zombie_leather_albedo.png",
        "res://assets/textures/zombie_leather_normal.png",
        "res://assets/textures/zombie_leather_roughness.png",
    ]:
        if not ResourceLoader.exists(texture_path):
            failures.append("Missing zombie texture: %s" % texture_path)
    model.animate(1.0 / 60.0, 2.8, 0.0)
    if model.get_head_position().distance_to(model.global_position) < 1.0:
        failures.append("Zombie head position is invalid")
    model.queue_free()

    if failures.is_empty():
        print("[IronYard] zombie visual test passed")
        quit(0)
    else:
        for failure in failures:
            push_error(failure)
        quit(1)

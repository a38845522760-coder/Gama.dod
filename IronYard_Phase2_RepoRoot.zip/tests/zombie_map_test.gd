extends SceneTree

## Headless check of the zombie map, Tesla gun, wave rules and time-based health.
## Run: godot --headless --path . --script res://tests/zombie_map_test.gd

func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    var failures: Array[String] = []
    AppState.pending_mode = "zombie"
    var packed := load("res://scenes/world/zombie_map.tscn")
    if not (packed is PackedScene):
        push_error("Zombie map scene failed to load")
        quit(1)
        return
    var map := (packed as PackedScene).instantiate()
    root.add_child(map)
    await process_frame
    await physics_frame
    await physics_frame

    for node_path in ["Player", "WorldEnvironment", "Moon", "RegionManager", "SpawnManager", "SessionHelper", "ModeManager", "Regions/Core"]:
        if map.get_node_or_null(node_path) == null:
            failures.append("Map node is missing: %s" % node_path)
    if get_nodes_in_group("spawn_points").size() < 24:
        failures.append("Expected at least 24 spawn points")
    var horde: int = 0
    var survivor: int = 0
    for spawn in get_nodes_in_group("spawn_points"):
        if str(spawn.get("team_id")) == "horde":
            horde += 1
        elif str(spawn.get("team_id")) == "survivor":
            survivor += 1
    if horde < 12 or survivor < 4:
        failures.append("Need horde and survivor spawn groups (got %d / %d)" % [horde, survivor])
    var tesla_shops: int = 0
    for node in map.find_children("WeaponShop_*", "", true, false):
        if (node.get("stock") as Array).has("tesla"):
            tesla_shops += 1
    if tesla_shops != 1:
        failures.append("Exactly one shop should sell the Tesla gun (got %d)" % tesla_shops)
    var wrecked_vehicle_count: int = map.find_children("WreckedSUV", "StaticBody3D", true, false).size() + map.find_children("WreckedSedan", "StaticBody3D", true, false).size()
    if wrecked_vehicle_count < 35:
        failures.append("Multiple detailed vehicle types should be used across the zombie map")
    if map.find_children("AbandonedAmbulance", "StaticBody3D", true, false).size() != 1:
        failures.append("Hospital district should contain one detailed ambulance")
    if map.find_children("*WindowGlass*", "MeshInstance3D", true, false).size() < 8:
        failures.append("Ruined building facades should contain framed glazing")
    if map.find_children("FreightWagon_*", "StaticBody3D", true, false).size() != 5:
        failures.append("Rail yard should contain five detailed freight wagons")
    if map.find_children("IndustrialGenerator", "StaticBody3D", true, false).size() < 4:
        failures.append("Industrial districts should contain detailed generator props")

    # Tesla gun numbers from the design.
    var tesla: Dictionary = WeaponDefinitions.get_definition("tesla")
    if int(tesla["magazine_size"]) != 5 or int(tesla["reserve_ammo"]) != 30:
        failures.append("Tesla gun must have a 5-round magazine and 30 reserve")
    if int(tesla["chain_targets_min"]) != 3 or int(tesla["chain_targets_max"]) != 5:
        failures.append("Tesla gun must chain 3-5 targets")

    # Wave rules and faster, denser zombie pacing.
    var manager: ModeManager = map.get_node("ModeManager")
    if ModeManager.default_enemy_count("zombie") != 32:
        failures.append("Zombie mode should default to 32 active enemies")
    if not manager.has_method("get_wave_status"):
        failures.append("Mode manager must expose live wave status for the HUD")
    if not manager.has_method("get_radar_contacts"):
        failures.append("Zombie mode must expose nearby radar contacts")
    if map.find_child("TacticalRadar", true, false) == null:
        failures.append("Zombie HUD should include the tactical radar")
    var smoke_emitters: int = map.find_children("AmbientSmoke_*", "GPUParticles3D", true, false).size()
    if smoke_emitters != 3:
        failures.append("Dead City should have three quality-scaled smoke vents")
    if manager._wave_list(1).size() < 24:
        failures.append("Wave 1 should contain at least 24 zombies")
    if manager._wave_list(2).size() <= manager._wave_list(1).size():
        failures.append("Zombie waves should grow in size")
    manager._wave = 1
    if manager._spawn_interval() > 0.16:
        failures.append("Zombie spawn interval should be 0.16 s or faster")
    if ModeManager.ZOMBIE_FIRST_SPAWN_DELAY > 0.15:
        failures.append("The first zombie should spawn almost immediately")
    var near_horde_spawns: int = 0
    for spawn in get_nodes_in_group("spawn_points"):
        if str(spawn.get("team_id")) == "horde" and Vector2(spawn.global_position.x, spawn.global_position.z).length() <= 110.0:
            near_horde_spawns += 1
    if near_horde_spawns < 40:
        failures.append("Expected at least 40 closer horde entrances")
    var chosen_horde_spawn: Transform3D = manager._pick_horde_spawn_transform()
    var chosen_horde_distance: float = Vector2(chosen_horde_spawn.origin.x - manager._player.global_position.x, chosen_horde_spawn.origin.z - manager._player.global_position.z).length()
    if chosen_horde_distance < 38.0 or chosen_horde_distance > 130.0:
        failures.append("Zombie spawn picker should choose a reasonable distance from the player")
    for wave in range(1, 31):
        var list: Array = manager._wave_list(wave)
        var counts: Dictionary = {}
        for entry in list:
            var id: String = str((entry as Dictionary)["profile"])
            counts[id] = int(counts.get(id, 0)) + 1
        if int(counts.get("brute", 0)) != (wave / 3 if wave % 3 == 0 else 0):
            failures.append("Wave %d: wrong brute count %d" % [wave, int(counts.get("brute", 0))])
        if int(counts.get("pyro", 0)) != (1 if wave % 10 == 0 else 0):
            failures.append("Wave %d: wrong pyro count" % wave)
        if wave % 5 == 0:
            for id in counts.keys():
                if id != "sprinter" and id != "brute" and id != "pyro":
                    failures.append("Wave %d should only hold sprinters (plus tanks/pyro)" % wave)
        elif int(counts.get("sprinter", 0)) > 0:
            failures.append("Wave %d should not hold sprinters" % wave)

    # Time-based health: regenerates fully ~6 s after 3 s without damage.
    var health := HealthComponent.new()
    health.regen_enabled = true
    root.add_child(health)
    health.apply_damage(70.0)
    for step in range(60):
        health._process(0.05)
    if health.current_health > 31.0:
        failures.append("Health must not regenerate during the first 3 seconds")
    for step in range(130):
        health._process(0.05)
    if health.current_health < health.max_health - 0.5:
        failures.append("Health should be full after ~6 s of regeneration")

    # Gadgets start full.
    var gadgets: GadgetController = manager.get_gadgets()
    if gadgets == null or gadgets.grenades != 4 or gadgets.traps != 4:
        failures.append("Gadgets should start with 4 grenades and 4 traps")

    if failures.is_empty():
        print("[IronYard] zombie map test passed")
        quit(0)
    else:
        for failure in failures:
            push_error(failure)
        quit(1)

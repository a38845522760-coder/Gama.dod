extends SceneTree

## Verifies the new Research Institute / underground complex is connected for walking and bots.
## Run: godot --headless --path . --script res://tests/zombie_nav_test.gd

func _initialize() -> void:
    call_deferred("_run")

func _path_ok(map: Node, from_point: Vector3, to_point: Vector3, label: String, failures: Array[String]) -> void:
    var world: World3D = map.get_viewport().world_3d
    var a: Vector3 = BotNav.closest_point(world, from_point)
    var b: Vector3 = BotNav.closest_point(world, to_point)
    var path: PackedVector3Array = BotNav.find_path(world, a, b)
    if path.size() < 2:
        failures.append("%s: no path" % label)
        return
    var end: Vector3 = path[path.size() - 1]
    if end.distance_to(b) > 1.5:
        failures.append("%s: path stops %.1f m short (%s -> %s)" % [label, end.distance_to(b), str(end), str(b)])
    else:
        print("  nav ok: %s (%d points)" % [label, path.size()])

func _run() -> void:
    var failures: Array[String] = []
    root.get_node("AppState").set("pending_mode", "zombie")
    var map := (load("res://scenes/world/zombie_map.tscn") as PackedScene).instantiate()
    root.add_child(map)
    var waited: int = 0
    while not BotNav.ready and waited < 900:
        await physics_frame
        waited += 1
    if not BotNav.ready:
        failures.append("nav mesh never finished baking")
    else:
        for i in range(10):
            await physics_frame
        NavigationServer3D.map_force_update(map.get_viewport().world_3d.navigation_map)
        var plaza := Vector3(0.0, 0.0, 20.0)
        _path_ok(map, plaza, Vector3(55.0, -9.0, 40.0), "plaza -> lower lab", failures)
        _path_ok(map, plaza, Vector3(102.0, -9.0, 40.0), "plaza -> tesla room", failures)
        _path_ok(map, Vector3(102.0, -9.0, 40.0), Vector3(100.0, 0.0, -50.0), "tesla room -> outskirts exit", failures)
        _path_ok(map, plaza, Vector3(55.0, 5.4, 72.0), "plaza -> institute upper floor", failures)
        _path_ok(map, Vector3(102.0, -9.0, 40.0), Vector3(125.0, -9.0, 70.0), "tesla room -> control room (hidden tunnel)", failures)
        _path_ok(map, Vector3(125.0, -9.0, 70.0), Vector3(102.0, -9.0, 58.0), "control room -> vault", failures)
        _path_ok(map, plaza, Vector3(-135.0, 0.0, -96.0), "plaza -> health perk spot", failures)
    if failures.is_empty():
        print("ZOMBIE_NAV: PASS")
        quit(0)
    else:
        for f in failures:
            print("FAIL: " + f)
        print("ZOMBIE_NAV: FAIL")
        quit(1)

extends SceneTree

## Headless test for the downloadable-content logic (ContentCatalog) and the scripts around it.
## Run: godot --headless --path . --script res://tests/content_test.gd

func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    var failures: Array[String] = []

    for script_path in [
        "res://scripts/content/content_catalog.gd",
        "res://scripts/content/content_manager.gd",
        "res://scripts/ui/content_screen.gd",
        "res://scripts/world/pack_map.gd",
    ]:
        if load(script_path) == null:
            failures.append("Script failed to load/parse: %s" % script_path)
    if not (load("res://scenes/world/pack_map.tscn") is PackedScene):
        failures.append("pack_map.tscn failed to load")

    var good := JSON.stringify({"schema": 1, "packs": [
        {"id": "demo_arena", "type": "map", "version": 2, "file": "demo_arena_v2.pck", "size": 2048,
         "sha256": "ABCDEF", "name": {"fa": "الف", "en": "A"}, "battle": true, "max_players": 6},
        {"id": "ak_47", "type": "weapon", "version": 1, "file": "ak_47_v1.pck", "size": 10},
        {"id": "../evil", "type": "map", "version": 1, "file": "x.pck"},
        {"id": "bad_file", "type": "map", "version": 1, "file": "../x.pck"},
        {"id": "no_ext", "type": "map", "version": 1, "file": "x.zip"},
        {"id": "demo_arena", "type": "map", "version": 9, "file": "dup.pck"},
        {"id": "weird_type", "type": "spaceship", "version": 1, "file": "w.pck"},
    ]})
    var parsed := ContentCatalog.parse_manifest(good)
    if not bool(parsed["ok"]):
        failures.append("Valid manifest was rejected: %s" % parsed["error"])
    else:
        var packs: Array = parsed["packs"]
        if packs.size() != 3:
            failures.append("Expected 3 safe packs (demo_arena, ak_47, weird_type), got %d" % packs.size())
        var first: Dictionary = packs[0]
        if str(first["sha256"]) != "abcdef" or int(first["max_players"]) != 6 or not bool(first["battle"]):
            failures.append("Pack fields were not normalized")
        if str((packs[2] as Dictionary)["type"]) != "other":
            failures.append("Unknown pack type must become 'other'")
        if ContentCatalog.filter_by_type(packs, "weapon").size() != 1:
            failures.append("filter_by_type failed")

    if bool(ContentCatalog.parse_manifest("not json")["ok"]):
        failures.append("Garbage manifest was accepted")
    if bool(ContentCatalog.parse_manifest("{\"schema\": 99, \"packs\": []}")["ok"]):
        failures.append("Wrong schema was accepted")

    if ContentCatalog.build_url("https://x.y/r", "a.pck") != "https://x.y/r/a.pck":
        failures.append("build_url must add a slash")
    if ContentCatalog.build_url("https://x.y/r/", "a.pck") != "https://x.y/r/a.pck":
        failures.append("build_url must not double the slash")
    if ContentCatalog.format_size(5 * 1048576) != "5.0 MB":
        failures.append("format_size MB wrong")
    if ContentCatalog.localized_name({"id": "q", "name": {"en": "Q"}}, "fa") != "Q":
        failures.append("localized_name must fall back to English")
    var pack := {"id": "demo_arena", "version": 2}
    if ContentCatalog.pack_status(pack, {}) != "missing":
        failures.append("pack_status missing")
    if ContentCatalog.pack_status(pack, {"demo_arena": {"version": 1}}) != "update":
        failures.append("pack_status update")
    if ContentCatalog.pack_status(pack, {"demo_arena": {"version": 2}}) != "installed":
        failures.append("pack_status installed")

    for key in ["content", "content_download", "content_delete", "content_play", "content_empty"]:
        if not (load("res://scripts/autoload/localization.gd") as GDScript).get_script_constant_map()["STRINGS"].has(key):
            failures.append("Missing localization key: %s" % key)

    if failures.is_empty():
        print("IRON_YARD_CONTENT_TEST: PASS")
        quit(0)
    else:
        for failure in failures:
            push_error(failure)
        print("IRON_YARD_CONTENT_TEST: FAIL (%d)" % failures.size())
        quit(1)

extends SceneTree

## Full zombie-mode flow: switches + doors, perks, Tesla quest (3 machines, batteries, boss,
## 20 s assembly), Tesla ammo rules, cage / hatch / button / Pack-a-Punch (6 s), self-revive.
## Run: godot --headless --path . --script res://tests/zombie_flow_test.gd

var failures: Array[String] = []
var game
var player
var map: Node
var BotScript
var PerkDefsScript
var WeaponDefsScript
var ModeManagerScript
var PickupScript

func check(condition: bool, message: String) -> void:
    if condition:
        print("  ok: " + message)
    else:
        failures.append(message)
        print("  FAIL: " + message)

func use(node_name: String) -> void:
    var node: Node = game.root3d.find_child(node_name, true, false)
    if node == null:
        failures.append("interact node missing: " + node_name)
        print("  FAIL: missing " + node_name)
        return
    node.call("interact", player)

func frames(count: int) -> void:
    for i in range(count):
        await physics_frame

func make_zombie(at: Vector3):
    var bot = BotScript.new()
    bot.profile_id = "walker"
    bot.team = "zombie"
    map.add_child(bot)
    bot.global_position = at
    return bot

func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    BotScript = load("res://scripts/enemies/bot.gd")
    PerkDefsScript = load("res://scripts/zombie/perk_defs.gd")
    WeaponDefsScript = load("res://scripts/weapons/weapon_definitions.gd")
    ModeManagerScript = load("res://scripts/modes/mode_manager.gd")
    PickupScript = load("res://scripts/gameplay/pickup.gd")
    root.get_node("AppState").set("pending_mode", "zombie")
    map = (load("res://scenes/world/zombie_map.tscn") as PackedScene).instantiate()
    root.add_child(map)
    await frames(40)
    game = map.get_game()
    player = map.get_node("Player")
    var weapon: Node = player.get_node("WeaponController")
    var health = player.get_node("HealthComponent")
    check(game != null and game.is_in_group("zombie_game"), "ZombieGame exists")
    check(game.points == 500, "starting points = 500")

    print("[points & doors]")
    use("Interact_Door_gate")
    check(not game.doors["gate"].is_open or game.points == 500 - 750 or game.points == 500, "gate stays shut without points")
    check(not game.doors["gate"].is_open, "gate not opened with 500 points")
    game.add_points(1000)
    use("Interact_Door_gate")
    check(game.points == 750, "gate costs 750 (points %d)" % game.points)
    await create_timer(1.6).timeout
    check(game.doors["gate"].is_open, "gate opened after animation")
    check(game.doors["gate"].collision_layer == 0, "open gate no longer collides")
    game.add_points(5000)
    use("Interact_Door_restricted")
    check(not game.doors["restricted"].is_open, "restricted door locked before the switches")
    for i in range(3):
        use("Interact_Switch_%d" % i)
    check(game.power_restored(), "3 switches restore power")
    var before: int = game.points
    use("Interact_Door_restricted")
    check(before - game.points == 1250, "restricted door costs 1250 after switches")
    use("Interact_Door_hatch")
    use("Interact_Door_maintenance")
    use("Interact_Door_vault")
    await create_timer(1.6).timeout
    check(game.doors["restricted"].is_open and game.doors["hatch"].is_open, "mission doors open")
    check(not game.doors["vault"].is_open, "vault door only opens through the button")

    print("[perks]")
    game.add_points(20000)
    var base_walk: float = float(player.get("walk_speed"))
    var base_health: float = health.max_health
    for id in PerkDefsScript.ORDER:
        use("Interact_Perk_" + id)
        await create_timer(1.7).timeout
    check(game.perks.size() == 6, "all six perks bought (%d)" % game.perks.size())
    check(absf(float(player.get("walk_speed")) - base_walk * 1.25) < 0.01, "speed perk +25%")
    check(absf(health.max_health - (base_health + 50.0)) < 0.01, "health perk +50")
    check(int(weapon.call("get_extra_slots")) == 1, "third weapon slot")
    var before_perk_points: int = game.points
    use("Interact_Perk_speed")
    check(game.points == before_perk_points, "a perk cannot be bought twice")

    print("[death & self-revive]")
    var lives_before: int = int(map.get_node("ModeManager").get("_lives"))
    health.apply_damage(9999.0, null)
    await create_timer(0.3).timeout
    check(not game.perks.has("revive"), "revive perk consumed")
    check(game.perks.size() == 5, "other perks kept after a self-revive")
    await create_timer(2.2).timeout
    check(not bool(player.call("is_dead")), "player revived in place")
    check(int(map.get_node("ModeManager").get("_lives")) == lives_before, "no life lost by a self-revive")
    await create_timer(3.2).timeout
    health.apply_damage(9999.0, null)
    await create_timer(0.5).timeout
    check(game.perks.is_empty(), "all perks lost on a real death")
    check(is_equal_approx(float(player.get("walk_speed")), base_walk), "speed restored after losing the perk")
    check(int(map.get_node("ModeManager").get("_lives")) == lives_before - 1, "real death costs one life")
    await create_timer(3.5).timeout
    check(not bool(player.call("is_dead")), "player respawned")
    var weapon_ids: Array = weapon.call("get_weapon_ids")
    check(weapon_ids.size() <= 2, "carry limit back to 2 weapons (%d)" % weapon_ids.size())

    health.damage_scale = 0.0  # the rest of the test is about quest logic, not survival
    print("[tesla quest: stage 1 machines]")
    var quest = game.quest
    for i in range(3):
        use("Interact_Charge_%d" % i)
        check(bool(quest.machines[i]["active"]), "machine %d active" % i)
    for i in range(3):
        var pos: Vector3 = quest.machines[i]["pos"]
        var outside = make_zombie(pos + Vector3(9.0, 0.0, 0.0))
        outside._kill(player, false)
        check(int(quest.machines[i]["charge"]) == 0, "kill outside the field gives no energy (machine %d)" % i)
        for k in range(quest.ENERGY_NEEDED):
            var z = make_zombie(pos + Vector3(2.0, 0.0, 1.0))
            z._kill(player, false)
        check(bool(quest.machines[i]["ready"]), "machine %d fully charged" % i)
    await create_timer(0.8).timeout
    print("[stage 2 batteries]")
    use("Interact_Charge_0")
    check(quest.carried == "battery", "battery picked up")
    use("Interact_Charge_1")
    check(quest.batteries_taken == 1, "only one battery can be carried at a time")
    use("Interact_Station")
    await create_timer(0.9).timeout
    check(quest.installed[0] and not quest.station_powered, "first battery installed")
    use("Interact_Charge_1")
    use("Interact_Station")
    await create_timer(0.9).timeout
    use("Interact_Charge_2")
    use("Interact_Station")
    await create_timer(0.9).timeout
    check(quest.station_powered, "station powered with 3 batteries")
    print("[stage 3 boss]")
    await create_timer(3.2).timeout
    check(quest.boss_spawned and quest.boss != null and is_instance_valid(quest.boss), "fire boss spawned")
    await frames(5)
    check(quest.boss.is_alive(), "boss alive")
    var boss_health: float = quest.boss.max_health
    check(boss_health > 1000.0, "boss has large health (%.0f)" % boss_health)
    quest.boss.receive_hit({"damage": boss_health * 0.65, "position": quest.boss.global_position + Vector3(0, 1, 0), "source": player, "headshot_multiplier": 1.0})
    await frames(3)
    quest.boss.receive_hit({"damage": 1.0, "position": quest.boss.global_position + Vector3(0, 1, 0), "source": player, "headshot_multiplier": 1.0})
    await create_timer(0.3).timeout
    check(quest.boss.phase == 2, "boss enters rage phase below 50%")
    quest.boss.receive_hit({"damage": boss_health, "position": quest.boss.global_position + Vector3(0, 1, 0), "source": player, "headshot_multiplier": 1.0})
    await frames(3)
    check(quest.boss_dead and is_instance_valid(quest.body_pickup), "boss dead and the Tesla body dropped")

    print("[stage 4 assembly: exactly 20 s]")
    use("Interact_TeslaBody")
    check(quest.carried == "body", "Tesla body carried")
    use("Interact_Assembly")
    check(quest.assembling, "assembly started")
    var steps: int = 0
    var finished_early: bool = false
    while quest.assembling and steps < 1000:
        quest._tick_assembly(0.05)
        steps += 1
        if steps == 399 and not quest.assembling:
            finished_early = true
    check(steps == 400 and not finished_early, "assembly takes exactly 20.0 s (%d steps of 0.05 s)" % steps)
    check(quest.assembly_done, "assembly complete")
    print("[stage 5 take Tesla]")
    use("Interact_Assembly")
    check(bool(weapon.call("has_weapon", "tesla")), "Tesla weapon given")
    check(weapon.call("get_ammo_for", "tesla") == Vector2i(3, quest.TESLA_START_RESERVE), "starting Tesla ammo 3/%d" % quest.TESLA_START_RESERVE)
    var def: Dictionary = WeaponDefsScript.get_definition("tesla")
    check(int(def["magazine_size"]) == 3 and int(def["reserve_ammo"]) == 15, "Tesla magazine 3 / reserve 15")
    check(int(weapon.call("tesla_capacity")) == 18, "Tesla total capacity 18")
    check(int(weapon.call("add_tesla_ammo", 100)) == 15 - quest.TESLA_START_RESERVE, "Tesla reserve is capped at 15")
    weapon.call("refill")
    check(int(weapon.call("tesla_total")) == 18, "refill never adds Tesla ammo beyond what you hold")
    check(int(weapon.call("get_weapon_ids").size()) <= 3, "Tesla does not use a weapon slot")
    check(not game.wants_tesla_drop(quest.boss), "boss never drops Tesla ammo")
    weapon.call("spend_tesla_ammo", 3)
    var drops: int = 0
    for i in range(400):
        if game.wants_tesla_drop(make_zombie(Vector3(0, 0, 0))):
            drops += 1
    check(drops > 5, "zombies can drop Tesla ammo (%d of 400)" % drops)
    var tesla_before: int = int(weapon.call("tesla_total"))
    game.on_wave_cleared(4)
    check(int(weapon.call("tesla_total")) == tesla_before, "wave 4 gives no Tesla ammo")
    game.on_wave_cleared(5)
    check(int(weapon.call("tesla_total")) > tesla_before, "wave 5 gives Tesla ammo")
    var pickup = PickupScript.new()
    pickup.kind = "tesla"
    map.add_child(pickup)
    check(pickup.kind == "tesla", "Tesla ammo pickup kind exists")

    print("[cage, hatch, button, Pack-a-Punch]")
    var hits_through_window: int = 0
    var space: PhysicsDirectSpaceState3D = player.get_world_3d().direct_space_state
    for i in range(20):
        var x: float = 96.0 + float(i) * 0.7
        var query := PhysicsRayQueryParameters3D.create(Vector3(x, -9.0 + 1.7, 44.0), Vector3(102.0, -9.0 + 2.2, 62.0), 1)
        var hit: Dictionary = space.intersect_ray(query)
        if not hit.is_empty() and hit["collider"].has_method("receive_tesla"):
            hits_through_window += 1
    check(hits_through_window >= 8, "the cage can be hit through the vault window (%d/20 rays)" % hits_through_window)
    use("Interact_Hatch")
    check(not quest.hatch_open, "hatch cannot be bought before the cage is shot")
    for i in range(3):
        quest.cage.receive_tesla(Vector3(102, -7, 60), player)
        await create_timer(0.3).timeout
    check(quest.cage.is_broken(), "3 Tesla hits break the cage circuits")
    quest.cage.receive_tesla(Vector3(102, -7, 60), player)
    check(quest.cage.hits == 3, "extra hits are ignored")
    game.points = 100
    use("Interact_Hatch")
    check(not quest.hatch_open and not quest._hatch_busy, "hatch needs the points fee")
    game.points = 1000
    use("Interact_Hatch")
    check(game.points == 1000 - quest.HATCH_FEE, "hatch fee %d" % quest.HATCH_FEE)
    await create_timer(3.0).timeout
    check(quest.hatch_open, "hatch opened")
    use("Interact_VaultButton")
    await create_timer(4.0).timeout
    check(game.doors["vault"].is_open and quest.cage.raised, "button opens the vault door and raises the cage")
    # Pack-a-Punch
    var held: String = str(weapon.call("get_weapon_id"))
    print("  debug switching=", weapon.call("is_switching"), " dead=", player.call("is_dead"), " held=", held)
    if held == "tesla":
        for candidate in weapon.call("get_weapon_ids"):
            if str(candidate) != "tesla":
                weapon.call("equip", str(candidate))
                break
        await create_timer(1.0).timeout
        held = str(weapon.call("get_weapon_id"))
    var base_def: Dictionary = WeaponDefsScript.get_definition(held)
    game.points = 4999
    use("Interact_PackAPunch")
    check(not quest.pap_busy, "Pack-a-Punch refuses with 4999 points")
    game.points = 5000 + 123
    print("  debug held=", held, " ids=", weapon.call("get_weapon_ids"), " reason=", quest.can_pack(held), " tesla=", weapon.call("tesla_total"))
    var tesla_total_before: int = int(weapon.call("tesla_total"))
    use("Interact_PackAPunch")
    check(quest.pap_busy, "Pack-a-Punch started")
    check(game.points == 123, "Pack-a-Punch costs 5000 points")
    check(tesla_total_before - int(weapon.call("tesla_total")) == 2, "Pack-a-Punch costs 2 Tesla charges")
    check(bool(weapon.call("is_weapon_locked")), "weapon is locked while inside the machine")
    var pap_steps: int = 0
    var pap_early: bool = false
    while quest.pap_busy and pap_steps < 1000:
        quest._tick_pap(0.05)
        pap_steps += 1
        if pap_steps == 119 and not quest.pap_busy:
            pap_early = true
    check(pap_steps == 120 and not pap_early, "weapon stays inside exactly 6.0 s (%d steps)" % pap_steps)
    check(bool(weapon.call("is_upgraded", held)), "weapon upgraded")
    check(not bool(weapon.call("is_weapon_locked")), "weapon returned")
    var ammo: Vector2i = weapon.call("get_ammo_for", held)
    check(ammo.x == int(base_def["magazine_size"]) * 2 and ammo.y == int(base_def["reserve_ammo"]) * 2, "magazine and reserve doubled (%s)" % str(ammo))
    game.points = 10000
    use("Interact_PackAPunch")
    check(not quest.pap_busy, "an upgraded weapon cannot be upgraded twice")

    print("[waves, spawns and balance]")
    check(ModeManagerScript.default_enemy_count("zombie") == 24, "24 zombies per wave by default")

    if failures.is_empty():
        print("ZOMBIE_FLOW: PASS")
        quit(0)
    else:
        for f in failures:
            print("FAIL: " + f)
        print("ZOMBIE_FLOW: FAIL (%d)" % failures.size())
        quit(1)

extends SceneTree

## Loads the zombie map headless, runs a few seconds of physics and prints PASS/FAIL.
## Run: godot --headless --path . --script res://tests/zombie_boot_test.gd

func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    var failures: Array[String] = []
    root.get_node("AppState").set("pending_mode", "zombie")
    var packed := load("res://scenes/world/zombie_map.tscn")
    if not (packed is PackedScene):
        push_error("zombie map failed to load")
        quit(1)
        return
    var map := (packed as PackedScene).instantiate()
    root.add_child(map)
    for i in range(30):
        await physics_frame
    var player := map.get_node_or_null("Player")
    if player == null:
        failures.append("Player missing")
    var manager := map.get_node_or_null("ModeManager")
    if manager == null:
        failures.append("ModeManager missing")
    if failures.is_empty():
        print("ZOMBIE_BOOT: PASS")
        quit(0)
    else:
        for f in failures:
            push_error(f)
        print("ZOMBIE_BOOT: FAIL")
        quit(1)

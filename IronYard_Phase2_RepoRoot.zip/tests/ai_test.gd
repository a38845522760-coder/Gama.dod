extends SceneTree

## Enemy AI checks: hands on weapons (IK), crouch, personalities, teamwork, lose-sight search,
## per-wave random spawn gates.
## Run: godot --headless --path . --script res://tests/ai_test.gd

var failures: Array[String] = []

func check(condition: bool, message: String) -> void:
    if condition:
        print("  ok: " + message)
    else:
        failures.append(message)
        print("  FAIL: " + message)

func _initialize() -> void:
    call_deferred("_run")

func _make_bot(profile: String, team: String, at: Vector3, parent: Node):
    var bot = load("res://scripts/enemies/bot.gd").new()
    bot.profile_id = profile
    bot.team = team
    parent.add_child(bot)
    bot.global_position = at
    return bot

func _run() -> void:
    root.get_node("AppState").set("pending_mode", "zombie")
    var defs = load("res://scripts/weapons/weapon_definitions.gd")
    var holder := Node3D.new()
    root.add_child(holder)
    var floor_body := StaticBody3D.new()
    var floor_shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(200, 1, 200)
    floor_shape.shape = box
    floor_body.add_child(floor_shape)
    floor_body.position = Vector3(0, -0.5, 0)
    holder.add_child(floor_body)
    await physics_frame

    print("[hands hold the weapon]")
    var soldier = _make_bot("grunt", "alpha", Vector3.ZERO, holder)
    await physics_frame
    var model = soldier._model
    var worst_right: float = 0.0
    var worst_left: float = 0.0
    for id in defs.ORDER:
        model.set_weapon(id)
        await physics_frame
        for aim in [0.0, 1.0]:
            for i in range(30):
                model.animate(0.05, 0.0, aim)
            var targets: Array = model.get_grip_targets()
            var hands: Array = model.get_hand_positions()
            var left_error: float = hands[0].distance_to(model._torso.to_global(targets[0]))
            var right_error: float = hands[1].distance_to(model._torso.to_global(targets[1]))
            worst_left = maxf(worst_left, left_error)
            worst_right = maxf(worst_right, right_error)
    print("  worst hand error: left %.3f m, right %.3f m" % [worst_left, worst_right])
    check(worst_right < 0.02, "right hand sits on the grip for every weapon (%.3f m)" % worst_right)
    check(worst_left < 0.06, "left hand reaches the foregrip for every weapon (%.3f m)" % worst_left)
    model.set_weapon("rifle")
    for i in range(30):
        model.animate(0.05, 3.5, 1.0)
    var moving_error: float = model.get_hand_positions()[1].distance_to(model._torso.to_global(model.get_grip_targets()[1]))
    check(moving_error < 0.02, "hands stay on the grip while running (%.3f m)" % moving_error)

    print("[crouch and slide]")
    var full_height: float = soldier._capsule.height
    soldier._set_crouch(1.0)
    check(soldier._capsule.height < full_height * 0.7, "crouching shrinks the collision capsule (%.2f -> %.2f)" % [full_height, soldier._capsule.height])
    check(soldier.is_crouching(), "is_crouching() reports it")
    var standing_y: float = model._torso.position.y
    for i in range(5):
        model.animate(0.05, 0.0, 0.0)
    check(model._torso.position.y < 1.0, "crouch lowers the body model (%.2f)" % model._torso.position.y)
    soldier._set_crouch(0.0)
    soldier._start_slide(Vector3(0, 0, -1))
    check(soldier.is_sliding(), "slide starts")

    print("[per-bot variety]")
    var patience: Dictionary = {}
    var jumpers: int = 0
    var crouchers: int = 0
    var flankers: int = 0
    for i in range(40):
        var b = _make_bot("grunt", "bravo", Vector3(50 + i, 0, 50), holder)
        patience[snappedf(float(b.personality["patience"]), 0.05)] = true
        if float(b.personality["jumpy"]) > 0.0:
            jumpers += 1
        if float(b.personality["crouchy"]) > 0.0:
            crouchers += 1
        if bool(b.personality["flanker"]):
            flankers += 1
    check(patience.size() > 20, "bots have individual personalities (%d distinct values of 40)" % patience.size())
    check(jumpers > 5 and jumpers < 40, "some bots jump while fighting (%d/40)" % jumpers)
    check(crouchers > 5 and crouchers < 40, "some bots crouch while fighting (%d/40)" % crouchers)
    check(flankers > 2 and flankers < 30, "some bots flank (%d/40)" % flankers)

    print("[teamwork]")
    var a = _make_bot("grunt", "alpha", Vector3(20, 0, 0), holder)
    var mate = _make_bot("grunt", "alpha", Vector3(30, 0, 0), holder)
    var far_mate = _make_bot("grunt", "alpha", Vector3(120, 0, 0), holder)
    var enemy = _make_bot("grunt", "bravo", Vector3(25, 0, -30), holder)
    await physics_frame
    a._alert_teammates(enemy)
    check(mate._target == enemy and mate._memory_left >= 5.0, "a spotted enemy alerts a nearby teammate")
    check(far_mate._target == null, "a distant teammate is not alerted")
    var zed = _make_bot("walker", "zombie", Vector3(60, 0, 60), holder)
    check(zed._target == null, "zombies are not part of soldier alerts")

    print("[lose sight -> search -> look around]")
    var seeker = _make_bot("grunt", "alpha", Vector3(-40, 0, 0), holder)
    var lost_enemy = _make_bot("grunt", "bravo", Vector3(-40, 0, -60), holder)
    await physics_frame
    seeker._target = lost_enemy
    seeker._target_visible = false
    seeker._memory_left = 30.0
    seeker._last_known = seeker.global_position + Vector3(0.5, 0.0, 0.5)
    seeker._decide(0.1)
    check(seeker.state == seeker.State.SEARCH and seeker._search_look_left > 0.0, "at the last known position the bot stops and scans")
    var scan_time: float = 0.0
    while seeker._search_look_left > 0.0 and scan_time < 10.0:
        seeker._decide(0.1)
        scan_time += 0.1
    check(scan_time >= 1.5, "scanning lasts its personal patience (%.1f s)" % scan_time)
    seeker._decide(0.1)
    check(seeker._memory_left == 0.0, "after scanning it gives up and resumes patrolling")

    print("[zombies spawn around the player]")
    var map = (load("res://scenes/world/zombie_map.tscn") as PackedScene).instantiate()
    root.add_child(map)
    for i in range(40):
        await physics_frame
    var manager = map.get_node("ModeManager")
    var player = map.get_node("Player")
    var near_ok: int = 0
    var spread: Dictionary = {}
    for round in range(20):
        var spawn_t: Transform3D = manager._pick_wave_spawn("horde")
        var spawn_distance: float = spawn_t.origin.distance_to(player.global_position)
        if spawn_distance >= 8.0 and spawn_distance <= 45.0:
            near_ok += 1
        spread["%d_%d" % [int(spawn_t.origin.x / 4.0), int(spawn_t.origin.z / 4.0)]] = true
    check(near_ok >= 18, "zombie spawns are close to the player (%d / 20 within 8-45 m)" % near_ok)
    check(spread.size() >= 5, "zombie spawns vary around the player (%d different cells)" % spread.size())

    if failures.is_empty():
        print("AI_TEST: PASS")
        quit(0)
    else:
        for f in failures:
            print("FAIL: " + f)
        print("AI_TEST: FAIL (%d)" % failures.size())
        quit(1)

extends SceneTree

func _initialize() -> void:
    call_deferred("_run_tests")

func _run_tests() -> void:
    var failures: Array[String] = []
    var player_resource := load("res://scenes/player/player.tscn")
    if not (player_resource is PackedScene):
        failures.append("Player scene could not be loaded as a PackedScene")
    else:
        var player := (player_resource as PackedScene).instantiate()
        if not (player is CharacterBody3D):
            failures.append("Player root is not CharacterBody3D")
        if player.get_node_or_null("CollisionShape3D") == null:
            failures.append("Player capsule collision is missing")
        if player.get_node_or_null("CameraPivot/Camera3D") == null:
            failures.append("First-person camera is missing")
        if player.get_node_or_null("HealthComponent") == null:
            failures.append("Health component is missing")
        if player.get_node_or_null("CameraPivot/Camera3D/EquipmentViewmodel") == null:
            failures.append("Stylized first-person equipment viewmodel is missing")
        if not player.has_method("get_movement_snapshot"):
            failures.append("Movement telemetry method is missing")
        if not player.has_method("_update_crouch") or not player.has_method("_has_standing_clearance"):
            failures.append("Collision-safe crouch implementation is missing")
        if not player.has_method("_update_sprint_stamina") or not player.has_method("_refresh_surface_profile") or not player.has_method("_blend_surface_response"):
            failures.append("Surface response and sprint endurance systems are missing")
        if not player.has_method("_get_current_stride_length"):
            failures.append("Distance-based gait timing is missing")
        player.free()

    var arena_resource := load("res://scenes/world/core_test_arena.tscn")
    if not (arena_resource is PackedScene):
        failures.append("Core test arena could not be loaded as a PackedScene")

    var settings_script := load("res://scripts/autoload/settings_manager.gd")
    if settings_script == null:
        failures.append("SettingsManager script could not be loaded")

    for script_path in [
        "res://scripts/player/equipment_viewmodel.gd",
        "res://scripts/world/rotating_valve_wheel.gd",
        "res://scripts/world/animated_pressure_gauge.gd",
        "res://scripts/world/rotating_industrial_fan.gd",
        "res://scripts/world/animated_warning_beacon.gd",
        "res://scripts/world/moving_test_platform.gd",
    ]:
        if load(script_path) == null:
            failures.append("Required movement/presentation script failed to load: %s" % script_path)

    for texture_path in [
        "res://assets/textures/concrete_albedo.png",
        "res://assets/textures/concrete_normal.png",
        "res://assets/textures/concrete_roughness.png",
        "res://assets/textures/painted_steel_albedo.png",
        "res://assets/textures/painted_steel_normal.png",
        "res://assets/textures/painted_steel_roughness.png",
        "res://assets/textures/rubber_albedo.png",
        "res://assets/textures/rubber_normal.png",
        "res://assets/textures/rubber_roughness.png",
    ]:
        if not FileAccess.file_exists(texture_path):
            failures.append("PBR texture is missing: %s" % texture_path)

    if not InputMap.has_action("scan"):
        failures.append("Utility scanner input action is missing")
    var viewmodel_script := load("res://scripts/player/equipment_viewmodel.gd")
    if viewmodel_script != null:
        var viewmodel_instance: Object = viewmodel_script.new()
        if not viewmodel_instance.has_method("play_activation") or not viewmodel_instance.has_method("play_inspect"):
            failures.append("First-person equipment animation API is incomplete")
        if not viewmodel_instance.has_method("play_scan") or not viewmodel_instance.has_method("play_landing"):
            failures.append("First-person equipment response animation API is incomplete")
        viewmodel_instance.free()
    if not InputMap.has_action("sprint") or not InputMap.has_action("jump"):
        failures.append("Core movement input actions are missing")
    for action_name in ["crouch", "activate_equipment", "inspect_equipment"]:
        if not InputMap.has_action(action_name):
            failures.append("Enhanced core input action is missing: %s" % action_name)

    var world_script := load("res://scripts/world/core_test_arena.gd")
    if world_script == null:
        failures.append("Detailed physics arena script could not be loaded")
    var controller_script := load("res://scripts/player/player_controller.gd")
    if controller_script == null:
        failures.append("Enhanced player controller script could not be loaded")

    if failures.is_empty():
        print("IRON_YARD_SMOKE_TEST: PASS")
        quit(0)
    else:
        for failure in failures:
            push_error(failure)
        print("IRON_YARD_SMOKE_TEST: FAIL (%d)" % failures.size())
        quit(1)

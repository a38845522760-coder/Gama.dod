extends RefCounted
class_name ProductionMaterials

## Access to the production library's PBR materials (res://production_library/materials/*.tres,
## each with albedo / normal / roughness / metallic / AO maps) and its texture families.
## Everything degrades to null when the library is not installed (the CI workflow downloads it
## from the visual-assets release), so callers keep their plain fallback materials.

const MATERIAL_DIR: String = "res://production_library/materials/"
const TEXTURE_DIR: String = "res://production_library/textures/"

static var _cache: Dictionary = {}

## A copy of a library material. `character` = true makes it suitable for animated bodies:
## vertex colours drive the albedo and the triplanar mapping stays in object space (the skin
## does not slide while the body moves). The height map is dropped (too costly on phones).
static func get_material(material_name: String, character: bool = false) -> StandardMaterial3D:
    var key: String = "%s_%s" % [material_name, character]
    if _cache.has(key):
        return _cache[key]
    var result: StandardMaterial3D = null
    var path: String = MATERIAL_DIR + material_name + ".tres"
    if ResourceLoader.exists(path):
        var base := load(path) as StandardMaterial3D
        if base != null:
            result = base.duplicate() as StandardMaterial3D
            result.heightmap_enabled = false
            if character:
                result.vertex_color_use_as_albedo = true
                result.uv1_triplanar = true
                result.uv1_world_triplanar = false
                result.uv1_scale = Vector3(1.6, 1.6, 1.6)
    _cache[key] = result
    return result

## Adds a library texture family (albedo, normal, roughness) to a plain material.
static func add_family(material: StandardMaterial3D, family: String, uv_scale: float = 0.6) -> void:
    var albedo_path: String = TEXTURE_DIR + family + "_albedo.webp"
    if not ResourceLoader.exists(albedo_path):
        return
    material.albedo_texture = load(albedo_path) as Texture2D
    var normal_path: String = TEXTURE_DIR + family + "_normal.webp"
    if ResourceLoader.exists(normal_path):
        material.normal_enabled = true
        material.normal_texture = load(normal_path) as Texture2D
        material.normal_scale = 0.5
    var rough_path: String = TEXTURE_DIR + family + "_roughness.png"
    if ResourceLoader.exists(rough_path):
        material.roughness_texture = load(rough_path) as Texture2D
    material.uv1_triplanar = true
    material.uv1_world_triplanar = true
    material.uv1_scale = Vector3(uv_scale, uv_scale, uv_scale)

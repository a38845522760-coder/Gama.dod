extends Node3D
class_name EquipmentViewmodel

## First-person tactical pulse carbine viewmodel with natural two-handed grip and recoil/muzzle feedback.

@export var idle_position := Vector3(0.24, -0.22, -0.48)
@export_range(0.05, 0.5, 0.01) var scan_duration: float = 0.20
@export_range(0.05, 0.5, 0.01) var activation_duration: float = 0.14

var _rig: Node3D
var _muzzle_point: Marker3D
var _core_material: StandardMaterial3D
var _glow_material: StandardMaterial3D
var _display_material: StandardMaterial3D
var _muzzle_material: StandardMaterial3D
var _scan_glow: MeshInstance3D
var _activation_glow: MeshInstance3D
var _activation_light: OmniLight3D
var _left_hand_pivot: Node3D
var _right_hand_pivot: Node3D
var _left_forearm: MeshInstance3D
var _right_forearm: MeshInstance3D
var _right_trigger_finger: MeshInstance3D
var _wrist_display: MeshInstance3D
var _animated_fins: Array[MeshInstance3D] = []
var _meter_bars: Array[MeshInstance3D] = []
var _sensor_spinner: Node3D
var _finger_segments: Array[MeshInstance3D] = []
var _wrist_indicators: Array[MeshInstance3D] = []
var _phase: float = 0.0
var _scan_left: float = 0.0
var _activation_left: float = 0.0
var _inspect_left: float = 0.0
var _scan_strength: float = 0.0
var _activation_strength: float = 0.0
var _recoil_kick: float = 0.0
var _recoil_velocity: float = 0.0
var _impact_offset: float = 0.0
var _impact_velocity: float = 0.0
var _jump_tuck: float = 0.0
var _acceleration_sway: Vector3 = Vector3.ZERO
var _base_rotation := Vector3(-0.02, -0.04, 0.0)
var _inspect_roll: float = 0.0
var _is_aiming: bool = false
var _aim_blend: float = 0.0
var _reload_left: float = 0.0
var _reload_duration: float = 1.1
var _reload_blend: float = 0.0
@export var aim_position := Vector3(0.0, -0.076, -0.34)

func _ready() -> void:
	_build_device()

func get_muzzle_global_position() -> Vector3:
	if _muzzle_point != null and is_inside_tree():
		return _muzzle_point.global_position
	if _rig != null and is_inside_tree():
		return _rig.global_position + (-_rig.global_transform.basis.z * 0.46)
	return global_position

func update_motion(delta: float, speed_ratio: float, sprint_blend: float, grounded: bool, look_sway: Vector2, crouch_blend: float = 0.0, vertical_speed: float = 0.0, horizontal_acceleration: Vector3 = Vector3.ZERO, gait_phase: float = -1.0) -> void:
	delta = clampf(delta, 0.0, 0.05)
	var motion_intensity := clampf(speed_ratio, 0.0, 1.0)
	if gait_phase >= 0.0:
		_phase = gait_phase
	else:
		_phase = fposmod(_phase + delta * lerpf(5.6, 11.8, motion_intensity), TAU)
	var bob_factor := motion_intensity if grounded else 0.20
	var bob_y := sin(_phase * 2.0) * lerpf(0.005, 0.012, motion_intensity) * bob_factor
	var bob_x := sin(_phase) * 0.008 * bob_factor
	var sprint_drop := sprint_blend * 0.075
	var crouch_drop := crouch_blend * 0.036

	var impact_state := _critical_spring(_impact_offset, 0.0, _impact_velocity, 0.13, delta)
	_impact_offset = clampf(impact_state.x, -0.09, 0.04)
	_impact_velocity = impact_state.y

	var recoil_state := _critical_spring(_recoil_kick, 0.0, _recoil_velocity, 0.075, delta)
	_recoil_kick = clampf(recoil_state.x, -0.02, 0.09)
	_recoil_velocity = recoil_state.y

	_jump_tuck = move_toward(_jump_tuck, 0.0, delta * 4.6)
	_inspect_left = maxf(0.0, _inspect_left - delta)
	var inspect_envelope := sin((1.0 - _inspect_left / 0.42) * PI) if _inspect_left > 0.0 else 0.0
	_inspect_roll = lerpf(_inspect_roll, inspect_envelope, 1.0 - exp(-12.0 * delta))

	var acceleration_target := Vector3(
		clampf(-horizontal_acceleration.x * 0.00018, -0.035, 0.035),
		clampf(horizontal_acceleration.z * 0.00009, -0.022, 0.022),
		0.0
	)
	_acceleration_sway = _acceleration_sway.lerp(acceleration_target, 1.0 - exp(-8.5 * delta))

	var idle_breath := sin(Time.get_ticks_msec() * 0.00155) * 0.0022 if motion_intensity < 0.08 and grounded else 0.0
	var airborne_tuck := clampf(-vertical_speed * 0.0035, -0.020, 0.038) if not grounded else 0.0
	var inspect_lift := _inspect_roll * 0.040
	_aim_blend = lerpf(_aim_blend, 1.0 if (_is_aiming and _reload_left <= 0.0) else 0.0, 1.0 - exp(-15.0 * delta))
	_reload_left = maxf(0.0, _reload_left - delta)
	var reload_env := sin((1.0 - _reload_left / maxf(_reload_duration, 0.1)) * PI) if _reload_left > 0.0 else 0.0
	_reload_blend = lerpf(_reload_blend, reload_env, 1.0 - exp(-16.0 * delta))

	var ads_damp := lerpf(1.0, 0.25, _aim_blend)
	var base_pos := idle_position.lerp(aim_position, _aim_blend)
	var target_position := base_pos + Vector3(
		(bob_x - look_sway.x * 0.14 + _acceleration_sway.x) * ads_damp - sprint_blend * 0.07 * (1.0 - _aim_blend) - _inspect_roll * 0.035 - _reload_blend * 0.06,
		(bob_y + idle_breath + _acceleration_sway.y) * ads_damp - sprint_drop * (1.0 - _aim_blend) - crouch_drop * 0.5 + _impact_offset + _jump_tuck * 0.015 + airborne_tuck + inspect_lift + _recoil_kick * 0.14 - _reload_blend * 0.11,
		sprint_blend * 0.06 * (1.0 - _aim_blend) + _inspect_roll * 0.065 + _scan_strength * 0.020 + _recoil_kick * 0.68 + _reload_blend * 0.05
	)

	if _rig != null:
		_rig.position = _rig.position.lerp(target_position, 1.0 - exp(-16.0 * delta))
		var base_rot := _base_rotation.lerp(Vector3.ZERO, _aim_blend)
		var target_rotation := base_rot + Vector3(
			(look_sway.y * 0.85 - _acceleration_sway.y * 0.6) * ads_damp - sprint_blend * 0.16 * (1.0 - _aim_blend),
			(-look_sway.x * 0.85 + _acceleration_sway.x) * ads_damp + sprint_blend * 0.36 * (1.0 - _aim_blend),
			-sprint_blend * 0.18 * (1.0 - _aim_blend) - crouch_blend * 0.04 * (1.0 - _aim_blend)
		)
		target_rotation.x += sin(_phase) * 0.016 * bob_factor * ads_damp
		target_rotation.z += sin(_phase * 0.5) * 0.012 * bob_factor * ads_damp
		target_rotation.x += _recoil_kick * 1.05 * lerpf(1.0, 0.55, _aim_blend)
		target_rotation.x -= _scan_strength * 0.020
		target_rotation.x += _impact_offset * 0.65 - _jump_tuck * 0.05
		target_rotation.y += _inspect_roll * 0.48 + _reload_blend * 0.32
		target_rotation.z += _inspect_roll * 0.14 + _reload_blend * 0.52
		target_rotation.x -= _reload_blend * 0.48
		_rig.rotation = _rig.rotation.lerp(target_rotation, 1.0 - exp(-15.0 * delta))

	# Subtle trigger finger pull while hands stay locked onto grip and handguard
	if _right_trigger_finger != null:
		_right_trigger_finger.rotation.x = lerpf(_right_trigger_finger.rotation.x, deg_to_rad(84.0) + _activation_strength * 0.28, 1.0 - exp(-24.0 * delta))

	_scan_left = maxf(0.0, _scan_left - delta)
	_activation_left = maxf(0.0, _activation_left - delta)
	var scan_envelope := sin((1.0 - _scan_left / maxf(scan_duration, 0.05)) * PI) if _scan_left > 0.0 else 0.0
	var activation_envelope := sin((1.0 - _activation_left / maxf(activation_duration, 0.05)) * PI) if _activation_left > 0.0 else 0.0
	_scan_strength = lerpf(_scan_strength, scan_envelope, 1.0 - exp(-25.0 * delta))
	_activation_strength = lerpf(_activation_strength, activation_envelope, 1.0 - exp(-34.0 * delta))

	var clock := Time.get_ticks_msec() * 0.001
	if _core_material != null:
		_core_material.emission_energy_multiplier = 1.7 + _scan_strength * 3.2 + _activation_strength * 5.2 + sin(clock * 2.5) * 0.15
	if _display_material != null:
		_display_material.emission_energy_multiplier = 1.0 + _scan_strength * 1.6 + _activation_strength * 2.4
	if _muzzle_material != null:
		_muzzle_material.emission_energy_multiplier = 2.0 + _activation_strength * 8.5
	if _scan_glow != null:
		_scan_glow.visible = _scan_strength > 0.025
		_scan_glow.scale = Vector3.ONE * (0.45 + _scan_strength * 1.35)
	if _activation_glow != null:
		_activation_glow.visible = _activation_strength > 0.035
		_activation_glow.scale = Vector3(0.75 + _activation_strength * 1.6, 0.75 + _activation_strength * 1.6, 1.0 + _activation_strength * 2.8)
	if _activation_light != null:
		_activation_light.light_energy = _activation_strength * 2.6
	if _sensor_spinner != null:
		_sensor_spinner.rotation.z = fposmod(
			_sensor_spinner.rotation.z + delta * (1.2 + _scan_strength * 12.0 + _activation_strength * 4.5),
			TAU
		)
	for index in range(_animated_fins.size()):
		var fin := _animated_fins[index]
		fin.rotation.x = sin(clock * 1.9 + float(index) * 1.7) * 0.035 + _scan_strength * 0.10 + _activation_strength * 0.12
	for index in range(_meter_bars.size()):
		var bar := _meter_bars[index]
		var pulse := 0.35 + 0.25 * sin(clock * 3.3 + float(index) * 0.8) + _activation_strength * 0.35
		bar.scale.y = maxf(0.15, pulse)
	for index in range(_wrist_indicators.size()):
		var indicator := _wrist_indicators[index]
		indicator.scale = Vector3.ONE * (0.75 + 0.25 * sin(clock * 2.0 + float(index) * 1.1) + _scan_strength * 0.25)

func _critical_spring(current_value: float, target_value: float, current_velocity: float, smooth_time: float, delta: float) -> Vector2:
	var safe_time := maxf(smooth_time, 0.01)
	var omega := 2.0 / safe_time
	var offset := current_value - target_value
	var decay := exp(-omega * delta)
	var temporary := (current_velocity + omega * offset) * delta
	var next_value := target_value + (offset + temporary) * decay
	var next_velocity := (current_velocity - omega * temporary) * decay
	return Vector2(next_value, next_velocity)

func set_aiming(aiming: bool) -> void:
	_is_aiming = aiming

func play_reload(duration: float = 1.1) -> void:
	_reload_duration = maxf(duration, 0.2)
	_reload_left = _reload_duration

func play_scan() -> void:
	_scan_left = maxf(scan_duration, 0.05)

func play_activation() -> void:
	_activation_left = maxf(activation_duration, 0.05)
	_recoil_kick = minf(_recoil_kick + 0.038, 0.085)
	_recoil_velocity += 0.55
	_impact_velocity += 0.22

func play_inspect() -> void:
	_inspect_left = 0.42

func play_jump() -> void:
	_jump_tuck = 1.0
	_impact_velocity += 0.14

func play_landing(intensity: float) -> void:
	_jump_tuck = 0.0
	_impact_velocity -= 0.24 + clampf(intensity, 0.0, 1.0) * 0.68

func _build_device() -> void:
	_rig = Node3D.new()
	_rig.name = "FictionalFieldEmitterRig"
	_rig.position = idle_position
	_rig.rotation = _base_rotation
	add_child(_rig)

	var casing := _make_material(Color("#1a2730"), 0.32, 0.80)
	var edge_material := _make_material(Color("#52616a"), 0.42, 0.72)
	var polymer := _make_material(Color("#24353f"), 0.78, 0.12)
	var accent := _make_material(Color("#d89a45"), 0.42, 0.45)
	_core_material = _make_emissive_material(Color("#41d9ee"), 1.7)
	_glow_material = _make_emissive_material(Color("#9bf4ff"), 1.0)
	_display_material = _make_emissive_material(Color("#78e7d4"), 1.0)
	_muzzle_material = _make_emissive_material(Color("#ffb057"), 2.0)

	# Sleek pulse carbine receiver, stock, handguard, barrel, pistol grip & optic
	_add_box("EmitterMainHousing", Vector3(0.0, 0.0, 0.0), Vector3(0.078, 0.092, 0.34), casing)
	_add_box("EmitterRearShell", Vector3(0.0, -0.008, 0.21), Vector3(0.068, 0.098, 0.12), edge_material)
	_add_box("EmitterBarrelShroud", Vector3(0.0, 0.008, -0.21), Vector3(0.066, 0.072, 0.18), polymer)
	_add_box("EmitterLowerTrim", Vector3(0.0, -0.036, -0.18), Vector3(0.056, 0.022, 0.16), edge_material)
	_add_box("EmitterLowerGrip", Vector3(0.0, -0.088, 0.115), Vector3(0.042, 0.125, 0.056), polymer, Vector3(deg_to_rad(-18.0), 0.0, 0.0))
	_add_box("EmitterTriggerGuard", Vector3(0.0, -0.062, 0.052), Vector3(0.022, 0.036, 0.072), edge_material)
	_add_box("EmitterTrigger", Vector3(0.0, -0.055, 0.064), Vector3(0.010, 0.024, 0.014), accent, Vector3(deg_to_rad(18.0), 0.0, 0.0))

	# Holographic reflex sight on top rail
	_add_box("EmitterTopRail", Vector3(0.0, 0.052, -0.04), Vector3(0.044, 0.014, 0.28), edge_material)
	_add_box("EmitterTopDisplayFrame", Vector3(0.0, 0.072, 0.01), Vector3(0.050, 0.034, 0.072), accent)
	_add_box("EmitterTopDisplay", Vector3(0.0, 0.076, 0.01), Vector3(0.034, 0.022, 0.006), _display_material)

	# Barrel & muzzle brake
	var barrel_mesh := CylinderMesh.new()
	barrel_mesh.top_radius = 0.015
	barrel_mesh.bottom_radius = 0.017
	barrel_mesh.height = 0.18
	var barrel := _add_mesh("EmitterBarrel", barrel_mesh, edge_material, Vector3(0.0, 0.014, -0.34))
	barrel.rotation.x = PI * 0.5

	var brake_mesh := CylinderMesh.new()
	brake_mesh.top_radius = 0.021
	brake_mesh.bottom_radius = 0.021
	brake_mesh.height = 0.042
	var brake := _add_mesh("EmitterMuzzleBrake", brake_mesh, casing, Vector3(0.0, 0.014, -0.435))
	brake.rotation.x = PI * 0.5

	_muzzle_point = Marker3D.new()
	_muzzle_point.name = "MuzzlePoint"
	_muzzle_point.position = Vector3(0.0, 0.014, -0.465)
	_rig.add_child(_muzzle_point)

	# Side rails & energy core strip
	_add_box("EmitterLeftSideRail", Vector3(-0.044, 0.005, -0.08), Vector3(0.012, 0.026, 0.24), edge_material)
	_add_box("EmitterRightSideRail", Vector3(0.044, 0.005, -0.08), Vector3(0.012, 0.026, 0.24), edge_material)
	_add_box("EmitterEnergyCoreStrip", Vector3(0.0, 0.016, -0.14), Vector3(0.072, 0.012, 0.12), _core_material)

	# Status meter bars & animated cooling fins
	for index in range(4):
		var meter := _add_box("EmitterStatusMeter_%d" % index, Vector3(-0.022 + float(index) * 0.015, 0.056, 0.115), Vector3(0.008, 0.014, 0.008), _display_material)
		_meter_bars.append(meter)
	for side: float in [-1.0, 1.0]:
		var fin := _add_box("EmitterSideFin_%s" % str(side), Vector3(side * 0.048, 0.006, -0.03), Vector3(0.008, 0.032, 0.08), accent)
		_animated_fins.append(fin)

	# Rotary survey sensor mounted on right front rail (required by runtime integration test)
	_sensor_spinner = Node3D.new()
	_sensor_spinner.name = "SurveySensorRotor"
	_sensor_spinner.position = Vector3(0.054, 0.008, -0.22)
	_rig.add_child(_sensor_spinner)
	var sensor_hub_mesh := SphereMesh.new()
	sensor_hub_mesh.radius = 0.012
	sensor_hub_mesh.height = 0.024
	var sensor_hub := MeshInstance3D.new()
	sensor_hub.name = "SensorRotorHub"
	sensor_hub.mesh = sensor_hub_mesh
	sensor_hub.material_override = _core_material
	_sensor_spinner.add_child(sensor_hub)
	for blade_index in range(4):
		var blade := BoxMesh.new()
		blade.size = Vector3(0.036, 0.005, 0.008)
		var blade_node := MeshInstance3D.new()
		blade_node.name = "SensorRotorBlade_%d" % blade_index
		blade_node.mesh = blade
		blade_node.material_override = accent
		blade_node.rotation.z = float(blade_index) * PI * 0.5
		_sensor_spinner.add_child(blade_node)

	# Hierarchical Two-Handed Grip Rig (hands locked to grip & handguard, forearms connected to wrists)
	var sleeve_material := _make_material(Color("#263843"), 0.74, 0.16)
	var guard_material := _make_material(Color("#67777e"), 0.48, 0.58)
	var glove_material := _make_material(Color("#151f25"), 0.88, 0.04)

	# RIGHT HAND: gripping the rear pistol grip + trigger
	_right_hand_pivot = Node3D.new()
	_right_hand_pivot.name = "RightHandPivot"
	_right_hand_pivot.position = Vector3(0.0, -0.085, 0.115)
	_rig.add_child(_right_hand_pivot)

	_add_box_to(_right_hand_pivot, "RightGlovePalm", Vector3(0.010, 0.0, 0.012), Vector3(0.056, 0.072, 0.066), glove_material)
	_add_box_to(_right_hand_pivot, "RightGuardPlate", Vector3(0.038, 0.006, 0.015), Vector3(0.016, 0.054, 0.054), guard_material)
	_add_box_to(_right_hand_pivot, "RightWristCuff", Vector3(0.022, -0.026, 0.070), Vector3(0.068, 0.042, 0.054), accent, Vector3(deg_to_rad(-14.0), deg_to_rad(18.0), 0.0))

	var right_sleeve := CapsuleMesh.new()
	right_sleeve.radius = 0.046
	right_sleeve.height = 0.36
	_right_forearm = _add_mesh_to(_right_hand_pivot, "RightForearmGuard", right_sleeve, sleeve_material, Vector3(0.095, -0.095, 0.235))
	_right_forearm.rotation = Vector3(deg_to_rad(-64.0), deg_to_rad(22.0), deg_to_rad(8.0))

	var right_thumb_mesh := CapsuleMesh.new()
	right_thumb_mesh.radius = 0.010
	right_thumb_mesh.height = 0.060
	var right_thumb := _add_mesh_to(_right_hand_pivot, "GloveThumb_1.0", right_thumb_mesh, glove_material, Vector3(-0.026, 0.022, 0.005))
	right_thumb.rotation = Vector3(deg_to_rad(56.0), deg_to_rad(20.0), deg_to_rad(18.0))

	var trigger_finger_mesh := CapsuleMesh.new()
	trigger_finger_mesh.radius = 0.009
	trigger_finger_mesh.height = 0.058
	_right_trigger_finger = _add_mesh_to(_right_hand_pivot, "GloveFinger_1.0_0", trigger_finger_mesh, glove_material, Vector3(0.024, 0.020, -0.036))
	_right_trigger_finger.rotation = Vector3(deg_to_rad(84.0), deg_to_rad(-14.0), 0.0)
	_finger_segments.append(_right_trigger_finger)

	for finger_index in range(1, 4):
		var finger_mesh := CapsuleMesh.new()
		finger_mesh.radius = 0.0095
		finger_mesh.height = 0.056
		var f_node := _add_mesh_to(_right_hand_pivot, "GloveFinger_1.0_%d" % finger_index, finger_mesh, glove_material,
			Vector3(0.0, 0.002 - float(finger_index) * 0.017, -0.026))
		f_node.rotation = Vector3(0.0, 0.0, PI * 0.5)
		_finger_segments.append(f_node)

	# LEFT HAND: cradling the front handguard (C-clamp / support grip)
	_left_hand_pivot = Node3D.new()
	_left_hand_pivot.name = "LeftHandPivot"
	_left_hand_pivot.position = Vector3(-0.006, -0.030, -0.185)
	_rig.add_child(_left_hand_pivot)

	_add_box_to(_left_hand_pivot, "LeftGlovePalm", Vector3(-0.014, -0.010, 0.0), Vector3(0.058, 0.052, 0.092), glove_material)
	_add_box_to(_left_hand_pivot, "LeftGuardPlate", Vector3(-0.044, -0.008, 0.004), Vector3(0.016, 0.048, 0.068), guard_material)
	_add_box_to(_left_hand_pivot, "LeftWristCuff", Vector3(-0.046, -0.028, 0.078), Vector3(0.068, 0.042, 0.054), accent, Vector3(deg_to_rad(-10.0), deg_to_rad(-28.0), 0.0))

	var left_sleeve := CapsuleMesh.new()
	left_sleeve.radius = 0.046
	left_sleeve.height = 0.36
	_left_forearm = _add_mesh_to(_left_hand_pivot, "LeftForearmGuard", left_sleeve, sleeve_material, Vector3(-0.155, -0.105, 0.235))
	_left_forearm.rotation = Vector3(deg_to_rad(-66.0), deg_to_rad(-34.0), deg_to_rad(-10.0))

	var left_thumb_mesh := CapsuleMesh.new()
	left_thumb_mesh.radius = 0.0105
	left_thumb_mesh.height = 0.066
	var left_thumb := _add_mesh_to(_left_hand_pivot, "GloveThumb_-1.0", left_thumb_mesh, glove_material, Vector3(-0.034, 0.024, -0.015))
	left_thumb.rotation = Vector3(deg_to_rad(78.0), deg_to_rad(-16.0), deg_to_rad(-22.0))

	for finger_index in range(4):
		var finger_mesh := CapsuleMesh.new()
		finger_mesh.radius = 0.0095
		finger_mesh.height = 0.062
		var f_node := _add_mesh_to(_left_hand_pivot, "GloveFinger_-1.0_%d" % finger_index, finger_mesh, glove_material,
			Vector3(0.018, -0.024, -0.030 + float(finger_index) * 0.020))
		f_node.rotation = Vector3(0.0, 0.0, PI * 0.5)
		_finger_segments.append(f_node)

	_wrist_display = _add_box_to(_left_hand_pivot, "WristStatusDisplay", Vector3(-0.050, 0.006, 0.072), Vector3(0.010, 0.028, 0.046), _display_material, Vector3(0.0, deg_to_rad(-28.0), 0.0))
	for index in range(3):
		var indicator := _add_box_to(_left_hand_pivot, "WristIndicator_%d" % index,
			Vector3(-0.052, 0.024, 0.056 + float(index) * 0.016),
			Vector3(0.006, 0.008, 0.008), _glow_material)
		_wrist_indicators.append(indicator)

	_scan_glow = _add_sphere("ScanPulseGlow", _glow_material, Vector3(0.0, 0.014, -0.45), 0.055)
	_scan_glow.visible = false
	_activation_glow = _add_sphere("ActivationPulseGlow", _muzzle_material, Vector3(0.0, 0.014, -0.475), 0.048)
	_activation_glow.visible = false
	_activation_light = OmniLight3D.new()
	_activation_light.name = "ActivationGlowLight"
	_activation_light.position = Vector3(0.0, 0.014, -0.48)
	_activation_light.light_color = Color("#ffaa4c")
	_activation_light.omni_range = 2.4
	_activation_light.light_energy = 0.0
	_activation_light.shadow_enabled = false
	_rig.add_child(_activation_light)

func _make_material(color: Color, roughness: float, metallic: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	material.metallic = metallic
	return material

func _make_emissive_material(color: Color, energy: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color.darkened(0.22)
	material.emission_enabled = true
	material.emission = color
	material.emission_energy_multiplier = energy
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	return material

func _add_box(node_name: String, local_position: Vector3, box_size: Vector3, material: Material, local_rotation: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	return _add_box_to(_rig, node_name, local_position, box_size, material, local_rotation)

func _add_box_to(parent_node: Node3D, node_name: String, local_position: Vector3, box_size: Vector3, material: Material, local_rotation: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = box_size
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = local_position
	instance.rotation = local_rotation
	parent_node.add_child(instance)
	return instance

func _add_sphere(node_name: String, material: Material, local_position: Vector3, radius: float) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	return _add_mesh(node_name, mesh, material, local_position)

func _add_mesh(node_name: String, mesh: Mesh, material: Material, local_position: Vector3) -> MeshInstance3D:
	return _add_mesh_to(_rig, node_name, mesh, material, local_position)

func _add_mesh_to(parent_node: Node3D, node_name: String, mesh: Mesh, material: Material, local_position: Vector3) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = local_position
	parent_node.add_child(instance)
	return instance

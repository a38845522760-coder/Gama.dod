extends Node3D
class_name EquipmentViewmodel

## Stylized fictional sci-fi field emitter used only for first-person presentation tests.
## Activation and scan are cosmetic light/animation effects; no projectile or damage exists.

@export var idle_position := Vector3(0.285, -0.245, -0.55)
@export_range(0.05, 0.5, 0.01) var scan_duration: float = 0.20
@export_range(0.05, 0.5, 0.01) var activation_duration: float = 0.14

var _rig: Node3D
var _core_material: StandardMaterial3D
var _glow_material: StandardMaterial3D
var _display_material: StandardMaterial3D
var _scan_glow: MeshInstance3D
var _activation_glow: MeshInstance3D
var _activation_light: OmniLight3D
var _left_forearm: MeshInstance3D
var _right_forearm: MeshInstance3D
var _wrist_display: MeshInstance3D
var _animated_fins: Array[MeshInstance3D] = []
var _meter_bars: Array[MeshInstance3D] = []
var _sensor_spinner: Node3D
var _finger_segments: Array[MeshInstance3D] = []
var _wrist_indicators: Array[MeshInstance3D] = []
var _phase: float = 0.0
var _scan_left: float = 0.0
var _activation_left: float = 0.0
var _inspect_left: float = 0.0
var _scan_strength: float = 0.0
var _activation_strength: float = 0.0
var _impact_offset: float = 0.0
var _impact_velocity: float = 0.0
var _jump_tuck: float = 0.0
var _acceleration_sway: Vector3 = Vector3.ZERO
var _base_rotation := Vector3(-0.08, -0.08, -0.02)
var _inspect_roll: float = 0.0

func _ready() -> void:
    _build_device()

func update_motion(delta: float, speed_ratio: float, sprint_blend: float, grounded: bool, look_sway: Vector2, crouch_blend: float = 0.0, vertical_speed: float = 0.0, horizontal_acceleration: Vector3 = Vector3.ZERO, gait_phase: float = -1.0) -> void:
    # Bound animation integration after a hitch/resume so viewmodel springs do not snap.
    delta = clampf(delta, 0.0, 0.05)
    var motion_intensity := clampf(speed_ratio, 0.0, 1.0)
    if gait_phase >= 0.0:
        _phase = gait_phase
    else:
        _phase = fposmod(_phase + delta * lerpf(5.6, 11.8, motion_intensity), TAU)
    var bob_factor := motion_intensity if grounded else 0.20
    var bob_y := sin(_phase * 2.0) * lerpf(0.006, 0.014, motion_intensity) * bob_factor
    var bob_x := sin(_phase) * 0.010 * bob_factor
    var sprint_drop := sprint_blend * 0.105
    var crouch_drop := crouch_blend * 0.052

    # Analytic critically damped response remains stable during frame-time spikes.
    var impact_state := _critical_spring(_impact_offset, 0.0, _impact_velocity, 0.13, delta)
    _impact_offset = clampf(impact_state.x, -0.10, 0.04)
    _impact_velocity = impact_state.y
    _jump_tuck = move_toward(_jump_tuck, 0.0, delta * 4.6)
    _inspect_left = maxf(0.0, _inspect_left - delta)
    var inspect_envelope := sin((1.0 - _inspect_left / 0.42) * PI) if _inspect_left > 0.0 else 0.0
    _inspect_roll = lerpf(_inspect_roll, inspect_envelope, 1.0 - exp(-12.0 * delta))

    var acceleration_target := Vector3(
        clampf(-horizontal_acceleration.x * 0.00020, -0.045, 0.045),
        clampf(horizontal_acceleration.z * 0.00010, -0.028, 0.028),
        0.0
    )
    _acceleration_sway = _acceleration_sway.lerp(acceleration_target, 1.0 - exp(-8.5 * delta))

    var idle_breath := sin(Time.get_ticks_msec() * 0.00155) * 0.0028 if motion_intensity < 0.08 and grounded else 0.0
    var airborne_tuck := clampf(-vertical_speed * 0.004, -0.025, 0.045) if not grounded else 0.0
    var inspect_lift := _inspect_roll * 0.045
    var target_position := idle_position + Vector3(
        bob_x - look_sway.x * 0.18 + _acceleration_sway.x + _inspect_roll * -0.035,
        bob_y - sprint_drop - crouch_drop + idle_breath + _impact_offset + _jump_tuck * 0.018 + airborne_tuck + _acceleration_sway.y + inspect_lift,
        sprint_blend * 0.19 + _inspect_roll * 0.075 + _scan_strength * 0.025
    )
    target_position += Vector3(0.0, _scan_strength * 0.012, _activation_strength * 0.014)

    if _rig != null:
        _rig.position = _rig.position.lerp(target_position, 1.0 - exp(-14.0 * delta))
        var target_rotation := _base_rotation + Vector3(
            look_sway.y * 0.92 - _acceleration_sway.y * 0.7,
            -look_sway.x * 0.90 + _acceleration_sway.x,
            -sprint_blend * 0.21 - crouch_blend * 0.065
        )
        target_rotation.x += sin(_phase) * 0.021 * bob_factor
        target_rotation.z += sin(_phase * 0.5) * 0.015 * bob_factor
        target_rotation.x -= _scan_strength * 0.023 + _activation_strength * 0.045
        target_rotation.x += _impact_offset * 0.76 - _jump_tuck * 0.06
        target_rotation.y += _inspect_roll * 0.52
        target_rotation.z += _inspect_roll * 0.12
        target_rotation.z += sin(_phase * 0.5) * 0.024 * sprint_blend
        _rig.rotation = _rig.rotation.lerp(target_rotation, 1.0 - exp(-12.5 * delta))

    var arm_swing := sin(_phase) * motion_intensity * (0.095 + sprint_blend * 0.045)
    if _left_forearm != null:
        _left_forearm.rotation.z = lerpf(_left_forearm.rotation.z, deg_to_rad(-29.0) + arm_swing, 1.0 - exp(-13.0 * delta))
        _left_forearm.position.y = lerpf(_left_forearm.position.y, -0.17 + sin(_phase + PI) * 0.018 * motion_intensity - crouch_blend * 0.012, 1.0 - exp(-13.0 * delta))
    if _right_forearm != null:
        _right_forearm.rotation.z = lerpf(_right_forearm.rotation.z, deg_to_rad(29.0) - arm_swing, 1.0 - exp(-13.0 * delta))
        _right_forearm.position.y = lerpf(_right_forearm.position.y, -0.17 + sin(_phase) * 0.018 * motion_intensity - crouch_blend * 0.012, 1.0 - exp(-13.0 * delta))
    for index in range(_finger_segments.size()):
        var finger := _finger_segments[index]
        var hand_phase := _phase + float(index % 4) * 0.35
        var flex := sin(hand_phase) * motion_intensity * 0.025 + sprint_blend * 0.035 + _activation_strength * 0.06
        finger.rotation.x = lerpf(finger.rotation.x, PI * 0.5 + flex, 1.0 - exp(-11.0 * delta))

    _scan_left = maxf(0.0, _scan_left - delta)
    _activation_left = maxf(0.0, _activation_left - delta)
    var scan_envelope := sin((1.0 - _scan_left / maxf(scan_duration, 0.05)) * PI) if _scan_left > 0.0 else 0.0
    var activation_envelope := sin((1.0 - _activation_left / maxf(activation_duration, 0.05)) * PI) if _activation_left > 0.0 else 0.0
    _scan_strength = lerpf(_scan_strength, scan_envelope, 1.0 - exp(-25.0 * delta))
    _activation_strength = lerpf(_activation_strength, activation_envelope, 1.0 - exp(-31.0 * delta))

    var clock := Time.get_ticks_msec() * 0.001
    if _core_material != null:
        _core_material.emission_energy_multiplier = 1.7 + _scan_strength * 3.2 + _activation_strength * 4.8 + sin(clock * 2.5) * 0.15
    if _display_material != null:
        _display_material.emission_energy_multiplier = 1.0 + _scan_strength * 1.6 + _activation_strength * 2.2
    if _scan_glow != null:
        _scan_glow.visible = _scan_strength > 0.025
        _scan_glow.scale = Vector3.ONE * (0.5 + _scan_strength * 1.45)
        _scan_glow.position.z = -0.365 - _scan_strength * 0.085
    if _activation_glow != null:
        _activation_glow.visible = _activation_strength > 0.035
        _activation_glow.scale = Vector3.ONE * (0.45 + _activation_strength * 1.85)
    if _activation_light != null:
        _activation_light.light_energy = _activation_strength * 1.25
    if _sensor_spinner != null:
        _sensor_spinner.rotation.z = fposmod(
            _sensor_spinner.rotation.z + delta * (1.2 + _scan_strength * 12.0 + _activation_strength * 3.0),
            TAU
        )
    for index in range(_animated_fins.size()):
        var fin := _animated_fins[index]
        fin.rotation.x = sin(clock * 1.9 + float(index) * 1.7) * 0.035 + _scan_strength * 0.10
    for index in range(_meter_bars.size()):
        var bar := _meter_bars[index]
        var pulse := 0.35 + 0.25 * sin(clock * 3.3 + float(index) * 0.8) + _activation_strength * 0.35
        bar.scale.y = maxf(0.15, pulse)
    for index in range(_wrist_indicators.size()):
        var indicator := _wrist_indicators[index]
        indicator.scale = Vector3.ONE * (0.75 + 0.25 * sin(clock * 2.0 + float(index) * 1.1) + _scan_strength * 0.25)


func _critical_spring(current_value: float, target_value: float, current_velocity: float, smooth_time: float, delta: float) -> Vector2:
    var safe_time := maxf(smooth_time, 0.01)
    var omega := 2.0 / safe_time
    var offset := current_value - target_value
    var decay := exp(-omega * delta)
    var temporary := (current_velocity + omega * offset) * delta
    var next_value := target_value + (offset + temporary) * decay
    var next_velocity := (current_velocity - omega * temporary) * decay
    return Vector2(next_value, next_velocity)

func play_scan() -> void:
    _scan_left = maxf(scan_duration, 0.05)

func play_activation() -> void:
    _activation_left = maxf(activation_duration, 0.05)
    _impact_velocity += 0.42

func play_inspect() -> void:
    _inspect_left = 0.42

func play_jump() -> void:
    _jump_tuck = 1.0
    _impact_velocity += 0.16

func play_landing(intensity: float) -> void:
    _jump_tuck = 0.0
    _impact_velocity -= 0.26 + clampf(intensity, 0.0, 1.0) * 0.72

func _build_device() -> void:
    _rig = Node3D.new()
    _rig.name = "FictionalFieldEmitterRig"
    _rig.position = idle_position
    _rig.rotation = _base_rotation
    add_child(_rig)

    var casing := _make_material(Color("#1a2730"), 0.31, 0.82)
    var edge_material := _make_material(Color("#52616a"), 0.42, 0.70)
    var polymer := _make_material(Color("#263b45"), 0.78, 0.12)
    var accent := _make_material(Color("#d89a45"), 0.43, 0.40)
    _core_material = _make_emissive_material(Color("#41d9ee"), 1.7)
    _glow_material = _make_emissive_material(Color("#9bf4ff"), 1.0)
    _display_material = _make_emissive_material(Color("#78e7d4"), 1.0)

    # Asymmetrical, abstract energy survey prop: industrial casing and luminous sensor face.
    _add_box("EmitterMainHousing", Vector3(0.0, 0.0, 0.0), Vector3(0.205, 0.128, 0.285), casing)
    _add_box("EmitterRearShell", Vector3(0.0, 0.0, 0.155), Vector3(0.178, 0.098, 0.045), edge_material)
    _add_box("EmitterLowerGrip", Vector3(0.008, -0.105, 0.065), Vector3(0.118, 0.15, 0.105), polymer, Vector3(deg_to_rad(-8.0), 0.0, deg_to_rad(-3.0)))
    _add_box("EmitterGripInset", Vector3(0.008, -0.108, 0.123), Vector3(0.078, 0.092, 0.012), casing)
    _add_box("EmitterTopDisplayFrame", Vector3(0.0, 0.078, 0.012), Vector3(0.153, 0.025, 0.148), accent)
    _add_box("EmitterTopDisplay", Vector3(0.0, 0.094, 0.012), Vector3(0.128, 0.008, 0.118), _display_material)
    _add_box("EmitterFrontSensorFrame", Vector3(0.0, 0.012, -0.151), Vector3(0.155, 0.094, 0.032), edge_material)
    _add_box("EmitterFrontSensor", Vector3(0.0, 0.012, -0.171), Vector3(0.098, 0.061, 0.009), _glow_material)
    _add_box("EmitterLeftSideRail", Vector3(-0.116, 0.002, 0.0), Vector3(0.022, 0.095, 0.23), edge_material)
    _add_box("EmitterRightSideRail", Vector3(0.116, 0.002, 0.0), Vector3(0.022, 0.095, 0.23), edge_material)
    _add_box("EmitterLowerTrim", Vector3(0.0, -0.073, -0.006), Vector3(0.16, 0.018, 0.19), edge_material)
    _add_box("EmitterSerialPlate", Vector3(0.0, -0.037, 0.155), Vector3(0.105, 0.028, 0.012), accent)

    for index in range(5):
        var z_offset := -0.112 + float(index) * 0.052
        _add_box("EmitterCoolingFin_%02d" % index, Vector3(0.0, 0.068, z_offset), Vector3(0.115, 0.009, 0.014), accent if index == 0 else edge_material)
    for side: float in [-1.0, 1.0]:
        for index in range(4):
            var rivet := SphereMesh.new()
            rivet.radius = 0.008
            rivet.height = 0.016
            _add_mesh("EmitterRivet_%s_%d" % [str(side), index], rivet, accent, Vector3(side * 0.12, -0.028 + float(index % 2) * 0.055, -0.08 + float(index) * 0.047))

    # Four animated status columns and a softly oscillating side fin pair.
    for index in range(4):
        var meter := _add_box("EmitterStatusMeter_%d" % index, Vector3(-0.052 + float(index) * 0.035, 0.108, 0.10), Vector3(0.012, 0.018, 0.012), _display_material)
        _meter_bars.append(meter)
    for side: float in [-1.0, 1.0]:
        var fin := _add_box("EmitterSideFin_%s" % str(side), Vector3(side * 0.132, 0.005, -0.015), Vector3(0.018, 0.075, 0.12), accent)
        _animated_fins.append(fin)

    # A tiny rotary survey head gives the field emitter a readable, animated focal point.
    _sensor_spinner = Node3D.new()
    _sensor_spinner.name = "SurveySensorRotor"
    _sensor_spinner.position = Vector3(0.0, 0.012, -0.185)
    _rig.add_child(_sensor_spinner)
    var sensor_hub_mesh := SphereMesh.new()
    sensor_hub_mesh.radius = 0.018
    sensor_hub_mesh.height = 0.036
    var sensor_hub := MeshInstance3D.new()
    sensor_hub.name = "SensorRotorHub"
    sensor_hub.mesh = sensor_hub_mesh
    sensor_hub.material_override = _core_material
    _sensor_spinner.add_child(sensor_hub)
    for blade_index in range(4):
        var blade := BoxMesh.new()
        blade.size = Vector3(0.064, 0.008, 0.012)
        var blade_node := MeshInstance3D.new()
        blade_node.name = "SensorRotorBlade_%d" % blade_index
        blade_node.mesh = blade
        blade_node.material_override = accent
        blade_node.rotation.z = float(blade_index) * PI * 0.5
        blade_node.position = Vector3(0.0, 0.0, -0.006)
        _sensor_spinner.add_child(blade_node)

    # Fine fasteners and shallow ventilation slots break up the large flat surfaces.
    for side: float in [-1.0, 1.0]:
        for index in range(5):
            var fastener := CylinderMesh.new()
            fastener.top_radius = 0.006
            fastener.bottom_radius = 0.006
            fastener.height = 0.004
            var fastener_node := MeshInstance3D.new()
            fastener_node.name = "HousingFastener_%s_%d" % [str(side), index]
            fastener_node.mesh = fastener
            fastener_node.material_override = accent
            fastener_node.position = Vector3(side * 0.105, -0.045, -0.105 + float(index) * 0.048)
            fastener_node.rotation.x = PI * 0.5
            _rig.add_child(fastener_node)

    var sleeve_material := _make_material(Color("#263843"), 0.74, 0.16)
    var guard_material := _make_material(Color("#67777e"), 0.48, 0.58)
    var glove_material := _make_material(Color("#151f25"), 0.88, 0.04)
    var left_sleeve := CapsuleMesh.new()
    left_sleeve.radius = 0.055
    left_sleeve.height = 0.37
    _left_forearm = _add_mesh("LeftForearmGuard", left_sleeve, sleeve_material, Vector3(-0.118, -0.17, 0.16))
    _left_forearm.rotation.z = deg_to_rad(-31.0)
    var right_sleeve := CapsuleMesh.new()
    right_sleeve.radius = 0.055
    right_sleeve.height = 0.37
    _right_forearm = _add_mesh("RightForearmGuard", right_sleeve, sleeve_material, Vector3(0.118, -0.17, 0.18))
    _right_forearm.rotation.z = deg_to_rad(31.0)
    _add_box("LeftWristCuff", Vector3(-0.12, -0.236, 0.12), Vector3(0.116, 0.038, 0.085), accent)
    _add_box("RightWristCuff", Vector3(0.12, -0.236, 0.16), Vector3(0.116, 0.038, 0.085), accent)
    _add_box("LeftGlovePalm", Vector3(-0.102, -0.25, -0.005), Vector3(0.105, 0.07, 0.12), glove_material)
    _add_box("RightGlovePalm", Vector3(0.102, -0.25, -0.015), Vector3(0.105, 0.07, 0.12), glove_material)
    _add_box("LeftGuardPlate", Vector3(-0.12, -0.16, 0.02), Vector3(0.075, 0.11, 0.027), guard_material)
    _add_box("RightGuardPlate", Vector3(0.12, -0.16, 0.02), Vector3(0.075, 0.11, 0.027), guard_material)

    # Simplified articulated glove fingers, deliberately stylized rather than anatomical.
    for side: float in [-1.0, 1.0]:
        for finger_index in range(4):
            var finger_mesh := CapsuleMesh.new()
            finger_mesh.radius = 0.0105
            finger_mesh.height = 0.066
            var finger_node := _add_mesh("GloveFinger_%s_%d" % [str(side), finger_index], finger_mesh, glove_material,
                Vector3(side * 0.102 + (float(finger_index) - 1.5) * 0.021, -0.252, -0.065))
            finger_node.rotation.x = PI * 0.5
            _finger_segments.append(finger_node)
        var thumb_mesh := CapsuleMesh.new()
        thumb_mesh.radius = 0.012
        thumb_mesh.height = 0.075
        var thumb_node := _add_mesh("GloveThumb_%s" % str(side), thumb_mesh, glove_material,
            Vector3(side * 0.158, -0.237, -0.018))
        thumb_node.rotation = Vector3(deg_to_rad(68.0), 0.0, deg_to_rad(side * -34.0))

    _wrist_display = _add_box("WristStatusDisplay", Vector3(-0.12, -0.132, 0.005), Vector3(0.052, 0.012, 0.066), _display_material)
    for index in range(3):
        var indicator := _add_box("WristIndicator_%d" % index,
            Vector3(-0.12 + float(index - 1) * 0.021, -0.112, -0.026),
            Vector3(0.010, 0.006, 0.012), _glow_material)
        _wrist_indicators.append(indicator)
    _scan_glow = _add_sphere("ScanPulseGlow", _glow_material, Vector3(0.0, 0.012, -0.20), 0.07)
    _scan_glow.visible = false
    _activation_glow = _add_sphere("ActivationPulseGlow", _core_material, Vector3(0.0, 0.012, -0.22), 0.055)
    _activation_glow.visible = false
    _activation_light = OmniLight3D.new()
    _activation_light.name = "ActivationGlowLight"
    _activation_light.position = Vector3(0.0, 0.01, -0.23)
    _activation_light.light_color = Color("#69eaff")
    _activation_light.omni_range = 1.15
    _activation_light.light_energy = 0.0
    _activation_light.shadow_enabled = false
    _rig.add_child(_activation_light)

func _make_material(color: Color, roughness: float, metallic: float) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = roughness
    material.metallic = metallic
    return material

func _make_emissive_material(color: Color, energy: float) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = color.darkened(0.22)
    material.emission_enabled = true
    material.emission = color
    material.emission_energy_multiplier = energy
    material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    return material

func _add_box(node_name: String, local_position: Vector3, box_size: Vector3, material: Material, local_rotation: Vector3 = Vector3.ZERO) -> MeshInstance3D:
    var mesh := BoxMesh.new()
    mesh.size = box_size
    var instance := MeshInstance3D.new()
    instance.name = node_name
    instance.mesh = mesh
    instance.material_override = material
    instance.position = local_position
    instance.rotation = local_rotation
    _rig.add_child(instance)
    return instance

func _add_sphere(node_name: String, material: Material, local_position: Vector3, radius: float) -> MeshInstance3D:
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    return _add_mesh(node_name, mesh, material, local_position)

func _add_mesh(node_name: String, mesh: Mesh, material: Material, local_position: Vector3) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    instance.name = node_name
    instance.mesh = mesh
    instance.material_override = material
    instance.position = local_position
    _rig.add_child(instance)
    return instance

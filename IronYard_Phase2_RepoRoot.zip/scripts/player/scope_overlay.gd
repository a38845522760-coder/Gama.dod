extends Control

## Scope view shown while zoomed. The reticle depends on the gun:
##   iron   - open sights: four small ticks, almost no darkening
##   reddot - a red dot inside a thin ring
##   holo   - ring reticle with a centre dot, light vignette
##   scope  - full scope: dark rim, crosshair, mil-dots
##   sniper - long-range scope: thicker rim, finer crosshair, range marks
## `amount` (0..1) is driven by the player's zoom blend. No class_name on purpose.

var style: String = "iron":
    set(value):
        style = value
        queue_redraw()

var amount: float = 0.0:
    set(value):
        amount = clampf(value, 0.0, 1.0)
        visible = amount > 0.02
        queue_redraw()

func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    visible = false

func _draw() -> void:
    if amount <= 0.02:
        return
    var c := size * 0.5
    match style:
        "iron":
            _vignette(c, minf(size.x, size.y) * 0.62, 0.35)
            var tick := Color(1, 1, 1, 0.85 * amount)
            for dir in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
                draw_line(c + dir * 14.0, c + dir * 30.0, tick, 3.0, true)
            draw_circle(c, 2.0, Color(1.0, 0.3, 0.2, 0.9 * amount))
        "reddot":
            _vignette(c, minf(size.x, size.y) * 0.6, 0.4)
            draw_arc(c, 34.0, 0.0, TAU, 48, Color(1.0, 0.25, 0.2, 0.55 * amount), 2.0, true)
            draw_circle(c, 4.0, Color(1.0, 0.2, 0.15, 0.95 * amount))
        "holo":
            _vignette(c, minf(size.x, size.y) * 0.55, 0.55)
            var col := Color(0.35, 1.0, 0.55, 0.9 * amount)
            draw_arc(c, 46.0, 0.0, TAU, 64, col, 2.5, true)
            for k in range(4):
                var dir := Vector2.from_angle(float(k) * PI * 0.5)
                draw_line(c + dir * 46.0, c + dir * 60.0, col, 2.5, true)
            draw_circle(c, 3.0, col)
        "sniper":
            _scope(c, 0.5, true)
        _:
            _scope(c, 0.46, false)

func _vignette(c: Vector2, r: float, strength: float) -> void:
    var width := maxf(c.length() - r + 8.0, 1.0)
    draw_arc(c, r + width * 0.5, 0.0, TAU, 96, Color(0, 0, 0, strength * amount), width, true)

func _scope(c: Vector2, ratio: float, long_range: bool) -> void:
    var r := minf(size.x, size.y) * ratio
    var width := c.length() - r + 8.0
    draw_arc(c, r + width * 0.5, 0.0, TAU, 96, Color(0, 0, 0, 0.94 * amount), width, true)
    draw_arc(c, r, 0.0, TAU, 96, Color(0, 0, 0, 0.9 * amount), 4.0 if long_range else 3.0, true)
    var line := Color(0.05, 0.05, 0.05, 0.8 * amount)
    var gap := 26.0 if long_range else 18.0
    draw_line(c + Vector2(-r, 0.0), c + Vector2(-gap, 0.0), line, 2.0, true)
    draw_line(c + Vector2(gap, 0.0), c + Vector2(r, 0.0), line, 2.0, true)
    draw_line(c + Vector2(0.0, -r), c + Vector2(0.0, -gap), line, 2.0, true)
    draw_line(c + Vector2(0.0, gap), c + Vector2(0.0, r), line, 2.0, true)
    if long_range:
        for k in range(1, 6):
            var y := gap + float(k) * 26.0
            draw_line(c + Vector2(-8.0, y), c + Vector2(8.0, y), line, 2.0, true)
            draw_line(c + Vector2(-y, -4.0), c + Vector2(-y, 4.0), line, 2.0, true)
            draw_line(c + Vector2(y, -4.0), c + Vector2(y, 4.0), line, 2.0, true)
    draw_circle(c, 2.0, Color(1.0, 0.25, 0.2, 0.9 * amount))

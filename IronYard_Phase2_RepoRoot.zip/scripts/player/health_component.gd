extends Node
class_name HealthComponent

signal health_changed(current: float, maximum: float)
signal depleted

@export_range(1.0, 1000.0, 1.0) var max_health: float = 100.0
var current_health: float = 100.0
var _depleted_emitted: bool = false

func _ready() -> void:
    max_health = maxf(1.0, max_health)
    current_health = max_health

func apply_damage(amount: float, _source: Node = null) -> float:
    if amount <= 0.0 or current_health <= 0.0:
        return current_health
    current_health = maxf(0.0, current_health - amount)
    health_changed.emit(current_health, max_health)
    if current_health <= 0.0 and not _depleted_emitted:
        _depleted_emitted = true
        depleted.emit()
    return current_health

func restore(amount: float) -> float:
    if amount <= 0.0 or current_health <= 0.0:
        return current_health
    current_health = minf(max_health, current_health + amount)
    health_changed.emit(current_health, max_health)
    return current_health

func reset() -> void:
    current_health = max_health
    _depleted_emitted = false
    health_changed.emit(current_health, max_health)

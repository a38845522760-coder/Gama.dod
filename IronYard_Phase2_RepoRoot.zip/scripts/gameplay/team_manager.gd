extends Node
class_name TeamManager

signal scores_changed(alpha_score: int, bravo_score: int)
signal kill_event(message: String)

const TEAM_ALPHA := &"alpha"
const TEAM_BRAVO := &"bravo"

var alpha_score: int = 0
var bravo_score: int = 0

func _ready() -> void:
	add_to_group("team_manager")

func register_elimination(killer_team: StringName, victim_name: String, victim_team: StringName) -> void:
	if killer_team == TEAM_ALPHA and victim_team == TEAM_BRAVO:
		alpha_score += 1
	elif killer_team == TEAM_BRAVO and victim_team == TEAM_ALPHA:
		bravo_score += 1
	scores_changed.emit(alpha_score, bravo_score)
	var tag := "ALPHA" if killer_team == TEAM_ALPHA else "BRAVO"
	kill_event.emit("%s eliminated %s" % [tag, victim_name])

func get_scores() -> Dictionary:
	return {"alpha": alpha_score, "bravo": bravo_score}

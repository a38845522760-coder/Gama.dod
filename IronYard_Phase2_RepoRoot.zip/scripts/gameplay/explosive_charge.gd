extends Node3D
class_name ExplosiveCharge

## Placed explosive (dynamite with a timer, or a remote-detonated bomb).
## fuse < 0 means "wait for detonate()".

var thrower: Node = null
var radius: float = 9.0
var damage: float = 260.0
var fuse: float = 3.5
var body_color: Color = Color("#b8302a")
var _blink: float = 0.0
var _done: bool = false

func _ready() -> void:
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(0.36, 0.14, 0.22) if fuse >= 0.0 else Vector3(0.3, 0.1, 0.3)
    mesh.mesh = box
    var material := StandardMaterial3D.new()
    material.albedo_color = body_color
    material.roughness = 0.6
    material.emission_enabled = true
    material.emission = Color("#ff3b2e")
    material.emission_energy_multiplier = 0.5
    mesh.material_override = material
    mesh.position = Vector3(0.0, 0.07, 0.0)
    add_child(mesh)

func _process(delta: float) -> void:
    if _done:
        return
    _blink += delta
    scale = Vector3.ONE * (1.0 + 0.06 * sin(_blink * 14.0))
    if fuse >= 0.0:
        fuse -= delta
        if fuse <= 0.0:
            detonate()

func detonate() -> void:
    if _done:
        return
    _done = true
    var center: Vector3 = global_position + Vector3(0.0, 0.4, 0.0)
    for node in get_tree().get_nodes_in_group("combatants"):
        if not (node is Node3D) or not CombatUtil.is_alive(node):
            continue
        if thrower != null and not CombatUtil.is_hostile(thrower, node):
            continue
        var target_point: Vector3 = (node as Node3D).global_position + Vector3(0.0, 0.9, 0.0)
        var distance: float = center.distance_to(target_point)
        if distance > radius:
            continue
        var amount: float = damage * (1.0 - distance / radius * 0.8)
        var direction: Vector3 = (target_point - center).normalized()
        CombatUtil.apply_damage(node, amount, thrower, {
            "position": target_point, "direction": direction, "normal": -direction,
            "weapon_id": "explosive", "headshot_multiplier": 1.0,
        })
    var parent: Node = get_parent()
    var flash := OmniLight3D.new()
    flash.light_color = Color("#ffb04a")
    flash.light_energy = 7.0
    flash.omni_range = radius * 1.6
    flash.shadow_enabled = false
    flash.add_to_group("no_shadow")
    parent.add_child(flash)
    flash.global_position = center
    var ball := MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 1.0
    sphere.height = 2.0
    ball.mesh = sphere
    var fire := StandardMaterial3D.new()
    fire.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    fire.albedo_color = Color(1.0, 0.6, 0.2, 0.85)
    fire.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    ball.material_override = fire
    parent.add_child(ball)
    ball.global_position = center
    ball.scale = Vector3.ONE * 0.4
    var tween := ball.create_tween()
    tween.set_parallel(true)
    tween.tween_property(ball, "scale", Vector3.ONE * radius * 0.55, 0.35)
    tween.tween_property(fire, "albedo_color:a", 0.0, 0.4)
    tween.chain().tween_callback(func() -> void:
        if is_instance_valid(ball):
            ball.queue_free()
        if is_instance_valid(flash):
            flash.queue_free())
    queue_free()

extends Node
class_name FieldKit

## Two extra items (grenade, dynamite, bomb, knife) and one support power (unlimited ammo,
## invisibility, shield, rage). The player picks them in the Loadout screen; they work in
## every game mode. Items are refilled when the player respawns (and with wave supplies).

signal changed

const ITEMS: Dictionary = {
    "grenade": {"name_fa": "نارنجک", "name_en": "Grenade", "count": 3,
        "desc_fa": "پرتاب می‌شود و بعد از چند ثانیه منفجر می‌شود.", "desc_en": "Thrown, explodes after a short fuse."},
    "dynamite": {"name_fa": "دینامیت", "name_en": "Dynamite", "count": 2,
        "desc_fa": "روی زمین می‌گذاری، بعد از ۳ ثانیه با انفجار بزرگ می‌ترکد.", "desc_en": "Placed on the ground, big blast after 3 seconds."},
    "bomb": {"name_fa": "بمب (کنترلی)", "name_en": "Remote bomb", "count": 1,
        "desc_fa": "می‌گذاری و هر وقت خواستی با دکمه‌ی دوباره منفجرش می‌کنی. خیلی قوی.", "desc_en": "Place it, press again to detonate. Very strong."},
    "knife": {"name_fa": "چاقو", "name_en": "Knife", "count": -1,
        "desc_fa": "ضربه‌ی نزدیک و سریع، بی‌نهایت.", "desc_en": "Fast close-range stab, unlimited."},
}
const POWERS: Dictionary = {
    "infinite_ammo": {"name_fa": "تیر نامحدود", "name_en": "Infinite ammo", "duration": 10.0, "cooldown": 45.0,
        "desc_fa": "۱۰ ثانیه هیچ تیری کم نمی‌شود.", "desc_en": "No ammo is used for 10 seconds."},
    "invisible": {"name_fa": "نامرئی", "name_en": "Invisibility", "duration": 9.0, "cooldown": 55.0,
        "desc_fa": "۹ ثانیه دشمن‌ها از دور نمی‌بیننت.", "desc_en": "Enemies lose sight of you for 9 seconds."},
    "shield": {"name_fa": "سپر", "name_en": "Shield", "duration": 12.0, "cooldown": 50.0,
        "desc_fa": "۱۲ ثانیه تقریباً ضدگلوله می‌شوی.", "desc_en": "Take very little damage for 12 seconds."},
    "rage": {"name_fa": "خشم", "name_en": "Rage", "duration": 10.0, "cooldown": 50.0,
        "desc_fa": "۱۰ ثانیه ضربه‌ی تفنگ‌ها ۷۰٪ بیشتر.", "desc_en": "+70% weapon damage for 10 seconds."},
}
const DEFAULT_LOADOUT: Dictionary = {"item1": "grenade", "item2": "dynamite", "power": "shield"}

var _player: CharacterBody3D
var _camera: Camera3D
var _slots: Array[String] = ["grenade", "dynamite"]
var _counts: Array[int] = [3, 2]
var _power_id: String = "shield"
var _power_left: float = 0.0
var _power_cooldown: float = 0.0
var _power_total: float = 1.0
var _item_cooldown: float = 0.0
var _bomb: ExplosiveCharge = null

static func get_loadout() -> Dictionary:
    var raw: Variant = SaveManager.get_progress("loadout", {})
    var result: Dictionary = DEFAULT_LOADOUT.duplicate()
    if raw is Dictionary:
        for key in ["item1", "item2"]:
            if (raw as Dictionary).has(key) and ITEMS.has(str((raw as Dictionary)[key])):
                result[key] = str((raw as Dictionary)[key])
        if (raw as Dictionary).has("power") and POWERS.has(str((raw as Dictionary)["power"])):
            result["power"] = str((raw as Dictionary)["power"])
    return result

static func set_loadout(key: String, id: String) -> void:
    var loadout: Dictionary = get_loadout()
    if key == "item1" or key == "item2":
        var other_key: String = "item2" if key == "item1" else "item1"
        if str(loadout[other_key]) == id:
            loadout[other_key] = str(loadout[key])
    loadout[key] = id
    SaveManager.set_progress("loadout", loadout)
    SaveManager.flush()

func setup(player: CharacterBody3D) -> void:
    _player = player
    _camera = player.get_node_or_null("CameraPivot/Camera3D") as Camera3D
    add_to_group("field_kit")
    _ensure_actions()
    var loadout: Dictionary = get_loadout()
    _slots = [str(loadout["item1"]), str(loadout["item2"])]
    _power_id = str(loadout["power"])
    refill()
    if player.has_signal("respawned"):
        player.connect("respawned", _on_respawned)

func _ensure_actions() -> void:
    for pair in [["item1", KEY_Z], ["item2", KEY_V], ["power", KEY_B]]:
        var action: String = str(pair[0])
        if not InputMap.has_action(action):
            InputMap.add_action(action)
            var event := InputEventKey.new()
            event.physical_keycode = int(pair[1]) as Key
            InputMap.action_add_event(action, event)

func refill() -> void:
    _counts = [int((ITEMS[_slots[0]] as Dictionary)["count"]), int((ITEMS[_slots[1]] as Dictionary)["count"])]
    changed.emit()

func _on_respawned() -> void:
    refill()
    _end_power()
    _power_cooldown = 0.0

# ---------------------------------------------------------------- queries for the HUD

func get_slot_id(slot: int) -> String:
    return _slots[clampi(slot, 0, 1)]

func get_slot_count(slot: int) -> int:
    return _counts[clampi(slot, 0, 1)]

func get_power_id() -> String:
    return _power_id

func is_power_active() -> bool:
    return _power_left > 0.0

## 0 = ready, 1 = just used.
func get_power_cooldown_fraction() -> float:
    if _power_left > 0.0:
        return 0.0
    return clampf(_power_cooldown / maxf(_power_total, 0.01), 0.0, 1.0)

func is_bomb_armed() -> bool:
    return _bomb != null and is_instance_valid(_bomb)

# ---------------------------------------------------------------- input

func _process(delta: float) -> void:
    if _player == null or not is_instance_valid(_player):
        return
    _item_cooldown = maxf(0.0, _item_cooldown - delta)
    if _power_left > 0.0:
        _power_left -= delta
        if _power_left <= 0.0:
            _end_power()
    elif _power_cooldown > 0.0:
        _power_cooldown = maxf(0.0, _power_cooldown - delta)
    if bool(_player.call("is_dead")):
        return
    if Input.is_action_just_pressed("item1"):
        use_item(0)
    elif Input.is_action_just_pressed("item2"):
        use_item(1)
    elif Input.is_action_just_pressed("power"):
        use_power()

func use_item(slot: int) -> bool:
    if _player == null or _camera == null or _item_cooldown > 0.0 or bool(_player.call("is_dead")):
        return false
    var id: String = get_slot_id(slot)
    # A planted remote bomb is detonated by pressing its button again.
    if id == "bomb" and is_bomb_armed():
        _bomb.detonate()
        _bomb = null
        _item_cooldown = 0.4
        changed.emit()
        return true
    var count: int = get_slot_count(slot)
    if count == 0:
        return false
    var used: bool = false
    match id:
        "grenade":
            used = _throw_grenade()
        "dynamite":
            used = _place_charge(3.5, 9.5, 270.0, Color("#b8302a"))
        "bomb":
            var charge: ExplosiveCharge = _place_charge_node(-1.0, 13.0, 420.0, Color("#2b2f33"))
            if charge != null:
                _bomb = charge
                used = true
        "knife":
            used = _stab()
    if used:
        if count > 0:
            _counts[clampi(slot, 0, 1)] = count - 1
        _item_cooldown = 0.55
        changed.emit()
    return used

func _throw_grenade() -> bool:
    var projectile := GrenadeProjectile.new()
    projectile.thrower = _player
    projectile.velocity = -_camera.global_transform.basis.z * 17.0 + Vector3.UP * 4.5 + _player.velocity * 0.4
    _player.get_parent().add_child(projectile)
    projectile.global_position = _camera.global_position + (-_camera.global_transform.basis.z) * 0.8
    return true

func _place_charge(fuse_time: float, radius: float, damage: float, color: Color) -> bool:
    return _place_charge_node(fuse_time, radius, damage, color) != null

func _place_charge_node(fuse_time: float, radius: float, damage: float, color: Color) -> ExplosiveCharge:
    var forward: Vector3 = -_player.global_transform.basis.z
    forward.y = 0.0
    forward = forward.normalized()
    var from_point: Vector3 = _player.global_position + forward * 1.5 + Vector3.UP * 1.5
    var space: PhysicsDirectSpaceState3D = _player.get_world_3d().direct_space_state
    var query := PhysicsRayQueryParameters3D.create(from_point, from_point + Vector3.DOWN * 4.0, 1)
    query.exclude = [_player.get_rid()]
    var hit: Dictionary = space.intersect_ray(query)
    var ground: Vector3 = _player.global_position
    if not hit.is_empty():
        ground = hit["position"]
    var charge := ExplosiveCharge.new()
    charge.thrower = _player
    charge.fuse = fuse_time
    charge.radius = radius
    charge.damage = damage
    charge.body_color = color
    _player.get_parent().add_child(charge)
    charge.global_position = ground + Vector3(0.0, 0.02, 0.0)
    return charge

func _stab() -> bool:
    var origin: Vector3 = _camera.global_position
    var direction: Vector3 = -_camera.global_transform.basis.z
    var space: PhysicsDirectSpaceState3D = _player.get_world_3d().direct_space_state
    var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * 2.6, 1)
    query.exclude = [_player.get_rid()]
    query.collide_with_areas = false
    var hit: Dictionary = space.intersect_ray(query)
    if _player.has_method("add_recoil"):
        _player.call("add_recoil", 0.012, 0.0)
    if hit.is_empty():
        return true
    var collider: Object = hit["collider"]
    if collider != null and collider.has_method("receive_hit"):
        collider.call("receive_hit", {
            "damage": 115.0, "position": hit["position"], "normal": hit["normal"], "direction": direction,
            "source": _player, "weapon_id": "knife", "headshot_multiplier": 1.0,
        })
    return true

func use_power() -> bool:
    if _player == null or bool(_player.call("is_dead")) or _power_left > 0.0 or _power_cooldown > 0.0:
        return false
    var def: Dictionary = POWERS[_power_id]
    var duration: float = float(def["duration"])
    _power_left = duration
    _power_total = float(def["cooldown"])
    _power_cooldown = _power_total
    var weapon: Node = _player.get_node_or_null("WeaponController")
    match _power_id:
        "infinite_ammo":
            if weapon != null and weapon.has_method("set_infinite_ammo"):
                weapon.call("set_infinite_ammo", duration)
        "invisible":
            _player.set_meta("invisible_until", Time.get_ticks_msec() / 1000.0 + duration)
        "shield":
            var health := _player.get_node_or_null("HealthComponent") as HealthComponent
            if health != null:
                health.damage_scale = 0.15
        "rage":
            if weapon != null and weapon.has_method("set_power_damage"):
                weapon.call("set_power_damage", 1.7, duration)
    changed.emit()
    return true

func _end_power() -> void:
    _power_left = 0.0
    if _player == null or not is_instance_valid(_player):
        return
    var health := _player.get_node_or_null("HealthComponent") as HealthComponent
    if health != null:
        health.damage_scale = 1.0
    if _player.has_meta("invisible_until"):
        _player.set_meta("invisible_until", 0.0)
    var weapon: Node = _player.get_node_or_null("WeaponController")
    if weapon != null:
        if weapon.has_method("set_infinite_ammo"):
            weapon.call("set_infinite_ammo", 0.0)
        if weapon.has_method("set_power_damage"):
            weapon.call("set_power_damage", 1.0, 0.0)
    changed.emit()

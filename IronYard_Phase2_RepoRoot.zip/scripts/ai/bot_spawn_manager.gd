extends Node
class_name BotSpawnManager

const BOT_SCRIPT := preload("res://scripts/ai/bot_agent.gd")

@export var respawn_delay: float = 4.0

var _alpha_spawns: Array[Vector3] = []
var _bravo_spawns: Array[Vector3] = []
var _all_patrol: Array[Vector3] = []
var _team_manager: TeamManager

func initialize_bots(spawn_coords: Array[Vector3], team_mgr: TeamManager) -> void:
	_team_manager = team_mgr
	_all_patrol = spawn_coords.duplicate()
	_alpha_spawns.clear()
	_bravo_spawns.clear()

	for i in range(spawn_coords.size()):
		if i % 2 == 0:
			_alpha_spawns.append(spawn_coords[i])
		else:
			_bravo_spawns.append(spawn_coords[i])

	if _alpha_spawns.is_empty():
		_alpha_spawns.append(Vector3(0, 0.2, 40))
	if _bravo_spawns.is_empty():
		_bravo_spawns.append(Vector3(0, 0.2, -40))

	var per_team := int(SettingsManager.get_setting("bots_per_team", 4))
	var ally_count := maxi(1, per_team - 1)
	var enemy_count := maxi(1, per_team)

	for i in range(ally_count):
		var pos := _alpha_spawns[i % _alpha_spawns.size()] + Vector3(float(i) * 2.2 - 1.5, 0.2, 0.0)
		_spawn_bot(&"alpha", "Alpha-%d" % (i + 1), pos)

	for i in range(enemy_count):
		var pos := _bravo_spawns[i % _bravo_spawns.size()] + Vector3(float(i) * 2.2 - 1.5, 0.2, 0.0)
		_spawn_bot(&"bravo", "Bravo-%d" % (i + 1), pos)

func _spawn_bot(team: StringName, b_name: String, pos: Vector3) -> void:
	var bot: BotAgent = BOT_SCRIPT.new()
	bot.name = b_name
	bot.position = pos
	bot.setup(team, b_name, _all_patrol)
	bot.eliminated.connect(_on_bot_eliminated)
	get_parent().add_child(bot)

func _on_bot_eliminated(bot: BotAgent, killer_team: StringName) -> void:
	if _team_manager != null:
		_team_manager.register_elimination(killer_team, bot.bot_name, bot.team_id)
	get_tree().create_timer(respawn_delay).timeout.connect(func() -> void:
		if not is_instance_valid(bot):
			return
		var pool := _alpha_spawns if bot.team_id == &"alpha" else _bravo_spawns
		var sp := pool[randi() % pool.size()] + Vector3(randf_range(-2.0, 2.0), 0.2, randf_range(-2.0, 2.0))
		bot.respawn_at(Transform3D(Basis(), sp))
	)

extends CharacterBody3D
class_name BotAgent

signal eliminated(bot: BotAgent, killer_team: StringName)

@export var team_id: StringName = &"bravo"
@export var bot_name: String = "Unit"
@export var move_speed: float = 4.6
@export var max_health: float = 100.0

var current_health: float = 100.0
var _is_alive: bool = true
var _gravity: float = 18.0
var _patrol_points: Array[Vector3] = []
var _patrol_index: int = 0
var _target: Node3D = null
var _fire_cooldown: float = 0.0
var _retarget_timer: float = 0.0
var _strafe_dir: float = 1.0
var _strafe_timer: float = 1.5
var _stuck_timer: float = 0.0
var _last_pos: Vector3 = Vector3.ZERO
var _escape_dir: Vector3 = Vector3.ZERO
var _escape_timer: float = 0.0

var _visual_root: Node3D
var _body_mat: StandardMaterial3D
var _visor_mat: StandardMaterial3D
var _tracer_mat: StandardMaterial3D
var _muzzle_point: Marker3D
var _hit_flash_left: float = 0.0

func _ready() -> void:
	add_to_group("combatant")
	add_to_group("bot_agent")
	add_to_group("team_" + String(team_id))
	collision_layer = 1
	collision_mask = 1
	current_health = max_health
	_strafe_dir = 1.0 if randf() > 0.5 else -1.0
	_build_capsule_and_visuals()
	_last_pos = global_position

func setup(p_team: StringName, p_name: String, patrol_pts: Array[Vector3]) -> void:
	team_id = p_team
	bot_name = p_name
	_patrol_points = patrol_pts
	_patrol_index = randi() % maxi(1, _patrol_points.size())
	if is_inside_tree():
		_apply_team_colors()

func respawn_at(spawn_transform: Transform3D) -> void:
	global_transform = spawn_transform
	velocity = Vector3.ZERO
	current_health = max_health
	_is_alive = true
	_target = null
	visible = true
	$CollisionShape3D.disabled = false
	_last_pos = global_position

func apply_damage(amount: float, attacker_team: StringName = &"") -> void:
	if not _is_alive:
		return
	if attacker_team == team_id:
		return
	current_health -= amount
	_hit_flash_left = 0.12
	if current_health <= 0.0:
		current_health = 0.0
		_is_alive = false
		visible = false
		$CollisionShape3D.disabled = true
		eliminated.emit(self, attacker_team)

func _physics_process(delta: float) -> void:
	if not _is_alive:
		return

	if _hit_flash_left > 0.0:
		_hit_flash_left = maxf(0.0, _hit_flash_left - delta)
		if _body_mat != null:
			_body_mat.emission_enabled = _hit_flash_left > 0.0
			_body_mat.emission = Color.WHITE
			_body_mat.emission_energy_multiplier = 1.6 if _hit_flash_left > 0.0 else 0.0

	if not is_on_floor():
		velocity.y = maxf(velocity.y - _gravity * delta, -24.0)
	else:
		velocity.y = 0.0

	_fire_cooldown = maxf(0.0, _fire_cooldown - delta)
	_retarget_timer -= delta
	if _retarget_timer <= 0.0:
		_retarget_timer = 0.35
		_target = _find_best_enemy()

	var desired_dir := Vector3.ZERO
	if _escape_timer > 0.0:
		_escape_timer -= delta
		desired_dir = _escape_dir
	elif is_instance_valid(_target) and _has_line_of_sight(_target):
		var to_target := _target.global_position - global_position
		to_target.y = 0.0
		var dist := to_target.length()
		var fwd := to_target.normalized() if dist > 0.1 else -global_transform.basis.z
		_face_direction(fwd, delta)

		_strafe_timer -= delta
		if _strafe_timer <= 0.0:
			_strafe_timer = randf_range(1.1, 2.4)
			_strafe_dir = -_strafe_dir

		var right := Vector3(-fwd.z, 0.0, fwd.x)
		if dist > 22.0:
			desired_dir = (fwd + right * _strafe_dir * 0.45).normalized()
		elif dist < 10.0:
			desired_dir = (-fwd * 0.6 + right * _strafe_dir * 0.8).normalized()
		else:
			desired_dir = right * _strafe_dir

		if _fire_cooldown <= 0.0:
			_fire_cooldown = randf_range(0.45, 0.72)
			_fire_at_target(_target)
	else:
		var nav_goal := _get_navigation_goal()
		var to_goal := nav_goal - global_position
		to_goal.y = 0.0
		if to_goal.length() < 3.0:
			if not _patrol_points.is_empty():
				_patrol_index = (_patrol_index + 1) % _patrol_points.size()
		else:
			desired_dir = to_goal.normalized()
			_face_direction(desired_dir, delta)

	# Multi-ray obstacle avoidance steering
	if desired_dir.length_squared() > 0.01:
		desired_dir = _steer_around_obstacles(desired_dir)

	velocity.x = lerpf(velocity.x, desired_dir.x * move_speed, 1.0 - exp(-8.0 * delta))
	velocity.z = lerpf(velocity.z, desired_dir.z * move_speed, 1.0 - exp(-8.0 * delta))
	move_and_slide()

	# Jump over low obstacles or recover if stuck
	if is_on_wall() and is_on_floor() and randf() < 0.15:
		velocity.y = 5.2
	_stuck_timer += delta
	if _stuck_timer >= 0.9:
		_stuck_timer = 0.0
		if desired_dir.length_squared() > 0.2 and global_position.distance_to(_last_pos) < 0.45:
			var angle := randf_range(PI * 0.45, PI * 0.85) * (1.0 if randf() > 0.5 else -1.0)
			_escape_dir = desired_dir.rotated(Vector3.UP, angle).normalized()
			_escape_timer = 0.75
		_last_pos = global_position

func _get_navigation_goal() -> Vector3:
	if team_id == &"alpha":
		var players := get_tree().get_nodes_in_group("player_controller")
		if not players.is_empty():
			var p := players[0] as Node3D
			var dist := global_position.distance_to(p.global_position)
			if dist > 16.0:
				return p.global_position
	if not _patrol_points.is_empty():
		return _patrol_points[_patrol_index]
	return global_position

func _steer_around_obstacles(desired: Vector3) -> Vector3:
	if get_world_3d() == null:
		return desired
	var space := get_world_3d().direct_space_state
	var origin := global_position + Vector3(0.0, 1.0, 0.0)
	var angles := [0.0, 0.52, -0.52, 1.05, -1.05]
	var weights := [1.0, 0.6, 0.6, 0.35, 0.35]
	var accum := Vector3.ZERO
	var blocked_front := false

	for i in range(angles.size()):
		var ray_dir := desired.rotated(Vector3.UP, angles[i]).normalized()
		var q := PhysicsRayQueryParameters3D.create(origin, origin + ray_dir * 3.4, 1, [get_rid()])
		q.collide_with_areas = false
		var hit := space.intersect_ray(q)
		if hit.is_empty():
			accum += ray_dir * weights[i]
		elif i == 0:
			blocked_front = true

	if blocked_front and accum.length_squared() > 0.01:
		return accum.normalized()
	return desired if not blocked_front else desired.rotated(Vector3.UP, PI * 0.5 * _strafe_dir)

func _find_best_enemy() -> Node3D:
	var best: Node3D = null
	var best_dist := 58.0
	for node in get_tree().get_nodes_in_group("combatant"):
		if not (node is Node3D) or node == self:
			continue
		var other := node as Node3D
		if not other.visible:
			continue
		var other_team: StringName = other.get("team_id") if "team_id" in other else &"alpha"
		if other_team == team_id:
			continue
		var d := global_position.distance_to(other.global_position)
		if d < best_dist and _has_line_of_sight(other):
			best_dist = d
			best = other
	return best

func _has_line_of_sight(target_node: Node3D) -> bool:
	if get_world_3d() == null:
		return false
	var from_pos := global_position + Vector3(0.0, 1.45, 0.0)
	var to_pos := target_node.global_position + Vector3(0.0, 1.25, 0.0)
	var q := PhysicsRayQueryParameters3D.create(from_pos, to_pos, 1, [get_rid()])
	q.collide_with_areas = false
	var res := get_world_3d().direct_space_state.intersect_ray(q)
	if res.is_empty():
		return true
	var col: Object = res.get("collider", null)
	return col == target_node

func _fire_at_target(target_node: Node3D) -> void:
	if get_world_3d() == null or get_tree() == null:
		return
	var start := _muzzle_point.global_position if _muzzle_point != null else global_position + Vector3(0.0, 1.35, 0.0)
	var aim_pos := target_node.global_position + Vector3(randf_range(-0.35, 0.35), randf_range(0.95, 1.45), randf_range(-0.35, 0.35))
	var dir := (aim_pos - start).normalized()
	var end_pos := start + dir * 65.0
	var q := PhysicsRayQueryParameters3D.create(start, end_pos, 1, [get_rid()])
	var res := get_world_3d().direct_space_state.intersect_ray(q)
	var hit_pos := end_pos
	if not res.is_empty():
		hit_pos = res["position"]
		var col: Object = res.get("collider", null)
		if col != null and col.has_method("apply_damage"):
			col.call("apply_damage", 11.0, team_id)
		elif col != null and col.get("health") != null:
			var hp := col.get("health")
			if hp != null and hp.has_method("apply_damage"):
				hp.call("apply_damage", 9.0)
	_spawn_bot_tracer(start, hit_pos)

func _spawn_bot_tracer(from_pos: Vector3, to_pos: Vector3) -> void:
	var scene_root := get_tree().current_scene if get_tree().current_scene != null else get_tree().root
	if scene_root == null or _tracer_mat == null:
		return
	var dist := from_pos.distance_to(to_pos)
	if dist < 0.2:
		return
	var bolt := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.025, 0.025, 0.75)
	bolt.mesh = bm
	bolt.material_override = _tracer_mat
	scene_root.add_child(bolt)
	bolt.global_position = from_pos
	var up_v := Vector3.UP if absf((to_pos - from_pos).normalized().dot(Vector3.UP)) < 0.98 else Vector3.RIGHT
	bolt.look_at(to_pos, up_v)
	var tween := bolt.create_tween()
	tween.tween_property(bolt, "global_position", to_pos, clampf(dist / 85.0, 0.05, 0.22))
	tween.tween_callback(bolt.queue_free)

func _face_direction(dir: Vector3, delta: float) -> void:
	if dir.length_squared() < 0.001:
		return
	var target_yaw := atan2(-dir.x, -dir.z)
	rotation.y = lerp_angle(rotation.y, target_yaw, 1.0 - exp(-10.0 * delta))

func _build_capsule_and_visuals() -> void:
	var col := CollisionShape3D.new()
	col.name = "CollisionShape3D"
	var cap := CapsuleShape3D.new()
	cap.radius = 0.36
	cap.height = 1.80
	col.shape = cap
	col.position.y = 0.90
	add_child(col)

	_visual_root = Node3D.new()
	_visual_root.name = "BotVisual"
	add_child(_visual_root)

	_body_mat = StandardMaterial3D.new()
	_visor_mat = StandardMaterial3D.new()
	_visor_mat.emission_enabled = true
	_visor_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_tracer_mat = StandardMaterial3D.new()
	_tracer_mat.emission_enabled = true
	_tracer_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_apply_team_colors()

	var dark_mat := StandardMaterial3D.new()
	dark_mat.albedo_color = Color("#1b2228")
	dark_mat.roughness = 0.75

	# Torso, Helmet, Visor, Legs, Arms, Rifle
	_add_part("Torso", Vector3(0, 1.08, 0), Vector3(0.46, 0.56, 0.28), _body_mat)
	_add_part("Head", Vector3(0, 1.56, 0), Vector3(0.30, 0.32, 0.30), _body_mat)
	_add_part("Visor", Vector3(0, 1.57, -0.155), Vector3(0.24, 0.10, 0.04), _visor_mat)
	_add_part("LegL", Vector3(-0.13, 0.42, 0), Vector3(0.18, 0.80, 0.20), dark_mat)
	_add_part("LegR", Vector3(0.13, 0.42, 0), Vector3(0.18, 0.80, 0.20), dark_mat)
	_add_part("ArmR", Vector3(0.30, 1.12, -0.14), Vector3(0.14, 0.14, 0.42), _body_mat)
	_add_part("ArmL", Vector3(-0.26, 1.08, -0.18), Vector3(0.14, 0.14, 0.40), _body_mat)
	_add_part("Rifle", Vector3(0.16, 1.12, -0.36), Vector3(0.08, 0.12, 0.56), dark_mat)

	_muzzle_point = Marker3D.new()
	_muzzle_point.position = Vector3(0.16, 1.14, -0.68)
	_visual_root.add_child(_muzzle_point)

func _apply_team_colors() -> void:
	if _body_mat == null:
		return
	var is_alpha := team_id == &"alpha"
	_body_mat.albedo_color = Color("#296b8f") if is_alpha else Color("#8f2c29")
	var accent := Color("#4ae6ff") if is_alpha else Color("#ff5038")
	_visor_mat.albedo_color = accent
	_visor_mat.emission = accent
	_visor_mat.emission_energy_multiplier = 2.5
	_tracer_mat.albedo_color = accent
	_tracer_mat.emission = accent
	_tracer_mat.emission_energy_multiplier = 4.5

func _add_part(p_name: String, pos: Vector3, sz: Vector3, mat: Material) -> void:
	var mi := MeshInstance3D.new()
	mi.name = p_name
	var bm := BoxMesh.new()
	bm.size = sz
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	_visual_root.add_child(mi)

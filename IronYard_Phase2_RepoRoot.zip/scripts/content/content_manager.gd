extends Node

## Downloadable content (autoload "ContentManager").
##
## Maps, weapons and characters ship as separate .pck packs hosted on a GitHub release.
## The APK stays small; the player downloads only what they want, and a pack is mounted
## (cheap, nothing is loaded into RAM) at startup. Only the scenes the match actually
## instantiates take memory. Packs must be data-only (scenes, meshes, textures, resources) -
## no scripts - so they can never break the base game.
##
## Flow: refresh_manifest() -> get_packs() -> install_pack(id) -> pack_installed(id)
##       -> load_pack_scene(id) / get_pack_meta(id).
## Offline: ready-made packs (<id>_v<version>.pck) copied to the phone can be installed with
##       scan_phone_folder() + import_from_file(path).

signal manifest_loaded(pack_count: int)
signal manifest_failed(reason: String)
signal pack_progress(pack_id: String, received: int, total: int)
signal pack_installed(pack_id: String)
signal pack_removed(pack_id: String)
signal pack_failed(pack_id: String, reason: String)

## The release that holds manifest.json and the .pck files. Can be overridden without a
## rebuild by writing a different URL into user://content/base_url.txt.
const DEFAULT_BASE_URL: String = "https://github.com/a38845522760-coder/Gama.dod/releases/download/content-v1/"
const OVERRIDE_URL_PATH: String = "user://content/base_url.txt"
const MANIFEST_CACHE_PATH: String = "user://content/manifest_cache.json"
const STATE_PATH: String = "user://content/installed.json"
const PACK_DIR: String = "user://content/packs"
const TMP_DIR: String = "user://content/tmp"
## Folders scanned for ready-made .pck files to import (phone storage, then a desktop test folder).
const IMPORT_DIRS: Array[String] = [
    "/storage/emulated/0/Download/IronYard",
    "/storage/emulated/0/IronYard",
    "/sdcard/Download/IronYard",
    "user://import",
]

var manifest_online: bool = false
var restart_required: bool = false

var _packs: Array = []
var _extras: Array = []
var _installed: Dictionary = {}
var _mounted: Dictionary = {}
var _downloads: Dictionary = {}
var _manifest_request: HTTPRequest = null
var _last_emitted: Dictionary = {}

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    DirAccess.make_dir_recursive_absolute(PACK_DIR)
    DirAccess.make_dir_recursive_absolute(TMP_DIR)
    _load_state()
    _load_manifest_cache()
    _mount_all_installed()
    _rebuild_extras()
    set_process(false)

# ---- public queries ---------------------------------------------------------------------

func get_base_url() -> String:
    var override_text := FileUtil.read_text(OVERRIDE_URL_PATH).strip_edges()
    if override_text.begins_with("http"):
        return override_text
    return DEFAULT_BASE_URL

func get_packs() -> Array:
    ## Online manifest entries plus installed packs the manifest does not list (imported ones).
    var merged: Array = _packs.duplicate()
    var known: Dictionary = {}
    for pack in _packs:
        known[str((pack as Dictionary).get("id", ""))] = true
    for pack in _extras:
        if not known.has(str((pack as Dictionary).get("id", ""))) and _installed.has(str(pack["id"])):
            merged.append(pack)
    return merged

func get_packs_of_type(pack_type: String) -> Array:
    return ContentCatalog.filter_by_type(get_packs(), pack_type)

func get_pack_info(pack_id: String) -> Dictionary:
    for pack in get_packs():
        if str((pack as Dictionary).get("id", "")) == pack_id:
            return pack
    return {}

func get_status(pack_id: String) -> String:
    ## "missing" | "installed" | "update" | "downloading" | "verifying"
    if _downloads.has(pack_id):
        return str((_downloads[pack_id] as Dictionary).get("phase", "downloading"))
    var info := get_pack_info(pack_id)
    if info.is_empty():
        return "installed" if _installed.has(pack_id) else "missing"
    return ContentCatalog.pack_status(info, _installed)

func is_installed(pack_id: String) -> bool:
    return _installed.has(pack_id) and _mounted.get(pack_id, false)

func get_installed_ids() -> Array:
    return _installed.keys()

func get_installed_maps_for_mode(mode: String) -> Array:
    ## Installed maps offered for a mode: "battle", "duel", ...
    var out: Array = []
    for pack in ContentCatalog.filter_maps_for_mode(get_packs(), mode):
        if is_installed(str((pack as Dictionary)["id"])):
            out.append(pack)
    return out

func get_installed_battle_maps() -> Array:
    return get_installed_maps_for_mode("battle")

func get_total_installed_bytes() -> int:
    var total: int = 0
    for id in _installed:
        total += int((_installed[id] as Dictionary).get("size", 0))
    return total

func get_progress(pack_id: String) -> Vector2i:
    ## (received, total) bytes for an active download, else (0, 0).
    if not _downloads.has(pack_id):
        return Vector2i.ZERO
    var download: Dictionary = _downloads[pack_id]
    return Vector2i(int(download.get("received", 0)), int(download.get("total", 0)))

func get_pack_meta(pack_id: String) -> Dictionary:
    ## Reads res://content/<id>/pack_meta.txt (JSON text) from a mounted pack.
    if not is_installed(pack_id):
        return {}
    var path := "res://content/%s/pack_meta.txt" % pack_id
    if not FileAccess.file_exists(path):
        return {}
    var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
    return parsed if parsed is Dictionary else {}

func load_pack_scene(pack_id: String) -> PackedScene:
    var meta := get_pack_meta(pack_id)
    var entry := str(meta.get("entry_scene", ""))
    if entry.is_empty() or not entry.begins_with("res://content/%s/" % pack_id):
        return null
    var resource: Resource = load(entry)
    return resource as PackedScene

# ---- manifest ----------------------------------------------------------------------------

func refresh_manifest() -> void:
    if _manifest_request != null:
        return
    var request := HTTPRequest.new()
    request.timeout = 20.0
    add_child(request)
    _manifest_request = request
    request.request_completed.connect(_on_manifest_completed.bind(request))
    var error := request.request(ContentCatalog.build_url(get_base_url(), "manifest.json"))
    if error != OK:
        _manifest_request = null
        request.queue_free()
        manifest_online = false
        manifest_failed.emit("request error %d" % error)

func _on_manifest_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray, request: HTTPRequest) -> void:
    _manifest_request = null
    request.queue_free()
    if result != HTTPRequest.RESULT_SUCCESS or response_code != 200:
        manifest_online = false
        manifest_failed.emit("network %d / http %d" % [result, response_code])
        return
    var text := body.get_string_from_utf8()
    var parsed := ContentCatalog.parse_manifest(text)
    if not bool(parsed["ok"]):
        manifest_online = false
        manifest_failed.emit(str(parsed["error"]))
        return
    _packs = parsed["packs"]
    manifest_online = true
    FileUtil.write_text_atomic(MANIFEST_CACHE_PATH, text, false)
    manifest_loaded.emit(_packs.size())

func _load_manifest_cache() -> void:
    var text := FileUtil.read_text(MANIFEST_CACHE_PATH)
    if text.is_empty():
        return
    var parsed := ContentCatalog.parse_manifest(text)
    if bool(parsed["ok"]):
        _packs = parsed["packs"]

# ---- install / remove -------------------------------------------------------------------

func install_pack(pack_id: String) -> void:
    if _downloads.has(pack_id):
        return
    var info := get_pack_info(pack_id)
    if info.is_empty():
        pack_failed.emit(pack_id, "unknown pack")
        return
    var tmp_path := "%s/%s.part" % [TMP_DIR, pack_id]
    FileUtil.remove_file(tmp_path)
    var request := HTTPRequest.new()
    request.download_file = tmp_path
    request.accept_gzip = false
    request.use_threads = true
    request.download_chunk_size = 262144
    request.timeout = 0.0
    add_child(request)
    _downloads[pack_id] = {
        "request": request, "tmp": tmp_path, "info": info, "phase": "downloading",
        "received": 0, "total": int(info.get("size", 0)),
    }
    request.request_completed.connect(_on_download_completed.bind(pack_id))
    var error := request.request(ContentCatalog.build_url(get_base_url(), str(info["file"])))
    if error != OK:
        _fail(pack_id, "request error %d" % error)
        return
    set_process(true)

func cancel_install(pack_id: String) -> void:
    if _downloads.has(pack_id) and str((_downloads[pack_id] as Dictionary).get("phase", "")) == "downloading":
        _fail(pack_id, "cancelled")

# ---- import from phone storage -------------------------------------------------------------

func scan_phone_folder() -> Array:
    ## Ready-made packs found in IMPORT_DIRS: [{"path", "file", "id", "version", "size"}].
    var found: Array = []
    var seen: Dictionary = {}
    for folder in IMPORT_DIRS:
        var dir := DirAccess.open(folder)
        if dir == null:
            continue
        for file_name in dir.get_files():
            var parsed := ContentCatalog.parse_pack_file_name(file_name)
            if parsed.is_empty() or seen.has(file_name):
                continue
            seen[file_name] = true
            var path := "%s/%s" % [folder, file_name]
            found.append({"path": path, "file": file_name, "id": parsed["id"],
                "version": parsed["version"], "size": _file_length(path)})
    return found

func import_from_file(path: String) -> void:
    var file_name := path.get_file()
    var parsed := ContentCatalog.parse_pack_file_name(file_name)
    if parsed.is_empty():
        pack_failed.emit(file_name, "file name must look like id_v1.pck")
        return
    var pack_id := str(parsed["id"])
    if _downloads.has(pack_id):
        return
    var tmp_path := "%s/%s.part" % [TMP_DIR, pack_id]
    FileUtil.remove_file(tmp_path)
    var thread := Thread.new()
    _downloads[pack_id] = {
        "request": null, "tmp": tmp_path, "phase": "verifying", "imported": true, "thread": thread,
        "received": 0, "total": 0,
        "info": {"id": pack_id, "version": int(parsed["version"]), "file": file_name, "sha256": "", "size": 0},
    }
    thread.start(_import_job.bind(pack_id, path, tmp_path))

func _import_job(pack_id: String, source_path: String, tmp_path: String) -> void:
    var error := DirAccess.copy_absolute(source_path, tmp_path)
    if error != OK or _file_length(tmp_path) <= 0:
        _import_failed.call_deferred(pack_id, "copy failed (%d)" % error)
        return
    _hash_done.call_deferred(pack_id, FileAccess.get_sha256(tmp_path))

func _import_failed(pack_id: String, reason: String) -> void:
    if _downloads.has(pack_id) and (_downloads[pack_id] as Dictionary).has("thread"):
        ((_downloads[pack_id] as Dictionary)["thread"] as Thread).wait_to_finish()
        (_downloads[pack_id] as Dictionary).erase("thread")
    _fail(pack_id, reason)

func remove_pack(pack_id: String) -> void:
    if _downloads.has(pack_id) or not _installed.has(pack_id):
        return
    var record: Dictionary = _installed[pack_id]
    FileUtil.remove_file("%s/%s" % [PACK_DIR, str(record.get("file", ""))])
    _installed.erase(pack_id)
    _save_state()
    # A mounted pack cannot be unmounted at runtime; its files disappear after a restart.
    pack_removed.emit(pack_id)

func _process(_delta: float) -> void:
    if _downloads.is_empty():
        set_process(false)
        return
    for pack_id in _downloads.keys():
        var download: Dictionary = _downloads[pack_id]
        if str(download.get("phase", "")) != "downloading":
            continue
        var request: HTTPRequest = download.get("request")
        if request == null:
            continue
        var received: int = request.get_downloaded_bytes()
        var total: int = request.get_body_size()
        if total <= 0:
            total = int(download.get("total", 0))
        download["received"] = received
        download["total"] = total
        var key := Vector2i(received / 65536, total)
        if _last_emitted.get(pack_id, Vector2i(-1, -1)) != key:
            _last_emitted[pack_id] = key
            pack_progress.emit(pack_id, received, total)

func _on_download_completed(result: int, response_code: int, _headers: PackedStringArray, _body: PackedByteArray, pack_id: String) -> void:
    if not _downloads.has(pack_id):
        return
    var download: Dictionary = _downloads[pack_id]
    if result != HTTPRequest.RESULT_SUCCESS or response_code != 200:
        _fail(pack_id, "network %d / http %d" % [result, response_code])
        return
    var tmp_path := str(download["tmp"])
    var info: Dictionary = download["info"]
    var length := _file_length(tmp_path)
    var expected := int(info.get("size", 0))
    if length <= 0 or (expected > 0 and length != expected):
        _fail(pack_id, "size mismatch (%d / %d)" % [length, expected])
        return
    download["phase"] = "verifying"
    download["received"] = length
    download["total"] = length
    pack_progress.emit(pack_id, length, length)
    var thread := Thread.new()
    download["thread"] = thread
    thread.start(_hash_job.bind(pack_id, tmp_path))

func _hash_job(pack_id: String, path: String) -> void:
    var digest := FileAccess.get_sha256(path)
    _hash_done.call_deferred(pack_id, digest)

func _hash_done(pack_id: String, digest: String) -> void:
    if not _downloads.has(pack_id):
        return
    var download: Dictionary = _downloads[pack_id]
    if download.has("thread"):
        (download["thread"] as Thread).wait_to_finish()
        download.erase("thread")
    var info: Dictionary = download["info"]
    var expected_hash := str(info.get("sha256", ""))
    if not expected_hash.is_empty() and expected_hash != digest.to_lower():
        _fail(pack_id, "checksum mismatch")
        return
    var tmp_path := str(download["tmp"])
    var file_name := str(info["file"])
    var final_path := "%s/%s" % [PACK_DIR, file_name]
    FileUtil.remove_file(final_path)
    FileUtil.rename_file(tmp_path, final_path)
    if not FileAccess.file_exists(final_path):
        _fail(pack_id, "could not store the pack")
        return
    var previous: Dictionary = _installed.get(pack_id, {})
    var previous_file := str(previous.get("file", ""))
    if not previous_file.is_empty() and previous_file != file_name:
        FileUtil.remove_file("%s/%s" % [PACK_DIR, previous_file])
    _installed[pack_id] = {
        "version": int(info.get("version", 1)), "file": file_name,
        "sha256": digest.to_lower(), "size": _file_length(final_path),
    }
    _save_state()
    if _mounted.get(pack_id, false):
        # An older version of this pack is already mounted; the new files apply after a restart.
        restart_required = true
    elif not _mount(pack_id):
        _installed.erase(pack_id)
        _save_state()
        FileUtil.remove_file(final_path)
        _fail(pack_id, "pack could not be mounted")
        return
    if bool(download.get("imported", false)):
        var meta := get_pack_meta(pack_id)
        if str(meta.get("id", "")) != pack_id:
            _installed.erase(pack_id)
            _save_state()
            FileUtil.remove_file(final_path)
            _fail(pack_id, "pack_meta id does not match the file name")
            return
    _rebuild_extras()
    _finish_download(pack_id)
    pack_installed.emit(pack_id)

func _fail(pack_id: String, reason: String) -> void:
    if _downloads.has(pack_id):
        var download: Dictionary = _downloads[pack_id]
        var request: HTTPRequest = download.get("request")
        if request != null and is_instance_valid(request):
            request.cancel_request()
        FileUtil.remove_file(str(download.get("tmp", "")))
    _finish_download(pack_id)
    pack_failed.emit(pack_id, reason)

func _finish_download(pack_id: String) -> void:
    if _downloads.has(pack_id):
        var request: HTTPRequest = (_downloads[pack_id] as Dictionary).get("request")
        if request != null and is_instance_valid(request):
            request.queue_free()
        _downloads.erase(pack_id)
    _last_emitted.erase(pack_id)

# ---- mounting & state ---------------------------------------------------------------------

func _mount_all_installed() -> void:
    for pack_id in _installed.keys():
        if not _mount(str(pack_id)):
            _installed.erase(pack_id)
    _save_state()

func _mount(pack_id: String) -> bool:
    if _mounted.get(pack_id, false):
        return true
    var record: Dictionary = _installed.get(pack_id, {})
    var path := "%s/%s" % [PACK_DIR, str(record.get("file", ""))]
    if not FileAccess.file_exists(path):
        return false
    # replace_files = false: a pack can add content but never override base-game files.
    if not ProjectSettings.load_resource_pack(path, false):
        return false
    _mounted[pack_id] = true
    return true

func _rebuild_extras() -> void:
    ## Catalog entries for installed packs, built from each pack's own metadata, so imported packs
    ## show up (and everything installed stays visible when the manifest cannot be downloaded).
    _extras.clear()
    for pack_id in _installed.keys():
        var meta := get_pack_meta(str(pack_id))
        if meta.is_empty():
            continue
        meta["id"] = str(pack_id)
        var record: Dictionary = _installed[pack_id]
        var entry := ContentCatalog.pack_from_meta(meta, str(record.get("file", "")), int(record.get("size", 0)))
        if not entry.is_empty():
            _extras.append(entry)

func _load_state() -> void:
    var state_text := FileUtil.read_text(STATE_PATH)
    if state_text.strip_edges().is_empty():
        return
    var parsed: Variant = JSON.parse_string(state_text)
    if parsed is Dictionary and (parsed as Dictionary).get("installed") is Dictionary:
        for id in (parsed["installed"] as Dictionary):
            if ContentCatalog.is_safe_name(str(id)) and (parsed["installed"][id] is Dictionary):
                var record: Dictionary = parsed["installed"][id]
                if ContentCatalog.is_safe_file(str(record.get("file", ""))):
                    _installed[str(id)] = record

func _save_state() -> void:
    FileUtil.write_text_atomic(STATE_PATH, JSON.stringify({"schema": 1, "installed": _installed}))

func _file_length(path: String) -> int:
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        return 0
    var length := file.get_length()
    file.close()
    return int(length)

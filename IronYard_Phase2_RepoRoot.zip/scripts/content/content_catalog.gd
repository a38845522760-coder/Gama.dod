extends RefCounted
class_name ContentCatalog

## Pure logic for the downloadable-content manifest (no network, no autoloads), so it can be
## unit-tested headless. ContentManager does the I/O; this class only parses and decides.
##
## manifest.json layout (schema 1):
## {
##   "schema": 1,
##   "packs": [
##     {"id": "demo_arena", "type": "map", "version": 1, "file": "demo_arena.pck",
##      "size": 123456, "sha256": "<hex>",
##      "name": {"fa": "...", "en": "..."},
##      "battle": true, "max_players": 8}
##   ]
## }

const SCHEMA: int = 1
const TYPES: Array[String] = ["map", "weapon", "character", "other"]
const BIG_DOWNLOAD_BYTES: int = 100 * 1024 * 1024

static func parse_manifest(text: String) -> Dictionary:
    ## Returns {"ok": bool, "packs": Array[Dictionary], "error": String}.
    var result := {"ok": false, "packs": [], "error": ""}
    var parsed: Variant = JSON.parse_string(text)
    if not (parsed is Dictionary):
        result["error"] = "manifest is not a JSON object"
        return result
    var root: Dictionary = parsed
    if int(root.get("schema", 0)) != SCHEMA:
        result["error"] = "unsupported manifest schema"
        return result
    if not (root.get("packs") is Array):
        result["error"] = "manifest has no packs array"
        return result
    var seen: Dictionary = {}
    var packs: Array = []
    for entry in (root["packs"] as Array):
        if not (entry is Dictionary):
            continue
        var clean := sanitize_pack(entry)
        if clean.is_empty() or seen.has(clean["id"]):
            continue
        seen[clean["id"]] = true
        packs.append(clean)
    result["ok"] = true
    result["packs"] = packs
    return result

static func sanitize_pack(entry: Dictionary) -> Dictionary:
    var id := str(entry.get("id", "")).strip_edges()
    var file := str(entry.get("file", "")).strip_edges()
    if not is_safe_name(id) or not is_safe_file(file):
        return {}
    var pack_type := str(entry.get("type", "other"))
    if not TYPES.has(pack_type):
        pack_type = "other"
    var name_table: Dictionary = {}
    if entry.get("name") is Dictionary:
        name_table = (entry["name"] as Dictionary).duplicate()
    return {
        "id": id,
        "type": pack_type,
        "version": maxi(1, int(entry.get("version", 1))),
        "file": file,
        "size": maxi(0, int(entry.get("size", 0))),
        "sha256": str(entry.get("sha256", "")).strip_edges().to_lower(),
        "name": name_table,
        "battle": bool(entry.get("battle", false)),
        "max_players": maxi(1, int(entry.get("max_players", 1))),
    }

static func is_safe_name(value: String) -> bool:
    ## Pack ids become folder/file names, so only plain identifiers are allowed.
    if value.is_empty() or value.length() > 64:
        return false
    for index in range(value.length()):
        var code := value.unicode_at(index)
        var ok := (code >= 48 and code <= 57) or (code >= 97 and code <= 122) or code == 95 or code == 45
        if not ok:
            return false
    return true

static func is_safe_file(value: String) -> bool:
    if value.is_empty() or value.length() > 96 or not value.ends_with(".pck"):
        return false
    if value.contains("/") or value.contains("\\") or value.contains(".."):
        return false
    return true

static func build_url(base_url: String, file: String) -> String:
    var base := base_url.strip_edges()
    if not base.ends_with("/"):
        base += "/"
    return base + file

static func localized_name(pack: Dictionary, language: String) -> String:
    var table: Dictionary = pack.get("name", {})
    if table.has(language):
        return str(table[language])
    if table.has("en"):
        return str(table["en"])
    return str(pack.get("id", "?"))

static func format_size(bytes: int) -> String:
    if bytes >= 1024 * 1024 * 1024:
        return "%.2f GB" % (float(bytes) / 1073741824.0)
    if bytes >= 1024 * 1024:
        return "%.1f MB" % (float(bytes) / 1048576.0)
    return "%d KB" % maxi(1, int(ceil(float(bytes) / 1024.0)))

static func pack_status(pack: Dictionary, installed: Dictionary) -> String:
    ## "missing" | "installed" | "update"
    var id := str(pack.get("id", ""))
    if not installed.has(id):
        return "missing"
    var record: Dictionary = installed[id]
    if int(record.get("version", 0)) < int(pack.get("version", 1)):
        return "update"
    return "installed"

static func filter_by_type(packs: Array, pack_type: String) -> Array:
    var out: Array = []
    for pack in packs:
        if str((pack as Dictionary).get("type", "other")) == pack_type:
            out.append(pack)
    return out

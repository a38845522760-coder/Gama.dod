extends RefCounted
class_name ProductionAudio

## Static access to the Iron Yard production sound bank (res://production_library/audio/*.wav).
## Streams are cached; every call degrades gracefully (returns null / plays nothing) if a file is
## missing, so the game keeps its procedural sounds as a fallback.

const AUDIO_DIR: String = "res://production_library/audio/"
const LOOP_EVENTS: Array[String] = ["tesla_idle_loop", "reactor_hum_loop", "lab_hvac_loop", "drone_hover_loop", "facility_alarm_loop"]

static var _cache: Dictionary = {}

static func stream(event: String) -> AudioStream:
    if _cache.has(event):
        return _cache[event]
    var path: String = AUDIO_DIR + event + ".wav"
    var result: AudioStream = null
    if ResourceLoader.exists(path):
        result = load(path) as AudioStream
        if result is AudioStreamWAV and LOOP_EVENTS.has(event):
            var wav: AudioStreamWAV = result as AudioStreamWAV
            wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
            wav.loop_begin = 0
            wav.loop_end = int(wav.get_length() * float(wav.mix_rate))
    _cache[event] = result
    return result

## "infected_idle" + 6 -> "infected_idle_03" and so on.
static func numbered(prefix: String, count: int) -> String:
    return "%s_%02d" % [prefix, randi() % maxi(count, 1) + 1]

static func bus_name() -> String:
    return "SFX" if AudioServer.get_bus_index("SFX") != -1 else "Master"

static func play_3d(parent: Node, event: String, world_position: Vector3, volume_db: float = 0.0, max_distance: float = 45.0, pitch: float = 1.0) -> AudioStreamPlayer3D:
    var audio: AudioStream = stream(event)
    if audio == null or parent == null or not parent.is_inside_tree():
        return null
    var player := AudioStreamPlayer3D.new()
    player.stream = audio
    player.volume_db = volume_db
    player.pitch_scale = pitch
    player.max_distance = max_distance
    player.unit_size = 6.0
    player.bus = bus_name()
    parent.add_child(player)
    player.global_position = world_position
    player.finished.connect(player.queue_free)
    player.play()
    return player

static func play_2d(parent: Node, event: String, volume_db: float = 0.0) -> AudioStreamPlayer:
    var audio: AudioStream = stream(event)
    if audio == null or parent == null or not parent.is_inside_tree():
        return null
    var player := AudioStreamPlayer.new()
    player.stream = audio
    player.volume_db = volume_db
    player.bus = bus_name()
    parent.add_child(player)
    player.finished.connect(player.queue_free)
    player.play()
    return player

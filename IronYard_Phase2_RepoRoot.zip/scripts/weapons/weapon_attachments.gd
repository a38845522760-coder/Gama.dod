extends RefCounted
class_name WeaponAttachments

## Buyable gun attachments. Bought once with credits, then equipped per gun (max 3 per gun).

const ORDER: Array[String] = ["ext_mag", "suppressor", "grip", "optic", "barrel"]
const MAX_EQUIPPED: int = 3
const DEFS: Dictionary = {
    "ext_mag": {"name_fa": "خشاب بزرگ", "name_en": "Extended magazine", "price": 300,
        "desc_fa": "۵۰٪ ظرفیت بیشتر، ریلود کمی کندتر.", "desc_en": "+50% capacity, slightly slower reload."},
    "suppressor": {"name_fa": "صدا‌خفه‌کن", "name_en": "Suppressor", "price": 350,
        "desc_fa": "صدای شلیک خیلی کم‌تر، ضربه ۸٪ کم‌تر.", "desc_en": "Much quieter shots, 8% less damage."},
    "grip": {"name_fa": "دسته‌ی جلو", "name_en": "Foregrip", "price": 250,
        "desc_fa": "پس‌زنش ۳۵٪ کم‌تر و دقت بهتر هنگام حرکت.", "desc_en": "35% less recoil, steadier on the move."},
    "optic": {"name_fa": "دوربین بهتر", "name_en": "Better optic", "price": 300,
        "desc_fa": "زوم ۳۵٪ بیشتر.", "desc_en": "35% more zoom."},
    "barrel": {"name_fa": "لوله‌ی سنگین", "name_en": "Heavy barrel", "price": 400,
        "desc_fa": "۱۲٪ ضربه‌ی بیشتر و برد بیشتر.", "desc_en": "+12% damage and range."},
}

static func get_name(id: String, language: String) -> String:
    var def: Dictionary = DEFS.get(id, {})
    return str(def.get("name_fa" if language == "fa" else "name_en", id))

static func get_desc(id: String, language: String) -> String:
    var def: Dictionary = DEFS.get(id, {})
    return str(def.get("desc_fa" if language == "fa" else "desc_en", ""))

static func get_price(id: String) -> int:
    return int((DEFS.get(id, {}) as Dictionary).get("price", 0))

static func get_owned() -> Array:
    var raw: Variant = SaveManager.get_progress("att_owned", [])
    return (raw as Array).duplicate() if raw is Array else []

static func owns(id: String) -> bool:
    return get_owned().has(id)

static func buy(id: String) -> bool:
    if not DEFS.has(id) or owns(id):
        return owns(id)
    if not SaveManager.spend_credits(get_price(id)):
        return false
    var owned: Array = get_owned()
    owned.append(id)
    SaveManager.set_progress("att_owned", owned)
    SaveManager.flush()
    return true

static func get_equipped(weapon_id: String) -> Array:
    var raw: Variant = SaveManager.get_progress("att_equipped", {})
    if raw is Dictionary and (raw as Dictionary).has(weapon_id):
        var list: Variant = (raw as Dictionary)[weapon_id]
        if list is Array:
            var out: Array = []
            for entry in list:
                if get_owned().has(str(entry)) and DEFS.has(str(entry)):
                    out.append(str(entry))
            return out
    return []

## Returns false when the gun already carries MAX_EQUIPPED attachments.
static func set_equipped(weapon_id: String, id: String, on: bool) -> bool:
    var list: Array = get_equipped(weapon_id)
    if on:
        if list.has(id):
            return true
        if list.size() >= MAX_EQUIPPED or not owns(id):
            return false
        list.append(id)
    else:
        list.erase(id)
    var raw: Variant = SaveManager.get_progress("att_equipped", {})
    var table: Dictionary = (raw as Dictionary).duplicate() if raw is Dictionary else {}
    table[weapon_id] = list
    SaveManager.set_progress("att_equipped", table)
    SaveManager.flush()
    return true

static func apply(def: Dictionary, list: Array) -> Dictionary:
    var result: Dictionary = def.duplicate(true)
    for id in list:
        match str(id):
            "ext_mag":
                result["magazine_size"] = int(ceil(float(result["magazine_size"]) * 1.5))
                result["reload_time"] = float(result["reload_time"]) * 1.1
            "suppressor":
                result["sound_volume"] = float(result["sound_volume"]) - 13.0
                result["sound_pitch"] = float(result["sound_pitch"]) * 1.12
                result["damage"] = float(result["damage"]) * 0.92
                result["suppressed"] = true
            "grip":
                result["recoil_pitch"] = float(result["recoil_pitch"]) * 0.65
                result["recoil_yaw"] = float(result["recoil_yaw"]) * 0.65
                result["spread_move"] = float(result["spread_move"]) * 0.8
            "optic":
                result["zoom"] = float(result.get("zoom", 2.0)) * 1.35
            "barrel":
                result["damage"] = float(result["damage"]) * 1.12
                result["range"] = float(result["range"]) * 1.12
    return result

extends Node
class_name WeaponController

## Hitscan weapon logic: ammo, fire rate, spread, recoil, reload, damage, tracers and holes.
## Visuals live in EquipmentViewmodel; effects in BulletEffects; numbers in WeaponDefinitions.

signal ammo_changed(magazine: int, reserve: int, magazine_size: int)
signal reload_state_changed(is_reloading: bool, duration: float)
signal fired
signal dry_fired
signal hit_confirmed(headshot: bool, killed: bool)

@export var weapon_id: String = "rifle"

var _def: Dictionary = {}
var _player: CharacterBody3D
var _camera: Camera3D
var _viewmodel: Node3D
var _fx: BulletEffects
var _magazine: int = 0
var _reserve: int = 0
var _magazine_size: int = 30
var _cooldown: float = 0.0
var _spread: float = 0.0
var _reloading: bool = false
var _reload_left: float = 0.0
var _reload_total: float = 1.0
var _reload_stage: int = 0
var _auto_reload_delay: float = -1.0
var _shot_players: Array[AudioStreamPlayer] = []
var _shot_cursor: int = 0
var _fx_player: AudioStreamPlayer
var _shots_in_burst: int = 0
var _burst_reset: float = 0.0
var _last_cone: float = 0.0

func _ready() -> void:
    add_to_group("weapon_controller")
    _def = WeaponDefinitions.get_definition(weapon_id)
    _magazine_size = int(_def["magazine_size"])
    _magazine = _magazine_size
    _reserve = int(_def["reserve_ammo"])
    _player = get_parent() as CharacterBody3D
    if _player != null:
        _camera = _player.get_node_or_null("CameraPivot/Camera3D") as Camera3D
        if _camera != null:
            _viewmodel = _camera.get_node_or_null("EquipmentViewmodel") as Node3D
    # On touch devices emulated mouse clicks must never fire the weapon; only the FIRE button does.
    if OS.has_feature("android") or OS.has_feature("ios"):
        InputMap.action_erase_events("fire")
    _fx = BulletEffects.new()
    _fx.name = "BulletEffects"
    add_child(_fx)
    for i in range(4):
        var shot_player := AudioStreamPlayer.new()
        shot_player.stream = WeaponAudio.get_stream("shot")
        shot_player.bus = "SFX" if AudioServer.get_bus_index("SFX") != -1 else "Master"
        shot_player.volume_db = -3.0
        add_child(shot_player)
        _shot_players.append(shot_player)
    _fx_player = AudioStreamPlayer.new()
    _fx_player.bus = "SFX" if AudioServer.get_bus_index("SFX") != -1 else "Master"
    add_child(_fx_player)
    ammo_changed.emit(_magazine, _reserve, _magazine_size)

func get_magazine() -> int:
    return _magazine

func get_reserve() -> int:
    return _reserve

func get_magazine_size() -> int:
    return _magazine_size

func is_reloading() -> bool:
    return _reloading

func get_reload_progress() -> float:
    if not _reloading:
        return 0.0
    return clampf(1.0 - _reload_left / maxf(_reload_total, 0.01), 0.0, 1.0)

func get_current_spread() -> float:
    return _last_cone

func get_effects() -> BulletEffects:
    return _fx

func get_weapon_name() -> String:
    return str(_def.get("display_name", "Rifle"))

func refill() -> void:
    _reloading = false
    _reload_left = 0.0
    _magazine = _magazine_size
    _reserve = int(_def["reserve_ammo"])
    _spread = 0.0
    _cooldown = 0.0
    if _viewmodel != null and _viewmodel.has_method("cancel_reload"):
        _viewmodel.call("cancel_reload")
    reload_state_changed.emit(false, 0.0)
    ammo_changed.emit(_magazine, _reserve, _magazine_size)

func _is_fire_held() -> bool:
    if Input.is_action_pressed("fire") and (Input.mouse_mode == Input.MOUSE_MODE_CAPTURED or OS.has_feature("android") or OS.has_feature("ios") or _touch_hud_present()):
        return true
    return false

func _touch_hud_present() -> bool:
    return get_tree().get_first_node_in_group("touch_controls") != null

func _process(delta: float) -> void:
    if _player == null or _camera == null:
        return
    if _player.has_method("is_dead") and bool(_player.call("is_dead")):
        return
    _cooldown = maxf(0.0, _cooldown - delta)
    _spread = maxf(0.0, _spread - float(_def["spread_recovery"]) * delta)
    _burst_reset -= delta
    if _burst_reset <= 0.0:
        _shots_in_burst = 0
    if _auto_reload_delay >= 0.0:
        _auto_reload_delay -= delta
        if _auto_reload_delay < 0.0:
            start_reload()
    if Input.is_action_just_pressed("reload"):
        start_reload()
    if _reloading:
        _update_reload(delta)
        return
    if _is_fire_held():
        # Shooting from a sprint: the rifle first comes up to the ready position, then fires.
        if _player.has_method("suppress_sprint"):
            _player.call("suppress_sprint", 0.35)
        if _player.has_method("is_ready_to_fire") and not bool(_player.call("is_ready_to_fire")):
            return
        if _cooldown <= 0.0:
            _try_fire()

func _try_fire() -> void:
    if _magazine <= 0:
        _cooldown = 0.28
        _play_fx("dry", -6.0)
        dry_fired.emit()
        if _reserve > 0:
            _auto_reload_delay = 0.1
        return
    _magazine -= 1
    _cooldown = 60.0 / float(_def["rounds_per_minute"])
    _shots_in_burst += 1
    _burst_reset = 0.25
    SaveManager.increment_stat("shots_fired")
    _fire_ray()
    _spread = minf(_spread + float(_def["spread_per_shot"]), float(_def["spread_max"]))
    var shot_player := _shot_players[_shot_cursor]
    _shot_cursor = (_shot_cursor + 1) % _shot_players.size()
    shot_player.pitch_scale = randf_range(0.95, 1.06)
    shot_player.play()
    if _viewmodel != null and _viewmodel.has_method("play_fire"):
        _viewmodel.call("play_fire")
    if _player.has_method("add_recoil"):
        var climb: float = float(_def["recoil_pitch"]) * (1.0 + minf(float(_shots_in_burst), 12.0) * 0.035)
        var sway: float = randf_range(-1.0, 1.0) * float(_def["recoil_yaw"])
        _player.call("add_recoil", climb, sway)
    fired.emit()
    ammo_changed.emit(_magazine, _reserve, _magazine_size)
    if _magazine == 0 and _reserve > 0:
        _auto_reload_delay = 0.28

func _compute_cone() -> float:
    var cone: float = float(_def["spread_base"]) + _spread
    var horizontal_speed: float = Vector2(_player.velocity.x, _player.velocity.z).length()
    cone += float(_def["spread_move"]) * clampf(horizontal_speed / 7.0, 0.0, 1.3)
    if not _player.is_on_floor():
        cone += float(_def["spread_air"])
    if _player.has_method("is_crouch_active") and bool(_player.call("is_crouch_active")):
        cone *= float(_def["crouch_spread_multiplier"])
    _last_cone = cone
    return cone

func _fire_ray() -> void:
    var origin: Vector3 = _camera.global_position
    var basis: Basis = _camera.global_transform.basis
    var forward: Vector3 = -basis.z
    var cone := _compute_cone()
    var angle: float = randf() * TAU
    var radius: float = sqrt(randf()) * cone
    var direction: Vector3 = (forward + basis.x * cos(angle) * radius + basis.y * sin(angle) * radius).normalized()
    var max_range: float = float(_def["range"])
    var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * max_range, 1)
    query.exclude = [_player.get_rid()]
    query.collide_with_areas = false
    var hit: Dictionary = _player.get_world_3d().direct_space_state.intersect_ray(query)

    var muzzle: Vector3 = origin + forward * 0.9 + basis.x * 0.12 - basis.y * 0.1
    if _viewmodel != null and _viewmodel.has_method("get_muzzle_global_position"):
        muzzle = _viewmodel.call("get_muzzle_global_position")
    if _player.has_method("is_third_person") and bool(_player.call("is_third_person")):
        muzzle = _player.call("get_third_person_muzzle")
    var end_point: Vector3 = origin + direction * max_range
    var tracer_speed: float = float(_def["tracer_speed"])
    if hit.is_empty():
        _fx.spawn_tracer(muzzle, end_point, tracer_speed)
        return

    end_point = hit["position"]
    var normal: Vector3 = hit["normal"]
    var collider: Object = hit["collider"]
    var distance: float = origin.distance_to(end_point)
    _fx.spawn_tracer(muzzle, end_point, tracer_speed)
    var falloff: float = lerpf(1.0, float(_def["falloff_min_multiplier"]), clampf(distance / max_range, 0.0, 1.0))
    var damage: float = float(_def["damage"]) * falloff
    var is_target: bool = false
    if collider != null and collider.has_method("receive_hit"):
        is_target = true
        var info: Dictionary = {"damage": damage, "position": end_point, "normal": normal, "direction": direction, "source": _player}
        var result: Dictionary = collider.call("receive_hit", info)
        var headshot: bool = bool(result.get("headshot", false))
        var killed: bool = bool(result.get("killed", false))
        SaveManager.increment_stat("shots_hit")
        hit_confirmed.emit(headshot, killed)
        _play_fx("kill" if killed else "hit", -4.0)
    elif collider is RigidBody3D:
        var body := collider as RigidBody3D
        body.apply_impulse(direction * float(_def["impulse"]), end_point - body.global_position)
    _fx.spawn_impact(end_point, normal, is_target)
    if not is_target:
        _fx.spawn_hole(end_point, normal, collider as Node)

func start_reload() -> bool:
    if _reloading or _magazine >= _magazine_size or _reserve <= 0:
        return false
    _reloading = true
    _reload_total = float(_def["reload_time"])
    _reload_left = _reload_total
    _reload_stage = 0
    _auto_reload_delay = -1.0
    if _viewmodel != null and _viewmodel.has_method("play_reload"):
        _viewmodel.call("play_reload", _reload_total)
    reload_state_changed.emit(true, _reload_total)
    return true

func _update_reload(delta: float) -> void:
    _reload_left -= delta
    var progress := 1.0 - _reload_left / maxf(_reload_total, 0.01)
    if _reload_stage == 0 and progress >= 0.30:
        _reload_stage = 1
        _play_fx("mag_out", -5.0)
    elif _reload_stage == 1 and progress >= 0.62:
        _reload_stage = 2
        _play_fx("mag_in", -4.0)
    elif _reload_stage == 2 and progress >= 0.9:
        _reload_stage = 3
        _play_fx("bolt", -5.0)
    if _reload_left <= 0.0:
        var needed: int = _magazine_size - _magazine
        var taken: int = mini(needed, _reserve)
        _magazine += taken
        _reserve -= taken
        _reloading = false
        reload_state_changed.emit(false, 0.0)
        ammo_changed.emit(_magazine, _reserve, _magazine_size)

func _play_fx(kind: String, volume_db: float) -> void:
    _fx_player.stream = WeaponAudio.get_stream(kind)
    _fx_player.volume_db = volume_db
    _fx_player.play()

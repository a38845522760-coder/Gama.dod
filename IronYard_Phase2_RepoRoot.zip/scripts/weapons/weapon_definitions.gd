extends RefCounted
class_name WeaponDefinitions

## Data table for every weapon. Balance numbers live here, not in the controller.
## Players and AI soldiers both read from this table, so a gun behaves the same in anyone's hands.

## Display / shop order.
const ORDER: Array[String] = [
    "pistol", "pistol_tac", "pistol_heavy", "pistol_auto",
    "revolver", "revolver_snub", "revolver_long",
    "smg", "smg_compact", "smg_heavy",
    "rifle", "rifle_carbine", "rifle_dmr",
    "shotgun", "shotgun_auto", "shotgun_sawed",
    "lmg", "lmg_light", "lmg_heavy", "lmg_minigun",
    "sniper", "sniper_semi", "sniper_marksman", "sniper_heavy",
    "tesla",
]

## Scope per base gun: [zoom divider, reticle style]. Variants set their own "zoom"/"scope".
const BASE_OPTICS: Dictionary = {
    "pistol": [1.25, "iron"], "revolver": [1.4, "iron"], "smg": [1.55, "reddot"], "rifle": [2.2, "holo"],
    "shotgun": [1.2, "iron"], "lmg": [2.0, "holo"], "sniper": [6.0, "scope"], "tesla": [1.6, "holo"],
}

## Variants copy a base gun, scale numbers with "mul" and overwrite anything else.
const VARIANTS: Dictionary = {
    "pistol_tac": {"base": "pistol", "name_fa": "کلت تاکتیکال", "display_name": "IY-9 Tactical",
        "description_fa": "خشاب بزرگ‌تر و شلیک تندتر، ولی ضربه‌ی کم‌تر.", "description_en": "Bigger magazine, quicker trigger, lighter hit.",
        "mul": {"damage": 0.85, "rounds_per_minute": 1.25, "magazine_size": 1.35, "reserve_ammo": 1.2}, "zoom": 1.35, "scope": "reddot", "price": 250, "accent": "#59e0c5"},
    "pistol_heavy": {"base": "pistol", "name_fa": "کلت سنگین", "display_name": "IY-45 Heavy",
        "description_fa": "هر گلوله‌اش سنگین است ولی خشابش کوچک.", "description_en": "Hard-hitting rounds, small magazine.",
        "mul": {"damage": 1.65, "rounds_per_minute": 0.7, "magazine_size": 0.6, "recoil_pitch": 1.6, "reload_time": 1.1}, "zoom": 1.45, "scope": "iron", "price": 400, "accent": "#c8d2d8", "sound_pitch": 0.9},
    "pistol_auto": {"base": "pistol", "name_fa": "کلت اتوماتیک", "display_name": "IY-18 Auto",
        "description_fa": "تپانچه‌ی رگباری: سریع، ولی لرزان.", "description_en": "Machine pistol: fast but twitchy.",
        "mul": {"damage": 0.62, "rounds_per_minute": 1.9, "magazine_size": 1.6, "recoil_pitch": 1.2, "spread_per_shot": 1.5}, "auto": true, "zoom": 1.2, "scope": "iron", "price": 550, "accent": "#e08fd2"},
    "revolver_snub": {"base": "revolver", "name_fa": "مگنوم کوتاه", "display_name": "Snub .38",
        "description_fa": "سبک و تند؛ پنج تیر سریع.", "description_en": "Light and quick five-shooter.",
        "mul": {"damage": 0.72, "rounds_per_minute": 1.5, "magazine_size": 0.85, "reload_time": 0.75, "range": 0.7}, "zoom": 1.15, "scope": "iron", "price": 380, "accent": "#d9c27a"},
    "revolver_long": {"base": "revolver", "name_fa": "مگنوم بلند", "display_name": "Longbarrel .50",
        "description_fa": "لوله‌ی بلند، دوربرد و کشنده.", "description_en": "Long barrel, long range, lethal.",
        "mul": {"damage": 1.3, "rounds_per_minute": 0.82, "range": 1.5, "recoil_pitch": 1.3}, "zoom": 1.8, "scope": "holo", "price": 900, "accent": "#ffcf5a"},
    "smg_compact": {"base": "smg", "name_fa": "مسلسل کوچک", "display_name": "Mini SMG",
        "description_fa": "خیلی سریع ولی ضعیف‌تر؛ برای نزدیک.", "description_en": "Very fast but weaker; close quarters.",
        "mul": {"damage": 0.78, "rounds_per_minute": 1.3, "magazine_size": 0.8, "reload_time": 0.85}, "zoom": 1.3, "scope": "reddot", "price": 500, "accent": "#7de08e"},
    "smg_heavy": {"base": "smg", "name_fa": "مسلسل سنگین", "display_name": "Heavy SMG",
        "description_fa": "گلوله‌ی درشت‌تر، کنترل سخت‌تر.", "description_en": "Bigger rounds, harder to control.",
        "mul": {"damage": 1.35, "rounds_per_minute": 0.78, "magazine_size": 1.1, "recoil_pitch": 1.3}, "zoom": 1.8, "scope": "holo", "price": 800, "accent": "#3fae5a"},
    "rifle_carbine": {"base": "rifle", "name_fa": "کارابین", "display_name": "IY Carbine",
        "description_fa": "سبک‌تر و چابک‌تر، ضربه کمی کم‌تر.", "description_en": "Lighter and handier, slightly weaker.",
        "mul": {"damage": 0.9, "rounds_per_minute": 1.12, "reload_time": 0.85, "recoil_pitch": 0.85}, "zoom": 1.9, "scope": "reddot", "price": 600, "accent": "#e0a35a"},
    "rifle_dmr": {"base": "rifle", "name_fa": "تفنگ دقیق‌زن", "display_name": "IY Marksman DMR",
        "description_fa": "تک‌تیر نیمه‌خودکار، دقیق و دوربرد.", "description_en": "Semi-auto, accurate and long range.",
        "mul": {"damage": 1.85, "rounds_per_minute": 0.38, "magazine_size": 0.5, "range": 1.4, "recoil_pitch": 1.4, "spread_base": 0.5}, "auto": false, "zoom": 3.2, "scope": "scope", "price": 1300, "accent": "#a58a5a"},
    "shotgun_auto": {"base": "shotgun", "name_fa": "شاتگان نیمه‌اتومات", "display_name": "Auto-12",
        "description_fa": "پشت‌سرهم شلیک می‌کند، ولی ساچمه‌ها پراکنده‌ترند.", "description_en": "Rapid fire with wider spread.",
        "mul": {"damage": 0.68, "rounds_per_minute": 3.2, "magazine_size": 1.5, "pellet_spread": 1.25}, "auto": true, "zoom": 1.3, "scope": "iron", "price": 1000, "accent": "#f08a6a"},
    "shotgun_sawed": {"base": "shotgun", "name_fa": "شاتگان دسته‌کوتاه", "display_name": "Sawed-Off",
        "description_fa": "پراکندگی زیاد، مرگبار از نزدیک.", "description_en": "Huge spread, deadly up close.",
        "mul": {"damage": 1.25, "rounds_per_minute": 1.2, "magazine_size": 0.35, "pellet_spread": 1.8, "range": 0.55}, "zoom": 1.1, "scope": "iron", "price": 650, "accent": "#b03a2a"},
    "lmg_light": {"base": "lmg", "name_fa": "تیربار سبک", "display_name": "Light MG",
        "description_fa": "سبک و تند ولی خشاب کوچک‌تر.", "description_en": "Light and quick, smaller belt.",
        "mul": {"damage": 0.85, "rounds_per_minute": 1.1, "magazine_size": 0.6, "reload_time": 0.75, "recoil_pitch": 0.85}, "zoom": 1.7, "scope": "reddot", "price": 1400, "accent": "#e6d56a"},
    "lmg_heavy": {"base": "lmg", "name_fa": "تیربار سنگین", "display_name": "Heavy MG",
        "description_fa": "نوار فشنگ بلند و ضربه‌ی سنگین.", "description_en": "Long belt and heavy hits.",
        "mul": {"damage": 1.35, "rounds_per_minute": 0.8, "magazine_size": 1.5, "reload_time": 1.25, "recoil_pitch": 1.25}, "zoom": 2.6, "scope": "holo", "price": 1900, "accent": "#b89a2a"},
    "lmg_minigun": {"base": "lmg", "name_fa": "مینی‌گان", "display_name": "Minigun",
        "description_fa": "رگبار وحشتناک؛ دویست تیر پشت‌سرهم.", "description_en": "Brutal fire rate, two hundred rounds.",
        "mul": {"damage": 0.7, "rounds_per_minute": 1.75, "magazine_size": 2.0, "reload_time": 1.6, "recoil_pitch": 0.9, "spread_per_shot": 1.4}, "zoom": 1.4, "scope": "iron", "price": 2600, "accent": "#ff9a3a"},
    "sniper_semi": {"base": "sniper", "name_fa": "اسنایپر نیمه‌اتومات", "display_name": "Semi Sniper",
        "description_fa": "شلیک تند پشت‌سرهم، زوم کم‌تر.", "description_en": "Rapid semi-auto sniper, lower zoom.",
        "mul": {"damage": 0.62, "rounds_per_minute": 3.4, "magazine_size": 2.0, "reload_time": 0.8}, "zoom": 4.0, "scope": "scope", "price": 1500, "accent": "#8fa0e8"},
    "sniper_marksman": {"base": "sniper", "name_fa": "اسنایپر میان‌برد", "display_name": "Marksman Rifle",
        "description_fa": "تعادل بین سرعت و دقت.", "description_en": "A balance of speed and precision.",
        "mul": {"damage": 0.8, "rounds_per_minute": 1.8, "magazine_size": 1.6}, "zoom": 5.0, "scope": "scope", "price": 1800, "accent": "#b7a0ff"},
    "sniper_heavy": {"base": "sniper", "name_fa": "اسنایپر ضدمواد", "display_name": "Anti-Materiel",
        "description_fa": "هر تیرش کشنده، زوم هشت‌برابر.", "description_en": "One shot, one kill. 8x zoom.",
        "mul": {"damage": 2.0, "rounds_per_minute": 0.6, "magazine_size": 0.6, "reload_time": 1.4, "recoil_pitch": 1.8}, "zoom": 8.0, "scope": "sniper", "price": 3200, "accent": "#6a55cc"},
}


const DEFAULTS: Dictionary = {
    "auto": true,
    "pellets": 1,
    "pellet_spread": 0.0,
    "headshot_multiplier": 2.0,
    "sound_pitch": 1.0,
    "sound_volume": -3.0,
    "price": 0,
    "style": "rifle",
    "kick": 78.0,
    "description_fa": "",
    "description_en": "",
}

const DEFINITIONS: Dictionary = {
    "pistol": {
        "display_name": "IY-9 Pistol",
        "name_fa": "کلت آیرون ۹",
        "description_fa": "سبک و دقیق. اولین سلاح هر جنگجو.",
        "description_en": "Light and accurate. Every fighter's first sidearm.",
        "style": "pistol",
        "auto": false,
        "damage": 21.0,
        "rounds_per_minute": 420.0,
        "magazine_size": 15,
        "reserve_ammo": 90,
        "reload_time": 1.35,
        "range": 90.0,
        "falloff_min_multiplier": 0.5,
        "spread_base": 0.0030,
        "spread_move": 0.016,
        "spread_air": 0.026,
        "spread_per_shot": 0.0050,
        "spread_max": 0.030,
        "spread_recovery": 0.022,
        "crouch_spread_multiplier": 0.65,
        "recoil_pitch": 0.0075,
        "recoil_yaw": 0.0022,
        "impulse": 2.5,
        "tracer_speed": 190.0,
        "sound_pitch": 1.25,
        "sound_volume": -6.0,
        "price": 0,
        "kick": 60.0,
    },
    "revolver": {
        "display_name": "Magnum .44",
        "name_fa": "مگنوم ۴۴",
        "description_fa": "هر گلوله یک ضربه سنگین. حریف را سریع از پا درمی‌آورد.",
        "description_en": "One heavy shot at a time. Drops enemies fast.",
        "style": "revolver",
        "auto": false,
        "damage": 68.0,
        "rounds_per_minute": 160.0,
        "magazine_size": 6,
        "reserve_ammo": 42,
        "reload_time": 2.3,
        "range": 120.0,
        "falloff_min_multiplier": 0.6,
        "spread_base": 0.0025,
        "spread_move": 0.020,
        "spread_air": 0.030,
        "spread_per_shot": 0.012,
        "spread_max": 0.040,
        "spread_recovery": 0.020,
        "crouch_spread_multiplier": 0.6,
        "recoil_pitch": 0.020,
        "recoil_yaw": 0.0050,
        "impulse": 9.0,
        "tracer_speed": 230.0,
        "headshot_multiplier": 2.2,
        "sound_pitch": 0.72,
        "sound_volume": -1.0,
        "price": 450,
        "kick": 130.0,
    },
    "smg": {
        "display_name": "IY-5 SMG",
        "name_fa": "مسلسل سبک آیرون ۵",
        "description_fa": "رگبار سریع برای نبرد نزدیک.",
        "description_en": "Fast spray for close quarters.",
        "style": "smg",
        "auto": true,
        "damage": 14.5,
        "rounds_per_minute": 880.0,
        "magazine_size": 32,
        "reserve_ammo": 192,
        "reload_time": 1.7,
        "range": 70.0,
        "falloff_min_multiplier": 0.4,
        "spread_base": 0.0045,
        "spread_move": 0.014,
        "spread_air": 0.028,
        "spread_per_shot": 0.0032,
        "spread_max": 0.048,
        "spread_recovery": 0.020,
        "crouch_spread_multiplier": 0.62,
        "recoil_pitch": 0.0065,
        "recoil_yaw": 0.0034,
        "impulse": 2.5,
        "tracer_speed": 200.0,
        "sound_pitch": 1.12,
        "sound_volume": -5.0,
        "price": 350,
        "kick": 58.0,
    },
    "rifle": {
        "display_name": "IY-7 Assault Rifle",
        "name_fa": "کلاشینکف آیرون ۷",
        "description_fa": "همه‌کاره و قابل اعتماد در هر فاصله.",
        "description_en": "Reliable all-rounder at any range.",
        "style": "rifle",
        "auto": true,
        "damage": 24.0,
        "rounds_per_minute": 640.0,
        "magazine_size": 30,
        "reserve_ammo": 150,
        "reload_time": 2.0,
        "range": 140.0,
        "falloff_min_multiplier": 0.55,
        "spread_base": 0.0035,
        "spread_move": 0.020,
        "spread_air": 0.030,
        "spread_per_shot": 0.0028,
        "spread_max": 0.040,
        "spread_recovery": 0.018,
        "crouch_spread_multiplier": 0.6,
        "recoil_pitch": 0.0095,
        "recoil_yaw": 0.0030,
        "impulse": 4.0,
        "tracer_speed": 210.0,
        "price": 0,
    },
    "shotgun": {
        "display_name": "Breacher-12",
        "name_fa": "شاتگان بریچر ۱۲",
        "description_fa": "نه ساچمه در هر شلیک. در نزدیکی مرگبار است.",
        "description_en": "Nine pellets per shot. Deadly up close.",
        "style": "shotgun",
        "auto": false,
        "damage": 12.5,
        "pellets": 9,
        "pellet_spread": 0.040,
        "rounds_per_minute": 78.0,
        "magazine_size": 6,
        "reserve_ammo": 36,
        "reload_time": 2.7,
        "range": 48.0,
        "falloff_min_multiplier": 0.18,
        "spread_base": 0.006,
        "spread_move": 0.018,
        "spread_air": 0.028,
        "spread_per_shot": 0.010,
        "spread_max": 0.040,
        "spread_recovery": 0.030,
        "crouch_spread_multiplier": 0.75,
        "recoil_pitch": 0.026,
        "recoil_yaw": 0.0060,
        "impulse": 3.0,
        "tracer_speed": 170.0,
        "sound_pitch": 0.58,
        "sound_volume": 0.0,
        "price": 600,
        "kick": 150.0,
    },
    "lmg": {
        "display_name": "Hammer LMG",
        "name_fa": "مسلسل سنگین هَمر",
        "description_fa": "خشاب ۱۰۰ تایی. دشمن را زیر رگبار می‌گیرد.",
        "description_en": "100-round box. Pins enemies down with sustained fire.",
        "style": "lmg",
        "auto": true,
        "damage": 21.0,
        "rounds_per_minute": 700.0,
        "magazine_size": 100,
        "reserve_ammo": 300,
        "reload_time": 4.2,
        "range": 130.0,
        "falloff_min_multiplier": 0.55,
        "spread_base": 0.0050,
        "spread_move": 0.026,
        "spread_air": 0.034,
        "spread_per_shot": 0.0026,
        "spread_max": 0.050,
        "spread_recovery": 0.015,
        "crouch_spread_multiplier": 0.5,
        "recoil_pitch": 0.0100,
        "recoil_yaw": 0.0042,
        "impulse": 4.5,
        "tracer_speed": 215.0,
        "sound_pitch": 0.82,
        "sound_volume": -1.5,
        "price": 1100,
        "kick": 88.0,
    },
    "sniper": {
        "display_name": "Longbow .338",
        "name_fa": "اسنایپر لانگ‌بو",
        "description_fa": "یک شلیک، یک حذف. با زوم از دور بزن.",
        "description_en": "One shot, one kill. Zoom in and reach out.",
        "style": "sniper",
        "auto": false,
        "damage": 105.0,
        "rounds_per_minute": 52.0,
        "magazine_size": 5,
        "reserve_ammo": 25,
        "reload_time": 3.1,
        "range": 300.0,
        "falloff_min_multiplier": 0.85,
        "spread_base": 0.0004,
        "spread_move": 0.060,
        "spread_air": 0.080,
        "spread_per_shot": 0.020,
        "spread_max": 0.060,
        "spread_recovery": 0.030,
        "crouch_spread_multiplier": 0.5,
        "recoil_pitch": 0.030,
        "recoil_yaw": 0.0040,
        "impulse": 12.0,
        "tracer_speed": 320.0,
        "headshot_multiplier": 2.5,
        "sound_pitch": 0.50,
        "sound_volume": 1.0,
        "price": 1000,
        "kick": 170.0,
    },
    "tesla": {
        "display_name": "Tesla Arc Cannon",
        "name_fa": "تفنگ تسلا",
        "description_fa": "رعد زنجیره‌ای: هر شلیک همزمان ۳ تا ۵ زامبی را می‌زند. خشاب ۳ تایی، ۱۵ تیر ذخیره. فقط با ماموریت تسلا ساخته می‌شود؛ مهمات قابل خرید نیست.",
        "description_en": "Chain lightning: every shot hits 3-5 zombies at once. 3-round magazine, 15 in reserve. Built through the Tesla quest; ammo cannot be bought.",
        "style": "rifle",
        "auto": false,
        "damage": 55.0,
        "chain_targets_min": 3,
        "chain_targets_max": 5,
        "chain_radius": 9.0,
        "chain_falloff": 0.85,
        "map_shop_only": true,
        "rounds_per_minute": 150.0,
        "magazine_size": 3,
        "reserve_ammo": 15,
        "reload_time": 2.4,
        "range": 60.0,
        "falloff_min_multiplier": 0.8,
        "spread_base": 0.0015,
        "spread_move": 0.012,
        "spread_air": 0.022,
        "spread_per_shot": 0.006,
        "spread_max": 0.030,
        "spread_recovery": 0.025,
        "crouch_spread_multiplier": 0.6,
        "recoil_pitch": 0.012,
        "recoil_yaw": 0.0030,
        "impulse": 0.0,
        "tracer_speed": 420.0,
        "headshot_multiplier": 1.5,
        "sound_pitch": 1.6,
        "sound_volume": 0.0,
        "price": 1200,
        "kick": 100.0,
    },
}

const ACCENTS: Dictionary = {
    "pistol": "#41d9ee",
    "revolver": "#d9b04a",
    "smg": "#5cc26b",
    "rifle": "#c9822f",
    "shotgun": "#d4503a",
    "lmg": "#d8c64c",
    "sniper": "#9a85e6",
    "tesla": "#4fd8ff",
}

static func get_accent(weapon_id: String) -> Color:
    var def: Dictionary = get_definition(weapon_id)
    if def.has("accent"):
        return Color(str(def["accent"]))
    var base_id: String = str(def.get("base", weapon_id))
    return Color(str(ACCENTS.get(base_id, "#c9822f")))

static func get_definition(weapon_id: String) -> Dictionary:
    var result: Dictionary = DEFAULTS.duplicate(true)
    if VARIANTS.has(weapon_id):
        var variant: Dictionary = VARIANTS[weapon_id]
        var base_id: String = str(variant["base"])
        var base: Dictionary = DEFINITIONS[base_id]
        for key in base.keys():
            result[key] = base[key]
        var scale: Dictionary = variant.get("mul", {})
        for key in scale.keys():
            if result.has(key):
                var scaled: float = float(result[key]) * float(scale[key])
                if typeof(result[key]) == TYPE_INT:
                    result[key] = maxi(1, int(round(scaled)))
                else:
                    result[key] = scaled
        for key in variant.keys():
            if key != "mul":
                result[key] = variant[key]
        result["id"] = weapon_id
        return result
    var source: Dictionary = DEFINITIONS["rifle"]
    if DEFINITIONS.has(weapon_id):
        source = DEFINITIONS[weapon_id]
    for key in source.keys():
        result[key] = source[key]
    var found_id: String = weapon_id if DEFINITIONS.has(weapon_id) else "rifle"
    result["id"] = found_id
    if not result.has("zoom"):
        var optics: Array = BASE_OPTICS.get(found_id, [2.0, "holo"])
        result["zoom"] = float(optics[0])
        result["scope"] = str(optics[1])
    return result

static func exists(weapon_id: String) -> bool:
    return DEFINITIONS.has(weapon_id) or VARIANTS.has(weapon_id)

static func get_price(weapon_id: String) -> int:
    return int(get_definition(weapon_id).get("price", 0))

static func get_display_name(weapon_id: String, language: String = "en") -> String:
    var def: Dictionary = get_definition(weapon_id)
    if language == "fa":
        return str(def.get("name_fa", def.get("display_name", weapon_id)))
    return str(def.get("display_name", weapon_id))

extends RefCounted
class_name WeaponDefinitions

## Data table for every weapon. Balance numbers live here, not in the controller.

const DEFINITIONS: Dictionary = {
    "rifle": {
        "display_name": "IY-7 Assault Rifle",
        "damage": 24.0,
        "rounds_per_minute": 640.0,
        "magazine_size": 30,
        "reserve_ammo": 150,
        "reload_time": 2.0,
        "range": 140.0,
        "falloff_min_multiplier": 0.55,
        "spread_base": 0.0035,
        "spread_move": 0.020,
        "spread_air": 0.030,
        "spread_per_shot": 0.0028,
        "spread_max": 0.040,
        "spread_recovery": 0.018,
        "crouch_spread_multiplier": 0.6,
        "recoil_pitch": 0.0095,
        "recoil_yaw": 0.0030,
        "impulse": 4.0,
        "tracer_speed": 210.0,
    },
}

static func get_definition(weapon_id: String) -> Dictionary:
    if DEFINITIONS.has(weapon_id):
        return (DEFINITIONS[weapon_id] as Dictionary).duplicate(true)
    return (DEFINITIONS["rifle"] as Dictionary).duplicate(true)

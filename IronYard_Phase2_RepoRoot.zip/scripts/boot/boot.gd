extends Control

@onready var _status_label: Label = %StatusLabel

func _ready() -> void:
    _status_label.text = "IRON YARD CORE INITIALIZED"
    AppState.set_active_screen("boot")

extends Node
class_name IronYardAudioBank

## Lightweight runtime sound bank for the original procedural WAV assets.
const LOOP_EVENTS := ["tesla_idle_loop", "reactor_hum_loop", "lab_hvac_loop", "drone_hover_loop", "facility_alarm_loop"]
const SOUND_FILES := {
    "footstep_concrete_01": "res://production_library/audio/footstep_concrete_01.wav",
    "footstep_concrete_02": "res://production_library/audio/footstep_concrete_02.wav",
    "footstep_concrete_03": "res://production_library/audio/footstep_concrete_03.wav",
    "footstep_concrete_04": "res://production_library/audio/footstep_concrete_04.wav",
    "footstep_metal_01": "res://production_library/audio/footstep_metal_01.wav",
    "footstep_metal_02": "res://production_library/audio/footstep_metal_02.wav",
    "footstep_metal_03": "res://production_library/audio/footstep_metal_03.wav",
    "footstep_metal_04": "res://production_library/audio/footstep_metal_04.wav",
    "footstep_gravel_01": "res://production_library/audio/footstep_gravel_01.wav",
    "footstep_gravel_02": "res://production_library/audio/footstep_gravel_02.wav",
    "footstep_gravel_03": "res://production_library/audio/footstep_gravel_03.wav",
    "footstep_gravel_04": "res://production_library/audio/footstep_gravel_04.wav",
    "footstep_heavy_01": "res://production_library/audio/footstep_heavy_01.wav",
    "footstep_heavy_02": "res://production_library/audio/footstep_heavy_02.wav",
    "footstep_heavy_03": "res://production_library/audio/footstep_heavy_03.wav",
    "infected_idle_01": "res://production_library/audio/infected_idle_01.wav",
    "infected_idle_02": "res://production_library/audio/infected_idle_02.wav",
    "infected_idle_03": "res://production_library/audio/infected_idle_03.wav",
    "infected_idle_04": "res://production_library/audio/infected_idle_04.wav",
    "infected_idle_05": "res://production_library/audio/infected_idle_05.wav",
    "infected_idle_06": "res://production_library/audio/infected_idle_06.wav",
    "infected_alert_01": "res://production_library/audio/infected_alert_01.wav",
    "infected_alert_02": "res://production_library/audio/infected_alert_02.wav",
    "infected_alert_03": "res://production_library/audio/infected_alert_03.wav",
    "infected_alert_04": "res://production_library/audio/infected_alert_04.wav",
    "infected_call_01": "res://production_library/audio/infected_call_01.wav",
    "infected_call_02": "res://production_library/audio/infected_call_02.wav",
    "infected_call_03": "res://production_library/audio/infected_call_03.wav",
    "tesla_arc_01": "res://production_library/audio/tesla_arc_01.wav",
    "tesla_arc_02": "res://production_library/audio/tesla_arc_02.wav",
    "tesla_arc_03": "res://production_library/audio/tesla_arc_03.wav",
    "tesla_idle_loop": "res://production_library/audio/tesla_idle_loop.wav",
    "tesla_charge": "res://production_library/audio/tesla_charge.wav",
    "tesla_pulse": "res://production_library/audio/tesla_pulse.wav",
    "reactor_hum_loop": "res://production_library/audio/reactor_hum_loop.wav",
    "lab_hvac_loop": "res://production_library/audio/lab_hvac_loop.wav",
    "bulkhead_open": "res://production_library/audio/bulkhead_open.wav",
    "bulkhead_close": "res://production_library/audio/bulkhead_close.wav",
    "scanner_sweep": "res://production_library/audio/scanner_sweep.wav",
    "drone_hover_loop": "res://production_library/audio/drone_hover_loop.wav",
    "drone_scan": "res://production_library/audio/drone_scan.wav",
    "energy_fire_pulse": "res://production_library/audio/energy_fire_pulse.wav",
    "energy_fire_arc": "res://production_library/audio/energy_fire_arc.wav",
    "energy_fire_cryo": "res://production_library/audio/energy_fire_cryo.wav",
    "energy_cell_swap": "res://production_library/audio/energy_cell_swap.wav",
    "overheat_warning": "res://production_library/audio/overheat_warning.wav",
    "energy_cooldown": "res://production_library/audio/energy_cooldown.wav",
    "weapon_equip_fictional": "res://production_library/audio/weapon_equip_fictional.wav",
    "weapon_inspect_fictional": "res://production_library/audio/weapon_inspect_fictional.wav",
    "ui_confirm_01": "res://production_library/audio/ui_confirm_01.wav",
    "ui_confirm_02": "res://production_library/audio/ui_confirm_02.wav",
    "ui_confirm_03": "res://production_library/audio/ui_confirm_03.wav",
    "ui_confirm_04": "res://production_library/audio/ui_confirm_04.wav",
    "ui_cancel": "res://production_library/audio/ui_cancel.wav",
    "ui_hover": "res://production_library/audio/ui_hover.wav",
    "item_pickup": "res://production_library/audio/item_pickup.wav",
    "energy_pickup": "res://production_library/audio/energy_pickup.wav",
    "facility_alarm_loop": "res://production_library/audio/facility_alarm_loop.wav",
    "generator_start": "res://production_library/audio/generator_start.wav",
    "generator_shutdown": "res://production_library/audio/generator_shutdown.wav",
    "pod_unlock": "res://production_library/audio/pod_unlock.wav",
    "pod_open": "res://production_library/audio/pod_open.wav",
    "pod_close": "res://production_library/audio/pod_close.wav",
    "boss_reveal_sting": "res://production_library/audio/boss_reveal_sting.wav",
    "boss_roar_synthetic": "res://production_library/audio/boss_roar_synthetic.wav",
}

func play_2d(event_name: String, volume_db: float = 0.0) -> AudioStreamPlayer:
    var path: String = SOUND_FILES.get(event_name, "")
    if path.is_empty():
        push_warning("Unknown Iron Yard audio event: " + event_name)
        return null
    var player := AudioStreamPlayer.new()
    player.stream = load(path) as AudioStream
    if event_name in LOOP_EVENTS and player.stream is AudioStreamWAV:
        (player.stream as AudioStreamWAV).loop_mode = AudioStreamWAV.LOOP_FORWARD
    player.volume_db = volume_db
    add_child(player)
    player.finished.connect(player.queue_free)
    player.play()
    return player

func play_3d(event_name: String, world_position: Vector3, volume_db: float = 0.0) -> AudioStreamPlayer3D:
    var path: String = SOUND_FILES.get(event_name, "")
    if path.is_empty():
        push_warning("Unknown Iron Yard audio event: " + event_name)
        return null
    var player := AudioStreamPlayer3D.new()
    player.stream = load(path) as AudioStream
    if event_name in LOOP_EVENTS and player.stream is AudioStreamWAV:
        (player.stream as AudioStreamWAV).loop_mode = AudioStreamWAV.LOOP_FORWARD
    player.volume_db = volume_db
    add_child(player)
    player.global_position = world_position
    player.finished.connect(player.queue_free)
    player.play()
    return player

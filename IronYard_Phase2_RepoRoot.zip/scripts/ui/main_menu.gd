extends Control

## Main menu: tactical command-screen layout with responsive mobile/desktop composition.

const ARENA_SCENE := "res://scenes/world/core_test_arena.tscn"
const MAP_SCENE := "res://scenes/world/iron_yard_map.tscn"

var _settings_screen: Control
var _content_screen: Control
var _mode_screen: Control
var _shop_screen: Control
var _loadout_screen: Control
var _stripe_shift: float = 0.0
var _radar_angle: float = 0.0
var _menu_rng := RandomNumberGenerator.new()
var _menu_specks: Array[Vector2] = []
var _menu_speck_speeds: Array[float] = []

func _ready() -> void:
    theme = UIStyle.get_theme()
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    Loc.language_changed.connect(func(_language: String) -> void: _build())
    AppState.set_active_screen("main_menu")
    _seed_menu_specks()
    if NetGame.match_running:
        NetGame.leave(false)
    if not (OS.has_feature("android") or OS.has_feature("ios")):
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    _build()

func _process(delta: float) -> void:
    _stripe_shift = fposmod(_stripe_shift + delta * 12.0, 120.0)
    _radar_angle = fposmod(_radar_angle + delta * 0.18, TAU)
    for index in range(_menu_specks.size()):
        var point: Vector2 = _menu_specks[index]
        point.y += _menu_speck_speeds[index] * delta
        point.x += sin(_radar_angle + float(index)) * delta * 2.0
        if point.y > size.y + 5.0:
            point.y = -5.0
            point.x = _menu_rng.randf_range(0.0, maxf(size.x, 1.0))
        _menu_specks[index] = point
    queue_redraw()

func _seed_menu_specks() -> void:
    _menu_rng.randomize()
    _menu_specks.clear()
    _menu_speck_speeds.clear()
    for index in range(42):
        _menu_specks.append(Vector2(_menu_rng.randf_range(0.0, maxf(size.x, 1.0)), _menu_rng.randf_range(0.0, maxf(size.y, 1.0))))
        _menu_speck_speeds.append(_menu_rng.randf_range(2.0, 10.0))

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, size), UIStyle.COLOR_BG)
    # Layered horizon light and a restrained blueprint grid create depth without a
    # full-screen image or expensive real-time scene behind the menu.
    for band in range(16):
        var alpha := 0.025 * float(16 - band) / 16.0
        draw_rect(Rect2(0.0, size.y * 0.43 + float(band) * 24.0, size.x, 24.0), Color(0.14, 0.34, 0.42, alpha))
    for gx in range(0, int(size.x) + 1, 64):
        draw_line(Vector2(gx, 0.0), Vector2(gx, size.y), Color(0.32, 0.48, 0.56, 0.035), 1.0)
    for gy in range(0, int(size.y) + 1, 64):
        draw_line(Vector2(0.0, gy), Vector2(size.x, gy), Color(0.32, 0.48, 0.56, 0.035), 1.0)
    # Low-contrast tactical radar graphic, kept behind all interactive panels.
    var radar_center := Vector2(size.x * 0.79, size.y * 0.36)
    var radar_radius: float = minf(size.x * 0.23, size.y * 0.29)
    for ring in range(1, 5):
        draw_arc(radar_center, radar_radius * float(ring) / 4.0, 0.0, TAU, 80, Color(0.28, 0.67, 0.72, 0.07), 1.0, true)
    draw_line(radar_center + Vector2(-radar_radius, 0.0), radar_center + Vector2(radar_radius, 0.0), Color(0.28, 0.67, 0.72, 0.06), 1.0)
    draw_line(radar_center + Vector2(0.0, -radar_radius), radar_center + Vector2(0.0, radar_radius), Color(0.28, 0.67, 0.72, 0.06), 1.0)
    var radar_tip := radar_center + Vector2(cos(_radar_angle), sin(_radar_angle)) * radar_radius
    draw_line(radar_center, radar_tip, Color(0.34, 0.85, 0.8, 0.18), 2.0, true)
    draw_circle(radar_center, 2.4, Color(0.7, 0.9, 0.83, 0.28))
    for index in range(_menu_specks.size()):
        var speck: Vector2 = _menu_specks[index]
        draw_circle(speck, 1.0 + float(index % 3) * 0.35, Color(0.58, 0.76, 0.78, 0.08 + float(index % 4) * 0.018))
    # Distant ruined skyline silhouette.
    var skyline_y := size.y * 0.78
    draw_rect(Rect2(0.0, skyline_y, size.x, size.y - skyline_y), Color(0.012, 0.022, 0.03, 0.46))
    for index in range(26):
        var building_x := float(index) * size.x / 25.0
        var building_w := 18.0 + float((index * 13) % 31)
        var building_h := 34.0 + float((index * 29) % 105)
        draw_rect(Rect2(building_x, skyline_y - building_h, building_w, building_h), Color(0.018, 0.034, 0.045, 0.75))
        if index % 3 == 0:
            for row in range(2):
                draw_rect(Rect2(building_x + 5.0, skyline_y - building_h + 14.0 + float(row) * 18.0, 3.0, 5.0), Color(0.8, 0.52, 0.25, 0.28))
    # Animated caution strip is deliberately confined to the bottom edge.
    var stripe_y := size.y - 7.0
    draw_rect(Rect2(0.0, stripe_y, size.x, 7.0), Color(0.06, 0.08, 0.09, 0.9))
    var x := -120.0 + _stripe_shift
    while x < size.x + 120.0:
        var polygon := PackedVector2Array([
            Vector2(x, stripe_y + 7.0), Vector2(x + 32.0, stripe_y + 7.0),
            Vector2(x + 44.0, stripe_y), Vector2(x + 12.0, stripe_y)])
        draw_colored_polygon(polygon, Color(0.9, 0.57, 0.24, 0.85))
        x += 120.0

func _build() -> void:
    for child in get_children():
        child.queue_free()
    Loc.apply_direction(self)

    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    for side in ["left", "right", "top", "bottom"]:
        margin.add_theme_constant_override("margin_" + side, 22)
    add_child(margin)

    var scroll := TouchScroll.new()
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
    scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    margin.add_child(scroll)

    var content := VBoxContainer.new()
    content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_theme_constant_override("separation", 18)
    scroll.add_child(content)

    var wide := get_viewport_rect().size.x >= 900.0
    var header := HBoxContainer.new()
    header.add_theme_constant_override("separation", 12)
    content.add_child(header)
    var brand_stack := VBoxContainer.new()
    brand_stack.add_theme_constant_override("separation", 1)
    brand_stack.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    header.add_child(brand_stack)
    var brand := UIStyle.make_label("IRON YARD  /  COMMAND", 15, UIStyle.COLOR_CYAN)
    brand_stack.add_child(brand)
    var title := UIStyle.make_label(Loc.t("app_title"), 48 if wide else 38, UIStyle.COLOR_TEXT)
    title.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.8))
    brand_stack.add_child(title)
    var tagline := UIStyle.make_label(Loc.t("tagline"), 18, UIStyle.COLOR_TEXT_DIM)
    brand_stack.add_child(tagline)

    var stats_chip := PanelContainer.new()
    stats_chip.custom_minimum_size = Vector2(180, 64)
    stats_chip.visible = wide
    stats_chip.add_theme_stylebox_override("panel", UIStyle.box(Color(0.04, 0.07, 0.09, 0.88), Color(0.34, 0.48, 0.55, 0.5), 12, 1))
    header.add_child(stats_chip)
    var stats_chip_inner := VBoxContainer.new()
    stats_chip_inner.add_theme_constant_override("separation", 0)
    stats_chip.add_child(stats_chip_inner)
    stats_chip_inner.add_child(UIStyle.make_label("OPERATOR CREDITS", 11, UIStyle.COLOR_TEXT_DIM))
    stats_chip_inner.add_child(UIStyle.make_label(str(SaveManager.get_credits()), 26, Color("#ffd58a")))

    var content_panel := PanelContainer.new()
    content_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content_panel.add_theme_stylebox_override("panel", UIStyle.box(Color(0.025, 0.043, 0.058, 0.94), Color(0.3, 0.42, 0.49, 0.62), 18, 1))
    content.add_child(content_panel)
    var panel_margin := MarginContainer.new()
    for side in ["left", "right", "top", "bottom"]:
        panel_margin.add_theme_constant_override("margin_" + side, 22)
    content_panel.add_child(panel_margin)

    # HBoxContainer and VBoxContainer share BoxContainer; annotate the common type
    # explicitly so Godot does not infer Variant from the conditional expression.
    var body: BoxContainer = HBoxContainer.new() if wide else VBoxContainer.new()
    body.add_theme_constant_override("separation", 22)
    panel_margin.add_child(body)

    var action_column := VBoxContainer.new()
    action_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    action_column.add_theme_constant_override("separation", 12)
    body.add_child(action_column)
    action_column.add_child(UIStyle.make_label("FIELD OPERATIONS  //  READY", 14, UIStyle.COLOR_ACCENT))
    var hero := UIStyle.make_label(Loc.t("choose_mode"), 34 if wide else 29, UIStyle.COLOR_TEXT)
    action_column.add_child(hero)
    var briefing := UIStyle.make_label("Select an operation, configure your kit, and deploy.", 16, UIStyle.COLOR_TEXT_DIM)
    briefing.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    action_column.add_child(briefing)

    var play_button := UIStyle.make_button(Loc.t("play") + "   ›", true, Vector2(0, 72))
    play_button.add_theme_font_size_override("font_size", 27)
    play_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    play_button.pressed.connect(_on_play)
    action_column.add_child(play_button)

    var actions := GridContainer.new()
    actions.columns = 2
    actions.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    actions.add_theme_constant_override("h_separation", 10)
    actions.add_theme_constant_override("v_separation", 10)
    action_column.add_child(actions)
    var shop_button := UIStyle.make_button(Loc.t("shop"), false, Vector2(0, 58))
    shop_button.pressed.connect(_on_shop)
    actions.add_child(shop_button)
    var loadout_button := UIStyle.make_button(Loc.t("loadout"), false, Vector2(0, 58))
    loadout_button.pressed.connect(_on_loadout)
    actions.add_child(loadout_button)
    var training_button := UIStyle.make_button(Loc.t("map_training"), false, Vector2(0, 58))
    training_button.pressed.connect(_on_training)
    actions.add_child(training_button)
    var content_button := UIStyle.make_button(Loc.t("content"), false, Vector2(0, 58))
    content_button.pressed.connect(_on_content)
    actions.add_child(content_button)
    var settings_button := UIStyle.make_button(Loc.t("settings"), false, Vector2(0, 58))
    settings_button.pressed.connect(_on_settings)
    actions.add_child(settings_button)

    var intel := PanelContainer.new()
    intel.custom_minimum_size = Vector2(270 if wide else 0, 280)
    intel.size_flags_horizontal = Control.SIZE_EXPAND_FILL if not wide else Control.SIZE_SHRINK_BEGIN
    intel.add_theme_stylebox_override("panel", UIStyle.box(Color(0.045, 0.073, 0.09, 0.88), Color(0.26, 0.42, 0.49, 0.52), 14, 1))
    body.add_child(intel)
    var intel_column := VBoxContainer.new()
    intel_column.add_theme_constant_override("separation", 11)
    intel.add_child(intel_column)
    intel_column.add_child(UIStyle.make_label("MISSION INTELLIGENCE", 13, UIStyle.COLOR_CYAN))
    intel_column.add_child(UIStyle.make_label("DEAD CITY  /  IRON YARD", 21, UIStyle.COLOR_TEXT))
    var divider := HSeparator.new()
    divider.add_theme_color_override("separator", Color(0.32, 0.47, 0.53, 0.7))
    intel_column.add_child(divider)
    _add_intel_row(intel_column, "CREDITS", str(SaveManager.get_credits()), Color("#ffd58a"))
    _add_intel_row(intel_column, "BEST SCORE", str(int(SaveManager.get_value("best_score", 0))), UIStyle.COLOR_ACCENT)
    _add_intel_row(intel_column, "TOTAL ELIMINATIONS", str(SaveManager.get_stat("kills")), UIStyle.COLOR_TEXT)
    _add_intel_row(intel_column, "MISSION STATUS", "AVAILABLE", UIStyle.COLOR_SUCCESS)
    var spacer := Control.new()
    spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
    intel_column.add_child(spacer)
    intel_column.add_child(UIStyle.make_label("SYSTEMS CHECK  •  READY", 12, UIStyle.COLOR_TEXT_DIM))

    if not (OS.has_feature("android") or OS.has_feature("ios")):
        var quit_button := UIStyle.make_button(Loc.t("quit"), false, Vector2(0, 48))
        quit_button.pressed.connect(func() -> void: get_tree().quit())
        content.add_child(quit_button)

func _add_intel_row(parent: VBoxContainer, label_text: String, value_text: String, value_color: Color) -> void:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 8)
    parent.add_child(row)
    var label := UIStyle.make_label(label_text, 13, UIStyle.COLOR_TEXT_DIM)
    label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(label)
    row.add_child(UIStyle.make_label(value_text, 17, value_color))

func _on_play() -> void:
    if _mode_screen != null and is_instance_valid(_mode_screen):
        return
    _mode_screen = ModeSelectScreen.new()
    _mode_screen.closed.connect(func() -> void:
        _mode_screen.queue_free()
        _mode_screen = null)
    add_child(_mode_screen)

func _on_shop() -> void:
    if _shop_screen != null and is_instance_valid(_shop_screen):
        return
    _shop_screen = ShopScreen.new()
    _shop_screen.closed.connect(func() -> void:
        _shop_screen.queue_free()
        _shop_screen = null
        _build())
    add_child(_shop_screen)

func _on_loadout() -> void:
    if _loadout_screen != null and is_instance_valid(_loadout_screen):
        return
    _loadout_screen = LoadoutScreen.new()
    _loadout_screen.closed.connect(func() -> void:
        _loadout_screen.queue_free()
        _loadout_screen = null)
    add_child(_loadout_screen)

func _on_training() -> void:
    SaveManager.set_progress("last_map", "core_test_arena")
    get_tree().change_scene_to_file(ARENA_SCENE)

func _on_settings() -> void:
    if _settings_screen != null and is_instance_valid(_settings_screen):
        return
    _settings_screen = SettingsScreen.new()
    _settings_screen.closed.connect(func() -> void:
        _settings_screen.queue_free()
        _settings_screen = null)
    add_child(_settings_screen)

func _on_content() -> void:
    if _content_screen != null and is_instance_valid(_content_screen):
        return
    _content_screen = ContentScreen.new()
    _content_screen.closed.connect(func() -> void:
        _content_screen.queue_free()
        _content_screen = null)
    add_child(_content_screen)

extends Control
class_name MainMenu

const MAPS := [
	{
		"id": "map_factory",
		"title": "1. INDUSTRIAL FACTORY  (کارخانه)",
		"subtitle": "160x160 Heavy Factory: 3 Smokestacks, Furnace Core, Turbines, Overhead Crane, Silos, Trucks & Zone Streaming",
		"scene": "res://scenes/world/map_factory.tscn",
	},
	{
		"id": "map_fortress",
		"title": "2. CITADEL FORTRESS  (قلعه)",
		"subtitle": "160x160 Stone Fortress: Central Keep, Walkable Battlements, 4 Bastion Towers, Gatehouse & Courtyard",
		"scene": "res://scenes/world/map_fortress.tscn",
	},
	{
		"id": "map_warehouse",
		"title": "3. MEGA WAREHOUSE  (انبار بزرگ)",
		"subtitle": "160x160 Logistics Hub: Twin Distribution Halls, Multi-tier Racks, Container Maze, Trucks & Dispatch Tower",
		"scene": "res://scenes/world/map_warehouse.tscn",
	},
	{
		"id": "map_military_base",
		"title": "4. MILITARY BASE  (پایگاه نظامی)",
		"subtitle": "160x160 Military Compound: Runway, Aircraft Hangar, Helipad, Radar Bunker, Barracks & Watchtowers",
		"scene": "res://scenes/world/map_military_base.tscn",
	},
	{
		"id": "core_test_arena",
		"title": "5. CORE TEST ARENA  (میدان تست)",
		"subtitle": "Compact physics & movement test facility with surface panels and dynamic crates",
		"scene": "res://scenes/world/core_test_arena.tscn",
	},
]

var _selected_map_index: int = 0
var _map_buttons: Array[Button] = []
var _map_desc_label: Label
var _quality_btn: OptionButton
var _weather_btn: OptionButton
var _sens_slider: HSlider
var _sens_value_label: Label
var _team_size_btn: OptionButton

func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	AppState.set_active_screen("main_menu")
	_build_ui()

func _build_ui() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var bg := ColorRect.new()
	bg.color = Color(0.04, 0.06, 0.08, 1.0)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 36)
	margin.add_theme_constant_override("margin_right", 36)
	margin.add_theme_constant_override("margin_top", 22)
	margin.add_theme_constant_override("margin_bottom", 22)
	add_child(margin)

	var root_vbox := VBoxContainer.new()
	root_vbox.add_theme_constant_override("separation", 14)
	margin.add_child(root_vbox)

	var title := Label.new()
	title.text = "IRON YARD  //  TACTICAL DEPLOYMENT"
	title.add_theme_font_size_override("font_size", 28)
	title.add_theme_color_override("font_color", Color(0.42, 0.88, 0.96, 1.0))
	root_vbox.add_child(title)

	var content_hbox := HBoxContainer.new()
	content_hbox.size_flags_vertical = Control.SIZE_EXPAND_FILL
	content_hbox.add_theme_constant_override("separation", 20)
	root_vbox.add_child(content_hbox)

	# Left Column: Map Selection
	var map_panel := _make_panel()
	map_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content_hbox.add_child(map_panel)

	var map_vbox := VBoxContainer.new()
	map_vbox.add_theme_constant_override("separation", 8)
	map_panel.add_child(map_vbox)

	var map_hdr := Label.new()
	map_hdr.text = "SELECT MAP (انتخاب نقشه)"
	map_hdr.add_theme_font_size_override("font_size", 16)
	map_hdr.add_theme_color_override("font_color", Color(0.95, 0.78, 0.36, 1.0))
	map_vbox.add_child(map_hdr)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	map_vbox.add_child(scroll)

	var list_vbox := VBoxContainer.new()
	list_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_vbox.add_theme_constant_override("separation", 8)
	scroll.add_child(list_vbox)

	for i in range(MAPS.size()):
		var btn := Button.new()
		btn.text = MAPS[i]["title"]
		btn.custom_minimum_size = Vector2(0, 46)
		btn.add_theme_font_size_override("font_size", 15)
		btn.pressed.connect(_on_select_map.bind(i))
		list_vbox.add_child(btn)
		_map_buttons.append(btn)

	_map_desc_label = Label.new()
	_map_desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_map_desc_label.add_theme_font_size_override("font_size", 13)
	_map_desc_label.add_theme_color_override("font_color", Color(0.75, 0.85, 0.90, 0.92))
	map_vbox.add_child(_map_desc_label)

	# Right Column: Settings
	var settings_panel := _make_panel()
	settings_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content_hbox.add_child(settings_panel)

	var set_vbox := VBoxContainer.new()
	set_vbox.add_theme_constant_override("separation", 14)
	settings_panel.add_child(set_vbox)

	var set_hdr := Label.new()
	set_hdr.text = "SETTINGS (تنظیمات)"
	set_hdr.add_theme_font_size_override("font_size", 16)
	set_hdr.add_theme_color_override("font_color", Color(0.95, 0.78, 0.36, 1.0))
	set_vbox.add_child(set_hdr)

	var q_row := HBoxContainer.new()
	var q_lbl := Label.new()
	q_lbl.text = "Graphics Quality:"
	q_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	q_row.add_child(q_lbl)
	_quality_btn = OptionButton.new()
	_quality_btn.custom_minimum_size = Vector2(160, 40)
	for q in ["low", "medium", "high"]:
		_quality_btn.add_item(q.to_upper())
	var cur_q := SettingsManager.get_quality_preset()
	_quality_btn.selected = ["low", "medium", "high"].find(cur_q)
	_quality_btn.item_selected.connect(_on_quality_selected)
	q_row.add_child(_quality_btn)
	set_vbox.add_child(q_row)

	var w_row := HBoxContainer.new()
	var w_lbl := Label.new()
	w_lbl.text = "Weather:"
	w_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	w_row.add_child(w_lbl)
	_weather_btn = OptionButton.new()
	_weather_btn.custom_minimum_size = Vector2(160, 40)
	for w in ["Clear", "Fog", "Rain & Storm"]:
		_weather_btn.add_item(w)
	var cur_w := str(SettingsManager.get_setting("weather_preset", "fog"))
	_weather_btn.selected = maxi(0, ["clear", "fog", "rain"].find(cur_w))
	_weather_btn.item_selected.connect(_on_weather_selected)
	w_row.add_child(_weather_btn)
	set_vbox.add_child(w_row)

	var s_hdr := HBoxContainer.new()
	var s_lbl := Label.new()
	s_lbl.text = "Look Sensitivity:"
	s_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s_hdr.add_child(s_lbl)
	_sens_value_label = Label.new()
	var cur_sens := float(SettingsManager.get_setting("look_sensitivity", 1.0))
	_sens_value_label.text = "%.2f" % cur_sens
	s_hdr.add_child(_sens_value_label)
	set_vbox.add_child(s_hdr)

	_sens_slider = HSlider.new()
	_sens_slider.min_value = 0.4
	_sens_slider.max_value = 2.2
	_sens_slider.step = 0.05
	_sens_slider.value = cur_sens
	_sens_slider.custom_minimum_size = Vector2(0, 32)
	_sens_slider.value_changed.connect(_on_sensitivity_changed)
	set_vbox.add_child(_sens_slider)

	var t_row := HBoxContainer.new()
	var t_lbl := Label.new()
	t_lbl.text = "Team Size (AI Bots):"
	t_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t_row.add_child(t_lbl)
	_team_size_btn = OptionButton.new()
	_team_size_btn.custom_minimum_size = Vector2(160, 40)
	for ts in ["2 vs 2", "4 vs 4", "6 vs 6"]:
		_team_size_btn.add_item(ts)
	var cur_b := int(SettingsManager.get_setting("bots_per_team", 4))
	_team_size_btn.selected = maxi(0, [2, 4, 6].find(cur_b))
	_team_size_btn.item_selected.connect(_on_team_size_selected)
	t_row.add_child(_team_size_btn)
	set_vbox.add_child(t_row)

	var play_btn := Button.new()
	play_btn.text = "DEPLOY TO MAP  (شروع بازی)"
	play_btn.custom_minimum_size = Vector2(0, 56)
	play_btn.add_theme_font_size_override("font_size", 20)
	play_btn.modulate = Color(0.45, 0.94, 1.0, 1.0)
	play_btn.pressed.connect(_on_play_pressed)
	root_vbox.add_child(play_btn)

	_on_select_map(0)

func _make_panel() -> PanelContainer:
	var panel := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.08, 0.12, 0.16, 0.92)
	style.border_color = Color(0.32, 0.65, 0.78, 0.55)
	style.set_border_width_all(2)
	style.set_corner_radius_all(12)
	style.set_content_margin_all(18)
	panel.add_theme_stylebox_override("panel", style)
	return panel

func _on_select_map(index: int) -> void:
	_selected_map_index = clampi(index, 0, MAPS.size() - 1)
	_map_desc_label.text = MAPS[_selected_map_index]["subtitle"]
	for i in range(_map_buttons.size()):
		_map_buttons[i].modulate = Color(0.45, 0.95, 1.0, 1.0) if i == _selected_map_index else Color(0.75, 0.82, 0.86, 0.75)

func _on_quality_selected(index: int) -> void:
	var presets := ["low", "medium", "high"]
	if index >= 0 and index < presets.size():
		SettingsManager.set_quality_preset(presets[index])

func _on_weather_selected(index: int) -> void:
	var presets := ["clear", "fog", "rain"]
	if index >= 0 and index < presets.size():
		SettingsManager.set_setting("weather_preset", presets[index])

func _on_sensitivity_changed(val: float) -> void:
	_sens_value_label.text = "%.2f" % val
	SettingsManager.set_setting("look_sensitivity", val)

func _on_team_size_selected(index: int) -> void:
	var counts := [2, 4, 6]
	if index >= 0 and index < counts.size():
		SettingsManager.set_setting("bots_per_team", counts[index])

func _on_play_pressed() -> void:
	var scene_path: String = MAPS[_selected_map_index]["scene"]
	get_tree().change_scene_to_file(scene_path)

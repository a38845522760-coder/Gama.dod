extends RefCounted
class_name UIStyle

## Shared look for every menu: rounded pill buttons, touch-sized sliders and dark steel panels.

const COLOR_BG := Color("#070d13")
const COLOR_PANEL := Color(0.035, 0.060, 0.080, 0.965)
const COLOR_PANEL_LIGHT := Color(0.075, 0.105, 0.132, 0.985)
const COLOR_BORDER := Color(0.22, 0.31, 0.37, 0.96)
const COLOR_ACCENT := Color("#e5a34b")
const COLOR_ACCENT_DARK := Color("#9f6428")
const COLOR_CYAN := Color("#62c8da")
const COLOR_TEXT := Color("#edf3f6")
const COLOR_TEXT_DIM := Color("#91a3ad")
const COLOR_DANGER := Color("#df5b50")
const COLOR_SUCCESS := Color("#78c89a")

static var _theme: Theme = null
static var _grabber: Texture2D = null

static func box(fill: Color, border: Color = Color(0, 0, 0, 0), radius: int = 16, border_width: int = 0) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = fill
    style.border_color = border
    style.set_border_width_all(border_width)
    style.set_corner_radius_all(radius)
    style.content_margin_left = 22
    style.content_margin_right = 22
    style.content_margin_top = 12
    style.content_margin_bottom = 12
    style.anti_aliasing = true
    style.shadow_color = Color(0.0, 0.0, 0.0, 0.34)
    style.shadow_size = 7 if radius >= 14 else 3
    style.shadow_offset = Vector2(0.0, 3.0)
    return style

static func get_theme() -> Theme:
    if _theme != null:
        return _theme
    var theme := Theme.new()
    theme.default_font_size = 22
    theme.set_color("font_color", "Label", COLOR_TEXT)
    theme.set_color("font_color", "Button", COLOR_TEXT)
    theme.set_color("font_hover_color", "Button", Color.WHITE)
    theme.set_color("font_pressed_color", "Button", Color.WHITE)
    theme.set_color("font_focus_color", "Button", Color.WHITE)
    theme.set_color("font_disabled_color", "Button", COLOR_TEXT_DIM)
    theme.set_stylebox("normal", "Button", box(COLOR_PANEL_LIGHT, COLOR_BORDER, 13, 1))
    theme.set_stylebox("hover", "Button", box(Color(0.105, 0.15, 0.18, 1.0), COLOR_CYAN, 13, 2))
    theme.set_stylebox("pressed", "Button", box(Color(0.18, 0.13, 0.075, 1.0), COLOR_ACCENT, 13, 2))
    theme.set_stylebox("focus", "Button", box(Color(0.08, 0.12, 0.15, 1.0), COLOR_CYAN, 13, 2))
    theme.set_stylebox("disabled", "Button", box(Color(0.075, 0.09, 0.105, 0.86), Color(0.18, 0.23, 0.27, 0.8), 13, 1))
    theme.set_constant("h_separation", "Button", 10)
    theme.set_constant("outline_size", "Button", 0)
    for control_type in ["LineEdit", "TextEdit"]:
        theme.set_stylebox("normal", control_type, box(Color(0.025, 0.045, 0.06, 0.98), COLOR_BORDER, 10, 1))
        theme.set_stylebox("focus", control_type, box(Color(0.035, 0.06, 0.075, 1.0), COLOR_CYAN, 10, 2))
    theme.set_stylebox("normal", "OptionButton", box(COLOR_PANEL_LIGHT, COLOR_BORDER, 12, 1))
    theme.set_stylebox("hover", "OptionButton", box(Color(0.105, 0.15, 0.18, 1.0), COLOR_CYAN, 12, 2))
    theme.set_stylebox("pressed", "OptionButton", box(Color(0.18, 0.13, 0.075, 1.0), COLOR_ACCENT, 12, 2))
    var track := box(Color(0.16, 0.22, 0.27, 1.0), Color(0, 0, 0, 0), 8, 0)
    track.content_margin_top = 6
    track.content_margin_bottom = 6
    var fill := box(COLOR_ACCENT, Color(0, 0, 0, 0), 8, 0)
    fill.content_margin_top = 6
    fill.content_margin_bottom = 6
    theme.set_stylebox("slider", "HSlider", track)
    theme.set_stylebox("grabber_area", "HSlider", fill)
    theme.set_stylebox("grabber_area_highlight", "HSlider", fill)
    var grabber := _make_grabber()
    theme.set_icon("grabber", "HSlider", grabber)
    theme.set_icon("grabber_highlight", "HSlider", grabber)
    theme.set_icon("grabber_disabled", "HSlider", grabber)
    theme.set_constant("center_grabber", "HSlider", 0)
    theme.set_stylebox("panel", "PanelContainer", box(COLOR_PANEL, COLOR_BORDER, 16, 1))
    theme.set_stylebox("panel", "PopupPanel", box(Color(0.025, 0.04, 0.055, 0.99), COLOR_BORDER, 14, 1))
    theme.set_color("font_color", "RichTextLabel", COLOR_TEXT)
    theme.set_color("font_color", "CheckBox", COLOR_TEXT)
    theme.set_color("font_color", "CheckButton", COLOR_TEXT)
    _theme = theme
    return theme

static func _make_grabber() -> Texture2D:
    if _grabber != null:
        return _grabber
    var size := 56
    var image := Image.create(size, size, false, Image.FORMAT_RGBA8)
    var center := Vector2(size * 0.5, size * 0.5)
    for y in range(size):
        for x in range(size):
            var distance := Vector2(x + 0.5, y + 0.5).distance_to(center)
            var color := Color(0, 0, 0, 0)
            if distance <= 26.0:
                color = Color("#f4f9fb") if distance <= 20.0 else COLOR_ACCENT
                color.a = clampf(27.0 - distance, 0.0, 1.0)
            image.set_pixel(x, y, color)
    _grabber = ImageTexture.create_from_image(image)
    return _grabber

static func style_primary(button: Button) -> void:
    button.add_theme_stylebox_override("normal", box(COLOR_ACCENT, Color("#f7d29a"), 13, 1))
    button.add_theme_stylebox_override("hover", box(Color("#f0b968"), Color.WHITE, 13, 2))
    button.add_theme_stylebox_override("pressed", box(COLOR_ACCENT_DARK, Color("#f7d29a"), 13, 2))
    button.add_theme_color_override("font_color", Color("#15100a"))
    button.add_theme_color_override("font_hover_color", Color("#15100a"))
    button.add_theme_color_override("font_pressed_color", Color.WHITE)
    button.add_theme_color_override("font_focus_color", Color("#15100a"))

static func style_danger(button: Button) -> void:
    button.add_theme_stylebox_override("normal", box(Color(0.30, 0.10, 0.09, 1.0), COLOR_DANGER, 13, 2))
    button.add_theme_stylebox_override("hover", box(Color(0.42, 0.13, 0.11, 1.0), COLOR_DANGER, 13, 2))

static func style_toggle(button: Button, active: bool, accent: Color = COLOR_CYAN) -> void:
    var fill := Color(0.13, 0.16, 0.17, 1.0) if active else COLOR_PANEL_LIGHT
    var line := accent if active else COLOR_BORDER
    button.add_theme_stylebox_override("normal", box(fill, line, 12, 2 if active else 1))
    button.add_theme_stylebox_override("hover", box(fill.lightened(0.08), accent, 12, 2))
    button.add_theme_stylebox_override("pressed", box(fill.darkened(0.08), accent.lightened(0.1), 12, 2))
    button.add_theme_color_override("font_color", COLOR_TEXT if active else COLOR_TEXT_DIM)

static func make_button(text: String, primary: bool = false, min_size: Vector2 = Vector2(0, 60)) -> Button:
    var button := Button.new()
    button.text = text
    button.custom_minimum_size = min_size
    button.focus_mode = Control.FOCUS_ALL
    button.add_theme_font_size_override("font_size", 22)
    button.clip_text = true
    if primary:
        style_primary(button)
    return button

static func make_label(text: String, size: int = 22, color: Color = COLOR_TEXT) -> Label:
    var label := Label.new()
    label.text = text
    label.add_theme_font_size_override("font_size", size)
    label.add_theme_color_override("font_color", color)
    label.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.5))
    label.add_theme_constant_override("shadow_offset_x", 1)
    label.add_theme_constant_override("shadow_offset_y", 2)
    return label

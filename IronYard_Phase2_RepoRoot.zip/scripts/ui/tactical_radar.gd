extends Control
class_name TacticalRadar

## Compact, rotation-relative tactical radar for zombie survival. Contacts are refreshed at
## 8 Hz; drawing remains lightweight and does not allocate scene nodes per contact.

var manager: Node
var _refresh_left: float = 0.0
var _contacts: Array[Dictionary] = []
const RADAR_RANGE: float = 96.0
const RADAR_RADIUS: float = 55.0

func _ready() -> void:
    custom_minimum_size = Vector2(148.0, 148.0)
    size = custom_minimum_size
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    process_mode = Node.PROCESS_MODE_PAUSABLE

func _process(delta: float) -> void:
    _refresh_left -= delta
    if _refresh_left > 0.0:
        return
    _refresh_left = 0.125
    if manager != null and is_instance_valid(manager) and manager.has_method("get_radar_contacts"):
        var raw: Variant = manager.call("get_radar_contacts", RADAR_RANGE)
        _contacts.clear()
        if raw is Array:
            for entry in raw:
                if entry is Dictionary:
                    _contacts.append(entry)
    queue_redraw()

func _draw() -> void:
    var center := size * 0.5
    draw_circle(center + Vector2(0.0, 2.0), RADAR_RADIUS + 12.0, Color(0.0, 0.0, 0.0, 0.32))
    draw_circle(center, RADAR_RADIUS + 11.0, Color(0.025, 0.045, 0.055, 0.82))
    draw_arc(center, RADAR_RADIUS + 10.0, 0.0, TAU, 72, Color(0.52, 0.72, 0.77, 0.5), 1.4, true)
    draw_circle(center, RADAR_RADIUS, Color(0.035, 0.085, 0.09, 0.72))
    for ring in [0.33, 0.66, 1.0]:
        draw_arc(center, RADAR_RADIUS * ring, 0.0, TAU, 56, Color(0.35, 0.77, 0.72, 0.16), 1.0, true)
    draw_line(center + Vector2(-RADAR_RADIUS, 0.0), center + Vector2(RADAR_RADIUS, 0.0), Color(0.42, 0.76, 0.74, 0.12), 1.0)
    draw_line(center + Vector2(0.0, -RADAR_RADIUS), center + Vector2(0.0, RADAR_RADIUS), Color(0.42, 0.76, 0.74, 0.12), 1.0)
    draw_arc(center, RADAR_RADIUS - 2.0, deg_to_rad(218.0), deg_to_rad(322.0), 28, Color(0.28, 0.85, 0.78, 0.2), 2.0, true)
    # Contacts arrive in view-relative normalized coordinates from ModeManager.
    for contact in _contacts:
        var relative: Vector2 = contact.get("relative", Vector2.ZERO)
        var point := center + relative * RADAR_RADIUS
        var is_boss: bool = bool(contact.get("boss", false))
        var dot_color := Color("#ffb45b") if is_boss else Color("#ff5d55")
        if is_boss:
            draw_circle(point, 6.8, Color(1.0, 0.46, 0.15, 0.16))
            draw_circle(point, 4.0, dot_color)
            draw_arc(point, 7.0, 0.0, TAU, 20, Color(1.0, 0.73, 0.36, 0.85), 1.3, true)
        else:
            draw_circle(point, 3.2, Color(1.0, 0.25, 0.22, 0.18))
            draw_circle(point, 2.0, dot_color)
    # Player marker is fixed at the center; the contact field rotates with the player's view.
    var marker := PackedVector2Array([center + Vector2(0.0, -7.0), center + Vector2(-5.0, 5.0), center + Vector2(5.0, 5.0)])
    draw_colored_polygon(marker, Color("#e5fff7"))
    draw_polyline(PackedVector2Array([marker[0], marker[1], marker[2], marker[0]]), Color(0.02, 0.16, 0.14, 0.9), 1.0, true)
    draw_string(ThemeDB.fallback_font, Vector2(8.0, 14.0), "TACTICAL", HORIZONTAL_ALIGNMENT_LEFT, -1.0, 9, Color(0.68, 0.85, 0.85, 0.78))
    draw_string(ThemeDB.fallback_font, Vector2(size.x - 8.0, size.y - 7.0), "96M", HORIZONTAL_ALIGNMENT_RIGHT, -1.0, 9, Color(0.68, 0.85, 0.85, 0.65))

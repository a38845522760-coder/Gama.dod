extends Control

## Shown between the mode-select screen and the map. The map is built from code, so it takes a
## moment: this screen appears first (with a progress bar) and the map loads behind it.

const MENU_SCENE := "res://scenes/ui/main_menu.tscn"
const MIN_SHOW_SECONDS: float = 0.8

var _path: String = ""
var _bar: ProgressBar
var _elapsed: float = 0.0
var _switching: bool = false

func _ready() -> void:
    AppState.set_active_screen("loading")
    _path = AppState.pending_scene
    AppState.pending_scene = ""
    _build()
    if _path.is_empty():
        _path = MENU_SCENE
    ResourceLoader.load_threaded_request(_path)

func _build() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var background := ColorRect.new()
    background.color = Color("#0b1118")
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(background)
    var center := CenterContainer.new()
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var box := VBoxContainer.new()
    box.custom_minimum_size = Vector2(520, 0)
    box.add_theme_constant_override("separation", 18)
    center.add_child(box)
    var title := Label.new()
    title.text = Loc.t("app_title")
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 56)
    title.add_theme_color_override("font_color", Color("#e1ecf7"))
    box.add_child(title)
    var status := Label.new()
    status.text = Loc.t("loading_map")
    status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    status.add_theme_font_size_override("font_size", 26)
    status.add_theme_color_override("font_color", Color("#ffd166"))
    box.add_child(status)
    _bar = ProgressBar.new()
    _bar.min_value = 0.0
    _bar.max_value = 100.0
    _bar.show_percentage = false
    _bar.custom_minimum_size = Vector2(0, 14)
    box.add_child(_bar)
    var tip := Label.new()
    tip.text = Loc.t("loading_tip")
    tip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    tip.add_theme_font_size_override("font_size", 20)
    tip.add_theme_color_override("font_color", Color("#8fa6b0"))
    box.add_child(tip)
    Loc.apply_direction(self)

func _process(delta: float) -> void:
    if _switching or _path.is_empty():
        return
    _elapsed += delta
    var progress: Array = []
    var status := ResourceLoader.load_threaded_get_status(_path, progress)
    var target: float = float(progress[0]) * 100.0 if not progress.is_empty() else 0.0
    # Keep the bar moving even while the scene itself is tiny: it also covers the map build time.
    target = maxf(target, minf(90.0, _elapsed / MIN_SHOW_SECONDS * 90.0))
    _bar.value = move_toward(_bar.value, target, 160.0 * delta)
    if status == ResourceLoader.THREAD_LOAD_FAILED or status == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
        _switching = true
        get_tree().change_scene_to_file(MENU_SCENE)
    elif status == ResourceLoader.THREAD_LOAD_LOADED and _elapsed >= MIN_SHOW_SECONDS:
        _switching = true
        _bar.value = 100.0
        _finish()

func _finish() -> void:
    # Let the full bar be drawn once, then build the map (the screen stays visible until it is ready).
    await get_tree().process_frame
    await get_tree().process_frame
    var packed := ResourceLoader.load_threaded_get(_path) as PackedScene
    if packed == null:
        get_tree().change_scene_to_file(MENU_SCENE)
    else:
        get_tree().change_scene_to_packed(packed)

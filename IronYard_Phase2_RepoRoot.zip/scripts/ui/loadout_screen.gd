extends Control
class_name LoadoutScreen

## Build your loadout: attachments for each gun, the support power and two extra items.

signal closed

var _weapon: String = "rifle"
var _content: VBoxContainer
var _scroll: TouchScroll
var _status: Label
var _credits: Label

func _ready() -> void:
    theme = UIStyle.get_theme()
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layout_direction = Control.LAYOUT_DIRECTION_RTL if Loc.is_rtl() else Control.LAYOUT_DIRECTION_LTR
    _weapon = SaveManager.get_selected_weapon()
    if not SaveManager.get_owned_weapons().has(_weapon):
        _weapon = SaveManager.get_owned_weapons()[0]
    var dim := ColorRect.new()
    dim.color = Color(0.02, 0.04, 0.06, 0.97)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(dim)
    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    for side in ["left", "right", "top", "bottom"]:
        margin.add_theme_constant_override("margin_" + side, 18)
    add_child(margin)
    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", 10)
    margin.add_child(column)
    var header := HBoxContainer.new()
    column.add_child(header)
    var title := UIStyle.make_label(Loc.t("loadout"), 38, UIStyle.COLOR_ACCENT)
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    header.add_child(title)
    _credits = UIStyle.make_label("", 24, UIStyle.COLOR_CYAN)
    header.add_child(_credits)
    var back := UIStyle.make_button(Loc.t("back"), false, Vector2(150, 56))
    back.pressed.connect(func() -> void: closed.emit())
    header.add_child(back)
    _status = UIStyle.make_label("", 20, UIStyle.COLOR_DANGER)
    _status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    column.add_child(_status)
    _scroll = TouchScroll.new()
    _scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    _scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    column.add_child(_scroll)
    _content = VBoxContainer.new()
    _content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    _content.add_theme_constant_override("separation", 10)
    _scroll.add_child(_content)
    _build_content()

func _lang() -> String:
    return Loc.language

func _rebuild() -> void:
    var keep: int = _scroll.scroll_vertical
    _build_content()
    _scroll.set_deferred("scroll_vertical", keep)

func _section(text: String) -> void:
    var label := UIStyle.make_label(text, 26, UIStyle.COLOR_ACCENT)
    _content.add_child(label)

func _build_content() -> void:
    for child in _content.get_children():
        child.queue_free()
    _credits.text = "%s: %d" % [Loc.t("credits"), SaveManager.get_credits()]

    # ---- weapon
    _section(Loc.t("loadout_weapon"))
    var flow := HFlowContainer.new()
    flow.add_theme_constant_override("h_separation", 8)
    flow.add_theme_constant_override("v_separation", 8)
    _content.add_child(flow)
    for id in SaveManager.get_owned_weapons():
        var weapon_id: String = id
        var button := UIStyle.make_button(WeaponDefinitions.get_display_name(weapon_id, _lang()), false, Vector2(0, 56))
        button.toggle_mode = true
        button.button_pressed = weapon_id == _weapon
        button.add_theme_font_size_override("font_size", 20)
        button.pressed.connect(func() -> void:
            _weapon = weapon_id
            SaveManager.set_selected_weapon(weapon_id)
            _status.text = ""
            _rebuild())
        flow.add_child(button)
    var def: Dictionary = WeaponAttachments.apply(WeaponDefinitions.get_definition(_weapon), WeaponAttachments.get_equipped(_weapon))
    var info := UIStyle.make_label("%s ×%.1f     %s %d     %s %.0f" % [Loc.t("zoom_label"), float(def.get("zoom", 2.0)), Loc.t("magazine"), int(def["magazine_size"]), Loc.t("damage"), float(def["damage"])], 20, UIStyle.COLOR_TEXT_DIM)
    info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _content.add_child(info)

    # ---- attachments
    _section("%s  (%d / %d)" % [Loc.t("loadout_attachments"), WeaponAttachments.get_equipped(_weapon).size(), WeaponAttachments.MAX_EQUIPPED])
    for att in WeaponAttachments.ORDER:
        _content.add_child(_attachment_row(att))

    # ---- power
    _section(Loc.t("loadout_power"))
    var loadout: Dictionary = FieldKit.get_loadout()
    for id in FieldKit.POWERS.keys():
        _content.add_child(_choice_row("power", str(id), FieldKit.POWERS[id], str(loadout["power"])))
    _section(Loc.t("loadout_item1"))
    for id in FieldKit.ITEMS.keys():
        _content.add_child(_choice_row("item1", str(id), FieldKit.ITEMS[id], str(loadout["item1"])))
    _section(Loc.t("loadout_item2"))
    for id in FieldKit.ITEMS.keys():
        _content.add_child(_choice_row("item2", str(id), FieldKit.ITEMS[id], str(loadout["item2"])))

func _attachment_row(att: String) -> Control:
    var owned: bool = WeaponAttachments.owns(att)
    var equipped: bool = WeaponAttachments.get_equipped(_weapon).has(att)
    var text: String = "%s\n%s" % [WeaponAttachments.get_name(att, _lang()), WeaponAttachments.get_desc(att, _lang())]
    if not owned:
        text += "\n%s: %d" % [Loc.t("att_buy"), WeaponAttachments.get_price(att)]
    var button := Button.new()
    button.toggle_mode = true
    button.focus_mode = Control.FOCUS_NONE
    button.button_pressed = equipped
    button.custom_minimum_size = Vector2(0, 96 if not owned else 80)
    button.alignment = HORIZONTAL_ALIGNMENT_LEFT if not Loc.is_rtl() else HORIZONTAL_ALIGNMENT_RIGHT
    button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    button.text = ("✓  " if equipped else "") + text
    button.add_theme_font_size_override("font_size", 20)
    var accent := Color("#41d9ee") if equipped else Color("#8fa6b0")
    button.add_theme_stylebox_override("normal", UIStyle.box(UIStyle.COLOR_PANEL_LIGHT, accent.darkened(0.3), 18, 2))
    button.add_theme_stylebox_override("pressed", UIStyle.box(accent.darkened(0.6), accent, 18, 3))
    button.add_theme_stylebox_override("hover", UIStyle.box(Color(0.16, 0.22, 0.27, 1.0), accent, 18, 2))
    button.pressed.connect(func() -> void: _on_attachment_pressed(att))
    return button

func _on_attachment_pressed(att: String) -> void:
    _status.text = ""
    if not WeaponAttachments.owns(att):
        if not WeaponAttachments.buy(att):
            _status.text = Loc.t("not_enough_credits")
            _rebuild()
            return
        if not WeaponAttachments.set_equipped(_weapon, att, true):
            _status.text = Loc.t("att_max")
        _rebuild()
        return
    var equipped: bool = WeaponAttachments.get_equipped(_weapon).has(att)
    if not WeaponAttachments.set_equipped(_weapon, att, not equipped):
        _status.text = Loc.t("att_max")
    _rebuild()

func _choice_row(slot: String, id: String, def: Dictionary, current: String) -> Control:
    var chosen: bool = id == current
    var button := Button.new()
    button.toggle_mode = true
    button.focus_mode = Control.FOCUS_NONE
    button.button_pressed = chosen
    button.custom_minimum_size = Vector2(0, 80)
    button.alignment = HORIZONTAL_ALIGNMENT_LEFT if not Loc.is_rtl() else HORIZONTAL_ALIGNMENT_RIGHT
    button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    var name_text: String = str(def.get("name_fa" if _lang() == "fa" else "name_en", id))
    var desc_text: String = str(def.get("desc_fa" if _lang() == "fa" else "desc_en", ""))
    button.text = ("✓  " if chosen else "") + name_text + "\n" + desc_text
    button.add_theme_font_size_override("font_size", 20)
    var accent := Color("#e8943a") if chosen else Color("#8fa6b0")
    button.add_theme_stylebox_override("normal", UIStyle.box(UIStyle.COLOR_PANEL_LIGHT, accent.darkened(0.3), 18, 2))
    button.add_theme_stylebox_override("pressed", UIStyle.box(accent.darkened(0.6), accent, 18, 3))
    button.add_theme_stylebox_override("hover", UIStyle.box(Color(0.16, 0.22, 0.27, 1.0), accent, 18, 2))
    button.pressed.connect(func() -> void:
        FieldKit.set_loadout(slot, id)
        _status.text = ""
        _rebuild())
    return button

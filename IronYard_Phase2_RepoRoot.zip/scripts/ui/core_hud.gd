extends CanvasLayer
class_name CoreHUD

var _info_label: Label
var _prompt_label: Label
var _crosshair: Label
var _movement_label: Label
var _stamina_label: Label
var _stamina_bar: ProgressBar
var _ammo_label: Label
var _elapsed: float = 0.0
var _player: Node

func _ready() -> void:
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(root)

    _info_label = Label.new()
    _info_label.position = Vector2(18.0, 16.0)
    _info_label.add_theme_color_override("font_color", Color(0.86, 0.94, 0.97, 0.92))
    _info_label.add_theme_font_size_override("font_size", 15)
    root.add_child(_info_label)

    _movement_label = Label.new()
    _movement_label.position = Vector2(18.0, 40.0)
    _movement_label.add_theme_color_override("font_color", Color(0.58, 0.77, 0.82, 0.88))
    _movement_label.add_theme_font_size_override("font_size", 12)
    root.add_child(_movement_label)

    _stamina_label = Label.new()
    _stamina_label.position = Vector2(18.0, 62.0)
    _stamina_label.text = "STAMINA 100%"
    _stamina_label.add_theme_color_override("font_color", Color(0.66, 0.84, 0.76, 0.90))
    _stamina_label.add_theme_font_size_override("font_size", 11)
    root.add_child(_stamina_label)

    _stamina_bar = ProgressBar.new()
    _stamina_bar.position = Vector2(18.0, 82.0)
    _stamina_bar.size = Vector2(190.0, 9.0)
    _stamina_bar.min_value = 0.0
    _stamina_bar.max_value = 100.0
    _stamina_bar.value = 100.0
    _stamina_bar.show_percentage = false
    _stamina_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
    root.add_child(_stamina_bar)

    _ammo_label = Label.new()
    _ammo_label.position = Vector2(18.0, 98.0)
    _ammo_label.text = "AMMO  30 / 180"
    _ammo_label.add_theme_color_override("font_color", Color(0.98, 0.84, 0.48, 0.94))
    _ammo_label.add_theme_font_size_override("font_size", 14)
    root.add_child(_ammo_label)

    _crosshair = Label.new()
    _crosshair.text = "+"
    _crosshair.add_theme_font_size_override("font_size", 28)
    _crosshair.add_theme_color_override("font_color", Color(0.9, 0.97, 1.0, 0.75))
    _crosshair.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    _crosshair.position = Vector2(-8.0, -18.0)
    root.add_child(_crosshair)

    _prompt_label = Label.new()
    _prompt_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
    _prompt_label.position = Vector2(-180.0, -112.0)
    _prompt_label.size = Vector2(360.0, 36.0)
    _prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _prompt_label.add_theme_font_size_override("font_size", 18)
    _prompt_label.add_theme_color_override("font_color", Color(0.85, 0.95, 0.98, 1.0))
    root.add_child(_prompt_label)

    var players := get_tree().get_nodes_in_group("player_controller")
    if not players.is_empty():
        _player = players[0]
        if _player.has_signal("interaction_prompt_changed"):
            _player.connect("interaction_prompt_changed", Callable(self, "_on_interaction_prompt_changed"))

func _process(delta: float) -> void:
    _elapsed += delta
    if _elapsed < 0.15:
        return
    _elapsed = 0.0
    var snapshot := PerformanceManager.get_performance_snapshot()
    var movement_text := "NO PLAYER"
    var movement: Dictionary = {}
    if is_instance_valid(_player) and _player.has_method("get_movement_snapshot"):
        movement = _player.call("get_movement_snapshot")
        var stance_tag := ""
        if bool(movement.get("sliding", false)):
            stance_tag = "  SLIDE"
        elif bool(movement.get("prone", false)):
            stance_tag = "  PRONE"
        elif bool(movement.get("crouched", false)):
            stance_tag = "  CROUCH"
        movement_text = "%s  %.1f m/s%s%s" % [
            str(movement.get("state", "idle")).to_upper(),
            float(movement.get("horizontal_speed", 0.0)),
            stance_tag,
            "  SPRINT LOCK" if bool(movement.get("sprinting_locked", false)) else ""
        ]
        if bool(movement.get("reloading", false)):
            _ammo_label.text = "RELOADING..."
        else:
            _ammo_label.text = "AMMO  %d / %d" % [int(movement.get("ammo", 30)), int(movement.get("reserve_ammo", 180))]
        var is_aiming := bool(movement.get("aiming", false))
        _crosshair.text = "•" if is_aiming else "+"
        _crosshair.add_theme_color_override("font_color", Color(1.0, 0.55, 0.25, 0.92) if is_aiming else Color(0.9, 0.97, 1.0, 0.75))
        var stamina_maximum := maxf(float(movement.get("stamina_max", 100.0)), 1.0)
        var stamina_current := clampf(float(movement.get("stamina", stamina_maximum)), 0.0, stamina_maximum)
        _stamina_bar.max_value = stamina_maximum
        _stamina_bar.value = stamina_current
        _stamina_label.text = "STAMINA  %d%%" % roundi(stamina_current / stamina_maximum * 100.0)
    _info_label.text = "IRON YARD  |  %s  |  %d FPS  |  %.1f ms p95  |  %.0f MB\n%s" % [
        str(snapshot["quality_preset"]).to_upper(),
        int(snapshot["fps"]),
        float(snapshot["p95_frame_time_ms"]),
        float(snapshot["memory_static_mb"]),
        movement_text,
    ]
    if not movement.is_empty():
        _movement_label.text = "%s  |  %.1f m/s  |  %s" % [
            str(movement.get("state", "idle")).to_upper(),
            float(movement.get("horizontal_speed", 0.0)),
            str(movement.get("surface_type", "concrete")).to_upper(),
        ]
    else:
        _movement_label.text = "MOVEMENT TELEMETRY UNAVAILABLE"

func _on_interaction_prompt_changed(prompt: String) -> void:
    _prompt_label.text = "[E] " + prompt if not prompt.is_empty() else ""

extends Node
class_name ZombieQuest

## The underground Research Wing Tesla quest and Pack-a-Punch chain.
##   1. Open three gas valves, detonate the underground blast door and activate the basement console.
##   2. Buy access to the main Research Wing and its separate point-locked internal rooms.
##   3. Carry three portable Tesla units from the surface to their matching lab pads.
##   4. Stabilize their fields through changing power, bioelectric, resonance and operator factors.
##   5. Synchronize the three fields, defeat the Inferno Colossus and assemble the Tesla weapon.
## After that: shoot the iron cage with Tesla 3 times, pay a small fee to open the hidden tunnel
## under the assembly machine, press the vault button, and use Pack-a-Punch (6 s).

signal stage_changed(stage: int)

const ASSEMBLY_SECONDS: float = 20.0
const HATCH_FEE: int = 300
const PAP_COST: int = 5000
const PAP_TESLA_COST: int = 2
const PAP_SECONDS: float = 6.0
const TESLA_START_RESERVE: int = 6
const DEVICE_COUNT: int = 3
const HATCH_SLIDE: float = 4.0
const CAGE_LIFT: float = 3.8
const BODY_ROOM_MIN: Vector2 = Vector2(91.0, 33.0)
const BODY_ROOM_MAX: Vector2 = Vector2(113.0, 49.0)

var game: ZombieGame
var machines: Array[Dictionary] = []
var gas_valves: Array[bool] = [false, false, false]
var gas_valve_visuals: Array[Node3D] = []
var device_pads: Array[Node3D] = []
var basement_activated: bool = false
var underground_detonated: bool = false
var basement_activation_visual: Node3D
var detonation_visual: Node3D
var _charge_clock: float = 0.0
var _charge_ui_timer: float = 0.0
var carried: String = ""
var carried_src: int = -1
var carried_node: Node3D
var station: Node3D
var station_powered: bool = false
var boss: FireBoss
var boss_spawned: bool = false
var boss_dead: bool = false
var body_pickup: Node3D
var body_pickup_interact: ZInteract
var assembly: Node3D
var assembly_interact: ZInteract
var assembling: bool = false
var assembly_t: float = 0.0
var assembly_done: bool = false
var tesla_taken: bool = false
var lift: Node3D
var cage: ZCage
var hatch_interact: ZInteract
var hatch_open: bool = false
var button_node: Node3D
var vault_released: bool = false
var pap: Node3D
var pap_busy: bool = false
var pap_t: float = 0.0
var pap_weapon: String = ""
var pap_count: int = 0

var _camera: Node3D
var _hum: AudioStreamPlayer3D
var _clank_left: float = 0.0
var _body_drop: Vector3 = Vector3(102.0, ZombieComplex.FLOOR_Y, 40.0)
var _pap_phase: int = 0
var _bob: float = 0.0
var _hatch_busy: bool = false
var _gun_model: Node3D
var _pap_token: Node3D

func setup(owner_game: ZombieGame) -> void:
    game = owner_game
    _camera = game.player.get_node_or_null("CameraPivot/Camera3D") as Node3D
    _build_gas_valves()
    _build_detonation_button()
    _build_basement_activation()
    _build_machines()
    _build_device_pads()
    _build_station()
    _build_assembly()
    _build_vault_objects()
    EventBus.combatant_killed.connect(_on_combatant_killed)

func _exit_tree() -> void:
    if EventBus.combatant_killed.is_connected(_on_combatant_killed):
        EventBus.combatant_killed.disconnect(_on_combatant_killed)

# ---------------------------------------------------------------- stage / mission text

func stage() -> int:
    if tesla_taken:
        return 6
    if assembly_done:
        return 5
    if boss_dead:
        return 4
    if station_powered:
        return 3
    if _devices_stable() > 0:
        return 2
    return 1

func gas_valve_count() -> int:
    var count: int = 0
    for opened in gas_valves:
        if opened:
            count += 1
    return count

func _delivered_count() -> int:
    var count: int = 0
    for m in machines:
        if bool(m.get("delivered", false)):
            count += 1
    return count

func _devices_stable() -> int:
    var count: int = 0
    for m in machines:
        if bool(m.get("ready", false)):
            count += 1
    return count

func _all_devices_stable() -> bool:
    return machines.size() == DEVICE_COUNT and _devices_stable() == DEVICE_COUNT

func _door_open(id: String) -> bool:
    var door: ZDoor = game.doors.get(id) as ZDoor
    return door != null and door.is_open

func mission_lines() -> Array:
    var t: Callable = ZombieGame.tx
    var lines: Array = []
    if not tesla_taken:
        if gas_valve_count() < 3:
            lines.append(t.call("① Open the three gas valves (%d/3)" % gas_valve_count(), "① سه شیر گاز را باز کن (%d/۳)" % gas_valve_count()))
        elif not _door_open("hatch"):
            lines.append(t.call("② Reach the underground blast door and use the detonation panel", "② به درِ انفجاری زیرزمین برو و پنل انفجار را فعال کن"))
        elif not basement_activated:
            lines.append(t.call("③ Enter the Tesla room and activate the basement system", "③ وارد اتاق تسلا شو و سامانه زیرزمین را فعال کن"))
        elif not _door_open("lab_main"):
            lines.append(t.call("④ Buy the main Research Wing door (1500 pts)", "④ درِ اصلی آزمایشگاه تحقیقاتی را با ۱۵۰۰ امتیاز باز کن"))
        elif _delivered_count() < DEVICE_COUNT:
            lines.append(t.call("⑥ Recover the three Tesla units and carry them to the lab pads (%d/3 delivered)" % _delivered_count(), "⑥ سه دستگاه تسلا را پیدا کن و به جایگاه‌های آزمایشگاه ببر (%d/۳ تحویل‌شده)" % _delivered_count()))
        elif not _all_devices_stable():
            lines.append(t.call("⑦ Stabilize the three Tesla fields (%d/3 stable) — grid power, bioelectric activity and resonance affect them" % _devices_stable(), "⑦ میدان سه دستگاه تسلا را پایدار کن (%d/۳ پایدار)؛ برق، فعالیت زیستی زامبی‌ها و تشدید میدان اثر دارند" % _devices_stable()))
        elif not station_powered:
            lines.append(t.call("⑧ Use the central Tesla synchronizer", "⑧ هماهنگ‌ساز مرکزی تسلا را فعال کن"))
        elif not boss_dead:
            lines.append(t.call("⑨ Defeat the Inferno Colossus", "⑨ غول آتشین را شکست بده"))
        elif not assembly_done and not assembling:
            lines.append(t.call("⑩ Carry the Tesla body to the assembly machine", "⑩ بدنه تسلا را به دستگاه مونتاژ ببر"))
        elif assembling:
            lines.append(t.call("⑩ Assembling… %.1f s" % maxf(0.0, ASSEMBLY_SECONDS - assembly_t), "⑩ مونتاژ… %.1f ثانیه" % maxf(0.0, ASSEMBLY_SECONDS - assembly_t)))
        else:
            lines.append(t.call("⑪ Take the finished Tesla gun", "⑪ تفنگ تسلای ساخته‌شده را بردار"))
    elif cage != null and not cage.is_broken():
        lines.append(t.call("Pack-a-Punch: activate the three cage relays with the Tesla (%d/3)" % cage.hits, "پک‌ای‌پانچ: سه رله قفس را با تسلا فعال کن (%d/۳)" % cage.hits))
    elif not hatch_open:
        lines.append(t.call("Pack-a-Punch: open the service hatch under the assembly machine (%d pts)" % HATCH_FEE, "پک‌ای‌پانچ: دریچه سرویس زیر دستگاه مونتاژ را با %d امتیاز باز کن" % HATCH_FEE))
    elif not vault_released:
        lines.append(t.call("Pack-a-Punch: reach the control room and press the vault release", "پک‌ای‌پانچ: به اتاق کنترل برو و دکمه آزادسازی خزانه را بزن"))
    else:
        lines.append(t.call("Pack-a-Punch ready: %d pts + %d Tesla charges" % [PAP_COST, PAP_TESLA_COST], "پک‌ای‌پانچ آماده است: %d امتیاز + %d شارژ تسلا" % [PAP_COST, PAP_TESLA_COST]))
    return lines

func _refresh() -> void:
    stage_changed.emit(stage())
    game.refresh_missions()

# ---------------------------------------------------------------- gas valves, underground access and portable Tesla units

func _build_gas_valves() -> void:
    gas_valves = [false, false, false]
    var index: int = 0
    for pos in game.sites["gas_valves"]:
        var visual: Node3D = ZombieProps.build_gas_valve()
        visual.name = "GasValve_%d" % index
        game.root3d.add_child(visual)
        visual.global_position = pos
        visual.rotation.y = atan2(-pos.x, -pos.z)
        gas_valve_visuals.append(visual)
        game.register_cullable(visual)
        var captured: int = index
        game.make_interact(visual, "Interact_GasValve_%d" % index, pos,
            func() -> String: return _gas_valve_text(captured),
            func(_a: Node) -> void: _open_gas_valve(captured),
            func(_a: Node) -> bool: return not gas_valves[captured],
            Vector3(2.3, 2.8, 2.3), Vector3(0.0, 1.3, 0.0), true)
        index += 1

func _gas_valve_text(index: int) -> String:
    if gas_valves[index]:
        return ZombieGame.tx("Gas valve open", "شیر گاز باز است")
    return ZombieGame.tx("Turn gas valve %d/3" % (index + 1), "بازکردن شیر گاز %d/۳" % (index + 1))

func _open_gas_valve(index: int) -> void:
    if gas_valves[index]:
        return
    gas_valves[index] = true
    var visual: Node3D = gas_valve_visuals[index]
    var wheel: Node3D = visual.get_meta("wheel")
    var tw: Tween = wheel.create_tween()
    tw.tween_property(wheel, "rotation:z", TAU, 0.9).as_relative().set_trans(Tween.TRANS_CUBIC)
    var lamp: StandardMaterial3D = visual.get_meta("lamp_mat")
    lamp.emission = Color("#3dff7a")
    lamp.albedo_color = Color("#3dff7a")
    var light_node: OmniLight3D = visual.get_meta("light")
    light_node.light_color = Color("#3dff7a")
    light_node.light_energy = 1.8
    ZombieProps.burst(game.root3d, visual.global_position + Vector3(0.0, 1.1, 0.0), Color("#9dffb0"), 12, 0.5)
    ZombieProps.play(visual, visual.global_position, "clank", -2.0, 0.9, 30.0)
    game.notify(ZombieGame.tx("Gas valve opened (%d/3)" % gas_valve_count(), "شیر گاز باز شد (%d/۳)" % gas_valve_count()), Color("#9dffb0"))
    _refresh()

func _build_detonation_button() -> void:
    var pos: Vector3 = game.sites["detonation_button"]
    detonation_visual = ZombieProps.build_button()
    detonation_visual.name = "UndergroundDetonationPanel"
    game.root3d.add_child(detonation_visual)
    detonation_visual.global_position = pos
    var title: Label3D = detonation_visual.find_child("Label3D", true, false) as Label3D
    if title != null:
        title.text = ZombieGame.tx("DETONATION PANEL", "پنل انفجار")
    game.register_cullable(detonation_visual)
    game.make_interact(detonation_visual, "Interact_Detonation", pos,
        func() -> String: return _detonation_text(),
        func(_a: Node) -> void: _detonate_underground_door(),
        func(_a: Node) -> bool: return not underground_detonated,
        Vector3(2.2, 2.8, 2.2), Vector3(0.0, 1.2, 0.0), true)

func _detonation_text() -> String:
    if underground_detonated:
        return ZombieGame.tx("Underground door opened", "درِ زیرزمین باز شده است")
    if gas_valve_count() < 3:
        return ZombieGame.tx("Detonation locked — open all three gas valves (%d/3)" % gas_valve_count(), "انفجار قفل است؛ هر سه شیر گاز را باز کن (%d/۳)" % gas_valve_count())
    return ZombieGame.tx("Press detonation control", "دکمه انفجار را فشار بده")

func _detonate_underground_door() -> void:
    if underground_detonated or gas_valve_count() < 3:
        game.notify(ZombieGame.tx("All three gas valves must be open first", "اول باید هر سه شیر گاز باز باشند"), Color("#ffd23d"))
        return
    underground_detonated = true
    var cap: Node3D = detonation_visual.get_meta("cap")
    var tw: Tween = cap.create_tween().set_parallel(true)
    tw.tween_property(cap, "position:y", 1.02, 0.18)
    tw.tween_property(cap, "scale", Vector3.ONE * 0.82, 0.18)
    var lamp: StandardMaterial3D = detonation_visual.get_meta("cap_mat")
    lamp.emission = Color("#3dff7a")
    lamp.albedo_color = Color("#3dff7a")
    var door: ZDoor = game.doors.get("hatch") as ZDoor
    if door != null:
        door.open(game.root3d)
    ZombieProps.burst(game.root3d, game.sites["detonation_button"] + Vector3(0.0, 1.0, 0.0), Color("#ffb04a"), 52, 0.85)
    ZombieProps.play(detonation_visual, detonation_visual.global_position, "alarm", 2.0, 0.85, 55.0)
    game.notify(ZombieGame.tx("Underground blast door released", "قفل درِ انفجاری زیرزمین آزاد شد"), Color("#9dffb0"))
    _refresh()

func _build_basement_activation() -> void:
    var pos: Vector3 = game.sites["basement_activation"]
    basement_activation_visual = ZombieProps.build_button()
    basement_activation_visual.name = "BasementActivationConsole"
    game.root3d.add_child(basement_activation_visual)
    basement_activation_visual.global_position = pos
    var title: Label3D = basement_activation_visual.find_child("Label3D", true, false) as Label3D
    if title != null:
        title.text = ZombieGame.tx("BASEMENT SYSTEM", "سامانه زیرزمین")
    game.register_cullable(basement_activation_visual)
    game.make_interact(basement_activation_visual, "Interact_BasementActivation", pos,
        func() -> String: return _basement_activation_text(),
        func(_a: Node) -> void: _activate_basement(),
        func(_a: Node) -> bool: return not basement_activated and _door_open("hatch"),
        Vector3(2.2, 2.8, 2.2), Vector3(0.0, 1.2, 0.0), true)

func _basement_activation_text() -> String:
    if basement_activated:
        return ZombieGame.tx("Basement system activated", "سامانه زیرزمین فعال شده است")
    if not _door_open("hatch"):
        return ZombieGame.tx("Basement console offline — open the blast door", "کنسول زیرزمین خاموش است؛ درِ انفجاری را باز کن")
    return ZombieGame.tx("Activate basement system", "فعال‌سازی سامانه زیرزمین")

func _activate_basement() -> void:
    if basement_activated or not _door_open("hatch"):
        return
    basement_activated = true
    var cap: Node3D = basement_activation_visual.get_meta("cap")
    cap.position.y = 1.08
    var lamp: StandardMaterial3D = basement_activation_visual.get_meta("cap_mat")
    lamp.emission = Color("#3dff7a")
    lamp.albedo_color = Color("#3dff7a")
    var l: OmniLight3D = basement_activation_visual.get_meta("light")
    l.light_color = Color("#3dff7a")
    l.light_energy = 2.2
    game.open_door_free("restricted")
    ZombieProps.burst(game.root3d, basement_activation_visual.global_position + Vector3(0.0, 1.2, 0.0), Color("#4fd8ff"), 26, 0.6)
    ZombieProps.play(basement_activation_visual, basement_activation_visual.global_position, "power_up", 1.0, 1.0, 45.0)
    game.notify(ZombieGame.tx("Basement systems online — research access can now be purchased", "سامانه زیرزمین فعال شد؛ حالا می‌توانی ورودی آزمایشگاه را بخری"), Color("#4fd8ff"))
    _refresh()

func _build_machines() -> void:
    var index: int = 0
    for pos in game.sites["tesla_devices"]:
        var node: Node3D = ZombieProps.build_portable_tesla_unit()
        node.name = "PortableTeslaUnit_%d" % index
        node.scale = Vector3.ONE * 0.68
        game.root3d.add_child(node)
        node.global_position = pos
        (node.get_meta("field") as Node3D).visible = false
        (node.get_meta("field_disc") as Node3D).visible = false
        game.register_cullable(node)
        var record: Dictionary = {
            "node": node, "pos": pos, "picked": false, "delivered": false,
            "charge": 0.0, "ready": false,
            "surge_until": 0.0, "surge_boost": 0.0, "pad_visual": null, "pad_interact": null,
        }
        machines.append(record)
        var captured: int = index
        var interact: ZInteract = game.make_interact(node, "Interact_Charge_%d" % index, pos,
            func() -> String: return _machine_text(captured),
            func(_a: Node) -> void: _machine_use(captured),
            func(_a: Node) -> bool: return not bool(machines[captured]["picked"]) and not bool(machines[captured]["delivered"]),
            Vector3(2.8, 3.3, 2.8), Vector3(0.0, 1.6, 0.0), true)
        record["interact"] = interact
        _update_machine_label(index)
        index += 1

func _machine_text(index: int) -> String:
    var m: Dictionary = machines[index]
    if bool(m["delivered"]):
        return ""
    if carried != "":
        return ZombieGame.tx("Hands full — deliver the item first", "دستت پر است؛ اول وسیله را تحویل بده")
    return ZombieGame.tx("Recover portable Tesla unit %d/3" % (index + 1), "برداشتن دستگاه قابل‌حمل تسلا %d/۳" % (index + 1))

func _machine_use(index: int) -> void:
    var m: Dictionary = machines[index]
    if bool(m["picked"]) or bool(m["delivered"]):
        return
    if carried != "":
        game.notify(ZombieGame.tx("Your hands are full", "دستت پر است"), Color("#ffd23d"))
        return
    var node: Node3D = m["node"]
    m["picked"] = true
    (m["interact"] as ZInteract).interaction_enabled = false
    _set_carry("device", index, node)
    ZombieProps.play(game.player, game.player.global_position, "mag_in", 0.0, 0.8, 12.0)
    game.notify(ZombieGame.tx("Tesla unit recovered — carry it to an empty lab pad", "دستگاه تسلا برداشته شد؛ آن را به جایگاه خالی آزمایشگاه ببر"), Color("#4fd8ff"))
    _refresh()

func _build_device_pads() -> void:
    var index: int = 0
    for pos in game.sites["tesla_pads"]:
        var pad: Node3D = ZombieProps.build_tesla_pad(index)
        game.root3d.add_child(pad)
        pad.global_position = pos
        game.register_cullable(pad)
        device_pads.append(pad)
        var captured: int = index
        var interact: ZInteract = game.make_interact(pad, "Interact_TeslaPad_%d" % index, pos,
            func() -> String: return _device_pad_text(captured),
            func(_a: Node) -> void: _install_device(captured),
            func(_a: Node) -> bool: return not bool(machines[captured].get("delivered", false)),
            Vector3(2.8, 2.6, 2.8), Vector3(0.0, 1.1, 0.0), true)
        machines[index]["pad_visual"] = pad
        machines[index]["pad_interact"] = interact
        index += 1

func _device_pad_text(index: int) -> String:
    var m: Dictionary = machines[index]
    if bool(m["delivered"]):
        return ZombieGame.tx("Tesla unit installed — %s" % _device_status(index), "دستگاه نصب شده — %s" % _device_status(index))
    if carried == "device":
        return ZombieGame.tx("Install Tesla unit in this pad", "نصب دستگاه تسلا در این جایگاه")
    return ZombieGame.tx("Empty Tesla pad — bring unit %d/3" % (index + 1), "جایگاه خالی است؛ دستگاه %d/۳ را بیاور" % (index + 1))

func _install_device(index: int) -> void:
    if index < 0 or index >= machines.size():
        return
    if bool(machines[index]["delivered"]):
        return
    if carried != "device" or carried_src < 0 or not is_instance_valid(carried_node):
        game.notify(ZombieGame.tx("Carry a portable Tesla unit here first", "اول یک دستگاه قابل‌حمل تسلا به اینجا بیاور"), Color("#ffd23d"))
        return
    if carried_src != index:
        game.notify(ZombieGame.tx("This pad is calibrated for another Tesla unit", "این جایگاه برای دستگاه تسلای دیگری تنظیم شده است"), Color("#ffd23d"))
        return
    var m: Dictionary = machines[index]
    var pad: Node3D = device_pads[index]
    var unit: Node3D = carried_node
    unit.reparent(pad, true)
    unit.position = Vector3(0.0, 1.15, 0.0)
    unit.rotation = Vector3.ZERO
    unit.scale = Vector3.ONE * 0.53
    m["delivered"] = true
    m["charge"] = 0.025
    m["pos"] = pad.global_position
    var status: Label3D = pad.get_meta("status")
    status.text = ZombieGame.tx("INITIALIZING", "راه‌اندازی")
    var ring_mat: StandardMaterial3D = pad.get_meta("ring_mat")
    ring_mat.emission_energy_multiplier = 1.8
    var light_node: OmniLight3D = pad.get_meta("light")
    light_node.light_energy = 1.25
    _clear_carry()
    var tw: Tween = unit.create_tween().set_parallel(true)
    tw.tween_property(unit, "position:y", 1.42, 0.55).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tw.tween_property(unit, "rotation:y", TAU, 2.0).as_relative()
    (m["pad_interact"] as ZInteract).interaction_enabled = false
    ZombieProps.burst(game.root3d, pad.global_position + Vector3(0.0, 1.2, 0.0), Color("#4fd8ff"), 26, 0.6)
    ZombieProps.play(pad, pad.global_position, "power_up", 0.5, 1.0, 35.0)
    game.notify(ZombieGame.tx("Tesla unit installed — its field will stabilize from local conditions", "دستگاه تسلا نصب شد؛ پایداری میدان به شرایط محیطی وابسته است"), Color("#4fd8ff"))
    _update_machine_label(index)
    _refresh()

func _device_status(index: int) -> String:
    var m: Dictionary = machines[index]
    if bool(m.get("ready", false)):
        return ZombieGame.tx("FIELD STABLE", "میدان پایدار")
    var charge: float = float(m.get("charge", 0.0))
    if charge < 0.28:
        return ZombieGame.tx("SEEKING RESONANCE", "جست‌وجوی تشدید")
    if charge < 0.62:
        return ZombieGame.tx("PHASE ALIGNMENT", "تنظیم فاز")
    return ZombieGame.tx("STABILIZING", "در حال پایدارسازی")

func _update_machine_label(index: int) -> void:
    var m: Dictionary = machines[index]
    var node: Node3D = m["node"]
    var label3: Label3D = node.get_meta("label") as Label3D
    var gauge: MeshInstance3D = node.get_meta("gauge") as MeshInstance3D
    var fraction: float = clampf(float(m.get("charge", 0.0)), 0.0, 1.0)
    gauge.scale.y = maxf(0.05, fraction * 16.0)
    gauge.position.y = 0.88 + fraction * 0.4
    if bool(m.get("ready", false)):
        label3.text = ZombieGame.tx("FIELD STABLE", "میدان پایدار")
    elif bool(m.get("delivered", false)):
        label3.text = _device_status(index)
    elif bool(m.get("picked", false)):
        label3.text = ZombieGame.tx("IN TRANSIT", "در حال انتقال")
    else:
        label3.text = ZombieGame.tx("PORTABLE UNIT", "دستگاه قابل‌حمل")
    var pad: Node3D = m.get("pad_visual") as Node3D
    if pad != null and is_instance_valid(pad):
        var status: Label3D = pad.get_meta("status") as Label3D
        status.text = _device_status(index) if bool(m.get("delivered", false)) else ZombieGame.tx("EMPTY SOCKET", "جایگاه خالی")
        var ring_mat: StandardMaterial3D = pad.get_meta("ring_mat")
        ring_mat.emission_energy_multiplier = 0.7 + fraction * 3.0
        var l: OmniLight3D = pad.get_meta("light") as OmniLight3D
        l.light_energy = 0.45 + fraction * 1.7

func _on_combatant_killed(victim: Node, _killer: Node, _headshot: bool) -> void:
    if not (victim is Bot) or not (victim as Bot).is_zombie:
        return
    var bot: Bot = victim as Bot
    if str(bot.profile_id) == "inferno":
        return
    var boost: float = 1.1 if str(bot.profile_id) in ["brute", "pyro", "tyrant", "spitter"] else 0.45
    for index in range(machines.size()):
        var m: Dictionary = machines[index]
        if not bool(m.get("delivered", false)) or bool(m.get("ready", false)):
            continue
        var device_pos: Vector3 = (m["pad_visual"] as Node3D).global_position
        var offset: Vector3 = bot.global_position - device_pos
        if absf(offset.y) <= 6.0 and Vector2(offset.x, offset.z).length() <= 18.0:
            m["surge_until"] = _charge_clock + (4.5 if boost > 1.0 else 2.8)
            m["surge_boost"] = boost

func _tick_device_charging(delta: float) -> void:
    _charge_clock += delta
    _charge_ui_timer -= delta
    var live_zombies: Array[Bot] = []
    for candidate in get_tree().get_nodes_in_group("bots"):
        if candidate is Bot and (candidate as Bot).is_zombie and CombatUtil.is_alive(candidate):
            live_zombies.append(candidate as Bot)
    var any_changed: bool = false
    for index in range(machines.size()):
        var m: Dictionary = machines[index]
        if not bool(m.get("delivered", false)) or bool(m.get("ready", false)):
            continue
        var pad: Node3D = m["pad_visual"] as Node3D
        var pos: Vector3 = pad.global_position
        var nearby: int = 0
        var elite: int = 0
        for zombie in live_zombies:
            var offset: Vector3 = zombie.global_position - pos
            if absf(offset.y) > 6.0 or Vector2(offset.x, offset.z).length() > 18.0:
                continue
            nearby += 1
            if str(zombie.profile_id) in ["brute", "pyro", "tyrant", "spitter"]:
                elite += 1
        var grid_factor: float = 0.34 + float(game.switch_count()) * 0.17
        var bio_factor: float = clampf(float(nearby) * 0.055 + float(elite) * 0.13, 0.0, 0.75)
        var phase_factor: float = 0.5 + 0.5 * absf(sin(_charge_clock * (0.72 + float(index) * 0.19) + float(index) * 1.17))
        var player_distance: float = game.player.global_position.distance_to(pos)
        var operator_factor: float = clampf(1.2 - player_distance / 95.0, 0.35, 1.2)
        var factor: float = 0.5
        match index:
            0:
                factor = grid_factor * 0.78 + bio_factor * 0.62 + phase_factor * 0.22
            1:
                factor = grid_factor * 0.42 + phase_factor * 0.78 + (0.14 if nearby > 0 else 0.0)
            _:
                factor = grid_factor * 0.42 + bio_factor * 0.38 + phase_factor * 0.42 + operator_factor * 0.22
        if _charge_clock < float(m.get("surge_until", 0.0)):
            factor += float(m.get("surge_boost", 0.0))
        factor = clampf(factor, 0.12, 1.8)
        var old_charge: float = float(m.get("charge", 0.0))
        # No fixed battery or kill quota: changing grid, resonance, nearby bioelectric activity,
        # and operator position continuously alter the field's stability rate.
        var drift: float = 0.0115 * factor
        if factor < 0.34:
            drift -= 0.0012
        m["charge"] = clampf(old_charge + drift * delta, 0.0, 1.0)
        if float(m["charge"]) >= 1.0:
            _machine_ready(index)
            any_changed = true
        elif absf(float(m["charge"]) - old_charge) > 0.0005:
            any_changed = true
    if any_changed and _charge_ui_timer <= 0.0:
        _charge_ui_timer = 0.35
        for index in range(machines.size()):
            _update_machine_label(index)
        _refresh()

func _machine_ready(index: int) -> void:
    var m: Dictionary = machines[index]
    if bool(m.get("ready", false)):
        return
    m["ready"] = true
    m["charge"] = 1.0
    var node: Node3D = m["node"]
    var core_mat: StandardMaterial3D = node.get_meta("core_mat")
    core_mat.emission = Color("#3dff7a")
    core_mat.albedo_color = Color("#3dff7a")
    core_mat.emission_energy_multiplier = 4.0
    var light_node: OmniLight3D = node.get_meta("light") as OmniLight3D
    light_node.light_color = Color("#3dff7a")
    light_node.light_energy = 2.0
    var ring_mat: StandardMaterial3D = (m["pad_visual"] as Node3D).get_meta("ring_mat")
    ring_mat.emission = Color("#3dff7a")
    ring_mat.albedo_color = Color("#3dff7a")
    ring_mat.emission_energy_multiplier = 4.5
    ZombieProps.burst(game.root3d, (m["pad_visual"] as Node3D).global_position + Vector3(0.0, 1.4, 0.0), Color("#3dff7a"), 38, 0.8)
    ZombieProps.play(node, node.global_position + Vector3(0.0, 2.0, 0.0), "power_up", 2.5, 1.1, 60.0)
    game.notify(ZombieGame.tx("Tesla field stabilized", "میدان تسلا پایدار شد"), Color("#3dff7a"))
    _update_machine_label(index)
    _refresh()

# ---------------------------------------------------------------- carrying

func _kill_tweens(node: Node) -> void:
    for tween in node.get_meta("tweens", []):
        if tween is Tween and (tween as Tween).is_valid():
            (tween as Tween).kill()

func _set_carry(kind: String, src: int, node: Node3D) -> void:
    carried = kind
    carried_src = src
    carried_node = node
    # Stop any idle tweens on the node by re-parenting it under the camera.
    if _camera != null:
        var from_transform: Transform3D = node.global_transform
        node.reparent(_camera, true)
        node.global_transform = from_transform
        var target: Vector3 = Vector3(0.0, -0.34, -0.85)
        var target_scale: float = 0.53 if kind == "device" else 0.8
        var tw: Tween = node.create_tween().set_parallel(true)
        tw.tween_property(node, "position", target, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
        tw.tween_property(node, "rotation", Vector3(0.0, 0.5, 0.0), 0.5)
        tw.tween_property(node, "scale", Vector3.ONE * target_scale, 0.5)
    game.hud.set_carry(_carry_text())

func _carry_text() -> String:
    if carried == "device":
        return ZombieGame.tx("Carrying: portable Tesla unit ⚡", "در دست: دستگاه قابل‌حمل تسلا ⚡")
    if carried == "body":
        return ZombieGame.tx("Carrying: Tesla body ⚡", "در دست: بدنه‌ی تسلا ⚡")
    return ""

func _clear_carry() -> void:
    carried = ""
    carried_src = -1
    carried_node = null
    game.hud.set_carry("")

## Dying drops a carried Tesla unit or returns the recovered body to its pickup location.
func on_player_died() -> void:
    if carried == "device" and carried_src >= 0:
        var m: Dictionary = machines[carried_src]
        if is_instance_valid(carried_node):
            carried_node.reparent(game.root3d, true)
            carried_node.global_position = game.player.global_position + Vector3(0.0, 0.05, 0.0)
            carried_node.rotation = Vector3.ZERO
            carried_node.scale = Vector3.ONE * 0.68
        m["picked"] = false
        (m["interact"] as ZInteract).interaction_enabled = true
        _clear_carry()
        game.notify(ZombieGame.tx("The portable Tesla unit was dropped", "دستگاه تسلا روی زمین افتاد"), Color("#ff8a7a"))
    elif carried == "body":
        if is_instance_valid(carried_node):
            carried_node.queue_free()
        _clear_carry()
        _spawn_body_pickup(_body_drop)
        game.notify(ZombieGame.tx("You dropped the Tesla body in the Tesla room", "بدنه تسلا در اتاق تسلا افتاد"), Color("#ff8a7a"))
    _refresh()

# ---------------------------------------------------------------- central Tesla synchronizer

func _build_station() -> void:
    var pos: Vector3 = game.sites["tesla_station"]
    station = ZombieProps.build_tesla_sync_station()
    game.root3d.add_child(station)
    station.global_position = pos
    game.register_cullable(station)
    game.make_interact(station, "Interact_Station", pos + Vector3(0.0, 0.0, 0.6),
        func() -> String: return _station_text(),
        func(_a: Node) -> void: _station_use(),
        Callable(), Vector3(4.8, 2.8, 2.4), Vector3(0.0, 1.4, 0.2), true)

func _station_text() -> String:
    if station_powered:
        return ZombieGame.tx("Tesla fields synchronized", "میدان‌های تسلا هماهنگ شده‌اند")
    if not _all_devices_stable():
        return ZombieGame.tx("Synchronizer offline — %d/3 Tesla fields stable" % _devices_stable(), "هماهنگ‌ساز آماده نیست؛ %d/۳ میدان پایدار است" % _devices_stable())
    return ZombieGame.tx("Synchronize all three Tesla fields", "هماهنگ‌سازی هر سه میدان تسلا")

func _station_use() -> void:
    if station_powered:
        return
    if not _all_devices_stable():
        game.notify(ZombieGame.tx("All three Tesla fields must stabilize first", "اول باید میدان هر سه دستگاه تسلا پایدار شود"), Color("#ffd23d"))
        return
    station_powered = true
    _station_powered_up()
    _refresh()

func _station_powered_up() -> void:
    var l: OmniLight3D = station.get_meta("light")
    l.light_color = Color("#3dff7a")
    ZombieProps.play(station, station.global_position + Vector3(0.0, 2.0, 0.0), "alarm", 3.0, 1.0, 80.0)
    game.notify(ZombieGame.tx("The station roars to life… something awakens in the Tesla room!", "ایستگاه روشن شد… چیزی در اتاق تسلا بیدار می‌شود!"), Color("#ff8a3a"))
    # Red alarm pulse, then the boss erupts from the floor.
    var pulse: Tween = l.create_tween().set_loops(4)
    pulse.tween_property(l, "light_color", Color("#ff2a1a"), 0.3)
    pulse.tween_property(l, "light_color", Color("#3dff7a"), 0.3)
    get_tree().create_timer(2.6).timeout.connect(spawn_boss)

# ---------------------------------------------------------------- stage 3: the fire boss

func spawn_boss() -> void:
    if boss_spawned:
        return
    boss_spawned = true
    var at := Transform3D(Basis.IDENTITY, Vector3(108.0, ZombieComplex.FLOOR_Y + 0.1, 37.0))
    boss = FireBoss.new()
    boss.difficulty = int(game.mode.call("get_difficulty"))
    boss.display_name = ZombieGame.tx("Inferno Colossus", "غول آتشین")
    boss.fx = game.mode.get("fx")
    boss.mode_ref = game.mode
    var spec: Dictionary = {"profile": "inferno", "team": "zombie", "name": boss.display_name, "hunt": true}
    boss.profile_id = "inferno"
    boss.team = "zombie"
    game.mode.call("spawn_special", boss, spec, at)
    boss.died.connect(_on_boss_died)
    game.hud.show_boss(boss.display_name)
    ZombieProps.burst(game.root3d, at.origin + Vector3(0.0, 0.5, 0.0), Color("#ff6a1a"), 80, 1.2)
    game.notify(ZombieGame.tx("Inferno Colossus!", "غول آتشین!"), Color("#ff6a1a"))
    _refresh()

func _on_boss_died(dead: Bot, _killer: Node, _headshot: bool) -> void:
    boss_dead = true
    game.hud.hide_boss()
    var p: Vector3 = dead.global_position
    _body_drop = Vector3(clampf(p.x, BODY_ROOM_MIN.x, BODY_ROOM_MAX.x), ZombieComplex.FLOOR_Y, clampf(p.z, BODY_ROOM_MIN.y, BODY_ROOM_MAX.y))
    _spawn_body_pickup(_body_drop)
    game.notify(ZombieGame.tx("The Colossus fell and dropped the Tesla body!", "غول سقوط کرد و بدنه‌ی تسلا را انداخت!"), Color("#4fd8ff"))
    _refresh()

func _spawn_body_pickup(at: Vector3) -> void:
    if is_instance_valid(body_pickup):
        body_pickup.queue_free()
    body_pickup = Node3D.new()
    body_pickup.name = "TeslaBodyPickup"
    game.root3d.add_child(body_pickup)
    body_pickup.global_position = at
    var model: Node3D = ZombieProps.build_tesla_body()
    model.position = Vector3(0.0, 1.0, 0.0)
    model.scale = Vector3.ONE * 1.5
    body_pickup.add_child(model)
    var l: OmniLight3D = ZombieProps.light(body_pickup, Color("#4fd8ff"), 2.4, 8.0, Vector3(0.0, 1.5, 0.0))
    l.name = "BodyLight"
    var spin: Tween = model.create_tween().set_loops()
    spin.tween_property(model, "rotation:y", TAU, 3.0).as_relative()
    var bob: Tween = model.create_tween().set_loops()
    bob.tween_property(model, "position:y", 1.25, 0.8).set_trans(Tween.TRANS_SINE)
    bob.tween_property(model, "position:y", 0.9, 0.8).set_trans(Tween.TRANS_SINE)
    model.set_meta("tweens", [spin, bob])
    body_pickup.set_meta("model", model)
    body_pickup_interact = game.make_interact(body_pickup, "Interact_TeslaBody", at,
        func() -> String: return ZombieGame.tx("Pick up the Tesla body", "برداشتن بدنه‌ی تسلا") if carried == "" else ZombieGame.tx("Your hands are full", "دستت پر است"),
        func(_a: Node) -> void: _pickup_body(),
        Callable(), Vector3(2.0, 2.0, 2.0), Vector3(0.0, 1.0, 0.0), false)

func _pickup_body() -> void:
    if carried != "":
        game.notify(ZombieGame.tx("Your hands are full", "دستت پر است"), Color("#ffd23d"))
        return
    if not is_instance_valid(body_pickup):
        return
    var model: Node3D = body_pickup.get_meta("model")
    var spent: Node3D = model
    _kill_tweens(spent)
    spent.reparent(game.root3d, true)
    body_pickup.queue_free()
    body_pickup = null
    _set_carry("body", -1, spent)
    ZombieProps.play(game.player, game.player.global_position, "mag_in", 0.0, 0.6, 12.0)
    _refresh()

# ---------------------------------------------------------------- stage 4 + 5: assembly machine

func _build_assembly() -> void:
    var pos: Vector3 = game.sites["assembly"]
    var hatch: Rect2 = game.sites["hatch"]
    lift = Node3D.new()
    lift.name = "HatchLift"
    game.root3d.add_child(lift)
    lift.global_position = Vector3(hatch.position.x + hatch.size.x * 0.5, ZombieComplex.FLOOR_Y, hatch.position.y + hatch.size.y * 0.5)
    game.register_cullable(lift)
    # Cover plate over the hidden stairs (lies on the floor so the player simply steps onto it).
    var cover := StaticBody3D.new()
    cover.name = "HatchCover"
    cover.collision_layer = 1
    lift.add_child(cover)
    var cover_shape := CollisionShape3D.new()
    var cover_box := BoxShape3D.new()
    cover_box.size = Vector3(hatch.size.x + 0.2, 0.12, hatch.size.y + 0.2)
    cover_shape.shape = cover_box
    cover_shape.position = Vector3(0.0, 0.06, 0.0)
    cover.add_child(cover_shape)
    ZombieProps.box(cover, "Plate", Vector3(0.0, 0.06, 0.0), Vector3(hatch.size.x + 0.2, 0.12, hatch.size.y + 0.2), ZombieProps.mat(Color("#2b3036"), 0.0, 0.45, 0.8))
    for i in range(6):
        ZombieProps.box(cover, "Seam", Vector3(-hatch.size.x * 0.5 + 0.6 + float(i) * (hatch.size.x - 1.2) / 5.0, 0.125, 0.0), Vector3(0.06, 0.01, hatch.size.y), ZombieProps.mat(Color("#d9a21e"), 0.0, 0.6, 0.1))
    assembly = ZombieProps.build_assembly_machine()
    assembly.name = "AssemblyMachine"
    lift.add_child(assembly)
    assembly.global_position = pos
    assembly.rotation.y = PI
    assembly.position.y += 0.12
    assembly_interact = game.make_interact(assembly, "Interact_Assembly", pos,
        func() -> String: return _assembly_text(),
        func(_a: Node) -> void: _assembly_use(),
        Callable(), Vector3(4.2, 3.0, 3.2), Vector3(0.0, 1.5, 0.0), true)
    _hum = AudioStreamPlayer3D.new()
    _hum.stream = WeaponAudio.get_stream("hum")
    _hum.max_distance = 50.0
    _hum.unit_size = 8.0
    _hum.volume_db = -2.0
    _hum.bus = "SFX" if AudioServer.get_bus_index("SFX") != -1 else "Master"
    assembly.add_child(_hum)
    # Hatch fee interaction (active once the cage circuits are shorted).
    hatch_interact = game.make_interact(lift, "Interact_Hatch", lift.global_position + Vector3(0.0, 0.0, 2.6),
        func() -> String: return ZombieGame.tx("Open the hidden tunnel — %d pts" % HATCH_FEE, "باز کردن تونل مخفی — %d امتیاز" % HATCH_FEE),
        func(_a: Node) -> void: _hatch_use(),
        func(_a: Node) -> bool: return cage != null and cage.is_broken() and not hatch_open and not _hatch_busy,
        Vector3(6.0, 2.0, 1.8), Vector3(0.0, 1.0, 0.0), false)

func _assembly_text() -> String:
    if tesla_taken:
        return ""
    if assembling:
        return ZombieGame.tx("Assembling… %.1f s" % maxf(0.0, ASSEMBLY_SECONDS - assembly_t), "در حال مونتاژ… %.1f ثانیه" % maxf(0.0, ASSEMBLY_SECONDS - assembly_t))
    if assembly_done:
        return ZombieGame.tx("Take the Tesla gun", "برداشتن تفنگ تسلا")
    if carried == "body":
        return ZombieGame.tx("Insert the Tesla body (20 s assembly)", "قراردادن بدنه‌ی تسلا (۲۰ ثانیه مونتاژ)")
    return ZombieGame.tx("Tesla assembly machine — needs the Tesla body", "دستگاه مونتاژ تسلا — به بدنه‌ی تسلا نیاز دارد")

func _assembly_use() -> void:
    if tesla_taken or assembling:
        return
    if assembly_done:
        _take_tesla()
        return
    if carried != "body" or not is_instance_valid(carried_node):
        game.notify(ZombieGame.tx("The machine needs the Tesla body dropped by the Colossus", "دستگاه به بدنه‌ی تسلا که غول انداخته نیاز دارد"), Color("#ffd23d"))
        return
    start_assembly()

func start_assembly() -> void:
    assembling = true
    assembly_t = 0.0
    var body: Node3D = carried_node
    _clear_carry()
    var anchor: Node3D = assembly.get_meta("anchor")
    body.reparent(anchor, true)
    _gun_model = body
    var tw: Tween = body.create_tween().set_parallel(true)
    tw.tween_property(body, "position", Vector3.ZERO, 0.8).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
    tw.tween_property(body, "rotation", Vector3(0.0, PI * 0.5, 0.0), 0.8)
    tw.tween_property(body, "scale", Vector3.ONE * 1.6, 0.8)
    for s in assembly.get_meta("sparks"):
        (s as CPUParticles3D).emitting = true
    _hum.play()
    _clank_left = 0.0
    game.notify(ZombieGame.tx("Assembly started: 20 seconds — hold the room!", "مونتاژ شروع شد: ۲۰ ثانیه — از اتاق دفاع کن!"), Color("#ffd23d"))
    _refresh()

func _process(delta: float) -> void:
    _bob += delta
    _tick_device_charging(delta)
    if carried_node != null and is_instance_valid(carried_node) and carried_node.get_parent() == _camera:
        carried_node.position.y += sin(_bob * 2.2) * 0.0006
    if boss != null and is_instance_valid(boss) and not boss_dead:
        game.hud.set_boss_health(boss.get_health_fraction())
    if assembling:
        _tick_assembly(delta)
    if pap_busy:
        _tick_pap(delta)

func _tick_assembly(delta: float) -> void:
    assembly_t += delta
    var remaining: float = maxf(0.0, ASSEMBLY_SECONDS - assembly_t)
    game.hud.set_countdown(remaining, "⚙ ")
    var timer_label: Label3D = assembly.get_meta("timer")
    timer_label.text = "%05.2f" % remaining
    # Mechanical movement: the two arms swing out of phase, the gears spin, the lights flicker.
    var arms: Array = assembly.get_meta("arms")
    (arms[0] as Node3D).rotation.z = sin(assembly_t * 3.1) * 0.55
    (arms[1] as Node3D).rotation.z = sin(assembly_t * 3.1 + PI) * 0.55
    (arms[0] as Node3D).rotation.x = sin(assembly_t * 1.7) * 0.25
    (arms[1] as Node3D).rotation.x = cos(assembly_t * 1.7) * 0.25
    for gear in assembly.get_meta("gears"):
        (gear as Node3D).rotate_z(delta * 4.5)
    var lights: Array = assembly.get_meta("lights")
    (lights[0] as OmniLight3D).light_energy = 1.2 + sin(assembly_t * 17.0) * 0.8 + randf() * 0.5
    (lights[1] as OmniLight3D).light_energy = (0.6 + randf() * 1.4) * minf(1.0, assembly_t / 10.0)
    (assembly.get_meta("screen_mat") as StandardMaterial3D).emission_energy_multiplier = 1.6 + sin(assembly_t * 9.0) * 0.9
    if _gun_model != null and is_instance_valid(_gun_model):
        _gun_model.rotation.y += delta * (1.0 + assembly_t * 0.25)
    _clank_left -= delta
    if _clank_left <= 0.0:
        _clank_left = 0.9 - minf(assembly_t / ASSEMBLY_SECONDS, 1.0) * 0.5
        ZombieProps.play(assembly, assembly.global_position + Vector3(0.0, 1.5, 0.0), "clank", 0.0, randf_range(0.7, 1.3), 50.0)
        if randf() < 0.6:
            ZombieProps.play(assembly, assembly.global_position + Vector3(0.0, 2.0, 0.0), "zap", -4.0, randf_range(0.8, 1.2), 50.0)
    if assembly_t >= ASSEMBLY_SECONDS - 0.0001:
        _finish_assembly()
    else:
        game.refresh_missions()

func _finish_assembly() -> void:
    assembling = false
    assembly_done = true
    assembly_t = ASSEMBLY_SECONDS
    game.hud.set_countdown(-1.0)
    _hum.stop()
    for s in assembly.get_meta("sparks"):
        (s as CPUParticles3D).emitting = false
    var arms: Array = assembly.get_meta("arms")
    for arm in arms:
        var a: Node3D = arm
        var back: Tween = a.create_tween().set_parallel(true)
        back.tween_property(a, "rotation", Vector3(0.0, 0.0, 0.0), 0.6)
    (assembly.get_meta("timer") as Label3D).text = ZombieGame.tx("COMPLETE", "کامل شد")
    (assembly.get_meta("screen_mat") as StandardMaterial3D).emission = Color("#3dff7a")
    # Completion show: white flash, a burst, the gun rises and its coils light up.
    var lights: Array = assembly.get_meta("lights")
    var flash: Tween = (lights[0] as OmniLight3D).create_tween()
    (lights[0] as OmniLight3D).light_color = Color("#ffffff")
    flash.tween_property(lights[0], "light_energy", 9.0, 0.15)
    flash.tween_property(lights[0], "light_energy", 1.4, 1.0)
    ZombieProps.burst(game.root3d, assembly.global_position + Vector3(0.0, 1.8, 0.0), Color("#8fe8ff"), 80, 1.1)
    ZombieProps.play(assembly, assembly.global_position + Vector3(0.0, 1.5, 0.0), "power_up", 4.0, 1.1, 70.0)
    if _gun_model != null and is_instance_valid(_gun_model):
        var rise: Tween = _gun_model.create_tween()
        rise.tween_property(_gun_model, "position:y", 0.7, 0.8).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    game.notify(ZombieGame.tx("The Tesla gun is complete! Take it.", "تفنگ تسلا کامل شد! آن را بردار."), Color("#4fd8ff"))
    _refresh()

func _take_tesla() -> void:
    tesla_taken = true
    if _gun_model != null and is_instance_valid(_gun_model):
        var fly: Tween = _gun_model.create_tween()
        var target: Vector3 = (_camera.global_position + -_camera.global_transform.basis.z * 0.5) if _camera != null else game.player.global_position
        fly.tween_property(_gun_model, "global_position", target, 0.4).set_trans(Tween.TRANS_QUAD)
        fly.tween_callback(_gun_model.queue_free)
    game.weapon.call("give_tesla", TESLA_START_RESERVE)
    ZombieProps.play(game.player, game.player.global_position, "power_up", 0.0, 1.4, 12.0)
    (assembly.get_meta("timer") as Label3D).text = ""
    assembly_interact.interaction_enabled = false
    game.notify(ZombieGame.tx("Tesla gun acquired — ammo only comes from drops and every 5th wave", "تفنگ تسلا به دست آمد — مهمات فقط از دراپ و هر موج پنجم می‌آید"), Color("#4fd8ff"))
    _refresh()

# ---------------------------------------------------------------- cage, hatch, button

func _build_vault_objects() -> void:
    var pap_pos: Vector3 = game.sites["pap"]
    cage = ZombieProps.build_cage()
    game.root3d.add_child(cage)
    cage.global_position = pap_pos
    game.register_cullable(cage)
    cage.tesla_hit.connect(_on_cage_hit)
    pap = ZombieProps.build_pap()
    pap.name = "PackAPunch"
    game.root3d.add_child(pap)
    pap.global_position = pap_pos
    pap.rotation.y = PI * 0.5
    game.register_cullable(pap)
    game.make_interact(pap, "Interact_PackAPunch", pap_pos,
        func() -> String: return _pap_text(),
        func(_a: Node) -> void: _pap_use(),
        Callable(), Vector3(2.8, 3.0, 2.4), Vector3(0.0, 1.5, 0.0), true)
    var button_pos: Vector3 = game.sites["button"]
    button_node = ZombieProps.build_button()
    game.root3d.add_child(button_node)
    button_node.global_position = button_pos
    game.register_cullable(button_node)
    game.make_interact(button_node, "Interact_VaultButton", button_pos,
        func() -> String: return ZombieGame.tx("Vault released", "خزانه آزاد شد") if vault_released else ZombieGame.tx("Press the vault release button", "زدن دکمه‌ی آزادسازی خزانه"),
        func(_a: Node) -> void: _button_use(),
        func(_a: Node) -> bool: return not vault_released,
        Vector3(1.4, 2.0, 1.4), Vector3(0.0, 1.0, 0.0), true)

func _on_cage_hit(count: int) -> void:
    if count < ZCage.REQUIRED_HITS:
        game.notify(ZombieGame.tx("Cage circuit hit %d/%d" % [count, ZCage.REQUIRED_HITS], "ضربه به مدار قفس %d/%d" % [count, ZCage.REQUIRED_HITS]), Color("#4fd8ff"))
    else:
        game.notify(ZombieGame.tx("The cage circuits are fried! The assembly machine's hatch can now be opened.", "مدار قفس سوخت! دریچه‌ی زیر دستگاه مونتاژ حالا قابل باز شدن است."), Color("#4fd8ff"))
        ZombieProps.play(cage, cage.global_position + Vector3(0.0, 2.0, 0.0), "alarm", 0.0, 0.8, 60.0)
    _refresh()

func _hatch_use() -> void:
    if hatch_open or _hatch_busy or cage == null or not cage.is_broken():
        return
    if not game.spend_points(HATCH_FEE):
        return
    _hatch_busy = true
    ZombieProps.play(lift, lift.global_position + Vector3(0.0, 1.0, 0.0), "clank", 4.0, 0.5, 60.0)
    game.notify(ZombieGame.tx("The assembly machine slides away… a hidden tunnel opens!", "دستگاه مونتاژ کنار می‌رود… تونل مخفی باز می‌شود!"), Color("#ffd23d"))
    var tw: Tween = lift.create_tween()
    tw.tween_property(lift, "position:z", lift.position.z + HATCH_SLIDE, 2.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    tw.tween_callback(func() -> void:
        hatch_open = true
        _hatch_busy = false
        hatch_interact.interaction_enabled = false
        ZombieProps.burst(game.root3d, lift.global_position + Vector3(0.0, 0.3, 0.0), Color("#d9a21e"), 30, 0.8)
        _refresh())
    # Rumble while it moves.
    for step in range(5):
        get_tree().create_timer(0.4 + 0.5 * float(step)).timeout.connect(func() -> void:
            ZombieProps.play(lift, lift.global_position, "clank", -2.0, randf_range(0.4, 0.7), 50.0))

func _button_use() -> void:
    if vault_released:
        return
    vault_released = true
    var cap: Node3D = button_node.get_meta("cap")
    var press: Tween = cap.create_tween()
    press.tween_property(cap, "position:y", 1.1, 0.12)
    press.tween_property(cap, "position:y", 1.2, 0.25)
    var cap_mat: StandardMaterial3D = button_node.get_meta("cap_mat")
    cap_mat.emission = Color("#3dff7a")
    cap_mat.albedo_color = Color("#3dff7a")
    (button_node.get_meta("light") as OmniLight3D).light_color = Color("#3dff7a")
    ZombieProps.play(button_node, button_node.global_position + Vector3(0.0, 1.0, 0.0), "clank", 2.0, 1.4, 40.0)
    game.open_door_free("vault")
    raise_cage()
    game.notify(ZombieGame.tx("The vault door opens and the cage rises!", "درِ خزانه باز می‌شود و قفس بالا می‌رود!"), Color("#3dff7a"))
    _refresh()

func raise_cage() -> void:
    if cage.raised:
        return
    var tw: Tween = cage.create_tween()
    tw.tween_property(cage, "position:y", cage.position.y + CAGE_LIFT, 3.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    tw.tween_callback(func() -> void:
        cage.raised = true
        _refresh())
    for step in range(6):
        get_tree().create_timer(0.3 + 0.55 * float(step)).timeout.connect(func() -> void:
            ZombieProps.play(cage, cage.global_position + Vector3(0.0, 2.0, 0.0), "clank", 0.0, randf_range(0.5, 0.8), 60.0)
            ZombieProps.burst(game.root3d, cage.global_position + Vector3(0.0, 4.0, 0.0), Color("#8fe8ff"), 10, 0.5))

# ---------------------------------------------------------------- Pack-a-Punch

func _pap_text() -> String:
    if pap_busy:
        return ZombieGame.tx("Upgrading… %.1f s" % maxf(0.0, PAP_SECONDS - pap_t), "در حال ارتقا… %.1f ثانیه" % maxf(0.0, PAP_SECONDS - pap_t))
    if cage == null or not cage.raised:
        return ZombieGame.tx("Pack-a-Punch — locked behind the iron cage", "پک‌ای‌پانچ — پشت قفس آهنین قفل است")
    return ZombieGame.tx("Pack-a-Punch — %d pts + %d Tesla charges (+25%% damage, x2 magazine, x2 reserve)" % [PAP_COST, PAP_TESLA_COST],
        "پک‌ای‌پانچ — %d امتیاز + %d شارژ تسلا (+۲۵٪ آسیب، ۲× خشاب، ۲× ذخیره)" % [PAP_COST, PAP_TESLA_COST])

func can_pack(id: String) -> String:
    ## Returns an empty string when the weapon can be upgraded, otherwise the reason.
    if cage == null or not cage.raised:
        return ZombieGame.tx("The machine is locked behind the iron cage", "دستگاه پشت قفس آهنین قفل است")
    if pap_busy:
        return ZombieGame.tx("The machine is busy", "دستگاه مشغول است")
    if id.is_empty():
        return ZombieGame.tx("Equip a weapon first", "اول یک سلاح در دست بگیر")
    if id == "tesla":
        return ZombieGame.tx("The Tesla gun cannot be upgraded", "تفنگ تسلا قابل ارتقا نیست")
    if bool(game.weapon.call("is_upgraded", id)):
        return ZombieGame.tx("This weapon is already upgraded", "این سلاح قبلاً ارتقا یافته")
    if int(game.weapon.call("tesla_total")) < PAP_TESLA_COST:
        return ZombieGame.tx("You need %d Tesla charges" % PAP_TESLA_COST, "به %d شارژ تسلا نیاز داری" % PAP_TESLA_COST)
    if game.points < PAP_COST:
        return ZombieGame.tx("Not enough points (%d needed)" % PAP_COST, "امتیاز کافی نیست (%d لازم است)" % PAP_COST)
    return ""

func _pap_use() -> void:
    var id: String = str(game.weapon.call("get_weapon_id"))
    var reason: String = can_pack(id)
    if not reason.is_empty():
        game.notify(reason, Color("#ffd23d"))
        return
    start_pap(id)

func start_pap(id: String) -> void:
    game.spend_points(PAP_COST)
    game.weapon.call("spend_tesla_ammo", PAP_TESLA_COST)
    game.weapon.call("lock_weapon", id)
    pap_busy = true
    pap_t = 0.0
    pap_weapon = id
    _pap_phase = 0
    (pap.get_meta("progress") as Label3D).text = ""
    for s in [pap.get_meta("sparks")]:
        (s as CPUParticles3D).emitting = true
    # Insertion: the slot doors open, the gun slides in, the doors close.
    var doors: Array = pap.get_meta("doors")
    var token: Node3D = ZombieProps.build_gun_token(WeaponDefinitions.get_accent(id))
    token.name = "GunToken"
    pap.add_child(token)
    _pap_token = token
    token.global_position = game.player.global_position + Vector3(0.0, 1.3, 0.0)
    var slot_anchor: Node3D = pap.get_meta("slot_anchor")
    var tw: Tween = token.create_tween()
    tw.tween_callback(func() -> void: _slide_doors(doors, true))
    tw.tween_property(token, "global_position", slot_anchor.global_position, 0.45).set_trans(Tween.TRANS_QUAD)
    tw.tween_property(token, "global_position", pap.global_position + Vector3(0.0, 1.25, 0.0), 0.3)
    tw.tween_callback(func() -> void:
        _slide_doors(doors, false)
        token.visible = false)
    ZombieProps.play(pap, pap.global_position + Vector3(0.0, 1.2, 0.0), "clank", 2.0, 0.8, 40.0)
    ZombieProps.play(pap, pap.global_position + Vector3(0.0, 1.2, 0.0), "power_up", 2.0, 0.6, 50.0)
    game.notify(ZombieGame.tx("Upgrading your weapon… 6 seconds", "در حال ارتقای سلاح… ۶ ثانیه"), Color("#d9b8ff"))
    _refresh()

func _slide_doors(doors: Array, open: bool) -> void:
    var left: Node3D = doors[0]
    var right: Node3D = doors[1]
    var tw: Tween = left.create_tween().set_parallel(true)
    tw.tween_property(left, "position:x", -0.95 if open else -0.32, 0.3)
    tw.tween_property(right, "position:x", 0.95 if open else 0.32, 0.3)

func _tick_pap(delta: float) -> void:
    pap_t += delta
    var remaining: float = maxf(0.0, PAP_SECONDS - pap_t)
    (pap.get_meta("progress") as Label3D).text = "%.1f" % remaining
    for gear in pap.get_meta("gears"):
        (gear as Node3D).rotate_x(delta * 6.0)
    (pap.get_meta("rune_mat") as StandardMaterial3D).emission_energy_multiplier = 1.5 + sin(pap_t * 10.0) * 1.2
    (pap.get_meta("light") as OmniLight3D).light_energy = 2.0 + sin(pap_t * 14.0) * 1.2 + randf() * 0.6
    if _pap_phase == 0 and pap_t >= PAP_SECONDS - 0.9:
        # Return animation starts: the doors open and the gun is pushed out onto the tray.
        _pap_phase = 1
        var doors: Array = pap.get_meta("doors")
        _slide_doors(doors, true)
        if _pap_token != null and is_instance_valid(_pap_token):
            _pap_token.visible = true
            var tray: Node3D = pap.get_meta("tray_anchor")
            var tw: Tween = _pap_token.create_tween()
            tw.tween_property(_pap_token, "global_position", (pap.get_meta("slot_anchor") as Node3D).global_position, 0.4)
            tw.tween_property(_pap_token, "global_position", tray.global_position + Vector3(0.0, 0.25, 0.0), 0.35)
        ZombieProps.play(pap, pap.global_position + Vector3(0.0, 1.2, 0.0), "clank", 2.0, 1.3, 40.0)
    if pap_t >= PAP_SECONDS - 0.0001:
        _finish_pap()

func _finish_pap() -> void:
    pap_busy = false
    pap_t = PAP_SECONDS
    var id: String = pap_weapon
    game.weapon.call("apply_upgrade", id)
    game.weapon.call("unlock_weapon")
    pap_count += 1
    (pap.get_meta("progress") as Label3D).text = ""
    (pap.get_meta("sparks") as CPUParticles3D).emitting = false
    ZombieProps.burst(game.root3d, pap.global_position + Vector3(0.0, 1.3, 0.0) + pap.global_transform.basis.z * 0.9, Color("#d9b8ff"), 50, 0.9)
    ZombieProps.play(pap, pap.global_position + Vector3(0.0, 1.2, 0.0), "power_up", 3.0, 1.5, 50.0)
    var doors: Array = pap.get_meta("doors")
    get_tree().create_timer(1.0).timeout.connect(func() -> void:
        _slide_doors(doors, false)
        if _pap_token != null and is_instance_valid(_pap_token):
            _pap_token.queue_free())
    game.notify(ZombieGame.tx("%s upgraded! (+25%% damage, double ammo)" % WeaponDefinitions.get_display_name(id, "en"), "%s ارتقا یافت! (+۲۵٪ آسیب، مهمات دو برابر)" % WeaponDefinitions.get_display_name(id, "fa")), Color("#d9b8ff"))
    _refresh()

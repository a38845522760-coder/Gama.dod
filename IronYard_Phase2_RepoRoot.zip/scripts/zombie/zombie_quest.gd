extends Node
class_name ZombieQuest

## The Tesla quest and Pack-a-Punch chain.
##   1. Charge three machines: zombies that die inside a machine's energy field feed it through
##      glowing energy beams; a full machine produces a battery.
##   2. Carry the batteries to the battery station in the Tesla room and install all three.
##   3. The station wakes the fire boss (Inferno Colossus). Killing it drops the Tesla body.
##   4. Carry the body to the assembly machine: exactly 20 s of construction.
##   5. Take the finished Tesla gun (only drops / every 5th wave give ammo).
## After that: shoot the iron cage with Tesla 3 times, pay a small fee to open the hidden tunnel
## under the assembly machine, press the vault button, and use Pack-a-Punch (6 s).

signal stage_changed(stage: int)

const ENERGY_NEEDED: int = 10
const FIELD_RADIUS: float = 6.0
const ASSEMBLY_SECONDS: float = 20.0
const HATCH_FEE: int = 300
const PAP_COST: int = 5000
const PAP_TESLA_COST: int = 2
const PAP_SECONDS: float = 6.0
const TESLA_START_RESERVE: int = 6
const BATTERY_COUNT: int = 3
const HATCH_SLIDE: float = 4.0
const CAGE_LIFT: float = 3.8
const BODY_ROOM_MIN: Vector2 = Vector2(91.0, 33.0)
const BODY_ROOM_MAX: Vector2 = Vector2(113.0, 49.0)

var game: ZombieGame
var machines: Array[Dictionary] = []
var installed: Array[bool] = [false, false, false]
var batteries_taken: int = 0
var carried: String = ""
var carried_src: int = -1
var carried_node: Node3D
var station: Node3D
var station_powered: bool = false
var boss: FireBoss
var boss_spawned: bool = false
var boss_dead: bool = false
var body_pickup: Node3D
var body_pickup_interact: ZInteract
var assembly: Node3D
var assembly_interact: ZInteract
var assembling: bool = false
var assembly_t: float = 0.0
var assembly_done: bool = false
var tesla_taken: bool = false
var lift: Node3D
var cage: ZCage
var hatch_interact: ZInteract
var hatch_open: bool = false
var button_node: Node3D
var vault_released: bool = false
var pap: Node3D
var pap_busy: bool = false
var pap_t: float = 0.0
var pap_weapon: String = ""
var pap_count: int = 0

var _camera: Node3D
var _hum: AudioStreamPlayer3D
var _clank_left: float = 0.0
var _body_drop: Vector3 = Vector3(102.0, ZombieComplex.FLOOR_Y, 40.0)
var _pap_phase: int = 0
var _bob: float = 0.0
var _hatch_busy: bool = false
var _gun_model: Node3D
var _pap_token: Node3D

func setup(owner_game: ZombieGame) -> void:
    game = owner_game
    _camera = game.player.get_node_or_null("CameraPivot/Camera3D") as Node3D
    _build_machines()
    _build_station()
    _build_assembly()
    _build_vault_objects()
    EventBus.combatant_killed.connect(_on_combatant_killed)

func _exit_tree() -> void:
    if EventBus.combatant_killed.is_connected(_on_combatant_killed):
        EventBus.combatant_killed.disconnect(_on_combatant_killed)

# ---------------------------------------------------------------- stage / mission text

func stage() -> int:
    if tesla_taken:
        return 6
    if assembly_done:
        return 5
    if boss_dead:
        return 4
    if station_powered:
        return 3
    if batteries_taken > 0 or _machines_charged() > 0:
        return 2 if _installed_count() > 0 or batteries_taken >= BATTERY_COUNT else 1
    return 1

func _machines_charged() -> int:
    var n: int = 0
    for m in machines:
        if bool(m["ready"]) or bool(m["taken"]):
            n += 1
    return n

func _installed_count() -> int:
    var n: int = 0
    for flag in installed:
        if flag:
            n += 1
    return n

func mission_lines() -> Array:
    var t: Callable = ZombieGame.tx
    var lines: Array = []
    if not tesla_taken:
        if not station_powered and batteries_taken < BATTERY_COUNT:
            lines.append(t.call("① Tesla: charge the 3 machines — kill zombies inside their energy field (%d/3 charged)" % _machines_charged(),
                "① تسلا: ۳ دستگاه را شارژ کن — زامبی‌ها را داخل میدان انرژی بکش (%d/۳ شارژ شده)" % _machines_charged()))
            if batteries_taken > 0:
                lines.append(t.call("   Batteries taken: %d/3" % batteries_taken, "   باتری‌های برداشته‌شده: %d/۳" % batteries_taken))
        elif not station_powered:
            lines.append(t.call("② Tesla: install the batteries at the battery station (%d/3)" % _installed_count(),
                "② تسلا: باتری‌ها را در ایستگاه باتری نصب کن (%d/۳)" % _installed_count()))
        elif not boss_dead:
            lines.append(t.call("③ Tesla: defeat the Inferno Colossus", "③ تسلا: غول آتشین را شکست بده"))
        elif not assembly_done and not assembling:
            lines.append(t.call("④ Tesla: carry the Tesla body to the assembly machine", "④ تسلا: بدنه‌ی تسلا را به دستگاه مونتاژ ببر"))
        elif assembling:
            lines.append(t.call("④ Tesla: assembling… %.1f s" % maxf(0.0, ASSEMBLY_SECONDS - assembly_t), "④ تسلا: در حال مونتاژ… %.1f ثانیه" % maxf(0.0, ASSEMBLY_SECONDS - assembly_t)))
        else:
            lines.append(t.call("⑤ Tesla: take the finished Tesla gun", "⑤ تسلا: تفنگ تسلای ساخته‌شده را بردار"))
    elif cage != null and not cage.is_broken():
        lines.append(t.call("Pack-a-Punch: shoot the iron cage with the Tesla (%d/3)" % cage.hits, "پک‌ای‌پانچ: با تسلا به قفس آهنین شلیک کن (%d/۳)" % cage.hits))
    elif not hatch_open:
        lines.append(t.call("Pack-a-Punch: open the hidden tunnel under the assembly machine (%d pts)" % HATCH_FEE, "پک‌ای‌پانچ: تونل مخفی زیر دستگاه مونتاژ را باز کن (%d امتیاز)" % HATCH_FEE))
    elif not vault_released:
        lines.append(t.call("Pack-a-Punch: take the tunnel and press the vault release button", "پک‌ای‌پانچ: از تونل برو و دکمه‌ی آزادسازی خزانه را بزن"))
    else:
        lines.append(t.call("Pack-a-Punch ready: %d pts + %d Tesla charges" % [PAP_COST, PAP_TESLA_COST], "پک‌ای‌پانچ آماده است: %d امتیاز + %d شارژ تسلا" % [PAP_COST, PAP_TESLA_COST]))
    return lines

func _refresh() -> void:
    stage_changed.emit(stage())
    game.refresh_missions()

# ---------------------------------------------------------------- stage 1: charging machines

func _build_machines() -> void:
    var index: int = 0
    for pos in game.sites["charge_machines"]:
        var node: Node3D = ZombieProps.build_charge_machine()
        node.name = "ChargeMachine_%d" % index
        game.root3d.add_child(node)
        node.global_position = pos
        game.register_cullable(node)
        var record: Dictionary = {"node": node, "pos": pos, "active": false, "charge": 0, "ready": false, "taken": false, "battery": null}
        machines.append(record)
        var captured: int = index
        var interact: ZInteract = game.make_interact(node, "Interact_Charge_%d" % index, pos,
            func() -> String: return _machine_text(captured),
            func(_a: Node) -> void: _machine_use(captured),
            Callable(), Vector3(2.6, 3.2, 2.6), Vector3(0.0, 1.6, 0.0), true)
        record["interact"] = interact
        _update_machine_label(captured)
        index += 1

func _machine_text(index: int) -> String:
    var m: Dictionary = machines[index]
    if bool(m["taken"]):
        return ""
    if bool(m["ready"]):
        if carried != "":
            return ZombieGame.tx("Battery ready — your hands are full", "باتری آماده است — دستت پر است")
        return ZombieGame.tx("Take the battery", "برداشتن باتری")
    if bool(m["active"]):
        return ZombieGame.tx("Charging %d/%d — kill zombies inside the energy field" % [int(m["charge"]), ENERGY_NEEDED], "در حال شارژ %d/%d — زامبی‌ها را داخل میدان انرژی بکش" % [int(m["charge"]), ENERGY_NEEDED])
    return ZombieGame.tx("Activate the charging machine", "فعال‌کردن دستگاه شارژ")

func _machine_use(index: int) -> void:
    var m: Dictionary = machines[index]
    var node: Node3D = m["node"]
    if bool(m["taken"]):
        return
    if bool(m["ready"]):
        if carried != "":
            game.notify(ZombieGame.tx("Your hands are full: install the battery first", "دستت پر است: اول باتری را نصب کن"), Color("#ffd23d"))
            return
        _take_battery(index)
        return
    if bool(m["active"]):
        game.notify(ZombieGame.tx("Kill zombies inside the blue energy field to charge it", "زامبی‌ها را داخل میدان آبی انرژی بکش تا شارژ شود"), Color("#4fd8ff"))
        return
    m["active"] = true
    (node.get_meta("field") as Node3D).visible = true
    (node.get_meta("field_disc") as Node3D).visible = true
    ZombieProps.play(node, node.global_position + Vector3(0.0, 2.0, 0.0), "power_up", 2.0, 0.9, 60.0)
    var core_mat: StandardMaterial3D = node.get_meta("core_mat")
    core_mat.emission_energy_multiplier = 3.0
    for ring in node.get_meta("rings"):
        var spin: Tween = (ring as Node3D).create_tween().set_loops()
        spin.tween_property(ring, "rotation:y", TAU, 1.6).as_relative()
    game.notify(ZombieGame.tx("Machine online: lure zombies into the energy field", "دستگاه روشن شد: زامبی‌ها را به میدان انرژی بکشان"), Color("#4fd8ff"))
    _update_machine_label(index)

func _update_machine_label(index: int) -> void:
    var m: Dictionary = machines[index]
    var node: Node3D = m["node"]
    var label: Label3D = node.get_meta("label")
    var gauge: MeshInstance3D = node.get_meta("gauge")
    var fraction: float = clampf(float(int(m["charge"])) / float(ENERGY_NEEDED), 0.0, 1.0)
    gauge.scale.y = maxf(0.05, fraction * 16.0)
    gauge.position.y = 0.88 + fraction * 0.4
    if bool(m["taken"]):
        label.text = ZombieGame.tx("DRAINED", "خالی")
    elif bool(m["ready"]):
        label.text = ZombieGame.tx("BATTERY READY", "باتری آماده")
    elif bool(m["active"]):
        label.text = "%d / %d" % [int(m["charge"]), ENERGY_NEEDED]
    else:
        label.text = ZombieGame.tx("OFFLINE", "خاموش")

func _on_combatant_killed(victim: Node, _killer: Node, _headshot: bool) -> void:
    if not (victim is Bot) or not (victim as Bot).is_zombie:
        return
    var bot: Bot = victim as Bot
    if str(bot.profile_id) == "inferno":
        return
    var value: int = 1
    var pid: String = str(bot.profile_id)
    if pid == "brute" or pid == "pyro" or pid == "tyrant" or pid == "spitter":
        value = 3 if pid != "spitter" else 2
    for index in range(machines.size()):
        var m: Dictionary = machines[index]
        if not bool(m["active"]) or bool(m["ready"]) or bool(m["taken"]):
            continue
        var offset: Vector3 = bot.global_position - (m["pos"] as Vector3)
        if absf(offset.y) > 4.0 or Vector2(offset.x, offset.z).length() > FIELD_RADIUS:
            continue
        _energy_beam(bot.global_position + Vector3(0.0, 1.0, 0.0), index)
        m["charge"] = mini(ENERGY_NEEDED, int(m["charge"]) + value)
        if int(m["charge"]) >= ENERGY_NEEDED:
            _machine_ready(index)
        else:
            _update_machine_label(index)
        return

## The zombie's energy flies to the machine core as a beam with a travelling orb.
func _energy_beam(from_point: Vector3, index: int) -> void:
    var node: Node3D = machines[index]["node"]
    var to_point: Vector3 = node.global_position + Vector3(0.0, 3.3, 0.0)
    var length: float = from_point.distance_to(to_point)
    var beam := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = Vector3(0.07, 0.07, length)
    beam.mesh = mesh
    var mat: StandardMaterial3D = ZombieProps.glow(Color("#6fe8ff"), 4.0, 0.85)
    beam.material_override = mat
    beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    game.root3d.add_child(beam)
    beam.global_position = (from_point + to_point) * 0.5
    beam.look_at(to_point, Vector3.UP if absf((to_point - from_point).normalized().y) < 0.98 else Vector3.RIGHT)
    var orb := ZombieProps.sphere(game.root3d, "EnergyOrb", from_point, 0.22, ZombieProps.glow(Color("#9ff2ff"), 5.0))
    var tw: Tween = orb.create_tween().set_parallel(true)
    tw.tween_property(orb, "global_position", to_point, 0.55).set_trans(Tween.TRANS_SINE)
    tw.tween_property(mat, "albedo_color:a", 0.0, 0.55)
    tw.chain().tween_callback(func() -> void:
        if is_instance_valid(beam):
            beam.queue_free()
        if is_instance_valid(orb):
            orb.queue_free()
        if is_instance_valid(node):
            _pulse_core(node))
    ZombieProps.play(node, from_point, "zap", -6.0, randf_range(1.2, 1.5), 30.0)

func _pulse_core(node: Node3D) -> void:
    var core_mat: StandardMaterial3D = node.get_meta("core_mat")
    core_mat.emission_energy_multiplier = 6.0
    var tw: Tween = node.create_tween()
    tw.tween_property(core_mat, "emission_energy_multiplier", 2.2, 0.35)
    ZombieProps.burst(game.root3d, node.global_position + Vector3(0.0, 3.3, 0.0), Color("#8fe8ff"), 10, 0.4)

func _machine_ready(index: int) -> void:
    var m: Dictionary = machines[index]
    var node: Node3D = m["node"]
    m["ready"] = true
    (node.get_meta("field") as Node3D).visible = false
    (node.get_meta("field_disc") as Node3D).visible = false
    var core_mat: StandardMaterial3D = node.get_meta("core_mat")
    core_mat.emission = Color("#3dff7a")
    core_mat.albedo_color = Color("#3dff7a")
    core_mat.emission_energy_multiplier = 3.5
    (node.get_meta("gauge_mat") as StandardMaterial3D).emission_energy_multiplier = 4.0
    var battery: Node3D = ZombieProps.build_battery(Color("#3dff7a"))
    node.add_child(battery)
    battery.position = Vector3(0.0, 4.6, 0.0)
    var bob: Tween = battery.create_tween().set_loops()
    bob.tween_property(battery, "position:y", 4.85, 0.7).set_trans(Tween.TRANS_SINE)
    bob.tween_property(battery, "position:y", 4.55, 0.7).set_trans(Tween.TRANS_SINE)
    var spin: Tween = battery.create_tween().set_loops()
    spin.tween_property(battery, "rotation:y", TAU, 2.4).as_relative()
    battery.set_meta("tweens", [bob, spin])
    m["battery"] = battery
    ZombieProps.burst(game.root3d, node.global_position + Vector3(0.0, 4.0, 0.0), Color("#3dff7a"), 40, 0.9)
    ZombieProps.play(node, node.global_position + Vector3(0.0, 3.0, 0.0), "power_up", 3.0, 1.3, 70.0)
    game.notify(ZombieGame.tx("Machine charged — take the battery", "دستگاه شارژ شد — باتری را بردار"), Color("#3dff7a"))
    _update_machine_label(index)
    _refresh()

func _take_battery(index: int) -> void:
    var m: Dictionary = machines[index]
    var battery: Node3D = m["battery"]
    m["ready"] = false
    m["taken"] = true
    batteries_taken += 1
    var node: Node3D = m["node"]
    var core_mat: StandardMaterial3D = node.get_meta("core_mat")
    core_mat.emission = Color("#35454d")
    core_mat.albedo_color = Color("#35454d")
    core_mat.emission_energy_multiplier = 0.3
    (node.get_meta("light") as OmniLight3D).light_energy = 0.1
    for tween_owner in node.get_meta("rings"):
        (tween_owner as Node3D).visible = false
    # The battery flies into the player's hands.
    _kill_tweens(battery)
    battery.reparent(game.root3d, true)
    _set_carry("battery", index, battery)
    ZombieProps.play(game.player, game.player.global_position, "mag_in", 0.0, 0.8, 12.0)
    _update_machine_label(index)
    (m["interact"] as ZInteract).interaction_enabled = false
    _refresh()

# ---------------------------------------------------------------- carrying

func _kill_tweens(node: Node) -> void:
    for tween in node.get_meta("tweens", []):
        if tween is Tween and (tween as Tween).is_valid():
            (tween as Tween).kill()

func _set_carry(kind: String, src: int, node: Node3D) -> void:
    carried = kind
    carried_src = src
    carried_node = node
    # Stop any idle tweens on the node by re-parenting it under the camera.
    if _camera != null:
        var from_transform: Transform3D = node.global_transform
        node.reparent(_camera, true)
        node.global_transform = from_transform
        var target: Vector3 = Vector3(0.34, -0.3, -0.7) if kind == "battery" else Vector3(0.0, -0.34, -0.85)
        var tw: Tween = node.create_tween().set_parallel(true)
        tw.tween_property(node, "position", target, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
        tw.tween_property(node, "rotation", Vector3(0.0, 0.5, 0.0), 0.5)
        tw.tween_property(node, "scale", Vector3.ONE * (0.8 if kind == "body" else 1.0), 0.5)
    game.hud.set_carry(_carry_text())

func _carry_text() -> String:
    if carried == "battery":
        return ZombieGame.tx("Carrying: battery ▮", "در دست: باتری ▮")
    if carried == "body":
        return ZombieGame.tx("Carrying: Tesla body ⚡", "در دست: بدنه‌ی تسلا ⚡")
    return ""

func _clear_carry() -> void:
    carried = ""
    carried_src = -1
    carried_node = null
    game.hud.set_carry("")

## Dying drops what you carry: batteries go back to their machine, the body back to the room.
func on_player_died() -> void:
    if carried == "battery" and carried_src >= 0:
        var m: Dictionary = machines[carried_src]
        if is_instance_valid(carried_node):
            carried_node.queue_free()
        m["taken"] = false
        m["ready"] = false
        m["charge"] = ENERGY_NEEDED - 3
        m["active"] = true
        batteries_taken -= 1
        (m["interact"] as ZInteract).interaction_enabled = true
        var node: Node3D = m["node"]
        (node.get_meta("field") as Node3D).visible = true
        (node.get_meta("field_disc") as Node3D).visible = true
        (node.get_meta("light") as OmniLight3D).light_energy = 1.0
        for ring in node.get_meta("rings"):
            (ring as Node3D).visible = true
        var core_mat: StandardMaterial3D = node.get_meta("core_mat")
        core_mat.emission = Color("#4fd8ff")
        core_mat.albedo_color = Color("#4fd8ff")
        core_mat.emission_energy_multiplier = 2.2
        _update_machine_label(carried_src)
        game.notify(ZombieGame.tx("You dropped the battery: the machine lost part of its charge", "باتری از دستت افتاد: دستگاه بخشی از شارژ را از دست داد"), Color("#ff8a7a"))
        _clear_carry()
    elif carried == "body":
        if is_instance_valid(carried_node):
            carried_node.queue_free()
        _clear_carry()
        _spawn_body_pickup(_body_drop)
        game.notify(ZombieGame.tx("You dropped the Tesla body in the Tesla room", "بدنه‌ی تسلا در اتاق تسلا افتاد"), Color("#ff8a7a"))
    _refresh()

# ---------------------------------------------------------------- stage 2: battery station

func _build_station() -> void:
    var pos: Vector3 = game.sites["battery_station"]
    station = ZombieProps.build_battery_station()
    game.root3d.add_child(station)
    station.global_position = pos
    game.register_cullable(station)
    game.make_interact(station, "Interact_Station", pos + Vector3(0.0, 0.0, 0.5),
        func() -> String: return _station_text(),
        func(_a: Node) -> void: _station_use(),
        Callable(), Vector3(4.2, 2.6, 1.8), Vector3(0.0, 1.3, 0.3), true)

func _station_text() -> String:
    if station_powered:
        return ZombieGame.tx("Battery station — fully powered", "ایستگاه باتری — کاملاً روشن")
    if carried == "battery":
        return ZombieGame.tx("Install the battery (%d/%d)" % [_installed_count(), BATTERY_COUNT], "نصب باتری (%d/%d)" % [_installed_count(), BATTERY_COUNT])
    return ZombieGame.tx("Battery station: needs %d batteries (%d installed)" % [BATTERY_COUNT, _installed_count()], "ایستگاه باتری: به %d باتری نیاز دارد (%d نصب شده)" % [BATTERY_COUNT, _installed_count()])

func _station_use() -> void:
    if station_powered:
        return
    if carried != "battery" or not is_instance_valid(carried_node):
        game.notify(ZombieGame.tx("Bring a charged battery from one of the three machines", "یک باتری شارژشده از یکی از سه دستگاه بیاور"), Color("#ffd23d"))
        return
    var slot: int = installed.find(false)
    if slot < 0:
        return
    var anchors: Array = station.get_meta("slots")
    var slot_mats: Array = station.get_meta("slot_mats")
    var anchor: Node3D = anchors[slot]
    var battery: Node3D = carried_node
    installed[slot] = true
    _clear_carry()
    battery.reparent(anchor, true)
    var tw: Tween = battery.create_tween().set_parallel(true)
    tw.tween_property(battery, "position", Vector3.ZERO, 0.7).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
    tw.tween_property(battery, "rotation", Vector3.ZERO, 0.7)
    tw.tween_property(battery, "scale", Vector3.ONE, 0.7)
    tw.chain().tween_callback(func() -> void:
        var mat: StandardMaterial3D = slot_mats[slot]
        mat.emission = Color("#3dff7a")
        mat.albedo_color = Color("#3dff7a")
        mat.emission_energy_multiplier = 3.0
        ZombieProps.burst(game.root3d, anchor.global_position, Color("#3dff7a"), 24, 0.6)
        ZombieProps.play(station, anchor.global_position, "clank", 2.0, 0.9, 40.0))
    game.notify(ZombieGame.tx("Battery installed %d/%d" % [_installed_count(), BATTERY_COUNT], "باتری نصب شد %d/%d" % [_installed_count(), BATTERY_COUNT]), Color("#3dff7a"))
    if _installed_count() >= BATTERY_COUNT:
        station_powered = true
        _station_powered_up()
    _refresh()

func _station_powered_up() -> void:
    var l: OmniLight3D = station.get_meta("light")
    l.light_color = Color("#3dff7a")
    ZombieProps.play(station, station.global_position + Vector3(0.0, 2.0, 0.0), "alarm", 3.0, 1.0, 80.0)
    game.notify(ZombieGame.tx("The station roars to life… something awakens in the Tesla room!", "ایستگاه روشن شد… چیزی در اتاق تسلا بیدار می‌شود!"), Color("#ff8a3a"))
    # Red alarm pulse, then the boss erupts from the floor.
    var pulse: Tween = l.create_tween().set_loops(4)
    pulse.tween_property(l, "light_color", Color("#ff2a1a"), 0.3)
    pulse.tween_property(l, "light_color", Color("#3dff7a"), 0.3)
    get_tree().create_timer(2.6).timeout.connect(spawn_boss)

# ---------------------------------------------------------------- stage 3: the fire boss

func spawn_boss() -> void:
    if boss_spawned:
        return
    boss_spawned = true
    var at := Transform3D(Basis.IDENTITY, Vector3(108.0, ZombieComplex.FLOOR_Y + 0.1, 37.0))
    boss = FireBoss.new()
    boss.difficulty = int(game.mode.call("get_difficulty"))
    boss.display_name = ZombieGame.tx("Inferno Colossus", "غول آتشین")
    boss.fx = game.mode.get("fx")
    boss.mode_ref = game.mode
    var spec: Dictionary = {"profile": "inferno", "team": "zombie", "name": boss.display_name, "hunt": true}
    boss.profile_id = "inferno"
    boss.team = "zombie"
    game.mode.call("spawn_special", boss, spec, at)
    boss.died.connect(_on_boss_died)
    game.hud.show_boss(boss.display_name)
    ZombieProps.burst(game.root3d, at.origin + Vector3(0.0, 0.5, 0.0), Color("#ff6a1a"), 80, 1.2)
    game.notify(ZombieGame.tx("Inferno Colossus!", "غول آتشین!"), Color("#ff6a1a"))
    _refresh()

func _on_boss_died(dead: Bot, _killer: Node, _headshot: bool) -> void:
    boss_dead = true
    game.hud.hide_boss()
    var p: Vector3 = dead.global_position
    _body_drop = Vector3(clampf(p.x, BODY_ROOM_MIN.x, BODY_ROOM_MAX.x), ZombieComplex.FLOOR_Y, clampf(p.z, BODY_ROOM_MIN.y, BODY_ROOM_MAX.y))
    _spawn_body_pickup(_body_drop)
    game.notify(ZombieGame.tx("The Colossus fell and dropped the Tesla body!", "غول سقوط کرد و بدنه‌ی تسلا را انداخت!"), Color("#4fd8ff"))
    _refresh()

func _spawn_body_pickup(at: Vector3) -> void:
    if is_instance_valid(body_pickup):
        body_pickup.queue_free()
    body_pickup = Node3D.new()
    body_pickup.name = "TeslaBodyPickup"
    game.root3d.add_child(body_pickup)
    body_pickup.global_position = at
    var model: Node3D = ZombieProps.build_tesla_body()
    model.position = Vector3(0.0, 1.0, 0.0)
    model.scale = Vector3.ONE * 1.5
    body_pickup.add_child(model)
    var l: OmniLight3D = ZombieProps.light(body_pickup, Color("#4fd8ff"), 2.4, 8.0, Vector3(0.0, 1.5, 0.0))
    l.name = "BodyLight"
    var spin: Tween = model.create_tween().set_loops()
    spin.tween_property(model, "rotation:y", TAU, 3.0).as_relative()
    var bob: Tween = model.create_tween().set_loops()
    bob.tween_property(model, "position:y", 1.25, 0.8).set_trans(Tween.TRANS_SINE)
    bob.tween_property(model, "position:y", 0.9, 0.8).set_trans(Tween.TRANS_SINE)
    model.set_meta("tweens", [spin, bob])
    body_pickup.set_meta("model", model)
    body_pickup_interact = game.make_interact(body_pickup, "Interact_TeslaBody", at,
        func() -> String: return ZombieGame.tx("Pick up the Tesla body", "برداشتن بدنه‌ی تسلا") if carried == "" else ZombieGame.tx("Your hands are full", "دستت پر است"),
        func(_a: Node) -> void: _pickup_body(),
        Callable(), Vector3(2.0, 2.0, 2.0), Vector3(0.0, 1.0, 0.0), false)

func _pickup_body() -> void:
    if carried != "":
        game.notify(ZombieGame.tx("Your hands are full", "دستت پر است"), Color("#ffd23d"))
        return
    if not is_instance_valid(body_pickup):
        return
    var model: Node3D = body_pickup.get_meta("model")
    var spent: Node3D = model
    _kill_tweens(spent)
    spent.reparent(game.root3d, true)
    body_pickup.queue_free()
    body_pickup = null
    _set_carry("body", -1, spent)
    ZombieProps.play(game.player, game.player.global_position, "mag_in", 0.0, 0.6, 12.0)
    _refresh()

# ---------------------------------------------------------------- stage 4 + 5: assembly machine

func _build_assembly() -> void:
    var pos: Vector3 = game.sites["assembly"]
    var hatch: Rect2 = game.sites["hatch"]
    lift = Node3D.new()
    lift.name = "HatchLift"
    game.root3d.add_child(lift)
    lift.global_position = Vector3(hatch.position.x + hatch.size.x * 0.5, ZombieComplex.FLOOR_Y, hatch.position.y + hatch.size.y * 0.5)
    game.register_cullable(lift)
    # Cover plate over the hidden stairs (lies on the floor so the player simply steps onto it).
    var cover := StaticBody3D.new()
    cover.name = "HatchCover"
    cover.collision_layer = 1
    lift.add_child(cover)
    var cover_shape := CollisionShape3D.new()
    var cover_box := BoxShape3D.new()
    cover_box.size = Vector3(hatch.size.x + 0.2, 0.12, hatch.size.y + 0.2)
    cover_shape.shape = cover_box
    cover_shape.position = Vector3(0.0, 0.06, 0.0)
    cover.add_child(cover_shape)
    ZombieProps.box(cover, "Plate", Vector3(0.0, 0.06, 0.0), Vector3(hatch.size.x + 0.2, 0.12, hatch.size.y + 0.2), ZombieProps.mat(Color("#2b3036"), 0.0, 0.45, 0.8))
    for i in range(6):
        ZombieProps.box(cover, "Seam", Vector3(-hatch.size.x * 0.5 + 0.6 + float(i) * (hatch.size.x - 1.2) / 5.0, 0.125, 0.0), Vector3(0.06, 0.01, hatch.size.y), ZombieProps.mat(Color("#d9a21e"), 0.0, 0.6, 0.1))
    assembly = ZombieProps.build_assembly_machine()
    assembly.name = "AssemblyMachine"
    lift.add_child(assembly)
    assembly.global_position = pos
    assembly.rotation.y = PI
    assembly.position.y += 0.12
    assembly_interact = game.make_interact(assembly, "Interact_Assembly", pos,
        func() -> String: return _assembly_text(),
        func(_a: Node) -> void: _assembly_use(),
        Callable(), Vector3(4.2, 3.0, 3.2), Vector3(0.0, 1.5, 0.0), true)
    _hum = AudioStreamPlayer3D.new()
    _hum.stream = WeaponAudio.get_stream("hum")
    _hum.max_distance = 50.0
    _hum.unit_size = 8.0
    _hum.volume_db = -2.0
    _hum.bus = "SFX" if AudioServer.get_bus_index("SFX") != -1 else "Master"
    assembly.add_child(_hum)
    # Hatch fee interaction (active once the cage circuits are shorted).
    hatch_interact = game.make_interact(lift, "Interact_Hatch", lift.global_position + Vector3(0.0, 0.0, 2.6),
        func() -> String: return ZombieGame.tx("Open the hidden tunnel — %d pts" % HATCH_FEE, "باز کردن تونل مخفی — %d امتیاز" % HATCH_FEE),
        func(_a: Node) -> void: _hatch_use(),
        func(_a: Node) -> bool: return cage != null and cage.is_broken() and not hatch_open and not _hatch_busy,
        Vector3(6.0, 2.0, 1.8), Vector3(0.0, 1.0, 0.0), false)

func _assembly_text() -> String:
    if tesla_taken:
        return ""
    if assembling:
        return ZombieGame.tx("Assembling… %.1f s" % maxf(0.0, ASSEMBLY_SECONDS - assembly_t), "در حال مونتاژ… %.1f ثانیه" % maxf(0.0, ASSEMBLY_SECONDS - assembly_t))
    if assembly_done:
        return ZombieGame.tx("Take the Tesla gun", "برداشتن تفنگ تسلا")
    if carried == "body":
        return ZombieGame.tx("Insert the Tesla body (20 s assembly)", "قراردادن بدنه‌ی تسلا (۲۰ ثانیه مونتاژ)")
    return ZombieGame.tx("Tesla assembly machine — needs the Tesla body", "دستگاه مونتاژ تسلا — به بدنه‌ی تسلا نیاز دارد")

func _assembly_use() -> void:
    if tesla_taken or assembling:
        return
    if assembly_done:
        _take_tesla()
        return
    if carried != "body" or not is_instance_valid(carried_node):
        game.notify(ZombieGame.tx("The machine needs the Tesla body dropped by the Colossus", "دستگاه به بدنه‌ی تسلا که غول انداخته نیاز دارد"), Color("#ffd23d"))
        return
    start_assembly()

func start_assembly() -> void:
    assembling = true
    assembly_t = 0.0
    var body: Node3D = carried_node
    _clear_carry()
    var anchor: Node3D = assembly.get_meta("anchor")
    body.reparent(anchor, true)
    _gun_model = body
    var tw: Tween = body.create_tween().set_parallel(true)
    tw.tween_property(body, "position", Vector3.ZERO, 0.8).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN_OUT)
    tw.tween_property(body, "rotation", Vector3(0.0, PI * 0.5, 0.0), 0.8)
    tw.tween_property(body, "scale", Vector3.ONE * 1.6, 0.8)
    for s in assembly.get_meta("sparks"):
        (s as CPUParticles3D).emitting = true
    _hum.play()
    _clank_left = 0.0
    game.notify(ZombieGame.tx("Assembly started: 20 seconds — hold the room!", "مونتاژ شروع شد: ۲۰ ثانیه — از اتاق دفاع کن!"), Color("#ffd23d"))
    _refresh()

func _process(delta: float) -> void:
    _bob += delta
    if carried_node != null and is_instance_valid(carried_node) and carried_node.get_parent() == _camera:
        carried_node.position.y += sin(_bob * 2.2) * 0.0006
    if boss != null and is_instance_valid(boss) and not boss_dead:
        game.hud.set_boss_health(boss.get_health_fraction())
    if assembling:
        _tick_assembly(delta)
    if pap_busy:
        _tick_pap(delta)

func _tick_assembly(delta: float) -> void:
    assembly_t += delta
    var remaining: float = maxf(0.0, ASSEMBLY_SECONDS - assembly_t)
    game.hud.set_countdown(remaining, "⚙ ")
    var timer_label: Label3D = assembly.get_meta("timer")
    timer_label.text = "%05.2f" % remaining
    # Mechanical movement: the two arms swing out of phase, the gears spin, the lights flicker.
    var arms: Array = assembly.get_meta("arms")
    (arms[0] as Node3D).rotation.z = sin(assembly_t * 3.1) * 0.55
    (arms[1] as Node3D).rotation.z = sin(assembly_t * 3.1 + PI) * 0.55
    (arms[0] as Node3D).rotation.x = sin(assembly_t * 1.7) * 0.25
    (arms[1] as Node3D).rotation.x = cos(assembly_t * 1.7) * 0.25
    for gear in assembly.get_meta("gears"):
        (gear as Node3D).rotate_z(delta * 4.5)
    var lights: Array = assembly.get_meta("lights")
    (lights[0] as OmniLight3D).light_energy = 1.2 + sin(assembly_t * 17.0) * 0.8 + randf() * 0.5
    (lights[1] as OmniLight3D).light_energy = (0.6 + randf() * 1.4) * minf(1.0, assembly_t / 10.0)
    (assembly.get_meta("screen_mat") as StandardMaterial3D).emission_energy_multiplier = 1.6 + sin(assembly_t * 9.0) * 0.9
    if _gun_model != null and is_instance_valid(_gun_model):
        _gun_model.rotation.y += delta * (1.0 + assembly_t * 0.25)
    _clank_left -= delta
    if _clank_left <= 0.0:
        _clank_left = 0.9 - minf(assembly_t / ASSEMBLY_SECONDS, 1.0) * 0.5
        ZombieProps.play(assembly, assembly.global_position + Vector3(0.0, 1.5, 0.0), "clank", 0.0, randf_range(0.7, 1.3), 50.0)
        if randf() < 0.6:
            ZombieProps.play(assembly, assembly.global_position + Vector3(0.0, 2.0, 0.0), "zap", -4.0, randf_range(0.8, 1.2), 50.0)
    if assembly_t >= ASSEMBLY_SECONDS - 0.0001:
        _finish_assembly()
    else:
        game.refresh_missions()

func _finish_assembly() -> void:
    assembling = false
    assembly_done = true
    assembly_t = ASSEMBLY_SECONDS
    game.hud.set_countdown(-1.0)
    _hum.stop()
    for s in assembly.get_meta("sparks"):
        (s as CPUParticles3D).emitting = false
    var arms: Array = assembly.get_meta("arms")
    for arm in arms:
        var a: Node3D = arm
        var back: Tween = a.create_tween().set_parallel(true)
        back.tween_property(a, "rotation", Vector3(0.0, 0.0, 0.0), 0.6)
    (assembly.get_meta("timer") as Label3D).text = ZombieGame.tx("COMPLETE", "کامل شد")
    (assembly.get_meta("screen_mat") as StandardMaterial3D).emission = Color("#3dff7a")
    # Completion show: white flash, a burst, the gun rises and its coils light up.
    var lights: Array = assembly.get_meta("lights")
    var flash: Tween = (lights[0] as OmniLight3D).create_tween()
    (lights[0] as OmniLight3D).light_color = Color("#ffffff")
    flash.tween_property(lights[0], "light_energy", 9.0, 0.15)
    flash.tween_property(lights[0], "light_energy", 1.4, 1.0)
    ZombieProps.burst(game.root3d, assembly.global_position + Vector3(0.0, 1.8, 0.0), Color("#8fe8ff"), 80, 1.1)
    ZombieProps.play(assembly, assembly.global_position + Vector3(0.0, 1.5, 0.0), "power_up", 4.0, 1.1, 70.0)
    if _gun_model != null and is_instance_valid(_gun_model):
        var rise: Tween = _gun_model.create_tween()
        rise.tween_property(_gun_model, "position:y", 0.7, 0.8).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    game.notify(ZombieGame.tx("The Tesla gun is complete! Take it.", "تفنگ تسلا کامل شد! آن را بردار."), Color("#4fd8ff"))
    _refresh()

func _take_tesla() -> void:
    tesla_taken = true
    if _gun_model != null and is_instance_valid(_gun_model):
        var fly: Tween = _gun_model.create_tween()
        var target: Vector3 = (_camera.global_position + -_camera.global_transform.basis.z * 0.5) if _camera != null else game.player.global_position
        fly.tween_property(_gun_model, "global_position", target, 0.4).set_trans(Tween.TRANS_QUAD)
        fly.tween_callback(_gun_model.queue_free)
    game.weapon.call("give_tesla", TESLA_START_RESERVE)
    ZombieProps.play(game.player, game.player.global_position, "power_up", 0.0, 1.4, 12.0)
    (assembly.get_meta("timer") as Label3D).text = ""
    assembly_interact.interaction_enabled = false
    game.notify(ZombieGame.tx("Tesla gun acquired — ammo only comes from drops and every 5th wave", "تفنگ تسلا به دست آمد — مهمات فقط از دراپ و هر موج پنجم می‌آید"), Color("#4fd8ff"))
    _refresh()

# ---------------------------------------------------------------- cage, hatch, button

func _build_vault_objects() -> void:
    var pap_pos: Vector3 = game.sites["pap"]
    cage = ZombieProps.build_cage()
    game.root3d.add_child(cage)
    cage.global_position = pap_pos
    game.register_cullable(cage)
    cage.tesla_hit.connect(_on_cage_hit)
    pap = ZombieProps.build_pap()
    pap.name = "PackAPunch"
    game.root3d.add_child(pap)
    pap.global_position = pap_pos
    pap.rotation.y = PI * 0.5
    game.register_cullable(pap)
    game.make_interact(pap, "Interact_PackAPunch", pap_pos,
        func() -> String: return _pap_text(),
        func(_a: Node) -> void: _pap_use(),
        Callable(), Vector3(2.8, 3.0, 2.4), Vector3(0.0, 1.5, 0.0), true)
    var button_pos: Vector3 = game.sites["button"]
    button_node = ZombieProps.build_button()
    game.root3d.add_child(button_node)
    button_node.global_position = button_pos
    game.register_cullable(button_node)
    game.make_interact(button_node, "Interact_VaultButton", button_pos,
        func() -> String: return ZombieGame.tx("Vault released", "خزانه آزاد شد") if vault_released else ZombieGame.tx("Press the vault release button", "زدن دکمه‌ی آزادسازی خزانه"),
        func(_a: Node) -> void: _button_use(),
        func(_a: Node) -> bool: return not vault_released,
        Vector3(1.4, 2.0, 1.4), Vector3(0.0, 1.0, 0.0), true)

func _on_cage_hit(count: int) -> void:
    if count < ZCage.REQUIRED_HITS:
        game.notify(ZombieGame.tx("Cage circuit hit %d/%d" % [count, ZCage.REQUIRED_HITS], "ضربه به مدار قفس %d/%d" % [count, ZCage.REQUIRED_HITS]), Color("#4fd8ff"))
    else:
        game.notify(ZombieGame.tx("The cage circuits are fried! The assembly machine's hatch can now be opened.", "مدار قفس سوخت! دریچه‌ی زیر دستگاه مونتاژ حالا قابل باز شدن است."), Color("#4fd8ff"))
        ZombieProps.play(cage, cage.global_position + Vector3(0.0, 2.0, 0.0), "alarm", 0.0, 0.8, 60.0)
    _refresh()

func _hatch_use() -> void:
    if hatch_open or _hatch_busy or cage == null or not cage.is_broken():
        return
    if not game.spend_points(HATCH_FEE):
        return
    _hatch_busy = true
    ZombieProps.play(lift, lift.global_position + Vector3(0.0, 1.0, 0.0), "clank", 4.0, 0.5, 60.0)
    game.notify(ZombieGame.tx("The assembly machine slides away… a hidden tunnel opens!", "دستگاه مونتاژ کنار می‌رود… تونل مخفی باز می‌شود!"), Color("#ffd23d"))
    var tw: Tween = lift.create_tween()
    tw.tween_property(lift, "position:z", lift.position.z + HATCH_SLIDE, 2.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    tw.tween_callback(func() -> void:
        hatch_open = true
        _hatch_busy = false
        hatch_interact.interaction_enabled = false
        ZombieProps.burst(game.root3d, lift.global_position + Vector3(0.0, 0.3, 0.0), Color("#d9a21e"), 30, 0.8)
        _refresh())
    # Rumble while it moves.
    for step in range(5):
        get_tree().create_timer(0.4 + 0.5 * float(step)).timeout.connect(func() -> void:
            ZombieProps.play(lift, lift.global_position, "clank", -2.0, randf_range(0.4, 0.7), 50.0))

func _button_use() -> void:
    if vault_released:
        return
    vault_released = true
    var cap: Node3D = button_node.get_meta("cap")
    var press: Tween = cap.create_tween()
    press.tween_property(cap, "position:y", 1.1, 0.12)
    press.tween_property(cap, "position:y", 1.2, 0.25)
    var cap_mat: StandardMaterial3D = button_node.get_meta("cap_mat")
    cap_mat.emission = Color("#3dff7a")
    cap_mat.albedo_color = Color("#3dff7a")
    (button_node.get_meta("light") as OmniLight3D).light_color = Color("#3dff7a")
    ZombieProps.play(button_node, button_node.global_position + Vector3(0.0, 1.0, 0.0), "clank", 2.0, 1.4, 40.0)
    game.open_door_free("vault")
    raise_cage()
    game.notify(ZombieGame.tx("The vault door opens and the cage rises!", "درِ خزانه باز می‌شود و قفس بالا می‌رود!"), Color("#3dff7a"))
    _refresh()

func raise_cage() -> void:
    if cage.raised:
        return
    var tw: Tween = cage.create_tween()
    tw.tween_property(cage, "position:y", cage.position.y + CAGE_LIFT, 3.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    tw.tween_callback(func() -> void:
        cage.raised = true
        _refresh())
    for step in range(6):
        get_tree().create_timer(0.3 + 0.55 * float(step)).timeout.connect(func() -> void:
            ZombieProps.play(cage, cage.global_position + Vector3(0.0, 2.0, 0.0), "clank", 0.0, randf_range(0.5, 0.8), 60.0)
            ZombieProps.burst(game.root3d, cage.global_position + Vector3(0.0, 4.0, 0.0), Color("#8fe8ff"), 10, 0.5))

# ---------------------------------------------------------------- Pack-a-Punch

func _pap_text() -> String:
    if pap_busy:
        return ZombieGame.tx("Upgrading… %.1f s" % maxf(0.0, PAP_SECONDS - pap_t), "در حال ارتقا… %.1f ثانیه" % maxf(0.0, PAP_SECONDS - pap_t))
    if cage == null or not cage.raised:
        return ZombieGame.tx("Pack-a-Punch — locked behind the iron cage", "پک‌ای‌پانچ — پشت قفس آهنین قفل است")
    return ZombieGame.tx("Pack-a-Punch — %d pts + %d Tesla charges (+25%% damage, x2 magazine, x2 reserve)" % [PAP_COST, PAP_TESLA_COST],
        "پک‌ای‌پانچ — %d امتیاز + %d شارژ تسلا (+۲۵٪ آسیب، ۲× خشاب، ۲× ذخیره)" % [PAP_COST, PAP_TESLA_COST])

func can_pack(id: String) -> String:
    ## Returns an empty string when the weapon can be upgraded, otherwise the reason.
    if cage == null or not cage.raised:
        return ZombieGame.tx("The machine is locked behind the iron cage", "دستگاه پشت قفس آهنین قفل است")
    if pap_busy:
        return ZombieGame.tx("The machine is busy", "دستگاه مشغول است")
    if id.is_empty():
        return ZombieGame.tx("Equip a weapon first", "اول یک سلاح در دست بگیر")
    if id == "tesla":
        return ZombieGame.tx("The Tesla gun cannot be upgraded", "تفنگ تسلا قابل ارتقا نیست")
    if bool(game.weapon.call("is_upgraded", id)):
        return ZombieGame.tx("This weapon is already upgraded", "این سلاح قبلاً ارتقا یافته")
    if int(game.weapon.call("tesla_total")) < PAP_TESLA_COST:
        return ZombieGame.tx("You need %d Tesla charges" % PAP_TESLA_COST, "به %d شارژ تسلا نیاز داری" % PAP_TESLA_COST)
    if game.points < PAP_COST:
        return ZombieGame.tx("Not enough points (%d needed)" % PAP_COST, "امتیاز کافی نیست (%d لازم است)" % PAP_COST)
    return ""

func _pap_use() -> void:
    var id: String = str(game.weapon.call("get_weapon_id"))
    var reason: String = can_pack(id)
    if not reason.is_empty():
        game.notify(reason, Color("#ffd23d"))
        return
    start_pap(id)

func start_pap(id: String) -> void:
    game.spend_points(PAP_COST)
    game.weapon.call("spend_tesla_ammo", PAP_TESLA_COST)
    game.weapon.call("lock_weapon", id)
    pap_busy = true
    pap_t = 0.0
    pap_weapon = id
    _pap_phase = 0
    (pap.get_meta("progress") as Label3D).text = ""
    for s in [pap.get_meta("sparks")]:
        (s as CPUParticles3D).emitting = true
    # Insertion: the slot doors open, the gun slides in, the doors close.
    var doors: Array = pap.get_meta("doors")
    var token: Node3D = ZombieProps.build_gun_token(WeaponDefinitions.get_accent(id))
    token.name = "GunToken"
    pap.add_child(token)
    _pap_token = token
    token.global_position = game.player.global_position + Vector3(0.0, 1.3, 0.0)
    var slot_anchor: Node3D = pap.get_meta("slot_anchor")
    var tw: Tween = token.create_tween()
    tw.tween_callback(func() -> void: _slide_doors(doors, true))
    tw.tween_property(token, "global_position", slot_anchor.global_position, 0.45).set_trans(Tween.TRANS_QUAD)
    tw.tween_property(token, "global_position", pap.global_position + Vector3(0.0, 1.25, 0.0), 0.3)
    tw.tween_callback(func() -> void:
        _slide_doors(doors, false)
        token.visible = false)
    ZombieProps.play(pap, pap.global_position + Vector3(0.0, 1.2, 0.0), "clank", 2.0, 0.8, 40.0)
    ZombieProps.play(pap, pap.global_position + Vector3(0.0, 1.2, 0.0), "power_up", 2.0, 0.6, 50.0)
    game.notify(ZombieGame.tx("Upgrading your weapon… 6 seconds", "در حال ارتقای سلاح… ۶ ثانیه"), Color("#d9b8ff"))
    _refresh()

func _slide_doors(doors: Array, open: bool) -> void:
    var left: Node3D = doors[0]
    var right: Node3D = doors[1]
    var tw: Tween = left.create_tween().set_parallel(true)
    tw.tween_property(left, "position:x", -0.95 if open else -0.32, 0.3)
    tw.tween_property(right, "position:x", 0.95 if open else 0.32, 0.3)

func _tick_pap(delta: float) -> void:
    pap_t += delta
    var remaining: float = maxf(0.0, PAP_SECONDS - pap_t)
    (pap.get_meta("progress") as Label3D).text = "%.1f" % remaining
    for gear in pap.get_meta("gears"):
        (gear as Node3D).rotate_x(delta * 6.0)
    (pap.get_meta("rune_mat") as StandardMaterial3D).emission_energy_multiplier = 1.5 + sin(pap_t * 10.0) * 1.2
    (pap.get_meta("light") as OmniLight3D).light_energy = 2.0 + sin(pap_t * 14.0) * 1.2 + randf() * 0.6
    if _pap_phase == 0 and pap_t >= PAP_SECONDS - 0.9:
        # Return animation starts: the doors open and the gun is pushed out onto the tray.
        _pap_phase = 1
        var doors: Array = pap.get_meta("doors")
        _slide_doors(doors, true)
        if _pap_token != null and is_instance_valid(_pap_token):
            _pap_token.visible = true
            var tray: Node3D = pap.get_meta("tray_anchor")
            var tw: Tween = _pap_token.create_tween()
            tw.tween_property(_pap_token, "global_position", (pap.get_meta("slot_anchor") as Node3D).global_position, 0.4)
            tw.tween_property(_pap_token, "global_position", tray.global_position + Vector3(0.0, 0.25, 0.0), 0.35)
        ZombieProps.play(pap, pap.global_position + Vector3(0.0, 1.2, 0.0), "clank", 2.0, 1.3, 40.0)
    if pap_t >= PAP_SECONDS - 0.0001:
        _finish_pap()

func _finish_pap() -> void:
    pap_busy = false
    pap_t = PAP_SECONDS
    var id: String = pap_weapon
    game.weapon.call("apply_upgrade", id)
    game.weapon.call("unlock_weapon")
    pap_count += 1
    (pap.get_meta("progress") as Label3D).text = ""
    (pap.get_meta("sparks") as CPUParticles3D).emitting = false
    ZombieProps.burst(game.root3d, pap.global_position + Vector3(0.0, 1.3, 0.0) + pap.global_transform.basis.z * 0.9, Color("#d9b8ff"), 50, 0.9)
    ZombieProps.play(pap, pap.global_position + Vector3(0.0, 1.2, 0.0), "power_up", 3.0, 1.5, 50.0)
    var doors: Array = pap.get_meta("doors")
    get_tree().create_timer(1.0).timeout.connect(func() -> void:
        _slide_doors(doors, false)
        if _pap_token != null and is_instance_valid(_pap_token):
            _pap_token.queue_free())
    game.notify(ZombieGame.tx("%s upgraded! (+25%% damage, double ammo)" % WeaponDefinitions.get_display_name(id, "en"), "%s ارتقا یافت! (+۲۵٪ آسیب، مهمات دو برابر)" % WeaponDefinitions.get_display_name(id, "fa")), Color("#d9b8ff"))
    _refresh()

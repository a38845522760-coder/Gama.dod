extends CanvasLayer
class_name ZombieHUD

## Zombie-mode overlay: points, active perks, mission progress, carried item, boss health bar,
## the 20 s assembly countdown, interaction toasts and the perk "drinking" animation.

var _root: Control
var _points_label: Label
var _points_delta: Label
var _perk_row: HBoxContainer
var _mission_panel: PanelContainer
var _mission_label: Label
var _carry_label: Label
var _boss_panel: Control
var _boss_name: Label
var _boss_fill: ColorRect
var _boss_back: ColorRect
var _countdown: Label
var _toast: Label
var _toast_tween: Tween
var _drink: Control
var _shown_points: float = 0.0
var _target_points: int = 0
var _delta_tween: Tween

func _ready() -> void:
    layer = 6
    name = "ZombieHUD"
    _root = Control.new()
    _root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(_root)
    _build_points()
    _build_mission()
    _build_boss()
    _build_center()

func _label(font_size: int, color: Color, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
    var l := Label.new()
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_color", color)
    l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
    l.add_theme_constant_override("outline_size", 6)
    l.horizontal_alignment = align
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return l

func _build_points() -> void:
    var box := VBoxContainer.new()
    box.mouse_filter = Control.MOUSE_FILTER_IGNORE
    box.anchor_left = 1.0
    box.anchor_right = 1.0
    box.offset_left = -300.0
    box.offset_right = -20.0
    box.offset_top = 108.0
    box.alignment = BoxContainer.ALIGNMENT_BEGIN
    _root.add_child(box)
    _points_label = _label(34, Color("#ffd23d"), HORIZONTAL_ALIGNMENT_RIGHT)
    box.add_child(_points_label)
    _points_delta = _label(20, Color("#9dffb0"), HORIZONTAL_ALIGNMENT_RIGHT)
    _points_delta.modulate.a = 0.0
    box.add_child(_points_delta)
    _perk_row = HBoxContainer.new()
    _perk_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _perk_row.alignment = BoxContainer.ALIGNMENT_END
    _perk_row.add_theme_constant_override("separation", 6)
    box.add_child(_perk_row)

func _build_mission() -> void:
    _mission_panel = PanelContainer.new()
    _mission_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _mission_panel.anchor_top = 0.40
    _mission_panel.anchor_bottom = 0.40
    _mission_panel.offset_left = 14.0
    _mission_panel.offset_right = 360.0
    _mission_panel.add_theme_stylebox_override("panel", UIStyle.box(Color(0.04, 0.07, 0.09, 0.62), Color("#41d9ee"), 12, 1))
    _root.add_child(_mission_panel)
    var col := VBoxContainer.new()
    col.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _mission_panel.add_child(col)
    var title := _label(15, Color("#41d9ee"))
    title.name = "MissionTitle"
    title.text = ZombieGame.tx("MISSIONS", "ماموریت‌ها")
    col.add_child(title)
    _mission_label = _label(17, Color("#e7f0f4"))
    _mission_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _mission_label.custom_minimum_size = Vector2(320.0, 0.0)
    col.add_child(_mission_label)
    _carry_label = _label(18, Color("#ffd23d"))
    _carry_label.visible = false
    col.add_child(_carry_label)

func _build_boss() -> void:
    _boss_panel = Control.new()
    _boss_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _boss_panel.anchor_left = 0.5
    _boss_panel.anchor_right = 0.5
    _boss_panel.offset_left = -260.0
    _boss_panel.offset_right = 260.0
    _boss_panel.offset_top = 112.0
    _boss_panel.offset_bottom = 164.0
    _boss_panel.visible = false
    _root.add_child(_boss_panel)
    _boss_name = _label(22, Color("#ff8a3a"), HORIZONTAL_ALIGNMENT_CENTER)
    _boss_name.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    _boss_panel.add_child(_boss_name)
    _boss_back = ColorRect.new()
    _boss_back.color = Color(0.05, 0.02, 0.02, 0.85)
    _boss_back.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _boss_back.anchor_right = 1.0
    _boss_back.offset_top = 30.0
    _boss_back.offset_bottom = 50.0
    _boss_panel.add_child(_boss_back)
    _boss_fill = ColorRect.new()
    _boss_fill.color = Color("#ff4a1a")
    _boss_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _boss_fill.offset_left = 3.0
    _boss_fill.offset_top = 3.0
    _boss_fill.offset_bottom = 17.0
    _boss_fill.offset_right = 3.0
    _boss_back.add_child(_boss_fill)

func _build_center() -> void:
    _countdown = _label(64, Color("#ffd23d"), HORIZONTAL_ALIGNMENT_CENTER)
    _countdown.anchor_left = 0.5
    _countdown.anchor_right = 0.5
    _countdown.offset_left = -200.0
    _countdown.offset_right = 200.0
    _countdown.offset_top = 170.0
    _countdown.visible = false
    _root.add_child(_countdown)
    _toast = _label(26, Color("#ffffff"), HORIZONTAL_ALIGNMENT_CENTER)
    _toast.anchor_left = 0.5
    _toast.anchor_right = 0.5
    _toast.anchor_top = 0.62
    _toast.anchor_bottom = 0.62
    _toast.offset_left = -360.0
    _toast.offset_right = 360.0
    _toast.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    _toast.modulate.a = 0.0
    _root.add_child(_toast)

func _process(delta: float) -> void:
    if absf(_shown_points - float(_target_points)) > 0.5:
        _shown_points = lerpf(_shown_points, float(_target_points), 1.0 - exp(-12.0 * delta))
    else:
        _shown_points = float(_target_points)
    _points_label.text = "%d  ✦" % roundi(_shown_points)

# ---------------------------------------------------------------- API used by ZombieGame

func set_points(value: int, change: int = 0) -> void:
    _target_points = value
    if change != 0:
        _points_delta.text = ("+%d" % change) if change > 0 else str(change)
        _points_delta.add_theme_color_override("font_color", Color("#9dffb0") if change > 0 else Color("#ff8a7a"))
        if _delta_tween != null:
            _delta_tween.kill()
        _points_delta.modulate.a = 1.0
        _delta_tween = create_tween()
        _delta_tween.tween_interval(0.5)
        _delta_tween.tween_property(_points_delta, "modulate:a", 0.0, 0.8)

func set_perks(ids: Array) -> void:
    for child in _perk_row.get_children():
        child.queue_free()
    for id in ids:
        var chip := PanelContainer.new()
        chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
        chip.add_theme_stylebox_override("panel", UIStyle.box(Color(0.04, 0.05, 0.07, 0.85), PerkDefs.color(str(id)), 10, 2))
        var l := _label(22, PerkDefs.color(str(id)), HORIZONTAL_ALIGNMENT_CENTER)
        l.text = str(PerkDefs.get_def(str(id)).get("icon", "?"))
        l.custom_minimum_size = Vector2(36.0, 30.0)
        chip.add_child(l)
        chip.tooltip_text = PerkDefs.display_name(str(id))
        _perk_row.add_child(chip)
        chip.modulate.a = 0.0
        chip.create_tween().tween_property(chip, "modulate:a", 1.0, 0.4)

func set_missions(lines: Array) -> void:
    _mission_label.text = "\n".join(PackedStringArray(lines))
    _mission_panel.visible = not lines.is_empty()

func set_carry(text: String) -> void:
    _carry_label.visible = not text.is_empty()
    _carry_label.text = text

func show_boss(display_name: String) -> void:
    _boss_name.text = display_name
    _boss_panel.visible = true
    set_boss_health(1.0)

func set_boss_health(fraction: float) -> void:
    var width: float = (_boss_back.size.x if _boss_back.size.x > 10.0 else 520.0) - 6.0
    _boss_fill.offset_right = 3.0 + width * clampf(fraction, 0.0, 1.0)
    _boss_fill.color = Color("#ff4a1a").lerp(Color("#ffd23d"), 1.0 - clampf(fraction, 0.0, 1.0)) if fraction > 0.5 else Color("#ff2a1a")

func hide_boss() -> void:
    _boss_panel.visible = false

func set_countdown(seconds: float, text: String = "") -> void:
    if seconds < 0.0:
        _countdown.visible = false
        return
    _countdown.visible = true
    _countdown.text = "%s%05.2f" % [text, seconds]

func toast(text: String, color: Color = Color.WHITE) -> void:
    _toast.text = text
    _toast.add_theme_color_override("font_color", color)
    if _toast_tween != null:
        _toast_tween.kill()
    _toast.modulate.a = 1.0
    _toast_tween = create_tween()
    _toast_tween.tween_interval(2.4)
    _toast_tween.tween_property(_toast, "modulate:a", 0.0, 0.7)

## Bottle that rises, tilts and empties while the perk is "drunk" (about 1.5 s).
func play_drink(color: Color, perk_name: String) -> void:
    if _drink != null and is_instance_valid(_drink):
        _drink.queue_free()
    _drink = Control.new()
    _drink.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _drink.anchor_left = 0.5
    _drink.anchor_right = 0.5
    _drink.anchor_top = 1.0
    _drink.anchor_bottom = 1.0
    _drink.offset_left = -60.0
    _drink.offset_right = 60.0
    _drink.offset_top = 0.0
    _drink.offset_bottom = 0.0
    _root.add_child(_drink)
    var bottle := Control.new()
    bottle.custom_minimum_size = Vector2(70.0, 160.0)
    bottle.size = Vector2(70.0, 160.0)
    bottle.pivot_offset = Vector2(35.0, 160.0)
    bottle.position = Vector2(25.0, 20.0)
    _drink.add_child(bottle)
    var glass := ColorRect.new()
    glass.color = Color(0.85, 0.95, 1.0, 0.28)
    glass.size = Vector2(54.0, 120.0)
    glass.position = Vector2(8.0, 40.0)
    bottle.add_child(glass)
    var neck := ColorRect.new()
    neck.color = Color(0.85, 0.95, 1.0, 0.28)
    neck.size = Vector2(22.0, 40.0)
    neck.position = Vector2(24.0, 0.0)
    bottle.add_child(neck)
    var liquid := ColorRect.new()
    liquid.color = Color(color.r, color.g, color.b, 0.95)
    liquid.size = Vector2(50.0, 100.0)
    liquid.position = Vector2(10.0, 58.0)
    bottle.add_child(liquid)
    var cap := ColorRect.new()
    cap.color = color.darkened(0.3)
    cap.size = Vector2(26.0, 10.0)
    cap.position = Vector2(22.0, -8.0)
    bottle.add_child(cap)
    var name_label := _label(22, color, HORIZONTAL_ALIGNMENT_CENTER)
    name_label.text = perk_name
    name_label.position = Vector2(-90.0, -30.0)
    name_label.size = Vector2(300.0, 30.0)
    _drink.add_child(name_label)
    var tw: Tween = create_tween()
    # Rise, tilt toward the face, drain, then drop away.
    tw.tween_property(_drink, "offset_top", -260.0, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tw.parallel().tween_property(_drink, "offset_bottom", -260.0, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tw.tween_property(bottle, "rotation", deg_to_rad(-70.0), 0.35)
    tw.tween_property(liquid, "size:y", 0.0, 0.6)
    tw.parallel().tween_property(liquid, "position:y", 158.0, 0.6)
    tw.tween_property(bottle, "rotation", 0.0, 0.2)
    tw.tween_property(_drink, "modulate:a", 0.0, 0.25)
    tw.tween_callback(_drink.queue_free)

extends InteractableBase
class_name ZInteract

## Generic interactable used by every zombie-mode machine. The owner supplies callables, so the
## game logic stays in ZombieGame while this node only handles collision, prompt and the E key.

var text_fn: Callable
var allow_fn: Callable
var use_fn: Callable
var box_size: Vector3 = Vector3(1.4, 2.0, 1.2)
var box_offset: Vector3 = Vector3(0.0, 1.0, 0.0)
var solid: bool = true
var visual: Node3D

func _ready() -> void:
    collision_layer = 3 if solid else 2
    collision_mask = 0
    var shape_node := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = box_size
    shape_node.shape = shape
    shape_node.position = box_offset
    shape_node.name = "InteractShape"
    add_child(shape_node)

func get_interaction_text() -> String:
    if not interaction_enabled:
        return ""
    if text_fn.is_valid():
        return str(text_fn.call())
    return interaction_text

func can_interact(actor: Node) -> bool:
    if not interaction_enabled:
        return false
    if allow_fn.is_valid():
        return bool(allow_fn.call(actor))
    return true

func interact(actor: Node) -> void:
    if not can_interact(actor):
        return
    interacted.emit(actor)
    if use_fn.is_valid():
        use_fn.call(actor)

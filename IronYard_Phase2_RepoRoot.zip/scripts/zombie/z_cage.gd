extends StaticBody3D
class_name ZCage

## The iron cage around the Pack-a-Punch machine. Only a Tesla bolt hurts it: three hits
## short-circuit the circuits and open the way for the hidden tunnel.

signal tesla_hit(count: int)

const REQUIRED_HITS: int = 3

var hits: int = 0
var raised: bool = false
var _hit_cooldown: float = 0.0

func _process(delta: float) -> void:
    _hit_cooldown = maxf(0.0, _hit_cooldown - delta)

func is_broken() -> bool:
    return hits >= REQUIRED_HITS

func receive_tesla(point: Vector3, _source: Node) -> void:
    if hits >= REQUIRED_HITS or raised:
        return
    if _hit_cooldown > 0.0:
        return
    _hit_cooldown = 0.25
    hits += 1
    var wire_mats: Array = get_meta("wire_mats", [])
    for entry in wire_mats:
        var m: StandardMaterial3D = entry
        m.emission_energy_multiplier = 7.0
        var tw: Tween = create_tween()
        tw.tween_property(m, "emission_energy_multiplier", 1.6 + float(hits) * 1.4, 0.45)
    if hits >= REQUIRED_HITS:
        for entry in wire_mats:
            var m2: StandardMaterial3D = entry
            m2.emission = Color("#ff3a2a")
            m2.albedo_color = Color("#ff3a2a")
    ZombieProps.burst(self, point, Color("#8fe8ff"), 28, 0.6)
    ZombieProps.play(self, point, "zap", 2.0, randf_range(0.9, 1.1), 60.0)
    tesla_hit.emit(hits)

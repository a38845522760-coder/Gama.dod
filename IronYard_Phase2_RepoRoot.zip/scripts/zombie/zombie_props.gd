extends RefCounted
class_name ZombieProps

## Procedural models for the zombie-mode machines (perk fountains, charging machines, switches,
## batteries, Tesla assembly machine, iron cage, Pack-a-Punch machine, doors). Everything is
## built from primitives; animated parts are returned in the node's meta so the game can drive them.

static var _cache: Dictionary = {}

static func mat(color: Color, emission: float = 0.0, rough: float = 0.55, metal: float = 0.35, alpha: float = 1.0) -> StandardMaterial3D:
    var key: String = "%s_%.2f_%.2f_%.2f_%.2f" % [color.to_html(), emission, rough, metal, alpha]
    if _cache.has(key):
        return _cache[key]
    var m := StandardMaterial3D.new()
    m.albedo_color = Color(color.r, color.g, color.b, alpha)
    m.roughness = rough
    m.metallic = metal
    if emission > 0.0:
        m.emission_enabled = true
        m.emission = color
        m.emission_energy_multiplier = emission
    if alpha < 0.99:
        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        ProductionMaterials.add_family(m, "bio_glass", 1.2)
    elif emission <= 0.0:
        # Machine bodies get production-library surface textures.
        if metal >= 0.4:
            ProductionMaterials.add_family(m, "brushed_titanium", 0.8)
        elif rough >= 0.7:
            ProductionMaterials.add_family(m, "rubberized_coating", 0.8)
        else:
            ProductionMaterials.add_family(m, "carbon_composite", 0.8)
    _cache[key] = m
    return m

## Emissive materials are NOT cached: machines animate their own copy.
static func glow(color: Color, energy: float = 2.0, alpha: float = 1.0) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = Color(color.r, color.g, color.b, alpha)
    m.emission_enabled = true
    m.emission = color
    m.emission_energy_multiplier = energy
    m.roughness = 0.4
    if alpha < 0.99:
        m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    return m

static func box(parent: Node3D, part_name: String, pos: Vector3, size: Vector3, material: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    instance.name = part_name
    var mesh := BoxMesh.new()
    mesh.size = size
    instance.mesh = mesh
    instance.material_override = material
    instance.position = pos
    instance.rotation = rot
    instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(instance)
    return instance

static func cyl(parent: Node3D, part_name: String, pos: Vector3, radius: float, height: float, material: Material, top_radius: float = -1.0, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    instance.name = part_name
    var mesh := CylinderMesh.new()
    mesh.bottom_radius = radius
    mesh.top_radius = radius if top_radius < 0.0 else top_radius
    mesh.height = height
    mesh.radial_segments = 20
    mesh.rings = 1
    instance.mesh = mesh
    instance.material_override = material
    instance.position = pos
    instance.rotation = rot
    instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(instance)
    return instance

static func sphere(parent: Node3D, part_name: String, pos: Vector3, radius: float, material: Material, squash: Vector3 = Vector3.ONE) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    instance.name = part_name
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 16
    mesh.rings = 8
    instance.mesh = mesh
    instance.material_override = material
    instance.position = pos
    instance.scale = squash
    instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(instance)
    return instance

static func torus(parent: Node3D, part_name: String, pos: Vector3, inner: float, outer: float, material: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    instance.name = part_name
    var mesh := TorusMesh.new()
    mesh.inner_radius = inner
    mesh.outer_radius = outer
    mesh.rings = 24
    mesh.ring_segments = 8
    instance.mesh = mesh
    instance.material_override = material
    instance.position = pos
    instance.rotation = rot
    instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(instance)
    return instance

static func label(parent: Node3D, text: String, pos: Vector3, color: Color, pixel: float = 0.006, font: int = 56) -> Label3D:
    var l := Label3D.new()
    l.text = text
    l.font_size = font
    l.pixel_size = pixel
    l.modulate = color
    l.outline_size = 10
    l.position = pos
    l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    l.no_depth_test = false
    parent.add_child(l)
    return l

static func light(parent: Node3D, color: Color, energy: float, light_range: float, pos: Vector3) -> OmniLight3D:
    var l := OmniLight3D.new()
    l.light_color = color
    l.light_energy = energy
    l.omni_range = light_range
    l.position = pos
    l.shadow_enabled = false
    l.add_to_group("no_shadow")
    parent.add_child(l)
    return l

static func sparks(parent: Node3D, pos: Vector3, color: Color = Color("#8fe8ff"), amount: int = 18) -> CPUParticles3D:
    var p := CPUParticles3D.new()
    p.position = pos
    p.amount = amount
    p.lifetime = 0.5
    p.one_shot = false
    p.emitting = false
    p.explosiveness = 0.2
    p.direction = Vector3.UP
    p.spread = 70.0
    p.initial_velocity_min = 2.0
    p.initial_velocity_max = 5.0
    p.gravity = Vector3(0.0, -9.0, 0.0)
    p.scale_amount_min = 0.03
    p.scale_amount_max = 0.07
    var m := StandardMaterial3D.new()
    m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    m.albedo_color = color
    m.emission_enabled = true
    m.emission = color
    m.emission_energy_multiplier = 3.0
    var q := QuadMesh.new()
    q.size = Vector2(1.0, 1.0)
    m.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    q.material = m
    p.mesh = q
    parent.add_child(p)
    return p

static func burst(parent: Node, world_pos: Vector3, color: Color, amount: int = 24, life: float = 0.7) -> void:
    ## One-shot spark burst placed in the world (self-cleaning).
    var holder := Node3D.new()
    parent.add_child(holder)
    holder.global_position = world_pos
    var p := sparks(holder, Vector3.ZERO, color, amount)
    p.one_shot = true
    p.lifetime = life
    p.explosiveness = 0.95
    p.emitting = true
    var timer := holder.get_tree().create_timer(life + 0.4)
    timer.timeout.connect(func() -> void:
        if is_instance_valid(holder):
            holder.queue_free())

static func play(parent: Node, world_pos: Vector3, kind: String, volume_db: float = 0.0, pitch: float = 1.0, max_distance: float = 40.0) -> void:
    var player := AudioStreamPlayer3D.new()
    player.stream = WeaponAudio.get_stream(kind)
    player.volume_db = volume_db
    player.pitch_scale = pitch
    player.max_distance = max_distance
    player.unit_size = 6.0
    player.bus = "SFX" if AudioServer.get_bus_index("SFX") != -1 else "Master"
    parent.add_child(player)
    player.global_position = world_pos
    player.finished.connect(player.queue_free)
    player.play()

# ---------------------------------------------------------------- perk fountains

static func build_perk(id: String) -> Node3D:
    var color: Color = PerkDefs.color(id)
    var root := Node3D.new()
    root.name = "PerkVisual_" + id
    var steel: StandardMaterial3D = mat(Color("#15181c"), 0.0, 0.45, 0.8)
    var tinted: StandardMaterial3D = mat(color.darkened(0.55), 0.0, 0.5, 0.6)
    var glass: StandardMaterial3D = glow(color, 1.1, 0.55)
    var lamp: StandardMaterial3D = glow(color, 3.0)
    # Shared cabinet: base, body, glass window, dispenser tray.
    box(root, "Base", Vector3(0.0, 0.1, 0.0), Vector3(1.7, 0.2, 1.3), steel)
    box(root, "Body", Vector3(0.0, 1.2, 0.0), Vector3(1.4, 2.0, 1.0), tinted)
    box(root, "Window", Vector3(0.0, 1.45, 0.52), Vector3(1.0, 1.0, 0.06), glass)
    box(root, "Tray", Vector3(0.0, 0.62, 0.62), Vector3(0.9, 0.12, 0.35), steel)
    box(root, "TrayGlow", Vector3(0.0, 0.69, 0.7), Vector3(0.7, 0.03, 0.2), lamp)
    box(root, "Cap", Vector3(0.0, 2.28, 0.0), Vector3(1.5, 0.16, 1.1), steel)
    var anim: Array = []
    match id:
        "speed":
            # Three slanted chevron blades on top and speed streaks along the sides.
            for i in range(3):
                var chev := box(root, "Chevron_%d" % i, Vector3(0.0, 2.55 + float(i) * 0.0, -0.1 + float(i) * 0.22 - 0.2), Vector3(0.9 - float(i) * 0.15, 0.1, 0.12), lamp, Vector3(0.0, 0.0, 0.0))
                chev.rotation = Vector3(deg_to_rad(-35.0), 0.0, 0.0)
                anim.append(chev)
            for sx in [-0.78, 0.78]:
                for i in range(3):
                    box(root, "Streak", Vector3(float(sx), 0.9 + float(i) * 0.5, 0.1), Vector3(0.05, 0.05, 0.9 - float(i) * 0.2), lamp)
        "health":
            # Heart on top (two spheres + a rotated block) and a red cross on the window.
            var heart_mat: StandardMaterial3D = glow(color, 2.6)
            var heart := Node3D.new()
            heart.name = "Heart"
            heart.position = Vector3(0.0, 2.75, 0.0)
            root.add_child(heart)
            sphere(heart, "L", Vector3(-0.17, 0.1, 0.0), 0.22, heart_mat)
            sphere(heart, "R", Vector3(0.17, 0.1, 0.0), 0.22, heart_mat)
            box(heart, "Tip", Vector3(0.0, -0.05, 0.0), Vector3(0.3, 0.3, 0.3), heart_mat, Vector3(0.0, 0.0, deg_to_rad(45.0)))
            anim.append(heart)
            box(root, "CrossV", Vector3(0.0, 1.45, 0.56), Vector3(0.18, 0.7, 0.04), mat(Color.WHITE, 2.0))
            box(root, "CrossH", Vector3(0.0, 1.45, 0.56), Vector3(0.7, 0.18, 0.04), mat(Color.WHITE, 2.0))
        "slot":
            # Three glowing slots chasing each other + three small pillars on top.
            for i in range(3):
                var bar := box(root, "SlotBar_%d" % i, Vector3(-0.3 + float(i) * 0.3, 1.45, 0.56), Vector3(0.18, 0.8, 0.05), glow(color, 2.4))
                anim.append(bar)
                cyl(root, "Pillar_%d" % i, Vector3(-0.4 + float(i) * 0.4, 2.55, 0.0), 0.11, 0.5, lamp)
        "damage":
            # Spiked crown of five cones, fist-shaped block, flickering orange light.
            for i in range(5):
                var spike := cyl(root, "Spike_%d" % i, Vector3(-0.56 + float(i) * 0.28, 2.55, 0.0), 0.12, 0.5, lamp, 0.0)
                anim.append(spike)
            box(root, "Fist", Vector3(0.0, 1.45, 0.56), Vector3(0.55, 0.45, 0.05), glow(color, 2.8))
            box(root, "FistTop", Vector3(0.0, 1.78, 0.56), Vector3(0.55, 0.18, 0.05), glow(color, 2.8))
        "reload":
            # Two counter-rotating rings (a spinning magazine drum) above a blue core.
            var ring_a := torus(root, "RingA", Vector3(0.0, 2.75, 0.0), 0.32, 0.46, lamp, Vector3(deg_to_rad(90.0), 0.0, 0.0))
            var ring_b := torus(root, "RingB", Vector3(0.0, 2.75, 0.0), 0.2, 0.3, glow(color.lightened(0.3), 3.2), Vector3(0.0, 0.0, 0.0))
            anim.append(ring_a)
            anim.append(ring_b)
            for i in range(3):
                box(root, "Bullet_%d" % i, Vector3(-0.3 + float(i) * 0.3, 1.45, 0.56), Vector3(0.1, 0.5, 0.05), glow(color, 2.4))
        "revive":
            # A floating halo above a glowing cross.
            var halo := torus(root, "Halo", Vector3(0.0, 2.85, 0.0), 0.26, 0.34, lamp, Vector3(0.0, 0.0, 0.0))
            anim.append(halo)
            box(root, "CrossV", Vector3(0.0, 1.45, 0.56), Vector3(0.2, 0.8, 0.05), glow(color, 2.8))
            box(root, "CrossH", Vector3(0.0, 1.45, 0.56), Vector3(0.8, 0.2, 0.05), glow(color, 2.8))
    var machine_light: OmniLight3D = light(root, color, 1.6, 9.0, Vector3(0.0, 1.6, 1.4))
    machine_light.name = "MachineLight"
    root.set_meta("anim_parts", anim)
    root.set_meta("light", machine_light)
    root.set_meta("window", box(root, "Pulse", Vector3(0.0, 1.45, 0.50), Vector3(1.04, 1.04, 0.02), glow(color, 0.8, 0.35)))
    return root

## Idle animation loops (tweens bound to the machine, unique per perk).
static func animate_perk(id: String, root: Node3D) -> void:
    var parts: Array = root.get_meta("anim_parts", [])
    var machine_light: OmniLight3D = root.get_meta("light")
    var base_energy: float = machine_light.light_energy
    var pulse: Tween = root.create_tween().set_loops()
    pulse.tween_property(machine_light, "light_energy", base_energy * 1.5, 0.8).set_trans(Tween.TRANS_SINE)
    pulse.tween_property(machine_light, "light_energy", base_energy * 0.8, 0.8).set_trans(Tween.TRANS_SINE)
    match id:
        "speed":
            for i in range(parts.size()):
                var chevron: Node3D = parts[i]
                var base_y: float = chevron.position.y
                var tw: Tween = chevron.create_tween().set_loops()
                tw.tween_interval(0.15 * float(i))
                tw.tween_property(chevron, "position:y", base_y + 0.18, 0.35)
                tw.tween_property(chevron, "position:y", base_y, 0.35)
                tw.tween_interval(0.45 - 0.15 * float(i))
        "health":
            var heart: Node3D = parts[0]
            var beat: Tween = heart.create_tween().set_loops()
            beat.tween_property(heart, "scale", Vector3.ONE * 1.25, 0.14)
            beat.tween_property(heart, "scale", Vector3.ONE, 0.16)
            beat.tween_property(heart, "scale", Vector3.ONE * 1.15, 0.12)
            beat.tween_property(heart, "scale", Vector3.ONE, 0.5)
        "slot":
            for i in range(parts.size()):
                var bar: MeshInstance3D = parts[i]
                var bar_mat: StandardMaterial3D = bar.material_override as StandardMaterial3D
                var tw2: Tween = bar.create_tween().set_loops()
                tw2.tween_interval(0.25 * float(i))
                tw2.tween_property(bar_mat, "emission_energy_multiplier", 4.0, 0.2)
                tw2.tween_property(bar_mat, "emission_energy_multiplier", 0.6, 0.3)
                tw2.tween_interval(0.5 - 0.25 * float(i))
        "damage":
            for i in range(parts.size()):
                var spike: Node3D = parts[i]
                var tw3: Tween = spike.create_tween().set_loops()
                tw3.tween_property(spike, "scale", Vector3(1.0, 1.0 + 0.4 * float((i % 2) + 1) * 0.5, 1.0), 0.12 + 0.03 * float(i))
                tw3.tween_property(spike, "scale", Vector3.ONE, 0.14)
        "reload":
            var ring_a: Node3D = parts[0]
            var ring_b: Node3D = parts[1]
            var spin_a: Tween = ring_a.create_tween().set_loops()
            spin_a.tween_property(ring_a, "rotation:y", TAU, 2.0).from(0.0)
            var spin_b: Tween = ring_b.create_tween().set_loops()
            spin_b.tween_property(ring_b, "rotation:x", -TAU, 1.3).from(0.0)
        "revive":
            var halo: Node3D = parts[0]
            var float_tw: Tween = halo.create_tween().set_loops()
            float_tw.tween_property(halo, "position:y", 3.0, 1.0).set_trans(Tween.TRANS_SINE)
            float_tw.tween_property(halo, "position:y", 2.8, 1.0).set_trans(Tween.TRANS_SINE)
            var rot_tw: Tween = halo.create_tween().set_loops()
            rot_tw.tween_property(halo, "rotation:y", TAU, 3.0).from(0.0)

# ---------------------------------------------------------------- quest machines

static func build_power_switch() -> Node3D:
    var root := Node3D.new()
    root.name = "PowerSwitchVisual"
    var steel: StandardMaterial3D = mat(Color("#1b2024"), 0.0, 0.5, 0.7)
    box(root, "Pad", Vector3(0.0, 0.05, 0.0), Vector3(1.8, 0.1, 1.4), mat(Color("#2b2f33"), 0.0, 0.9, 0.1))
    box(root, "Cabinet", Vector3(0.0, 1.1, 0.0), Vector3(1.2, 2.0, 0.5), steel)
    box(root, "Hood", Vector3(0.0, 2.15, 0.0), Vector3(1.4, 0.12, 0.7), steel)
    var lamp_mat: StandardMaterial3D = glow(Color("#ff3a2a"), 3.0)
    var lamp := sphere(root, "Lamp", Vector3(0.0, 1.9, 0.27), 0.12, lamp_mat)
    var slot := box(root, "Slot", Vector3(0.0, 1.25, 0.26), Vector3(0.18, 0.7, 0.04), mat(Color.BLACK))
    var lever := Node3D.new()
    lever.name = "Lever"
    lever.position = Vector3(0.0, 1.0, 0.3)
    lever.rotation = Vector3(deg_to_rad(40.0), 0.0, 0.0)
    root.add_child(lever)
    box(lever, "Arm", Vector3(0.0, 0.3, 0.0), Vector3(0.07, 0.6, 0.07), mat(Color("#cfd4d8"), 0.0, 0.3, 0.9))
    sphere(lever, "Knob", Vector3(0.0, 0.62, 0.0), 0.1, glow(Color("#ffd23d"), 1.5))
    var spark: CPUParticles3D = sparks(root, Vector3(0.0, 1.0, 0.4))
    var l := light(root, Color("#ff3a2a"), 1.2, 7.0, Vector3(0.0, 2.2, 0.9))
    root.set_meta("lever", lever)
    root.set_meta("lamp_mat", lamp_mat)
    root.set_meta("light", l)
    root.set_meta("sparks", spark)
    root.set_meta("slot", slot)
    lamp.name = "Lamp"
    return root

static func build_charge_machine() -> Node3D:
    var root := Node3D.new()
    root.name = "ChargeMachineVisual"
    var steel: StandardMaterial3D = mat(Color("#161a1e"), 0.0, 0.45, 0.8)
    box(root, "Base", Vector3(0.0, 0.15, 0.0), Vector3(2.4, 0.3, 2.4), steel)
    cyl(root, "Column", Vector3(0.0, 1.6, 0.0), 0.5, 2.6, mat(Color("#252b31"), 0.0, 0.4, 0.8))
    var core_mat: StandardMaterial3D = glow(Color("#4fd8ff"), 0.6)
    var core := sphere(root, "Core", Vector3(0.0, 3.3, 0.0), 0.55, core_mat)
    var ring_a := torus(root, "RingA", Vector3(0.0, 3.3, 0.0), 0.7, 0.8, glow(Color("#4fd8ff"), 1.8), Vector3(deg_to_rad(70.0), 0.0, 0.0))
    var ring_b := torus(root, "RingB", Vector3(0.0, 3.3, 0.0), 0.7, 0.8, glow(Color("#4fd8ff"), 1.8), Vector3(0.0, 0.0, deg_to_rad(70.0)))
    for i in range(4):
        var a: float = float(i) * PI * 0.5
        box(root, "Coil_%d" % i, Vector3(cos(a) * 1.0, 0.9, sin(a) * 1.0), Vector3(0.18, 1.4, 0.18), steel)
        sphere(root, "Cap_%d" % i, Vector3(cos(a) * 1.0, 1.7, sin(a) * 1.0), 0.16, glow(Color("#4fd8ff"), 2.0))
    var gauge_mat: StandardMaterial3D = glow(Color("#3dff7a"), 2.2)
    var gauge := box(root, "Gauge", Vector3(0.0, 1.0, 0.62), Vector3(0.12, 0.05, 0.05), gauge_mat)
    box(root, "GaugeFrame", Vector3(0.0, 1.3, 0.56), Vector3(0.2, 0.9, 0.04), mat(Color.BLACK))
    var l := light(root, Color("#4fd8ff"), 1.0, 10.0, Vector3(0.0, 3.3, 0.0))
    var field := torus(root, "Field", Vector3(0.0, 0.06, 0.0), 5.85, 6.0, glow(Color("#4fd8ff"), 2.0, 0.7))
    field.visible = false
    var field_disc := cyl(root, "FieldDisc", Vector3(0.0, 0.03, 0.0), 6.0, 0.02, glow(Color("#4fd8ff"), 0.5, 0.12))
    field_disc.visible = false
    var label3: Label3D = label(root, "", Vector3(0.0, 4.5, 0.0), Color("#9fe8ff"), 0.008, 56)
    root.set_meta("core_mat", core_mat)
    root.set_meta("rings", [ring_a, ring_b])
    root.set_meta("light", l)
    root.set_meta("field", field)
    root.set_meta("field_disc", field_disc)
    root.set_meta("gauge", gauge)
    root.set_meta("gauge_mat", gauge_mat)
    root.set_meta("label", label3)
    root.set_meta("core", core)
    return root

static func build_battery(color: Color = Color("#4fd8ff")) -> Node3D:
    var root := Node3D.new()
    root.name = "Battery"
    var shell: StandardMaterial3D = mat(Color("#1c2227"), 0.0, 0.35, 0.85)
    cyl(root, "Shell", Vector3(0.0, 0.0, 0.0), 0.16, 0.5, shell)
    cyl(root, "Cap", Vector3(0.0, 0.29, 0.0), 0.07, 0.1, mat(Color("#c9ced2"), 0.0, 0.3, 0.9))
    cyl(root, "Charge", Vector3(0.0, 0.0, 0.0), 0.17, 0.36, glow(color, 2.6, 0.9))
    for i in range(3):
        cyl(root, "Band_%d" % i, Vector3(0.0, -0.18 + float(i) * 0.18, 0.0), 0.175, 0.03, shell)
    return root

static func build_battery_station() -> Node3D:
    var root := Node3D.new()
    root.name = "BatteryStationVisual"
    var steel: StandardMaterial3D = mat(Color("#161a1e"), 0.0, 0.45, 0.8)
    box(root, "Base", Vector3(0.0, 0.15, 0.0), Vector3(4.2, 0.3, 1.6), steel)
    box(root, "Back", Vector3(0.0, 1.6, -0.55), Vector3(4.0, 2.6, 0.3), mat(Color("#20262b"), 0.0, 0.5, 0.7))
    var slots: Array = []
    var slot_mats: Array = []
    for i in range(3):
        var x: float = -1.2 + float(i) * 1.2
        box(root, "SlotFrame_%d" % i, Vector3(x, 1.4, -0.28), Vector3(0.7, 1.2, 0.2), mat(Color("#0c0e10"), 0.0, 0.5, 0.8))
        var s_mat: StandardMaterial3D = glow(Color("#ff3a2a"), 1.8)
        box(root, "SlotLamp_%d" % i, Vector3(x, 2.15, -0.28), Vector3(0.5, 0.1, 0.1), s_mat)
        var anchor := Node3D.new()
        anchor.name = "SlotAnchor_%d" % i
        anchor.position = Vector3(x, 1.4, -0.12)
        root.add_child(anchor)
        slots.append(anchor)
        slot_mats.append(s_mat)
    box(root, "Console", Vector3(0.0, 0.95, 0.55), Vector3(2.0, 0.9, 0.5), steel)
    box(root, "Screen", Vector3(0.0, 1.45, 0.45), Vector3(1.4, 0.5, 0.05), glow(Color("#58ffa8"), 1.5), Vector3(deg_to_rad(-20.0), 0.0, 0.0))
    var l := light(root, Color("#ff5a3a"), 1.4, 9.0, Vector3(0.0, 2.6, 0.8))
    label(root, "BATTERY STATION", Vector3(0.0, 3.3, 0.0), Color("#ffb04a"), 0.007, 56)
    root.set_meta("slots", slots)
    root.set_meta("slot_mats", slot_mats)
    root.set_meta("light", l)
    return root

static func build_tesla_body() -> Node3D:
    var root := Node3D.new()
    root.name = "TeslaBody"
    var metal: StandardMaterial3D = mat(Color("#2a3036"), 0.0, 0.35, 0.9)
    box(root, "Stock", Vector3(0.0, 0.0, 0.18), Vector3(0.16, 0.2, 0.6), metal)
    box(root, "Receiver", Vector3(0.0, 0.05, -0.2), Vector3(0.22, 0.28, 0.7), mat(Color("#1a1f24"), 0.0, 0.4, 0.9))
    box(root, "Grip", Vector3(0.0, -0.22, 0.0), Vector3(0.1, 0.3, 0.14), metal, Vector3(deg_to_rad(15.0), 0.0, 0.0))
    cyl(root, "Barrel", Vector3(0.0, 0.07, -0.78), 0.06, 0.8, metal, -1.0, Vector3(deg_to_rad(90.0), 0.0, 0.0))
    for i in range(3):
        torus(root, "Coil_%d" % i, Vector3(0.0, 0.07, -0.55 - float(i) * 0.22), 0.07, 0.11, glow(Color("#4fd8ff"), 2.4), Vector3(deg_to_rad(90.0), 0.0, 0.0))
    box(root, "Spine", Vector3(0.0, 0.22, -0.2), Vector3(0.05, 0.05, 0.6), glow(Color("#ff7a1a"), 2.0))
    return root

static func build_assembly_machine() -> Node3D:
    var root := Node3D.new()
    root.name = "AssemblyMachineVisual"
    var steel: StandardMaterial3D = mat(Color("#161a1e"), 0.0, 0.45, 0.8)
    var plate: StandardMaterial3D = mat(Color("#262c32"), 0.0, 0.5, 0.7)
    box(root, "Platform", Vector3(0.0, 0.1, 0.0), Vector3(4.0, 0.2, 3.0), plate)
    box(root, "Bed", Vector3(0.0, 0.7, 0.0), Vector3(2.8, 0.7, 1.4), steel)
    box(root, "Gantry_L", Vector3(-1.7, 1.5, 0.0), Vector3(0.25, 2.8, 0.25), steel)
    box(root, "Gantry_R", Vector3(1.7, 1.5, 0.0), Vector3(0.25, 2.8, 0.25), steel)
    box(root, "Gantry_Top", Vector3(0.0, 2.85, 0.0), Vector3(3.6, 0.3, 0.4), steel)
    # Two robotic arms hanging from the gantry; they swing while building.
    var arm_a := Node3D.new()
    arm_a.name = "ArmA"
    arm_a.position = Vector3(-0.8, 2.7, 0.0)
    root.add_child(arm_a)
    box(arm_a, "Upper", Vector3(0.0, -0.5, 0.0), Vector3(0.14, 1.0, 0.14), mat(Color("#c9a227"), 0.0, 0.4, 0.8))
    box(arm_a, "Tool", Vector3(0.0, -1.1, 0.0), Vector3(0.3, 0.2, 0.3), glow(Color("#ff7a1a"), 2.0))
    var arm_b := Node3D.new()
    arm_b.name = "ArmB"
    arm_b.position = Vector3(0.8, 2.7, 0.0)
    root.add_child(arm_b)
    box(arm_b, "Upper", Vector3(0.0, -0.5, 0.0), Vector3(0.14, 1.0, 0.14), mat(Color("#c9a227"), 0.0, 0.4, 0.8))
    box(arm_b, "Tool", Vector3(0.0, -1.1, 0.0), Vector3(0.3, 0.2, 0.3), glow(Color("#4fd8ff"), 2.0))
    var gear_a := cyl(root, "GearA", Vector3(-1.8, 1.4, 0.2), 0.45, 0.1, mat(Color("#6b737a"), 0.0, 0.4, 0.9), -1.0, Vector3(deg_to_rad(90.0), 0.0, 0.0))
    var gear_b := cyl(root, "GearB", Vector3(1.8, 1.4, 0.2), 0.45, 0.1, mat(Color("#6b737a"), 0.0, 0.4, 0.9), -1.0, Vector3(deg_to_rad(90.0), 0.0, 0.0))
    var screen_mat: StandardMaterial3D = glow(Color("#58ffa8"), 1.6)
    box(root, "Screen", Vector3(0.0, 1.35, 1.1), Vector3(1.4, 0.7, 0.06), screen_mat, Vector3(deg_to_rad(-25.0), 0.0, 0.0))
    var timer_label: Label3D = label(root, "", Vector3(0.0, 3.6, 0.0), Color("#ffd23d"), 0.012, 72)
    var anchor := Node3D.new()
    anchor.name = "BodyAnchor"
    anchor.position = Vector3(0.0, 1.2, 0.0)
    root.add_child(anchor)
    var spark_a: CPUParticles3D = sparks(root, Vector3(-0.8, 1.6, 0.0), Color("#ff9a3a"), 22)
    var spark_b: CPUParticles3D = sparks(root, Vector3(0.8, 1.6, 0.0), Color("#8fe8ff"), 22)
    var l := light(root, Color("#ffb04a"), 0.8, 10.0, Vector3(0.0, 2.2, 1.0))
    var l2 := light(root, Color("#4fd8ff"), 0.0, 9.0, Vector3(0.0, 1.5, -1.0))
    label(root, "TESLA ASSEMBLY", Vector3(0.0, 3.1, 0.0), Color("#ffb04a"), 0.007, 56)
    root.set_meta("arms", [arm_a, arm_b])
    root.set_meta("gears", [gear_a, gear_b])
    root.set_meta("screen_mat", screen_mat)
    root.set_meta("timer", timer_label)
    root.set_meta("anchor", anchor)
    root.set_meta("sparks", [spark_a, spark_b])
    root.set_meta("lights", [l, l2])
    return root

static func build_tesla_pedestal() -> Node3D:
    var root := Node3D.new()
    root.name = "TeslaPedestal"
    cyl(root, "Plinth", Vector3(0.0, 0.5, 0.0), 0.55, 1.0, mat(Color("#1b2024"), 0.0, 0.4, 0.8), 0.45)
    cyl(root, "Ring", Vector3(0.0, 1.02, 0.0), 0.5, 0.04, glow(Color("#4fd8ff"), 3.0))
    var gun: Node3D = build_tesla_body()
    gun.name = "TeslaGun"
    gun.position = Vector3(0.0, 1.5, 0.0)
    gun.rotation = Vector3(0.0, deg_to_rad(90.0), 0.0)
    gun.scale = Vector3.ONE * 1.3
    root.add_child(gun)
    root.set_meta("gun", gun)
    var l := light(root, Color("#4fd8ff"), 2.2, 8.0, Vector3(0.0, 2.0, 0.0))
    root.set_meta("light", l)
    return root

# ---------------------------------------------------------------- iron cage and Pack-a-Punch

static func build_cage() -> ZCage:
    var body := ZCage.new()
    body.name = "IronCage"
    body.collision_layer = 1
    body.collision_mask = 0
    var bar_mat: StandardMaterial3D = mat(Color("#0d0f11"), 0.0, 0.35, 0.95)
    var half: float = 3.5
    var height: float = 4.5
    var parts: Array = []
    var wire_mats: Array = []
    # Bars on all four sides (every 0.5 m), top and bottom frames. A single shell collider
    # represents the whole cage, so every Tesla bolt that reaches the cage counts.
    for side in range(4):
        var rot: float = float(side) * PI * 0.5
        var basis := Basis(Vector3.UP, rot)
        for i in range(15):
            var off: float = -half + float(i) * (half * 2.0 / 14.0)
            var pos: Vector3 = basis * Vector3(off, height * 0.5, half)
            box(body, "Bar", pos, Vector3(0.12, height, 0.12), bar_mat)
        for level in [0.0, 1.5, 3.0, 4.4]:
            var rail_pos: Vector3 = basis * Vector3(0.0, level + 0.1, half)
            box(body, "Rail", rail_pos, Vector3(half * 2.0 + 0.2, 0.14, 0.14), bar_mat, Vector3(0.0, rot, 0.0))
        # Electrical circuit strips running along the bars (the cage's weak point).
        var wire_mat: StandardMaterial3D = glow(Color("#4fd8ff"), 1.6)
        wire_mats.append(wire_mat)
        var wire_pos: Vector3 = basis * Vector3(0.0, 2.2, half + 0.1)
        box(body, "Circuit", wire_pos, Vector3(half * 2.0, 0.07, 0.04), wire_mat, Vector3(0.0, rot, 0.0))
        var box_pos: Vector3 = basis * Vector3(half - 0.7, 2.2, half + 0.18)
        var junction := box(body, "Junction", box_pos, Vector3(0.5, 0.5, 0.2), mat(Color("#222a30"), 0.0, 0.5, 0.7), Vector3(0.0, rot, 0.0))
        parts.append(junction)
    var shell := CollisionShape3D.new()
    var shell_box := BoxShape3D.new()
    shell_box.size = Vector3(half * 2.0 + 0.2, height, half * 2.0 + 0.2)
    shell.shape = shell_box
    shell.position = Vector3(0.0, height * 0.5, 0.0)
    body.add_child(shell)
    # Roof grid.
    for i in range(8):
        var off2: float = -half + float(i) * (half * 2.0 / 7.0)
        box(body, "RoofBar", Vector3(off2, height + 0.05, 0.0), Vector3(0.12, 0.12, half * 2.0), bar_mat)
    var l := light(body, Color("#4fd8ff"), 1.2, 9.0, Vector3(0.0, 3.0, 0.0))
    body.set_meta("wire_mats", wire_mats)
    body.set_meta("light", l)
    body.set_meta("junctions", parts)
    return body

static func build_pap() -> Node3D:
    var root := Node3D.new()
    root.name = "PackAPunchVisual"
    var gold: StandardMaterial3D = mat(Color("#c9a227"), 0.0, 0.3, 0.9)
    var dark: StandardMaterial3D = mat(Color("#14171b"), 0.0, 0.4, 0.85)
    var purple: StandardMaterial3D = glow(Color("#b784ff"), 2.4)
    box(root, "Base", Vector3(0.0, 0.2, 0.0), Vector3(2.8, 0.4, 2.0), dark)
    box(root, "Body", Vector3(0.0, 1.5, -0.2), Vector3(2.2, 2.4, 1.4), mat(Color("#1d3a63"), 0.0, 0.35, 0.8))
    box(root, "Crown", Vector3(0.0, 2.85, -0.2), Vector3(2.4, 0.3, 1.6), gold)
    box(root, "Trim_L", Vector3(-1.12, 1.5, 0.52), Vector3(0.1, 2.4, 0.1), gold)
    box(root, "Trim_R", Vector3(1.12, 1.5, 0.52), Vector3(0.1, 2.4, 0.1), gold)
    box(root, "Panel", Vector3(0.0, 1.9, 0.52), Vector3(1.9, 1.2, 0.06), mat(Color("#0c0e12"), 0.0, 0.4, 0.8))
    # Insertion slot with a sliding door (insertion / closing animation).
    box(root, "SlotFrame", Vector3(0.0, 1.25, 0.56), Vector3(1.5, 0.5, 0.1), gold)
    box(root, "SlotGlow", Vector3(0.0, 1.25, 0.5), Vector3(1.3, 0.34, 0.04), purple)
    var door_l := box(root, "DoorL", Vector3(-0.32, 1.25, 0.63), Vector3(0.66, 0.4, 0.05), dark)
    var door_r := box(root, "DoorR", Vector3(0.32, 1.25, 0.63), Vector3(0.66, 0.4, 0.05), dark)
    # Output tray where the upgraded weapon comes back.
    box(root, "Tray", Vector3(0.0, 0.85, 0.75), Vector3(1.4, 0.1, 0.5), gold)
    var tray_anchor := Node3D.new()
    tray_anchor.name = "TrayAnchor"
    tray_anchor.position = Vector3(0.0, 1.0, 0.75)
    root.add_child(tray_anchor)
    var slot_anchor := Node3D.new()
    slot_anchor.name = "SlotAnchor"
    slot_anchor.position = Vector3(0.0, 1.25, 0.9)
    root.add_child(slot_anchor)
    var gear_a := cyl(root, "GearA", Vector3(-1.2, 2.0, 0.0), 0.35, 0.12, gold, -1.0, Vector3(0.0, 0.0, deg_to_rad(90.0)))
    var gear_b := cyl(root, "GearB", Vector3(1.2, 2.0, 0.0), 0.35, 0.12, gold, -1.0, Vector3(0.0, 0.0, deg_to_rad(90.0)))
    var rune_mat: StandardMaterial3D = glow(Color("#b784ff"), 1.0)
    box(root, "Rune", Vector3(0.0, 2.35, 0.55), Vector3(1.4, 0.25, 0.04), rune_mat)
    var timer_label: Label3D = label(root, "PACK-A-PUNCH", Vector3(0.0, 3.5, 0.0), Color("#d9b8ff"), 0.009, 64)
    var progress_label: Label3D = label(root, "", Vector3(0.0, 3.0, 0.7), Color("#ffffff"), 0.007, 48)
    var l := light(root, Color("#b784ff"), 2.0, 11.0, Vector3(0.0, 2.2, 1.2))
    var beam := cyl(root, "Beam", Vector3(0.0, 1.25, 0.9), 0.05, 1.0, glow(Color("#d9b8ff"), 3.0, 0.8))
    beam.visible = false
    var spark: CPUParticles3D = sparks(root, Vector3(0.0, 1.25, 0.8), Color("#d9b8ff"), 30)
    root.set_meta("doors", [door_l, door_r])
    root.set_meta("gears", [gear_a, gear_b])
    root.set_meta("tray_anchor", tray_anchor)
    root.set_meta("slot_anchor", slot_anchor)
    root.set_meta("rune_mat", rune_mat)
    root.set_meta("title", timer_label)
    root.set_meta("progress", progress_label)
    root.set_meta("light", l)
    root.set_meta("beam", beam)
    root.set_meta("sparks", spark)
    return root

static func build_gun_token(color: Color = Color("#c9ced2")) -> Node3D:
    ## Simple gun silhouette shown while the weapon is inside the Pack-a-Punch machine.
    var root := Node3D.new()
    root.name = "GunToken"
    var metal: StandardMaterial3D = mat(Color("#2a3036"), 0.0, 0.35, 0.9)
    box(root, "Body", Vector3(0.0, 0.0, 0.0), Vector3(0.1, 0.16, 0.7), metal)
    box(root, "Barrel", Vector3(0.0, 0.03, -0.6), Vector3(0.05, 0.05, 0.6), metal)
    box(root, "Stock", Vector3(0.0, -0.02, 0.5), Vector3(0.09, 0.2, 0.3), metal)
    box(root, "Grip", Vector3(0.0, -0.18, 0.1), Vector3(0.07, 0.22, 0.1), metal, Vector3(deg_to_rad(15.0), 0.0, 0.0))
    box(root, "Mag", Vector3(0.0, -0.17, -0.15), Vector3(0.07, 0.24, 0.1), glow(color, 1.4))
    return root

static func build_button() -> Node3D:
    var root := Node3D.new()
    root.name = "VaultButtonVisual"
    box(root, "Post", Vector3(0.0, 0.5, 0.0), Vector3(0.5, 1.0, 0.5), mat(Color("#1a1f24"), 0.0, 0.4, 0.8))
    box(root, "Plate", Vector3(0.0, 1.05, 0.0), Vector3(0.7, 0.1, 0.7), mat(Color("#c9a227"), 0.0, 0.35, 0.9))
    var cap_mat: StandardMaterial3D = glow(Color("#ff3a2a"), 2.4)
    var cap := cyl(root, "Cap", Vector3(0.0, 1.2, 0.0), 0.22, 0.18, cap_mat)
    var l := light(root, Color("#ff3a2a"), 1.4, 6.0, Vector3(0.0, 1.6, 0.0))
    label(root, "VAULT RELEASE", Vector3(0.0, 2.0, 0.0), Color("#ffd23d"), 0.006, 48)
    root.set_meta("cap", cap)
    root.set_meta("cap_mat", cap_mat)
    root.set_meta("light", l)
    return root

static func build_door_visual(size: Vector3) -> Node3D:
    ## size = (width along the slab, height, thickness).
    var root := Node3D.new()
    root.name = "DoorVisual"
    box(root, "Slab", Vector3(0.0, size.y * 0.5, 0.0), size, mat(Color("#33393f"), 0.0, 0.55, 0.8))
    var stripes: StandardMaterial3D = mat(Color("#d9a21e"), 0.0, 0.6, 0.1)
    for i in range(4):
        box(root, "Stripe_%d" % i, Vector3(-size.x * 0.375 + float(i) * size.x * 0.25, size.y * 0.5, size.z * 0.52), Vector3(size.x * 0.06, size.y * 0.9, 0.02), stripes, Vector3(0.0, 0.0, deg_to_rad(18.0)))
    var lamp_mat: StandardMaterial3D = glow(Color("#ff3a2a"), 3.0)
    box(root, "Lamp", Vector3(0.0, size.y - 0.35, size.z * 0.55), Vector3(size.x * 0.3, 0.14, 0.04), lamp_mat)
    var l := light(root, Color("#ff3a2a"), 0.9, 6.0, Vector3(0.0, size.y - 0.4, 1.0))
    root.set_meta("lamp_mat", lamp_mat)
    root.set_meta("light", l)
    return root

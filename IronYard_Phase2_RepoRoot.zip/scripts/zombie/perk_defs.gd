extends RefCounted
class_name PerkDefs

## Data for the six perk machines ("power fountains"). Effects are applied by ZombieGame;
## the numbers below are the single place to tune prices and strengths.

const ORDER: Array[String] = ["speed", "health", "slot", "damage", "reload", "revive"]

const DEFS: Dictionary = {
    "speed": {
        "name_en": "Swift Surge", "name_fa": "موج سرعت", "icon": "»", "color": "#3dffb5", "price": 1000,
        "desc_en": "+25% run and walk speed", "desc_fa": "۲۵٪ سرعت بیشتر در راه رفتن و دویدن",
        "multiplier": 1.25,
    },
    "health": {
        "name_en": "Iron Heart", "name_fa": "قلب آهنین", "icon": "♥", "color": "#ff4d5e", "price": 1000,
        "desc_en": "+50 maximum health", "desc_fa": "۵۰ سلامتی بیشتر",
        "bonus": 50.0,
    },
    "slot": {
        "name_en": "Third Hand", "name_fa": "دست سوم", "icon": "③", "color": "#ffd23d", "price": 2000,
        "desc_en": "Carry three weapons", "desc_fa": "حمل سه سلاح",
        "slots": 1,
    },
    "damage": {
        "name_en": "Blood Rage", "name_fa": "خشم خونین", "icon": "✸", "color": "#ff7a1a", "price": 2500,
        "desc_en": "+50% weapon damage", "desc_fa": "۵۰٪ آسیب بیشتر",
        "multiplier": 1.5,
    },
    "reload": {
        "name_en": "Quick Hands", "name_fa": "دست چابک", "icon": "⟳", "color": "#4fb4ff", "price": 1500,
        "desc_en": "Reload takes 45% of the time", "desc_fa": "بارگذاری بسیار سریع‌تر",
        "multiplier": 0.45,
    },
    "revive": {
        "name_en": "Second Wind", "name_fa": "نفس دوباره", "icon": "✚", "color": "#c77dff", "price": 1500,
        "desc_en": "Revive once after death", "desc_fa": "یک بار زنده شدن پس از مرگ",
    },
}

static func get_def(id: String) -> Dictionary:
    return DEFS.get(id, {})

static func display_name(id: String) -> String:
    var def: Dictionary = get_def(id)
    return str(def.get("name_fa" if Loc.language == "fa" else "name_en", id))

static func description(id: String) -> String:
    var def: Dictionary = get_def(id)
    return str(def.get("desc_fa" if Loc.language == "fa" else "desc_en", ""))

static func price(id: String) -> int:
    return int(get_def(id).get("price", 1000))

static func color(id: String) -> Color:
    return Color(str(get_def(id).get("color", "#ffffff")))

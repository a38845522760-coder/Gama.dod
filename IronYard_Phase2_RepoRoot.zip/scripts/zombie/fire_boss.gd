extends Bot
class_name FireBoss

## "Inferno Colossus": the fire boss that guards the Tesla body. Unlike ordinary zombies it
## fights with a set of telegraphed attacks and gets an enraged second phase below 50% health.
##   - Flame breath: a roaring cone of fire, channelled for ~1.8 s.
##   - Fireball volley: three slow, dodgeable fireballs that burst on impact.
##   - Ground slam: red ring telegraph, then a shockwave around the boss.
##   - Charge (shared boss behaviour) and heavy melee.
##   - Rage: faster, shorter cooldowns, a nova of fire and a permanent fire aura.

signal phase_changed(phase: int)

const FLAME_RANGE: float = 12.5
const FLAME_DURATION: float = 1.8
const SLAM_RADIUS: float = 6.5
const SLAM_WINDUP: float = 1.0

var phase: int = 1
var _act: String = ""
var _act_left: float = 0.0
var _act_tick: float = 0.0
var _cd_flame: float = 4.0
var _cd_ball: float = 2.5
var _cd_slam: float = 6.0
var _telegraph: MeshInstance3D
var _glow: OmniLight3D
var _fire: CPUParticles3D
var _ember_audio: AudioStreamPlayer3D
var _intro_left: float = 1.6

func _ready() -> void:
    profile_id = "inferno"
    team = "zombie"
    super()
    always_hunt = true
    _build_fire_visuals()
    _play_voice("roar", 6.0, 0.55)
    ProductionAudio.play_2d(get_tree().root, "boss_reveal_sting", -4.0)

func _build_fire_visuals() -> void:
    var existing := get_node_or_null("FlameGlow") as OmniLight3D
    _glow = existing if existing != null else OmniLight3D.new()
    if existing == null:
        add_child(_glow)
    _glow.light_color = Color("#ff6a1a")
    _glow.light_energy = 3.0
    _glow.omni_range = 14.0
    _glow.position = Vector3(0.0, 2.6, 0.0)
    _glow.shadow_enabled = false
    _glow.add_to_group("no_shadow")
    var flicker: Tween = _glow.create_tween().set_loops()
    flicker.tween_property(_glow, "light_energy", 4.2, 0.18)
    flicker.tween_property(_glow, "light_energy", 2.4, 0.22)
    _fire = CPUParticles3D.new()
    _fire.amount = 42
    _fire.lifetime = 0.9
    _fire.position = Vector3(0.0, 2.2, 0.0)
    _fire.direction = Vector3.UP
    _fire.spread = 35.0
    _fire.initial_velocity_min = 1.0
    _fire.initial_velocity_max = 2.6
    _fire.gravity = Vector3(0.0, 1.5, 0.0)
    _fire.scale_amount_min = 0.15
    _fire.scale_amount_max = 0.4
    _fire.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
    _fire.emission_sphere_radius = 0.9
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.albedo_color = Color(1.0, 0.45, 0.08, 0.75)
    mat.emission_enabled = true
    mat.emission = Color(1.0, 0.35, 0.05)
    mat.emission_energy_multiplier = 3.0
    var quad := QuadMesh.new()
    quad.size = Vector2(1.0, 1.0)
    quad.material = mat
    _fire.mesh = quad
    _fire.emitting = true
    add_child(_fire)
    _telegraph = MeshInstance3D.new()
    var disc := CylinderMesh.new()
    disc.top_radius = SLAM_RADIUS
    disc.bottom_radius = SLAM_RADIUS
    disc.height = 0.04
    _telegraph.mesh = disc
    var tmat := StandardMaterial3D.new()
    tmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    tmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    tmat.albedo_color = Color(1.0, 0.2, 0.05, 0.35)
    _telegraph.material_override = tmat
    _telegraph.top_level = true
    _telegraph.visible = false
    _telegraph.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(_telegraph)
    _ember_audio = AudioStreamPlayer3D.new()
    _ember_audio.max_distance = 70.0
    _ember_audio.unit_size = 10.0
    _ember_audio.bus = "SFX" if AudioServer.get_bus_index("SFX") != -1 else "Master"
    add_child(_ember_audio)

func _play_voice(kind: String, volume_db: float = 3.0, pitch: float = 1.0) -> void:
    if _voice == null:
        return
    var stream: AudioStream = null
    if kind == "roar":
        stream = ProductionAudio.stream("boss_roar_synthetic")
    _voice.stream = stream if stream != null else WeaponAudio.get_stream(kind)
    _voice.pitch_scale = pitch * randf_range(0.95, 1.05)
    _voice.volume_db = volume_db
    _voice.play()

func _play_fx(kind: String, volume_db: float = 0.0, pitch: float = 1.0) -> void:
    _ember_audio.stream = WeaponAudio.get_stream(kind)
    _ember_audio.pitch_scale = pitch
    _ember_audio.volume_db = volume_db
    _ember_audio.play()

# ---------------------------------------------------------------- decisions

func _decide_zombie(delta: float, base_speed: float) -> void:
    if _intro_left > 0.0:
        _intro_left -= delta
        _move_dir = Vector3.ZERO
        _move_speed = 0.0
        return
    if _act != "":
        # Casting: the boss stands still (slam telegraph, fireball cast, flame channel).
        _move_dir = Vector3.ZERO
        _move_speed = 0.0
        return
    super(delta, base_speed * (1.3 if phase == 2 else 1.0))

func _update_zombie_attack(delta: float) -> void:
    if phase == 1 and health <= max_health * 0.5:
        _enter_rage()
    if _intro_left > 0.0:
        return
    var rage: float = 0.6 if phase == 2 else 1.0
    _cd_flame = maxf(0.0, _cd_flame - delta)
    _cd_ball = maxf(0.0, _cd_ball - delta)
    _cd_slam = maxf(0.0, _cd_slam - delta)
    if _target == null or not is_instance_valid(_target) or not CombatUtil.is_alive(_target):
        return
    if _act != "":
        _run_action(delta)
        return
    if _melee_windup >= 0.0:
        super(delta)
        return
    var to_target: Vector3 = _flat(_target.global_position - global_position)
    var distance: float = to_target.length()
    if _cd_slam <= 0.0 and distance < SLAM_RADIUS - 0.5:
        _start_action("slam", SLAM_WINDUP)
        _cd_slam = randf_range(7.0, 10.0) * rage
        return
    if _cd_flame <= 0.0 and distance < FLAME_RANGE - 2.0 and distance > 3.0 and _target_visible:
        _start_action("flame", FLAME_DURATION + 0.5)
        _cd_flame = randf_range(6.0, 9.0) * rage
        return
    if _cd_ball <= 0.0 and distance > 7.0 and distance < 38.0 and _target_visible:
        _start_action("fireball", 1.1)
        _cd_ball = randf_range(4.5, 7.0) * rage
        return
    super(delta)

func _start_action(action: String, duration: float) -> void:
    _act = action
    _act_left = duration
    _act_tick = 0.0
    _model.attack_swing()
    match action:
        "slam":
            _play_voice("roar", 5.0, 0.8)
            _telegraph.visible = true
            _telegraph.global_position = global_position + Vector3(0.0, 0.05, 0.0)
            _telegraph.scale = Vector3(0.15, 1.0, 0.15)
            var tw: Tween = create_tween()
            tw.tween_property(_telegraph, "scale", Vector3.ONE, SLAM_WINDUP).set_trans(Tween.TRANS_QUAD)
            # The boss rears up before slamming.
            var rear: Tween = create_tween()
            rear.tween_property(_model, "position:y", 0.45, SLAM_WINDUP * 0.8)
            rear.tween_property(_model, "position:y", 0.0, 0.12)
        "flame":
            _play_voice("roar", 4.0, 1.1)
            _play_fx("hum", 4.0, 0.6)
        "fireball":
            _play_voice("roar", 2.0, 1.3)

func _run_action(delta: float) -> void:
    _act_left -= delta
    match _act:
        "slam":
            if _act_left <= 0.0:
                _slam()
                _end_action()
        "flame":
            _act_tick -= delta
            if _act_left < FLAME_DURATION and _act_tick <= 0.0:
                _act_tick = 0.1
                _flame_tick()
            if _act_left <= 0.0:
                _ember_audio.stop()
                _end_action()
        "fireball":
            _act_tick -= delta
            if _act_left < 0.6 and _act_tick <= 0.0 and _act_left > -1.0:
                _act_tick = 0.22 if phase == 1 else 0.15
                _throw_fireball()
            if _act_left <= -0.45:
                _end_action()

func _end_action() -> void:
    _act = ""
    _telegraph.visible = false
    _melee_cd = maxf(_melee_cd, 0.6)

func _flame_tick() -> void:
    var muzzle: Vector3 = get_eye_position() + Vector3(0.0, -0.5, 0.0) + (-global_transform.basis.z) * 1.2
    var forward: Vector3 = -global_transform.basis.z
    _spawn_flame(muzzle, muzzle + forward * FLAME_RANGE)
    if _target == null or not is_instance_valid(_target):
        return
    var offset: Vector3 = _target.global_position + Vector3(0.0, 1.0, 0.0) - muzzle
    var flat_distance: float = _flat(offset).length()
    if flat_distance > FLAME_RANGE or absf(offset.y) > 3.0:
        return
    if forward.dot(_flat(offset).normalized()) < cos(deg_to_rad(28.0)):
        return
    var per_tick: float = (3.2 if phase == 1 else 4.4) * BotDefinitions.DIFFICULTY_DAMAGE[difficulty]
    CombatUtil.apply_damage(_target, per_tick, self, {
        "position": _target.global_position + Vector3(0, 1.0, 0), "direction": forward, "normal": -forward, "weapon_id": "flame",
    })

func _throw_fireball() -> void:
    if _target == null or not is_instance_valid(_target):
        return
    var muzzle: Vector3 = get_eye_position() + Vector3(0.0, -0.4, 0.0) + (-global_transform.basis.z) * 1.3
    var aim: Vector3 = _target.global_position + Vector3(0.0, 1.0, 0.0)
    # Lead the target a little, but not perfectly: the fireballs can be dodged.
    aim += Vector3(_target.velocity.x if _target is CharacterBody3D else 0.0, 0.0, _target.velocity.z if _target is CharacterBody3D else 0.0) * 0.35
    var dir: Vector3 = (aim - muzzle).normalized()
    dir = dir.rotated(Vector3.UP, deg_to_rad(randf_range(-7.0, 7.0)))
    var ball := FireBall.new()
    ball.direction = dir
    ball.damage = 16.0 * BotDefinitions.DIFFICULTY_DAMAGE[difficulty]
    ball.shooter = self
    ball.top_level = true
    add_child(ball)
    ball.global_position = muzzle
    _model.attack_swing()
    _play_fx("fire_burst", 0.0, randf_range(0.9, 1.15))

func _slam() -> void:
    _play_fx("thud", 8.0, 0.5)
    _play_voice("roar", 6.0, 0.6)
    ZombieProps.burst(get_parent(), global_position + Vector3(0.0, 0.2, 0.0), Color("#ff6a1a"), 60, 0.9)
    var ring := MeshInstance3D.new()
    var torus := TorusMesh.new()
    torus.inner_radius = SLAM_RADIUS - 0.4
    torus.outer_radius = SLAM_RADIUS
    ring.mesh = torus
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.albedo_color = Color(1.0, 0.5, 0.1, 0.9)
    ring.material_override = mat
    ring.top_level = true
    add_child(ring)
    ring.global_position = global_position + Vector3(0.0, 0.1, 0.0)
    ring.scale = Vector3(0.3, 1.0, 0.3)
    var tw: Tween = create_tween().set_parallel(true)
    tw.tween_property(ring, "scale", Vector3(1.4, 1.0, 1.4), 0.4)
    tw.tween_property(mat, "albedo_color:a", 0.0, 0.4)
    tw.chain().tween_callback(ring.queue_free)
    for node in get_tree().get_nodes_in_group("combatants"):
        if not (node is Node3D) or not CombatUtil.is_hostile(self, node) or not CombatUtil.is_alive(node):
            continue
        var offset: Vector3 = (node as Node3D).global_position - global_position
        if absf(offset.y) > 2.5 or _flat(offset).length() > SLAM_RADIUS:
            continue
        var falloff: float = 1.0 - clampf(_flat(offset).length() / SLAM_RADIUS, 0.0, 1.0) * 0.4
        CombatUtil.apply_damage(node, 34.0 * falloff * BotDefinitions.DIFFICULTY_DAMAGE[difficulty], self, {
            "position": (node as Node3D).global_position + Vector3(0, 1.0, 0), "direction": offset.normalized(),
            "normal": -offset.normalized(), "weapon_id": "slam",
        })
        if node is CharacterBody3D:
            var body := node as CharacterBody3D
            var push: Vector3 = _flat(offset).normalized() * 9.0
            body.velocity += Vector3(push.x, 4.5, push.z)

func _enter_rage() -> void:
    phase = 2
    phase_changed.emit(2)
    _act = ""
    _telegraph.visible = false
    _play_voice("roar", 8.0, 0.5)
    _glow.light_color = Color("#ff2a0a")
    _fire.amount = 90
    _fire.initial_velocity_max = 4.5
    ZombieProps.burst(get_parent(), global_position + Vector3(0.0, 1.0, 0.0), Color("#ff3a0a"), 90, 1.1)
    _intro_left = 1.0
    # Nova: everything close is scorched and thrown back.
    for node in get_tree().get_nodes_in_group("combatants"):
        if not (node is Node3D) or not CombatUtil.is_hostile(self, node) or not CombatUtil.is_alive(node):
            continue
        var offset: Vector3 = (node as Node3D).global_position - global_position
        if _flat(offset).length() < 8.0:
            CombatUtil.apply_damage(node, 20.0 * BotDefinitions.DIFFICULTY_DAMAGE[difficulty], self, {
                "position": (node as Node3D).global_position + Vector3(0, 1.0, 0), "direction": offset.normalized(), "normal": -offset.normalized(), "weapon_id": "nova",
            })
            if node is CharacterBody3D:
                (node as CharacterBody3D).velocity += Vector3(offset.x, 0.0, offset.z).normalized() * 10.0 + Vector3(0.0, 5.0, 0.0)

func _kill(killer: Node, headshot: bool) -> void:
    if not _alive:
        return
    _telegraph.visible = false
    _fire.emitting = false
    _glow.light_energy = 0.0
    _play_voice("roar", 8.0, 0.4)
    ZombieProps.burst(get_parent(), global_position + Vector3(0.0, 1.2, 0.0), Color("#ff7a1a"), 80, 1.2)
    super(killer, headshot)

## Inner class: one slow, dodgeable fireball.
class FireBall extends Node3D:
    var direction: Vector3 = Vector3.FORWARD
    var damage: float = 14.0
    var shooter: Node
    var _speed: float = 17.0
    var _life: float = 4.0

    func _ready() -> void:
        var m := MeshInstance3D.new()
        var sphere := SphereMesh.new()
        sphere.radius = 0.38
        sphere.height = 0.76
        m.mesh = sphere
        var mat := StandardMaterial3D.new()
        mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        mat.albedo_color = Color("#ffb040")
        mat.emission_enabled = true
        mat.emission = Color("#ff6a1a")
        mat.emission_energy_multiplier = 4.0
        m.material_override = mat
        m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(m)
        var l := OmniLight3D.new()
        l.light_color = Color("#ff7a2a")
        l.light_energy = 2.4
        l.omni_range = 7.0
        l.shadow_enabled = false
        l.add_to_group("no_shadow")
        add_child(l)

    func _physics_process(delta: float) -> void:
        _life -= delta
        if _life <= 0.0:
            queue_free()
            return
        var from_point: Vector3 = global_position
        var to_point: Vector3 = from_point + direction * _speed * delta
        var query := PhysicsRayQueryParameters3D.create(from_point, to_point, 1)
        if shooter is CollisionObject3D:
            query.exclude = [(shooter as CollisionObject3D).get_rid()]
        var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
        if not hit.is_empty():
            _explode(hit["position"])
            return
        global_position = to_point
        for node in get_tree().get_nodes_in_group("combatants"):
            if node == shooter or not (node is Node3D) or not CombatUtil.is_hostile(shooter, node) or not CombatUtil.is_alive(node):
                continue
            if ((node as Node3D).global_position + Vector3(0.0, 1.0, 0.0)).distance_to(global_position) < 1.1:
                _explode(global_position)
                return

    func _explode(point: Vector3) -> void:
        ZombieProps.burst(get_parent(), point, Color("#ff7a1a"), 36, 0.7)
        ZombieProps.play(get_parent(), point, "fire_burst", 0.0, randf_range(0.8, 1.0), 40.0)
        for node in get_tree().get_nodes_in_group("combatants"):
            if node == shooter or not (node is Node3D) or not CombatUtil.is_hostile(shooter, node) or not CombatUtil.is_alive(node):
                continue
            var distance: float = ((node as Node3D).global_position + Vector3(0.0, 1.0, 0.0)).distance_to(point)
            if distance < 2.8:
                CombatUtil.apply_damage(node, damage * (1.0 - distance / 3.6), shooter, {
                    "position": point, "direction": Vector3.UP, "normal": Vector3.UP, "weapon_id": "fireball",
                })
        queue_free()

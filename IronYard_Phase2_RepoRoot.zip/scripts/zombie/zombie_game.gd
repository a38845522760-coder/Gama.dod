extends Node
class_name ZombieGame

## Gameplay layer of the zombie map: match points, perk machines, power switches, purchasable
## doors, death / self-revive handling, Tesla ammunition rules and the Tesla quest (ZombieQuest).
## The level geometry comes from ZombieComplex; this node only adds the interactive objects.
## Lives in the group "zombie_game" so ModeManager / SessionHelper can talk to it.

signal points_changed(value: int)
signal perks_changed(perks: Array)

const STARTING_POINTS: int = 500
const SWITCH_COUNT: int = 3
const TESLA_DROP_CHANCE: float = 0.07
const TESLA_WAVE_REWARD: int = 6
const REVIVE_SHIELD_SECONDS: float = 3.0
const CULL_DISTANCE: float = 110.0

var points: int = STARTING_POINTS
var perks: Array[String] = []
var player: CharacterBody3D
var weapon: Node
var health: HealthComponent
var mode: Node
var map: Node3D
var hud: ZombieHUD
var sites: Dictionary = {}
var quest: ZombieQuest
var doors: Dictionary = {}
var switches_on: Array[bool] = [false, false, false]
var root3d: Node3D

var _base_max_health: float = 100.0
var _base_walk: float = 3.0
var _base_sprint: float = 4.2
var _revive_claimed: bool = false
var _cull_left: float = 0.0
var _culled: Array[Node3D] = []
var _switch_visuals: Array[Node3D] = []
var _perk_nodes: Dictionary = {}
var _perk_busy: bool = false
var _rng := RandomNumberGenerator.new()

static func tx(en: String, fa: String) -> String:
    return fa if Loc.language == "fa" else en

func setup(map_node: Node3D, player_node: CharacterBody3D, mode_manager: Node, site_data: Dictionary) -> void:
    map = map_node
    player = player_node
    mode = mode_manager
    sites = site_data
    _rng.randomize()
    add_to_group("zombie_game")
    weapon = player.get_node_or_null("WeaponController")
    health = player.get_node_or_null("HealthComponent") as HealthComponent
    if health != null:
        _base_max_health = health.max_health
    _base_walk = float(player.get("walk_speed"))
    _base_sprint = float(player.get("sprint_speed"))
    root3d = Node3D.new()
    root3d.name = "ZombieGameObjects"
    map.add_child(root3d)
    hud = ZombieHUD.new()
    add_child(hud)
    hud.set_points(points)
    EventBus.target_destroyed.connect(_on_target_destroyed)
    player.connect("died", Callable(self, "_on_player_died"))
    _build_doors()
    _build_perk_machines()
    _build_switches()
    quest = ZombieQuest.new()
    quest.name = "ZombieQuest"
    add_child(quest)
    quest.setup(self)
    refresh_missions()

func _exit_tree() -> void:
    if EventBus.target_destroyed.is_connected(_on_target_destroyed):
        EventBus.target_destroyed.disconnect(_on_target_destroyed)

# ---------------------------------------------------------------- helpers

func make_interact(parent: Node3D, node_name: String, world_pos: Vector3, text_fn: Callable, use_fn: Callable,
        allow_fn: Callable = Callable(), box_size: Vector3 = Vector3(1.6, 2.2, 1.6), box_offset: Vector3 = Vector3(0.0, 1.1, 0.0), solid: bool = false) -> ZInteract:
    var node := ZInteract.new()
    node.name = node_name
    node.text_fn = text_fn
    node.use_fn = use_fn
    node.allow_fn = allow_fn
    node.box_size = box_size
    node.box_offset = box_offset
    node.solid = solid
    parent.add_child(node)
    node.global_position = world_pos
    return node

func register_cullable(node: Node3D) -> void:
    _culled.append(node)

func notify(text: String, color: Color = Color.WHITE) -> void:
    hud.toast(text, color)

func tesla_owned() -> bool:
    return weapon != null and weapon.has_method("has_weapon") and bool(weapon.call("has_weapon", "tesla"))

# ---------------------------------------------------------------- points

func add_points(amount: int) -> void:
    if amount == 0:
        return
    points = maxi(0, points + amount)
    hud.set_points(points, amount)
    points_changed.emit(points)

func spend_points(amount: int) -> bool:
    if points < amount:
        notify(tx("Not enough points (%d needed)" % amount, "امتیاز کافی نیست (%d لازم است)" % amount), Color("#ff8a7a"))
        ZombieProps.play(player, player.global_position, "clank", -8.0, 1.6, 12.0)
        return false
    points -= amount
    hud.set_points(points, -amount)
    points_changed.emit(points)
    return true

func _on_target_destroyed(value: int, _headshot: bool) -> void:
    add_points(value)

# ---------------------------------------------------------------- doors

func _build_doors() -> void:
    for spec in sites["doors"]:
        var id: String = str(spec["id"])
        var door: ZDoor = ZDoor.build(id, spec["pos"], float(spec["width"]), float(spec["height"]), str(spec["along"]))
        root3d.add_child(door)
        door.position = spec["pos"]
        doors[id] = door
        var spec_copy: Dictionary = spec
        var half_span: float = float(spec["width"]) + 1.0
        var along_z: bool = str(spec["along"]) == "z"
        var size := Vector3(2.4, 3.2, half_span) if along_z else Vector3(half_span, 3.2, 2.4)
        var node: ZInteract = make_interact(root3d, "Interact_Door_" + id, spec["pos"],
            func() -> String: return _door_text(spec_copy),
            func(_a: Node) -> void: _try_open_door(spec_copy),
            func(_a: Node) -> bool: return not (doors[id] as ZDoor).is_open,
            size, Vector3(0.0, 1.6, 0.0))
        # The blast door is controlled only by the separate detonation panel; disable its
        # overlapping hitbox so the player cannot get two competing interaction prompts.
        if str(spec["type"]) == "blast":
            node.interaction_enabled = false
        door.opened.connect(func(_id: String) -> void:
            node.interaction_enabled = false
            refresh_missions())

func _door_name(spec: Dictionary) -> String:
    return tx(str(spec["name_en"]), str(spec["name_fa"]))

func _door_text(spec: Dictionary) -> String:
    var door_name: String = _door_name(spec)
    var kind: String = str(spec["type"])
    if kind == "button":
        return tx("%s — sealed: find the vault release button" % door_name, "%s — مهر و موم شده: دکمه آزادسازی خزانه را پیدا کن" % door_name)
    if kind == "blast":
        if quest == null or quest.gas_valve_count() < 3:
            var count: int = quest.gas_valve_count() if quest != null else 0
            return tx("%s — detonation locked (%d/3 gas valves)" % [door_name, count], "%s — انفجار قفل است (%d/۳ شیر گاز)" % [door_name, count])
        return tx("%s — use the detonation panel beside the door" % door_name, "%s — پنل انفجار کنار در را فعال کن" % door_name)
    if kind == "lab_access":
        if quest == null or not quest.basement_activated:
            return tx("%s — locked: activate the basement system first" % door_name, "%s — قفل است؛ ابتدا سامانه زیرزمین را فعال کن" % door_name)
        if str(spec["id"]) == "restricted":
            return tx("Tesla service passage — unlocked", "مسیر ارتباطی تونل تسلا — آزاد شده")
        return tx("Buy %s — %d pts" % [door_name, int(spec["cost"])], "خرید دسترسی %s — %d امتیاز" % [door_name, int(spec["cost"])])
    if kind == "mission" and not power_restored():
        return tx("%s — locked: restore power (%d/%d switches)" % [door_name, switch_count(), SWITCH_COUNT],
            "%s — قفل است: برق را وصل کن (%d/%d کلید)" % [door_name, switch_count(), SWITCH_COUNT])
    return tx("Open %s — %d pts" % [door_name, int(spec["cost"])], "باز کردن %s — %d امتیاز" % [door_name, int(spec["cost"])])

func _try_open_door(spec: Dictionary) -> void:
    var kind: String = str(spec["type"])
    var door: ZDoor = doors[str(spec["id"])]
    if door.is_open:
        return
    if kind == "button":
        notify(tx("The vault is sealed. Look for the release button.", "خزانه بسته است. دکمه آزادسازی را پیدا کن."), Color("#ffd23d"))
        return
    if kind == "blast":
        var valve_count: int = quest.gas_valve_count() if quest != null else 0
        notify(tx("Use the detonation panel after opening all three gas valves (%d/3)." % valve_count, "پس از بازکردن هر سه شیر گاز، پنل انفجار را فعال کن (%d/۳)." % valve_count), Color("#ffd23d"))
        return
    if kind == "lab_access" and (quest == null or not quest.basement_activated):
        notify(tx("Activate the basement console before opening this door.", "پیش از بازکردن این در، کنسول زیرزمین را فعال کن."), Color("#ffd23d"))
        return
    if kind == "lab_access" and str(spec["id"]) == "restricted":
        door.open(root3d)
        notify(tx("Tesla service passage unlocked", "مسیر ارتباطی تونل تسلا آزاد شد"), Color("#9dffb0"))
        return
    if kind == "mission" and not power_restored():
        notify(tx("The door has no power: activate all %d power switches first." % SWITCH_COUNT, "در برق ندارد: اول هر %d کلید برق را فعال کن." % SWITCH_COUNT), Color("#ffd23d"))
        return
    if not spend_points(int(spec["cost"])):
        return
    door.open(root3d)
    notify(tx("%s opened" % _door_name(spec), "%s باز شد" % _door_name(spec)), Color("#9dffb0"))

func open_door_free(id: String) -> void:
    var door: ZDoor = doors.get(id)
    if door != null:
        door.open(root3d)

# ---------------------------------------------------------------- power switches

func switch_count() -> int:
    var count: int = 0
    for on in switches_on:
        if on:
            count += 1
    return count

func power_restored() -> bool:
    return switch_count() >= SWITCH_COUNT

func _build_switches() -> void:
    var index: int = 0
    for pos in sites["switches"]:
        var visual: Node3D = ZombieProps.build_power_switch()
        visual.name = "PowerSwitch_%d" % index
        root3d.add_child(visual)
        visual.global_position = pos
        visual.rotation.y = atan2(-pos.x, -pos.z)
        _switch_visuals.append(visual)
        register_cullable(visual)
        var captured: int = index
        make_interact(visual, "Interact_Switch_%d" % index, pos + Vector3(0.0, 0.0, 0.0),
            func() -> String: return tx("Activate power switch %d/%d" % [captured + 1, SWITCH_COUNT], "فعال‌کردن کلید برق %d/%d" % [captured + 1, SWITCH_COUNT]) if not switches_on[captured] else tx("Power switch active", "کلید برق فعال است"),
            func(_a: Node) -> void: _activate_switch(captured),
            func(_a: Node) -> bool: return not switches_on[captured],
            Vector3(1.6, 2.2, 1.0), Vector3(0.0, 1.1, 0.4), true)
        index += 1

func _activate_switch(index: int) -> void:
    if switches_on[index]:
        return
    switches_on[index] = true
    var visual: Node3D = _switch_visuals[index]
    var lever: Node3D = visual.get_meta("lever")
    var tw: Tween = lever.create_tween()
    tw.tween_property(lever, "rotation:x", deg_to_rad(-40.0), 0.45).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    var lamp: StandardMaterial3D = visual.get_meta("lamp_mat")
    lamp.emission = Color("#3dff7a")
    lamp.albedo_color = Color("#3dff7a")
    var machine_light: OmniLight3D = visual.get_meta("light")
    machine_light.light_color = Color("#3dff7a")
    var sparks: CPUParticles3D = visual.get_meta("sparks")
    sparks.emitting = true
    sparks.get_tree().create_timer(1.2).timeout.connect(func() -> void:
        if is_instance_valid(sparks):
            sparks.emitting = false)
    ZombieProps.play(visual, visual.global_position + Vector3(0.0, 1.2, 0.0), "power_up", 2.0, 1.0, 60.0)
    ZombieProps.play(visual, visual.global_position + Vector3(0.0, 1.2, 0.0), "clank", 0.0, 1.2, 40.0)
    if power_restored():
        notify(tx("Power restored — the sealed doors can now be bought", "برق وصل شد — درهای مهروموم‌شده حالا قابل خرید هستند"), Color("#9dffb0"))
    else:
        notify(tx("Power switch %d/%d active" % [switch_count(), SWITCH_COUNT], "کلید برق %d/%d فعال شد" % [switch_count(), SWITCH_COUNT]), Color("#9dffb0"))
    refresh_missions()

# ---------------------------------------------------------------- perk machines

func _build_perk_machines() -> void:
    var perk_sites: Dictionary = sites["perks"]
    for id in PerkDefs.ORDER:
        var spec: Dictionary = perk_sites[id]
        var visual: Node3D = ZombieProps.build_perk(id)
        root3d.add_child(visual)
        visual.global_position = spec["pos"]
        visual.rotation.y = float(spec["yaw"])
        ZombieProps.animate_perk(id, visual)
        _perk_nodes[id] = visual
        register_cullable(visual)
        var perk_id: String = id
        make_interact(visual, "Interact_Perk_" + id, spec["pos"],
            func() -> String: return _perk_text(perk_id),
            func(_a: Node) -> void: buy_perk(perk_id),
            Callable(), Vector3(1.8, 2.6, 1.5), Vector3(0.0, 1.3, 0.0), true)

func _perk_text(id: String) -> String:
    if perks.has(id):
        return tx("%s — active" % PerkDefs.display_name(id), "%s — فعال است" % PerkDefs.display_name(id))
    return tx("Buy %s — %d pts (%s)" % [PerkDefs.display_name(id), PerkDefs.price(id), PerkDefs.description(id)],
        "خرید %s — %d امتیاز (%s)" % [PerkDefs.display_name(id), PerkDefs.price(id), PerkDefs.description(id)])

func has_perk(id: String) -> bool:
    return perks.has(id)

func buy_perk(id: String) -> bool:
    if perks.has(id):
        notify(tx("You already have %s" % PerkDefs.display_name(id), "%s را از قبل داری" % PerkDefs.display_name(id)), Color("#ffd23d"))
        return false
    if _perk_busy:
        return false
    if player.has_method("is_dead") and bool(player.call("is_dead")):
        return false
    if not spend_points(PerkDefs.price(id)):
        return false
    _perk_busy = true
    var visual: Node3D = _perk_nodes[id]
    var color: Color = PerkDefs.color(id)
    # Machine reacts: the light flares, a burst of sparks and the glass pulses.
    var machine_light: OmniLight3D = visual.get_meta("light")
    var flare: Tween = machine_light.create_tween()
    flare.tween_property(machine_light, "light_energy", 6.0, 0.15)
    flare.tween_property(machine_light, "light_energy", 1.6, 0.9)
    ZombieProps.burst(root3d, visual.global_position + Vector3(0.0, 0.8, 0.0) + visual.global_transform.basis.z * 0.7, color, 26, 0.8)
    ZombieProps.play(visual, visual.global_position + Vector3(0.0, 1.0, 0.0), "power_up", 0.0, 1.0 + 0.1 * float(PerkDefs.ORDER.find(id)), 40.0)
    # Drinking: bottle overlay + the weapon dips.
    hud.play_drink(color, PerkDefs.display_name(id))
    if weapon != null and weapon.has_method("play_dip"):
        weapon.call("play_dip")
    get_tree().create_timer(0.9).timeout.connect(func() -> void:
        ZombieProps.play(player, player.global_position, "drink", 0.0, 1.0, 12.0))
    get_tree().create_timer(1.5).timeout.connect(func() -> void:
        _perk_busy = false
        perks.append(id)
        _apply_perk(id, true)
        hud.set_perks(perks)
        perks_changed.emit(perks)
        notify("%s — %s" % [PerkDefs.display_name(id), PerkDefs.description(id)], color))
    return true

func _apply_perk(id: String, on: bool) -> void:
    var def: Dictionary = PerkDefs.get_def(id)
    match id:
        "speed":
            var factor: float = float(def["multiplier"]) if on else 1.0
            player.set("walk_speed", _base_walk * factor)
            player.set("sprint_speed", _base_sprint * factor)
        "health":
            if health != null:
                if on:
                    health.max_health = _base_max_health + float(def["bonus"])
                    health.restore(float(def["bonus"]))
                else:
                    health.max_health = _base_max_health
                    health.current_health = minf(health.current_health, health.max_health)
                    health.health_changed.emit(health.current_health, health.max_health)
        "slot":
            if weapon != null:
                weapon.call("set_extra_slots", int(def["slots"]) if on else 0)
        "damage":
            if weapon != null:
                weapon.call("set_perk_damage", float(def["multiplier"]) if on else 1.0)
        "reload":
            if weapon != null:
                weapon.call("set_reload_scale", float(def["multiplier"]) if on else 1.0)
        "revive":
            pass  # consumed in claims_death()

func clear_all_perks() -> void:
    var old: Array[String] = perks.duplicate()
    perks.clear()
    for id in old:
        _apply_perk(id, false)
    hud.set_perks(perks)
    perks_changed.emit(perks)

# ---------------------------------------------------------------- death and self-revive

## Called by ModeManager and SessionHelper when the player dies. The first call consumes the
## Second Wind perk; later calls for the same death keep answering true.
func claims_death() -> bool:
    if _revive_claimed:
        return true
    if perks.has("revive"):
        _revive_claimed = true
        perks.erase("revive")
        hud.set_perks(perks)
        perks_changed.emit(perks)
        return true
    return false

func _on_player_died() -> void:
    quest.on_player_died()
    if _revive_claimed:
        return
    if perks.has("revive"):
        return  # a later claims_death() call will handle it
    # Final death of this life: every perk is lost.
    clear_all_perks.call_deferred()

func perform_revive() -> void:
    hud.toast(tx("Second Wind! Getting back up…", "نفس دوباره! در حال برخاستن…"), PerkDefs.color("revive"))
    ZombieProps.play(player, player.global_position, "power_up", 3.0, 0.7, 30.0)
    await get_tree().create_timer(1.6).timeout
    if not is_instance_valid(player):
        return
    var at: Transform3D = player.global_transform
    player.call("respawn", at)
    var previous_scale: float = health.damage_scale if health != null else 1.0
    if health != null:
        health.damage_scale = 0.0
    # A purple shockwave throws the nearby horde back.
    ZombieProps.burst(root3d, player.global_position + Vector3(0.0, 1.0, 0.0), PerkDefs.color("revive"), 60, 0.9)
    for node in get_tree().get_nodes_in_group("bots"):
        if node is Bot and (node as Bot).is_alive() and (node as Bot).is_zombie:
            var offset: Vector3 = (node as Bot).global_position - player.global_position
            if offset.length() < 9.0:
                (node as Bot).velocity += Vector3(offset.x, 0.0, offset.z).normalized() * 12.0 + Vector3(0.0, 4.0, 0.0)
    _revive_claimed = false
    await get_tree().create_timer(REVIVE_SHIELD_SECONDS).timeout
    if health != null:
        health.damage_scale = previous_scale

# ---------------------------------------------------------------- wave hooks and Tesla ammo

func on_wave_started(_wave: int) -> void:
    refresh_missions()

func on_wave_cleared(wave: int) -> void:
    if wave % 5 == 0 and tesla_owned():
        var added: int = int(weapon.call("add_tesla_ammo", TESLA_WAVE_REWARD))
        if added > 0:
            notify(tx("Wave bonus: +%d Tesla charges" % added, "پاداش موج: +%d شارژ تسلا" % added), Color("#4fd8ff"))

func wants_tesla_drop(bot: Node) -> bool:
    if not tesla_owned():
        return false
    var total: int = int(weapon.call("tesla_total"))
    var capacity: int = int(weapon.call("tesla_capacity"))
    if total >= capacity:
        return false
    var chance: float = TESLA_DROP_CHANCE
    var profile_id: String = str(bot.get("profile_id"))
    if profile_id == "brute" or profile_id == "spitter":
        chance = 0.22
    elif profile_id == "pyro" or profile_id == "tyrant":
        chance = 0.8
    elif profile_id == "inferno":
        return false
    return _rng.randf() < chance

# ---------------------------------------------------------------- missions HUD

func refresh_missions() -> void:
    if quest == null:
        return
    var lines: Array = []
    if not power_restored():
        lines.append(tx("⚡ Power switches: %d/%d" % [switch_count(), SWITCH_COUNT], "⚡ کلیدهای برق: %d/%d" % [switch_count(), SWITCH_COUNT]))
    else:
        lines.append(tx("⚡ Power restored ✓", "⚡ برق وصل است ✓"))
    lines.append_array(quest.mission_lines())
    hud.set_missions(lines)

func _process(delta: float) -> void:
    _cull_left -= delta
    if _cull_left > 0.0 or not is_instance_valid(player):
        return
    _cull_left = 0.5
    for node in _culled:
        if is_instance_valid(node):
            node.visible = node.global_position.distance_to(player.global_position) < CULL_DISTANCE

extends StaticBody3D
class_name ZDoor

## A physical door. It blocks the player and zombies (collision layer 1) until it is opened; a
## separate ZInteract node (added by ZombieGame) provides the prompt.

signal opened(door_id: String)

var door_id: String = ""
var is_open: bool = false
var size: Vector3 = Vector3(4.0, 3.8, 0.5)
var along: String = "z"  # axis the slab's WIDTH runs along ("x" or "z")
var visual: Node3D
var _opening: bool = false

func _ready() -> void:
    collision_layer = 1
    collision_mask = 0
    var shape_node := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    # Width runs along local X; the door is rotated for "z" doors by the caller (see build()).
    shape.size = size
    shape_node.shape = shape
    shape_node.position = Vector3(0.0, size.y * 0.5, 0.0)
    shape_node.name = "DoorShape"
    add_child(shape_node)
    visual = ZombieProps.build_door_visual(size)
    add_child(visual)

## Doorway centre at floor level. `slab_axis` is the world axis the slab's width runs along.
static func build(id: String, world_pos: Vector3, width: float, height: float, slab_axis: String) -> ZDoor:
    var door := ZDoor.new()
    door.door_id = id
    door.along = slab_axis
    door.size = Vector3(width, height, 0.5)
    door.name = "Door_" + id
    door.position = world_pos
    # "along z" means the slab spans the z axis, so rotate it a quarter turn.
    door.rotation.y = deg_to_rad(90.0) if slab_axis == "z" else 0.0
    return door

func open(sound_parent: Node = null) -> void:
    if is_open or _opening:
        return
    _opening = true
    var lamp: StandardMaterial3D = visual.get_meta("lamp_mat", null)
    if lamp != null:
        lamp.emission = Color("#3dff7a")
        lamp.albedo_color = Color("#3dff7a")
    var machine_light: OmniLight3D = visual.get_meta("light", null)
    if machine_light != null:
        machine_light.light_color = Color("#3dff7a")
    ZombieProps.play(sound_parent if sound_parent != null else self, global_position + Vector3(0.0, 1.5, 0.0), "clank", 3.0, 0.7, 45.0)
    # The slab lifts straight up into the lintel, shaking a little first.
    var tw: Tween = create_tween()
    tw.tween_property(visual, "position:x", 0.06, 0.05)
    tw.tween_property(visual, "position:x", -0.06, 0.05)
    tw.tween_property(visual, "position:x", 0.0, 0.05)
    tw.tween_property(visual, "position:y", size.y + 0.1, 1.1).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
    tw.tween_callback(func() -> void:
        is_open = true
        _opening = false
        collision_layer = 0
        var shape_node := get_node_or_null("DoorShape") as CollisionShape3D
        if shape_node != null:
            shape_node.disabled = true
        visual.visible = false
        opened.emit(door_id))
    ZombieProps.burst(get_parent(), global_position + Vector3(0.0, size.y, 0.0), Color("#d9a21e"), 18, 0.8)

extends RefCounted
class_name ZombieComplex

## The "Research Institute" of Dead City: a two-storey laboratory on the surface plus an
## underground complex (lower lab, tunnels to the plaza and to the open outskirts, the Tesla
## room, the sealed Pack-a-Punch vault, a service control room and a hidden deep tunnel).
## This class only builds the STATIC level geometry (it is baked into the bot navigation
## mesh); doors, machines and quest objects are added by ZombieGame from `sites`.

const FLOOR_Y: float = -9.0
const CEIL_Y: float = -4.5
const DEEP_Y: float = -13.5
const SLAB: float = 0.6
const STEP_RISE: float = 0.25
const WALL_T: float = 0.6

## Surface openings (x, z, width, depth). The ground slab is cut here.
var surface_holes: Array[Rect2] = [
    Rect2(68.0, 52.0, 5.0, 18.5),    # Institute stairwell down to the lower lab
    Rect2(-4.5, 38.5, 18.5, 3.0),    # plaza tunnel stairs
    Rect2(98.5, -48.5, 3.0, 18.5),   # outskirts tunnel stairs
]
## Holes in the first underground floor slab.
var floor_holes: Array[Rect2] = [
    Rect2(102.5, 42.7, 9.0, 3.6),    # hidden stairs under the assembly machine
    Rect2(123.0, 58.2, 4.0, 9.0),    # stairs up into the control room
]
var sites: Dictionary = {}
## Light positions: {pos, color, energy, flicker}
var lights: Array[Dictionary] = []
var keepouts: Array[Rect2] = []

var _kit: MapKit
var _layout: RefCounted

func _init() -> void:
    for hole in surface_holes:
        keepouts.append(hole.grow(3.0))
    keepouts.append(Rect2(31.0, 48.0, 48.0, 34.0))  # Institute footprint + margin
    keepouts.append(Rect2(-8.0, 36.0, 24.0, 8.0))

func build(layout: RefCounted, kit: MapKit) -> void:
    _layout = layout
    _kit = kit
    _kit.add_plain("lab_floor", Color("#9aa7ad"), 0.55, 0.1)
    _kit.add_plain("lab_wall", Color("#b9c4c4"), 0.9, 0.02)
    _kit.add_plain("tunnel", Color("#6d6a62"), 0.95, 0.03)
    _kit.add_plain("hazard", Color("#d9a21e"), 0.6, 0.1)
    _kit.add_emissive("screen_green", Color("#58ffa8"), 1.6)
    _kit.add_emissive("screen_blue", Color("#58b8ff"), 1.8)
    _kit.add_emissive("lamp_white", Color("#fff3d6"), 2.4)
    _build_institute()
    _build_lower_lab()
    _build_tunnels()
    _build_tesla_room()
    _build_vault()
    _build_control_room()
    _build_deep_tunnel()
    _build_surface_markers()
    _define_sites()

# ---------------------------------------------------------------- generic helpers

func _cut(rect: Rect2, hole: Rect2) -> Array[Rect2]:
    var out: Array[Rect2] = []
    var cross: Rect2 = rect.intersection(hole)
    if cross.size.x <= 0.001 or cross.size.y <= 0.001:
        out.append(rect)
        return out
    var rect_end_x: float = rect.position.x + rect.size.x
    var rect_end_z: float = rect.position.y + rect.size.y
    var cross_end_x: float = cross.position.x + cross.size.x
    var cross_end_z: float = cross.position.y + cross.size.y
    if cross.position.x > rect.position.x:
        out.append(Rect2(rect.position.x, rect.position.y, cross.position.x - rect.position.x, rect.size.y))
    if cross_end_x < rect_end_x:
        out.append(Rect2(cross_end_x, rect.position.y, rect_end_x - cross_end_x, rect.size.y))
    if cross.position.y > rect.position.y:
        out.append(Rect2(cross.position.x, rect.position.y, cross.size.x, cross.position.y - rect.position.y))
    if cross_end_z < rect_end_z:
        out.append(Rect2(cross.position.x, cross_end_z, cross.size.x, rect_end_z - cross_end_z))
    return out

func cut_rects(rect: Rect2, holes: Array) -> Array[Rect2]:
    var pieces: Array[Rect2] = [rect]
    for hole in holes:
        var next: Array[Rect2] = []
        for piece in pieces:
            next.append_array(_cut(piece, hole as Rect2))
        pieces = next
    return pieces

## A horizontal slab whose TOP surface is at y_top.
func _slab(prefix: String, rect: Rect2, y_top: float, thick: float, mat: String, holes: Array = []) -> void:
    var index: int = 0
    for piece in cut_rects(rect, holes):
        if piece.size.x < 0.05 or piece.size.y < 0.05:
            continue
        _kit.solid_box("%s_%d" % [prefix, index], Vector3(piece.position.x + piece.size.x * 0.5, y_top - thick * 0.5, piece.position.y + piece.size.y * 0.5),
            Vector3(piece.size.x, thick, piece.size.y), mat, Vector3.ZERO, &"concrete")
        index += 1

func _gap_list(gaps: Array, center: float) -> Array:
    var result: Array = []
    for gap in gaps:
        var entry: Dictionary = (gap as Dictionary).duplicate()
        entry["at"] = float(entry["at"]) - center
        result.append(entry)
    return result

## Four walls of a room between floor_y and top_y. gaps: {"N": [{at, width, bottom, top}], ...}
## where `at` is an absolute world coordinate along the wall.
func _walls(prefix: String, x0: float, x1: float, z0: float, z1: float, floor_y: float, height: float, mat: String, gaps: Dictionary = {}) -> void:
    var cx: float = (x0 + x1) * 0.5
    var cz: float = (z0 + z1) * 0.5
    var layout: ZombieLayout = _layout as ZombieLayout
    layout._wall(prefix + "_N", Vector3(cx, floor_y, z0), x1 - x0 + WALL_T, height, WALL_T, true, mat, _gap_list(gaps.get("N", []), cx))
    layout._wall(prefix + "_S", Vector3(cx, floor_y, z1), x1 - x0 + WALL_T, height, WALL_T, true, mat, _gap_list(gaps.get("S", []), cx))
    layout._wall(prefix + "_W", Vector3(x0, floor_y, cz), z1 - z0 - WALL_T, height, WALL_T, false, mat, _gap_list(gaps.get("W", []), cz))
    layout._wall(prefix + "_E", Vector3(x1, floor_y, cz), z1 - z0 - WALL_T, height, WALL_T, false, mat, _gap_list(gaps.get("E", []), cz))

func _door_gap(at: float, width: float, top: float = 3.8) -> Dictionary:
    return {"at": at, "width": width, "bottom": 0.0, "top": top}

## An underground room: floor slab, walls and a ceiling slab.
func _room(prefix: String, x0: float, x1: float, z0: float, z1: float, floor_y: float, ceil_y: float, gaps: Dictionary = {}, floor_cuts: Array = [], ceil_cuts: Array = [], mat: String = "tunnel", floor_mat: String = "lab_floor") -> void:
    var rect := Rect2(x0 - WALL_T * 0.5, z0 - WALL_T * 0.5, x1 - x0 + WALL_T, z1 - z0 + WALL_T)
    _slab(prefix + "_Floor", rect, floor_y, SLAB, floor_mat, floor_cuts)
    _slab(prefix + "_Ceil", rect, ceil_y + SLAB, SLAB, "dark_steel", ceil_cuts)
    _walls(prefix, x0, x1, z0, z1, floor_y, ceil_y - floor_y, mat, gaps)

## A tunnel segment running along an axis (floor, ceiling, two side walls).
func _tunnel(prefix: String, x0: float, x1: float, z0: float, z1: float, floor_y: float, ceil_y: float, floor_cuts: Array = [], ceil_cuts: Array = [], along: String = "") -> void:
    var rect := Rect2(x0, z0, x1 - x0, z1 - z0)
    _slab(prefix + "_Floor", rect, floor_y, SLAB, "tunnel", floor_cuts)
    _slab(prefix + "_Ceil", rect, ceil_y + SLAB, SLAB, "dark_steel", ceil_cuts)
    var height: float = ceil_y - floor_y
    var runs_x: bool = (x1 - x0) >= (z1 - z0) if along.is_empty() else along == "x"
    if runs_x:
        _kit.solid_box(prefix + "_WN", Vector3((x0 + x1) * 0.5, floor_y + height * 0.5, z0 - WALL_T * 0.5), Vector3(x1 - x0, height, WALL_T), "tunnel")
        _kit.solid_box(prefix + "_WS", Vector3((x0 + x1) * 0.5, floor_y + height * 0.5, z1 + WALL_T * 0.5), Vector3(x1 - x0, height, WALL_T), "tunnel")
    else:
        _kit.solid_box(prefix + "_WW", Vector3(x0 - WALL_T * 0.5, floor_y + height * 0.5, (z0 + z1) * 0.5), Vector3(WALL_T, height, z1 - z0), "tunnel")
        _kit.solid_box(prefix + "_WE", Vector3(x1 + WALL_T * 0.5, floor_y + height * 0.5, (z0 + z1) * 0.5), Vector3(WALL_T, height, z1 - z0), "tunnel")

## Straight stairs. `start` is the bottom step's origin (y = lower floor); they rise along `dir`
## and side walls enclose the shaft up to `wall_top`.
func _stairs(prefix: String, start: Vector3, dir: Vector3, steps: int, width: float, wall_top: float, rise: float = STEP_RISE, run: float = 0.5) -> void:
    _kit.stairs(prefix, start, dir, steps, rise, run, width, "steel")
    var length: float = run * float(steps)
    var side := Vector3(-dir.z, 0.0, dir.x).normalized()
    var mid: Vector3 = start + dir * (length * 0.5)
    var height: float = wall_top - start.y
    var yaw: float = atan2(-dir.x, -dir.z)
    for sign in [-1.0, 1.0]:
        var pos: Vector3 = mid + side * (width * 0.5 + 0.3) * float(sign) + Vector3(0.0, height * 0.5, 0.0)
        _kit.solid_box("%s_Side%d" % [prefix, int(sign)], pos, Vector3(0.6, height, length), "tunnel", Vector3(0.0, yaw, 0.0))

func _light(pos: Vector3, color: Color, energy: float, flicker: bool = false) -> void:
    lights.append({"pos": pos, "color": color, "energy": energy, "flicker": flicker})

func _bench(prefix: String, pos: Vector3, size: Vector3) -> void:
    _kit.solid_box(prefix, pos + Vector3(0.0, size.y * 0.5, 0.0), size, "steel", Vector3.ZERO, &"metal")
    _kit.decor_box(prefix + "_Top", pos + Vector3(0.0, size.y + 0.02, 0.0), Vector3(size.x * 0.98, 0.04, size.z * 0.98), "lab_wall")

func _screen(pos: Vector3, yaw: float, mat: String = "screen_green") -> void:
    _kit.decor_box("Screen", pos, Vector3(0.9, 0.55, 0.05), mat, Vector3(0.0, yaw, 0.0))

# ---------------------------------------------------------------- the surface institute

func _build_institute() -> void:
    var x0: float = 33.0
    var x1: float = 77.0
    var z0: float = 50.0
    var z1: float = 80.0
    var window := {"width": 1.8, "bottom": 1.2, "top": 3.4}
    var north: Array = []
    var south: Array = []
    var east: Array = []
    for wx in [40.0, 48.0, 56.0, 64.0]:
        var w: Dictionary = window.duplicate()
        w["at"] = wx
        north.append(w)
        var w2: Dictionary = window.duplicate()
        w2["at"] = wx + 2.0
        south.append(w2)
    for wz in [56.0, 64.0, 72.0]:
        var w3: Dictionary = window.duplicate()
        w3["at"] = wz
        east.append(w3)
    # West wall faces the plaza: the physical gate (points door) lives in the 4.4 m opening.
    var west: Array = [{"at": 65.0, "width": 4.4, "bottom": 0.0, "top": 4.2}]
    for wz in [55.0, 75.0]:
        var w4: Dictionary = window.duplicate()
        w4["at"] = wz
        west.append(w4)
    _walls("Institute_Ground", x0, x1, z0, z1, 0.0, 5.0, "lab_wall", {"N": north, "S": south, "E": east, "W": west})
    # Upper storey: slab with a hole over the stairs, walls with big windows, roof.
    var upper_holes: Array = [Rect2(34.0, 50.4, 4.4, 10.8)]
    _slab("Institute_Upper", Rect2(x0 - 0.3, z0 - 0.3, x1 - x0 + 0.6, z1 - z0 + 0.6), 5.4, 0.4, "lab_floor", upper_holes)
    var up_n: Array = []
    var up_s: Array = []
    for wx in [38.0, 46.0, 54.0, 62.0, 70.0]:
        up_n.append({"at": wx, "width": 3.0, "bottom": 1.0, "top": 3.4})
        up_s.append({"at": wx, "width": 3.0, "bottom": 1.0, "top": 3.4})
    var up_w: Array = []
    var up_e: Array = []
    for wz in [58.0, 66.0, 74.0]:
        up_w.append({"at": wz, "width": 3.0, "bottom": 1.0, "top": 3.4})
        up_e.append({"at": wz, "width": 3.0, "bottom": 1.0, "top": 3.4})
    _walls("Institute_Upper", x0, x1, z0, z1, 5.4, 4.2, "lab_wall", {"N": up_n, "S": up_s, "E": up_e, "W": up_w})
    _kit.solid_box("Institute_Roof", Vector3((x0 + x1) * 0.5, 9.85, (z0 + z1) * 0.5), Vector3(x1 - x0 + 1.2, 0.5, z1 - z0 + 1.2), "roof", Vector3.ZERO, &"metal")
    # Stairs to the upper floor along the west wall (steps rise toward +z).
    _kit.stairs("Institute_Stairs", Vector3(36.0, 0.0, 51.0), Vector3(0.0, 0.0, 1.0), 20, 0.25, 0.5, 3.4, "steel")
    # Ground-floor lab: benches, screens, and a glowing reactor core.
    for row in range(3):
        for column in range(4):
            var bench_pos := Vector3(44.0 + float(column) * 7.0, 0.0, 56.0 + float(row) * 8.0)
            if row == 1 and column == 3:
                continue
            _bench("Institute_Bench_%d_%d" % [row, column], bench_pos, Vector3(4.0, 0.95, 1.4))
            _screen(bench_pos + Vector3(0.0, 1.35, 0.55), 0.0, "screen_green" if (row + column) % 2 == 0 else "screen_blue")
    _kit.cylinder("Institute_Core", Vector3(62.0, 2.2, 72.0), 1.4, 4.4, "dark_steel", true)
    _kit.cylinder("Institute_CoreGlow", Vector3(62.0, 2.2, 72.0), 1.0, 4.5, "tesla_blue", false)
    # Upper floor: server racks and the research office.
    for index in range(6):
        _kit.solid_box("Institute_Rack_%d" % index, Vector3(44.0 + float(index) * 5.5, 6.9, 53.5), Vector3(1.6, 3.0, 0.8), "dark_steel", Vector3.ZERO, &"metal")
        _kit.decor_box("Institute_RackLight_%d" % index, Vector3(44.0 + float(index) * 5.5, 7.6, 53.05), Vector3(1.2, 0.15, 0.05), "screen_green")
    for index in range(4):
        _bench("Institute_Desk_%d" % index, Vector3(46.0 + float(index) * 7.0, 5.4, 70.0), Vector3(3.0, 0.9, 1.3))
    for pos in [Vector3(44.0, 4.2, 58.0), Vector3(56.0, 4.2, 58.0), Vector3(66.0, 4.2, 66.0), Vector3(44.0, 4.2, 72.0), Vector3(40.0, 8.6, 60.0), Vector3(55.0, 8.6, 64.0), Vector3(70.0, 8.6, 72.0)]:
        _light(pos, Color("#bfe8ff"), 1.6, false)
    _light(Vector3(62.0, 2.5, 72.0), Color("#4fd8ff"), 2.0, false)
    _light(Vector3(36.0, 2.5, 56.0), Color("#ffe9b0"), 1.4, true)
    _layout.stats["buildings"] = int(_layout.stats["buildings"]) + 1

# ---------------------------------------------------------------- underground

func _build_lower_lab() -> void:
    # Lower lab: x 35..75, z 28..52. Openings: stairs shaft (south), plaza tunnel (west), Tesla tunnel (east).
    var gaps := {
        "S": [_door_gap(70.5, 4.2)],
        "W": [_door_gap(40.0, 3.2)],
        "E": [_door_gap(40.0, 4.0)],
    }
    _room("LowerLab", 35.0, 75.0, 28.0, 52.0, FLOOR_Y, CEIL_Y, gaps, [], [], "lab_wall")
    # Stairs up to the Institute (start at the south wall, rise toward +z).
    _stairs("LabStairs", Vector3(70.5, FLOOR_Y, 52.3), Vector3(0.0, 0.0, 1.0), 36, 4.0, 0.0)
    for index in range(5):
        _bench("LowerLab_Bench_%d" % index, Vector3(40.0 + float(index) * 6.0, FLOOR_Y, 34.0), Vector3(3.6, 0.95, 1.4))
        _screen(Vector3(40.0 + float(index) * 6.0, FLOOR_Y + 1.4, 33.6), 0.0, "screen_blue")
    for index in range(3):
        _kit.cylinder("LowerLab_Tank_%d" % index, Vector3(47.0 + float(index) * 8.0, FLOOR_Y + 1.6, 47.0), 1.1, 3.2, "steel", true)
        _kit.cylinder("LowerLab_TankGlow_%d" % index, Vector3(47.0 + float(index) * 8.0, FLOOR_Y + 1.6, 47.0), 0.8, 3.3, "toxic", false)
    for x in [41.0, 55.0, 69.0]:
        for z in [32.0, 46.0]:
            _light(Vector3(x, CEIL_Y - 0.6, z), Color("#9dffd0"), 1.5, x == 55.0 and z == 32.0)
    _light(Vector3(48.0, FLOOR_Y + 2.0, 47.0), Color("#3dff7a"), 1.2, false)

func _build_tunnels() -> void:
    # T2: plaza tunnel (x 14..35, floor -9) with stairs rising west to the plaza (x 14 -> -2.5).
    _tunnel("PlazaTunnel", 14.0, 35.0, 38.5, 41.5, FLOOR_Y, CEIL_Y)
    _stairs("PlazaStairs", Vector3(14.0, FLOOR_Y, 40.0), Vector3(-1.0, 0.0, 0.0), 36, 3.0, 0.0)
    for x in [20.0, 28.0]:
        _light(Vector3(x, CEIL_Y - 0.5, 40.0), Color("#ffb04a"), 1.3, x == 28.0)
    # T1: tunnel to the Tesla room (x 75..88).
    _tunnel("TeslaTunnel", 75.3, 87.7, 38.0, 42.0, FLOOR_Y, CEIL_Y)
    for x in [79.0, 84.0]:
        _light(Vector3(x, CEIL_Y - 0.5, 40.0), Color("#ff4a3a"), 1.2, false)
    # T3: tunnel from the Tesla room north to the open outskirts (x 98..102, z 30 .. -30) + stairs.
    _tunnel("OutskirtsTunnel", 98.0, 102.0, -30.0, 29.7, FLOOR_Y, CEIL_Y)
    _stairs("OutskirtsStairs", Vector3(100.0, FLOOR_Y, -30.0), Vector3(0.0, 0.0, -1.0), 36, 3.0, 0.0)
    for z in [20.0, 8.0, -4.0, -16.0]:
        _light(Vector3(100.0, CEIL_Y - 0.5, z), Color("#9dffb0") if z > 0.0 else Color("#ffb04a"), 1.3, z == 8.0)

func _build_tesla_room() -> void:
    # Tesla room x 88..116, z 30..51.5. North gap = outskirts tunnel, west gap = tesla tunnel.
    var gaps := {
        "N": [_door_gap(100.0, 4.0)],
        "W": [_door_gap(40.0, 4.0)],
        "S": [{"at": 102.0, "width": 16.0, "bottom": 0.0, "top": 4.5}],
    }
    _room("TeslaRoom", 88.0, 116.0, 30.0, 51.5, FLOOR_Y, CEIL_Y, gaps, floor_holes.slice(0, 1), [], "lab_wall", "lab_floor")
    # Barred window into the sealed vault, centred on the south wall: a ray can pass between bars.
    # (The wall itself is built by the vault room below; the bars stand inside the wall opening.)
    for x in [94.0, 98.0, 102.0, 106.0, 110.0]:
        _light(Vector3(x, CEIL_Y - 0.6, 36.0), Color("#4fd8ff"), 1.7, x == 102.0)
    for x in [94.0, 110.0]:
        _light(Vector3(x, CEIL_Y - 0.6, 46.0), Color("#a58bff"), 1.3, false)
    # Hazard stripes marking the hatch path.
    _kit.decor_box("HatchStripe", Vector3(107.0, FLOOR_Y + 0.03, 44.5), Vector3(9.0, 0.02, 3.2), "hazard")
    # Wall decorations: capacitors and coils.
    for index in range(4):
        var pos := Vector3(90.0, FLOOR_Y, 33.0 + float(index) * 4.2)
        _kit.cylinder("TeslaRoom_Coil_%d" % index, pos + Vector3(0.0, 1.6, 0.0), 0.35, 3.2, "dark_steel", true)
        _kit.cylinder("TeslaRoom_CoilRing_%d" % index, pos + Vector3(0.0, 3.2, 0.0), 0.7, 0.2, "tesla_blue", false)

func _build_vault() -> void:
    # Pack-a-Punch vault x 88..116, z 52.5..76, sealed except the door toward the control room.
    var gaps := {
        "E": [_door_gap(64.0, 4.0)],
        "N": [{"at": 102.0, "width": 16.0, "bottom": 0.0, "top": 4.5}],
    }
    _room("Vault", 88.0, 116.0, 52.5, 76.0, FLOOR_Y, CEIL_Y, gaps, [], [Rect2(98.2, 60.2, 7.6, 7.6)], "tunnel", "lab_floor")
    # Shared wall to the Tesla room: a solid wall with a barred window.
    var wall_y0: float = FLOOR_Y
    var height: float = CEIL_Y - FLOOR_Y
    var window_x0: float = 94.0
    var window_x1: float = 110.0
    var sill: float = 1.0
    var top: float = 3.4
    var wall_z: float = 52.0
    _kit.solid_box("VaultWall_L", Vector3((88.0 + window_x0) * 0.5, wall_y0 + height * 0.5, wall_z), Vector3(window_x0 - 88.0 + WALL_T, height, 1.0), "tunnel")
    _kit.solid_box("VaultWall_R", Vector3((window_x1 + 116.0) * 0.5, wall_y0 + height * 0.5, wall_z), Vector3(116.0 - window_x1 + WALL_T, height, 1.0), "tunnel")
    _kit.solid_box("VaultWall_Sill", Vector3((window_x0 + window_x1) * 0.5, wall_y0 + sill * 0.5, wall_z), Vector3(window_x1 - window_x0, sill, 1.0), "tunnel")
    _kit.solid_box("VaultWall_Lintel", Vector3((window_x0 + window_x1) * 0.5, wall_y0 + top + (height - top) * 0.5, wall_z), Vector3(window_x1 - window_x0, height - top, 1.0), "tunnel")
    var bar_x: float = window_x0 + 0.25
    while bar_x < window_x1:
        _kit.solid_box("WindowBar", Vector3(bar_x, wall_y0 + (sill + top) * 0.5, wall_z), Vector3(0.07, top - sill, 0.07), "black", Vector3.ZERO, &"metal")
        bar_x += 0.5
    # Recess above the cage so it can retract into the ceiling.
    var recess: Rect2 = Rect2(98.2, 60.2, 7.6, 7.6)
    var recess_h: float = 3.6
    for side in [[Vector3(recess.position.x + recess.size.x * 0.5, CEIL_Y + 0.3 + recess_h * 0.5, recess.position.y), Vector3(recess.size.x, recess_h, 0.3)],
            [Vector3(recess.position.x + recess.size.x * 0.5, CEIL_Y + 0.3 + recess_h * 0.5, recess.position.y + recess.size.y), Vector3(recess.size.x, recess_h, 0.3)],
            [Vector3(recess.position.x, CEIL_Y + 0.3 + recess_h * 0.5, recess.position.y + recess.size.y * 0.5), Vector3(0.3, recess_h, recess.size.y)],
            [Vector3(recess.position.x + recess.size.x, CEIL_Y + 0.3 + recess_h * 0.5, recess.position.y + recess.size.y * 0.5), Vector3(0.3, recess_h, recess.size.y)]]:
        _kit.solid_box("CageRecess", side[0], side[1], "dark_steel")
    _kit.solid_box("CageRecessTop", Vector3(recess.position.x + recess.size.x * 0.5, CEIL_Y + 0.3 + recess_h + 0.15, recess.position.y + recess.size.y * 0.5), Vector3(recess.size.x + 0.6, 0.3, recess.size.y + 0.6), "dark_steel")
    for pos in [Vector3(94.0, CEIL_Y - 0.6, 58.0), Vector3(110.0, CEIL_Y - 0.6, 58.0), Vector3(94.0, CEIL_Y - 0.6, 72.0), Vector3(110.0, CEIL_Y - 0.6, 72.0)]:
        _light(pos, Color("#ffd23d"), 1.5, false)
    _light(Vector3(102.0, FLOOR_Y + 3.0, 64.0), Color("#c9a0ff"), 2.4, false)

func _build_control_room() -> void:
    # Control room x 120..130, z 58..74, linked to the vault by a short passage (x 116..120).
    var gaps := {
        "W": [_door_gap(64.0, 4.0)],
    }
    _room("ControlRoom", 120.0, 130.0, 58.0, 74.0, FLOOR_Y, CEIL_Y, gaps, [floor_holes[1]], [], "lab_wall")
    _tunnel("VaultPassage", 116.3, 119.7, 62.0, 66.0, FLOOR_Y, CEIL_Y, [], [], "x")
    _stairs("ControlStairs", Vector3(125.0, DEEP_Y, 58.2), Vector3(0.0, 0.0, 1.0), 18, 4.0, FLOOR_Y, 0.25, 0.5)
    _bench("Control_Desk", Vector3(125.0, FLOOR_Y, 72.2), Vector3(5.0, 0.95, 1.3))
    for x in [122.0, 128.0]:
        _light(Vector3(x, CEIL_Y - 0.6, 66.0), Color("#ff4a3a"), 1.4, x == 128.0)
    _light(Vector3(117.8, CEIL_Y - 0.6, 64.0), Color("#ffd23d"), 1.2, false)

func _build_deep_tunnel() -> void:
    # Hidden tunnel (floor -13.5): stairs down from the Tesla room (under the assembly machine),
    # a corridor east, then south to the stairs that rise into the control room.
    var ceil_deep: float = FLOOR_Y - SLAB
    # The hatch stairs start at the bottom (x = 111.5) and rise toward the WEST up to the Tesla room floor.
    _stairs("HatchStairs", Vector3(111.5, DEEP_Y, 44.5), Vector3(-1.0, 0.0, 0.0), 18, 3.6, FLOOR_Y, 0.25, 0.5)
    _tunnel("DeepA", 111.5, 123.0, 42.5, 46.5, DEEP_Y, ceil_deep)
    # DeepB: the corner (x 123..127, z 42.5..46.5) plus the leg south to the control-room stairs.
    var deep_h: float = ceil_deep - DEEP_Y
    var deep_rect := Rect2(123.0, 42.5, 4.0, 58.2 - 42.5)
    _slab("DeepB_Floor", deep_rect, DEEP_Y, SLAB, "tunnel")
    _slab("DeepB_Ceil", deep_rect, ceil_deep + SLAB, SLAB, "dark_steel")
    _kit.solid_box("DeepB_WE", Vector3(127.3, DEEP_Y + deep_h * 0.5, 50.35), Vector3(WALL_T, deep_h, 15.7 + WALL_T), "tunnel")
    _kit.solid_box("DeepB_WW", Vector3(122.7, DEEP_Y + deep_h * 0.5, (46.5 + 58.2) * 0.5), Vector3(WALL_T, deep_h, 58.2 - 46.5), "tunnel")
    _kit.solid_box("DeepB_Cap", Vector3(125.0, DEEP_Y + deep_h * 0.5, 42.2), Vector3(4.6, deep_h, WALL_T), "tunnel")
    for pos in [Vector3(116.0, ceil_deep - 0.5, 44.5), Vector3(125.0, ceil_deep - 0.5, 44.5), Vector3(125.0, ceil_deep - 0.5, 53.0), Vector3(108.0, FLOOR_Y - 2.5, 44.5)]:
        _light(pos, Color("#ff7a3a"), 1.4, pos.x == 125.0 and pos.z == 53.0)

func _build_surface_markers() -> void:
    # Railings, warning stripes and signs around the three surface openings.
    for hole in surface_holes:
        var cx: float = hole.position.x + hole.size.x * 0.5
        var cz: float = hole.position.y + hole.size.y * 0.5
        # Hazard frame around the opening (never a lid over it).
        var rect: Rect2 = hole.grow(0.5)
        _kit.decor_box("HoleStripeN", Vector3(cx, 0.06, rect.position.y + 0.1), Vector3(rect.size.x, 0.02, 0.2), "hazard")
        _kit.decor_box("HoleStripeS", Vector3(cx, 0.06, rect.position.y + rect.size.y - 0.1), Vector3(rect.size.x, 0.02, 0.2), "hazard")
        _kit.decor_box("HoleStripeW", Vector3(rect.position.x + 0.1, 0.06, cz), Vector3(0.2, 0.02, rect.size.y), "hazard")
        _kit.decor_box("HoleStripeE", Vector3(rect.position.x + rect.size.x - 0.1, 0.06, cz), Vector3(0.2, 0.02, rect.size.y), "hazard")
    _light(Vector3(5.0, 3.0, 40.0), Color("#ffb04a"), 1.6, true)
    _light(Vector3(100.0, 3.0, -40.0), Color("#9dffb0"), 1.6, true)

# ---------------------------------------------------------------- sites for gameplay objects

func _define_sites() -> void:
    sites = {
        # Doors: pos = centre of the doorway at floor level; "along" = axis the door SLAB width runs.
        "doors": [
            {"id": "gate", "name_en": "Institute Gate", "name_fa": "دروازه مؤسسه", "pos": Vector3(33.0, 0.0, 65.0), "width": 4.4, "height": 4.2, "along": "z", "type": "points", "cost": 750},
            {"id": "maintenance", "name_en": "Maintenance Door", "name_fa": "درِ تعمیرات", "pos": Vector3(30.0, FLOOR_Y, 40.0), "width": 3.0, "height": 3.8, "along": "z", "type": "points", "cost": 500},
            {"id": "restricted", "name_en": "Restricted Lab Door", "name_fa": "درِ ممنوعه آزمایشگاه", "pos": Vector3(81.0, FLOOR_Y, 40.0), "width": 4.0, "height": 3.8, "along": "z", "type": "mission", "mission": "switches", "cost": 1250},
            {"id": "hatch", "name_en": "Service Hatch Door", "name_fa": "درِ دریچه سرویس", "pos": Vector3(100.0, FLOOR_Y, -24.0), "width": 4.0, "height": 3.8, "along": "x", "type": "mission", "mission": "switches", "cost": 500},
            {"id": "vault", "name_en": "Vault Door", "name_fa": "درِ خزانه", "pos": Vector3(116.0, FLOOR_Y, 64.0), "width": 4.0, "height": 3.8, "along": "z", "type": "button"},
        ],
        "perks": {
            "speed": {"pos": Vector3(-8.0, 0.0, 12.0), "yaw": deg_to_rad(150.0)},
            "health": {"pos": Vector3(-135.0, 0.0, -100.0), "yaw": 0.0},
            "slot": {"pos": Vector3(-125.0, 0.0, 106.0), "yaw": PI},
            "damage": {"pos": Vector3(125.0, 0.0, 106.0), "yaw": PI},
            "reload": {"pos": Vector3(70.0, FLOOR_Y + 14.4, 57.0), "yaw": 0.0},
            "revive": {"pos": Vector3(38.0, FLOOR_Y, 49.0), "yaw": PI},
        },
        "charge_machines": [Vector3(-62.0, 0.0, -62.0), Vector3(62.0, 0.0, -62.0), Vector3(-62.0, 0.0, 62.0)],
        "switches": [Vector3(-100.0, 0.0, 6.0), Vector3(6.0, 0.0, -100.0), Vector3(100.0, 0.0, 6.0)],
        "battery_station": Vector3(94.0, FLOOR_Y, 36.0),
        "assembly": Vector3(105.5, FLOOR_Y, 44.5),
        "hatch": Rect2(102.5, 42.7, 9.0, 3.6),
        "cage": Vector3(102.0, FLOOR_Y, 64.0),
        "pap": Vector3(102.0, FLOOR_Y, 64.0),
        "button": Vector3(125.0, FLOOR_Y, 71.0),
        "supply": [Vector3(60.0, FLOOR_Y, 50.0), Vector3(104.0, FLOOR_Y, 33.0)],
        "tesla_room_center": Vector3(102.0, FLOOR_Y, 40.0),
        "vault_window_y": FLOOR_Y + 2.0,
    }
    # Keep random scenery (wrecks, rubble, trees) away from everything placed on the surface.
    for key in ["perks"]:
        for id in (sites[key] as Dictionary).keys():
            var p: Vector3 = (sites[key] as Dictionary)[id]["pos"]
            if p.y >= -0.5 and p.y < 1.0:
                keepouts.append(Rect2(p.x - 3.5, p.z - 3.5, 7.0, 7.0))
    for p in sites["charge_machines"]:
        keepouts.append(Rect2(p.x - 5.0, p.z - 5.0, 10.0, 10.0))
    for p in sites["switches"]:
        keepouts.append(Rect2(p.x - 3.5, p.z - 3.5, 7.0, 7.0))

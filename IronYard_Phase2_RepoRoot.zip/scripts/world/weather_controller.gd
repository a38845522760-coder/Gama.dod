extends Node3D
class_name WeatherController

## Dynamic weather system supporting Clear, Fog, and Rain/Storm presets.

@export_enum("clear", "fog", "rain") var weather_preset: String = "fog"

var _world_env: WorldEnvironment
var _sun_light: DirectionalLight3D
var _rain_particles: CPUParticles3D
var _player: Node3D
var _lightning_timer: float = 8.0

func setup(world_env: WorldEnvironment, sun_light: DirectionalLight3D) -> void:
	_world_env = world_env
	_sun_light = sun_light
	_create_rain_particles()
	var saved_weather := str(SettingsManager.get_setting("weather_preset", weather_preset))
	apply_weather(saved_weather)

func apply_weather(preset: String) -> void:
	weather_preset = preset
	if _world_env == null or _world_env.environment == null:
		return
	var env := _world_env.environment
	match preset:
		"clear":
			env.fog_enabled = true
			env.fog_density = 0.0025
			env.fog_light_color = Color(0.62, 0.74, 0.86)
			if _sun_light != null:
				_sun_light.light_energy = 1.45
				_sun_light.light_color = Color(1.0, 0.95, 0.86)
			if _rain_particles != null:
				_rain_particles.emitting = false
				_rain_particles.visible = false
		"fog":
			env.fog_enabled = true
			env.fog_density = 0.014
			env.fog_light_color = Color(0.42, 0.52, 0.58)
			if _sun_light != null:
				_sun_light.light_energy = 0.95
				_sun_light.light_color = Color(0.84, 0.90, 0.95)
			if _rain_particles != null:
				_rain_particles.emitting = false
				_rain_particles.visible = false
		"rain":
			env.fog_enabled = true
			env.fog_density = 0.018
			env.fog_light_color = Color(0.24, 0.31, 0.38)
			if _sun_light != null:
				_sun_light.light_energy = 0.65
				_sun_light.light_color = Color(0.72, 0.82, 0.94)
			if _rain_particles != null:
				_rain_particles.visible = true
				_rain_particles.emitting = true

func _create_rain_particles() -> void:
	_rain_particles = CPUParticles3D.new()
	_rain_particles.name = "WeatherRainParticles"
	_rain_particles.amount = 180
	_rain_particles.lifetime = 0.65
	_rain_particles.preprocess = 0.5
	_rain_particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	_rain_particles.emission_box_extents = Vector3(14.0, 1.0, 14.0)
	_rain_particles.direction = Vector3(0.08, -1.0, 0.04)
	_rain_particles.spread = 3.0
	_rain_particles.gravity = Vector3(0.0, -24.0, 0.0)
	_rain_particles.initial_velocity_min = 16.0
	_rain_particles.initial_velocity_max = 22.0
	var streak := BoxMesh.new()
	streak.size = Vector3(0.016, 0.65, 0.016)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.72, 0.86, 0.98, 0.45)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	streak.material = mat
	_rain_particles.mesh = streak
	add_child(_rain_particles)

func _process(delta: float) -> void:
	if not is_instance_valid(_player):
		var players := get_tree().get_nodes_in_group("player_controller")
		if not players.is_empty():
			_player = players[0] as Node3D
	if is_instance_valid(_player) and _rain_particles != null:
		_rain_particles.global_position = _player.global_position + Vector3(0.0, 11.0, 0.0)

	if weather_preset == "rain" and _sun_light != null:
		_lightning_timer -= delta
		if _lightning_timer <= 0.0:
			_lightning_timer = randf_range(7.0, 15.0)
			_sun_light.light_energy = 2.4
		else:
			_sun_light.light_energy = lerpf(_sun_light.light_energy, 0.65, delta * 8.0)

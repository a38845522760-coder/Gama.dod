extends MapBuilderBase

func _ready() -> void:
	_init_world_systems("map_fortress", Color(0.18, 0.16, 0.24), Color(0.55, 0.44, 0.36), Vector3(-34.0, 48.0, 0.0))
	_build_terrain_and_courtyard()
	_build_outer_fortress_walls()
	_build_central_keep_zone()
	_build_gatehouse_zone()
	_build_bastion_towers_zone()
	_finalize_world([
		Vector3(0, 0.2, 54),
		Vector3(0, 0.2, 22),
		Vector3(-38, 0.2, 0),
		Vector3(38, 0.2, 0),
		Vector3(-34, 0.2, -38),
		Vector3(34, 0.2, -38),
	])

func _build_terrain_and_courtyard() -> void:
	var base := Node3D.new()
	base.name = "CourtyardTerrain"
	add_child(base)
	_add_static_box(base, "Ground", Vector3(0, -0.25, 0), Vector3(160, 0.5, 160), _materials["dirt"], "concrete")
	_add_static_box(base, "StoneCourtyard", Vector3(0, 0.03, 0), Vector3(106, 0.06, 106), _materials["stone"], "concrete")
	_add_static_box(base, "Causeway", Vector3(0, 0.05, 48), Vector3(10, 0.10, 56), _materials["stone_dark"], "concrete")

	# Courtyard pillars & foliage
	for sx in [-16.0, 16.0]:
		for sz in [14.0, 28.0]:
			_add_static_cylinder(base, "CourtyardPillar", Vector3(sx, 2.5, sz), 0.75, 5.0, _materials["stone_dark"], "concrete")
			_add_visual_box(base, "Torch", Vector3(sx, 5.2, sz), Vector3(0.45, 0.45, 0.45), _materials["glow_amber"])
	for p in [Vector3(-64, 0, -64), Vector3(64, 0, -64), Vector3(-64, 0, 64), Vector3(64, 0, 64), Vector3(-24, 0, 22), Vector3(24, 0, 22)]:
		_add_shrub(base, p, 1.5)

func _build_outer_fortress_walls() -> void:
	var walls := Node3D.new()
	walls.name = "OuterFortressWalls"
	add_child(walls)
	# Walkable 6m tall curtain walls with battlements
	_add_static_box(walls, "FortWallN", Vector3(0, 3.0, -56), Vector3(112, 6.0, 3.2), _materials["stone"], "concrete")
	_add_static_box(walls, "FortWallW", Vector3(-56, 3.0, 0), Vector3(3.2, 6.0, 112), _materials["stone"], "concrete")
	_add_static_box(walls, "FortWallE", Vector3(56, 3.0, 0), Vector3(3.2, 6.0, 112), _materials["stone"], "concrete")
	_add_static_box(walls, "FortWallSL", Vector3(-32, 3.0, 56), Vector3(48, 6.0, 3.2), _materials["stone"], "concrete")
	_add_static_box(walls, "FortWallSR", Vector3(32, 3.0, 56), Vector3(48, 6.0, 3.2), _materials["stone"], "concrete")

	# Crenellations along North wall
	for i in range(-12, 13):
		_add_static_box(walls, "MerlonN_%d" % i, Vector3(float(i) * 4.2, 6.6, -57.2), Vector3(2.0, 1.2, 0.8), _materials["stone_dark"], "concrete")

	# Outer boundary safety walls
	_add_static_box(walls, "BoundN", Vector3(0, 2.0, -79), Vector3(160, 4.0, 1.2), _materials["stone_dark"], "concrete")
	_add_static_box(walls, "BoundS", Vector3(0, 2.0, 79), Vector3(160, 4.0, 1.2), _materials["stone_dark"], "concrete")
	_add_static_box(walls, "BoundW", Vector3(-79, 2.0, 0), Vector3(1.2, 4.0, 160), _materials["stone_dark"], "concrete")
	_add_static_box(walls, "BoundE", Vector3(79, 2.0, 0), Vector3(1.2, 4.0, 160), _materials["stone_dark"], "concrete")

func _build_central_keep_zone() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_CentralKeep"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)
	var c := Vector3(0, 0, -24)

	# Grand Citadel Keep (28x24, 14m tall) with arched doorway & walkable roof
	_add_static_box(zone, "KeepRoof", c + Vector3(0, 12.0, 0), Vector3(28, 0.8, 24), _materials["stone_dark"], "concrete")
	_add_static_box(zone, "KeepN", c + Vector3(0, 6.0, -11.5), Vector3(28, 12.0, 1.4), _materials["stone"], "concrete")
	_add_static_box(zone, "KeepW", c + Vector3(-13.3, 6.0, 0), Vector3(1.4, 12.0, 24), _materials["stone"], "concrete")
	_add_static_box(zone, "KeepE", c + Vector3(13.3, 6.0, 0), Vector3(1.4, 12.0, 24), _materials["stone"], "concrete")
	_add_static_box(zone, "KeepSL", c + Vector3(-8.5, 6.0, 11.5), Vector3(11, 12.0, 1.4), _materials["stone"], "concrete")
	_add_static_box(zone, "KeepSR", c + Vector3(8.5, 6.0, 11.5), Vector3(11, 12.0, 1.4), _materials["stone"], "concrete")
	_add_static_box(zone, "KeepArch", c + Vector3(0, 9.0, 11.5), Vector3(6.2, 6.0, 1.4), _materials["stone_dark"], "concrete")

	# Climbable stone ramp up to Keep roof
	_add_static_box(zone, "KeepRamp", c + Vector3(16.5, 6.0, 0), Vector3(3.6, 0.5, 22.0), _materials["stone_dark"], "concrete", Vector3(deg_to_rad(-33), 0, 0))
	# Interior pillars & crates
	for px in [-6.0, 6.0]:
		for pz in [-4.0, 4.0]:
			_add_static_cylinder(detail, "KeepPillar", c + Vector3(px, 6.0, pz), 0.9, 12.0, _materials["stone_dark"], "concrete")
	_add_dynamic_crate(detail, c + Vector3(-2.5, 1.0, 2.0), "wood")
	_add_dynamic_barrel(detail, c + Vector3(2.5, 1.0, 2.0), "wood")

	var l := _add_zone_light(zone, c + Vector3(0, 9.5, 0), Color("#ffb057"), 3.2, 30.0)
	_zone_manager.register_zone(zone, c, detail, [l])

func _build_gatehouse_zone() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_Gatehouse"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)
	var c := Vector3(0, 0, 56)

	for gx in [-6.5, 6.5]:
		_add_static_box(zone, "GateTower", c + Vector3(gx, 6.5, 0), Vector3(5.5, 13.0, 6.5), _materials["stone_dark"], "concrete")
		_add_visual_box(detail, "GateBeacon", c + Vector3(gx, 13.5, 0), Vector3(0.8, 0.8, 0.8), _materials["glow_amber"])
	_add_static_box(zone, "GateBridge", c + Vector3(0, 8.0, 0), Vector3(8.0, 4.0, 5.0), _materials["stone"], "concrete")
	_add_dynamic_crate(detail, c + Vector3(-4, 1, -8), "wood")
	_add_dynamic_crate(detail, c + Vector3(4, 1, -8), "wood")

	var l := _add_zone_light(zone, c + Vector3(0, 6.0, 0), Color("#ffaa4c"), 2.6, 26.0)
	_zone_manager.register_zone(zone, c, detail, [l])

func _build_bastion_towers_zone() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_BastionTowers"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)

	for corner in [Vector3(-56, 0, -56), Vector3(56, 0, -56), Vector3(-56, 0, 56), Vector3(56, 0, 56)]:
		_add_static_box(zone, "Bastion", corner + Vector3(0, 5.5, 0), Vector3(10.0, 11.0, 10.0), _materials["stone_dark"], "concrete")
		_add_visual_box(detail, "BastionLight", corner + Vector3(0, 11.6, 0), Vector3(0.7, 0.7, 0.7), _materials["glow_amber"])
	# Ramp onto West wall battlements
	_add_static_box(zone, "WallRampW", Vector3(-50, 3.0, 0), Vector3(3.2, 0.4, 12.0), _materials["stone_dark"], "concrete", Vector3(deg_to_rad(30), 0, 0))
	_zone_manager.register_zone(zone, Vector3.ZERO, detail, [])

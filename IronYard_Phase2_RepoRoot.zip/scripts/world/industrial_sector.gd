extends Node3D

const PLAYER_SCENE := preload("res://scenes/player/player.tscn")
const HUD_SCRIPT := preload("res://scripts/ui/core_hud.gd")
const TOUCH_HUD_SCRIPT := preload("res://scripts/input/touch_hud.gd")
const SPAWN_POINT_SCRIPT := preload("res://scripts/world/spawn_point.gd")
const SPAWN_MANAGER_SCRIPT := preload("res://scripts/world/spawn_manager.gd")
const ZONE_STREAMING_SCRIPT := preload("res://scripts/world/zone_streaming_manager.gd")
const WEATHER_SCRIPT := preload("res://scripts/world/weather_controller.gd")

var _materials: Dictionary = {}
var _spawn_manager: Node
var _zone_manager: ZoneStreamingManager
var _weather: WeatherController
var _world_env: WorldEnvironment
var _sun_light: DirectionalLight3D

func _ready() -> void:
	_create_materials()
	_setup_lighting_and_sky()
	_zone_manager = ZONE_STREAMING_SCRIPT.new()
	_zone_manager.name = "ZoneStreamingManager"
	add_child(_zone_manager)

	_build_ground_and_roads()
	_build_perimeter_walls()
	_build_warehouse_zone()
	_build_factory_zone()
	_build_watchtower_zone()
	_build_crane_and_containers_zone()
	_build_trucks_and_props()
	_build_vegetation()
	_setup_spawns()
	_spawn_player()
	_spawn_huds()

	_weather = WEATHER_SCRIPT.new()
	_weather.name = "WeatherController"
	add_child(_weather)
	_weather.setup(_world_env, _sun_light)

	PerformanceManager.apply_quality_preset(SettingsManager.get_quality_preset())
	AppState.set_active_screen("industrial_sector")

func _create_materials() -> void:
	var concrete := _make_mat(Color("#3a4348"), 0.88, 0.06, "concrete")
	var asphalt := _make_mat(Color("#1d2226"), 0.94, 0.03, "rubber")
	var steel := _make_mat(Color("#54626a"), 0.56, 0.52, "painted_steel")
	var dark_steel := _make_mat(Color("#232d33"), 0.62, 0.48, "painted_steel")
	var rust_red := _make_mat(Color("#8c3b2b"), 0.72, 0.25, "painted_steel")
	var cargo_blue := _make_mat(Color("#2d5a78"), 0.66, 0.28, "painted_steel")
	var cargo_yellow := _make_mat(Color("#c48b2d"), 0.64, 0.22, "painted_steel")
	var cargo_olive := _make_mat(Color("#475c3e"), 0.72, 0.20, "painted_steel")
	var road_yellow := _make_mat(Color("#d9a938"), 0.85, 0.02, "")
	var road_white := _make_mat(Color("#cfd6d9"), 0.85, 0.02, "")
	var foliage := _make_mat(Color("#345432"), 0.92, 0.0, "")
	var dirt := _make_mat(Color("#4c4338"), 0.96, 0.0, "")
	var glass := _make_mat(Color("#487385"), 0.18, 0.65, "")

	var glow_cyan := StandardMaterial3D.new()
	glow_cyan.albedo_color = Color("#48d8f0")
	glow_cyan.emission_enabled = true
	glow_cyan.emission = Color("#48d8f0")
	glow_cyan.emission_energy_multiplier = 2.2
	glow_cyan.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED

	var glow_amber := StandardMaterial3D.new()
	glow_amber.albedo_color = Color("#ffaa3c")
	glow_amber.emission_enabled = true
	glow_amber.emission = Color("#ffaa3c")
	glow_amber.emission_energy_multiplier = 2.0
	glow_amber.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED

	_materials = {
		"concrete": concrete,
		"asphalt": asphalt,
		"steel": steel,
		"dark_steel": dark_steel,
		"rust_red": rust_red,
		"cargo_blue": cargo_blue,
		"cargo_yellow": cargo_yellow,
		"cargo_olive": cargo_olive,
		"road_yellow": road_yellow,
		"road_white": road_white,
		"foliage": foliage,
		"dirt": dirt,
		"glass": glass,
		"glow_cyan": glow_cyan,
		"glow_amber": glow_amber,
	}

func _make_mat(color: Color, roughness: float, metallic: float, tex_prefix: String) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	if not tex_prefix.is_empty():
		var root_path := "res://assets/textures/%s" % tex_prefix
		var albedo := load(root_path + "_albedo.png") as Texture2D
		var normal := load(root_path + "_normal.png") as Texture2D
		if albedo != null:
			mat.albedo_texture = albedo
		if normal != null:
			mat.normal_enabled = true
			mat.normal_texture = normal
			mat.normal_scale = 0.25
		mat.uv1_triplanar = true
		mat.uv1_world_triplanar = true
		mat.uv1_scale = Vector3(0.45, 0.45, 0.45)
	return mat

func _setup_lighting_and_sky() -> void:
	_world_env = WorldEnvironment.new()
	_world_env.name = "WorldEnvironment"
	var env := Environment.new()
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.14, 0.24, 0.34)
	sky_mat.sky_horizon_color = Color(0.42, 0.52, 0.60)
	sky_mat.ground_bottom_color = Color(0.09, 0.11, 0.13)
	sky_mat.ground_horizon_color = Color(0.28, 0.34, 0.38)
	sky.sky_material = sky_mat
	env.sky = sky
	env.background_mode = Environment.BG_SKY
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.55
	env.tonemap_mode = Environment.TONE_MAP_ACES
	env.glow_enabled = true
	env.glow_intensity = 0.45
	_world_env.environment = env
	add_child(_world_env)

	_sun_light = DirectionalLight3D.new()
	_sun_light.name = "DirectionalLight3D"
	_sun_light.rotation_degrees = Vector3(-42.0, 32.0, 0.0)
	_sun_light.shadow_enabled = true
	_sun_light.directional_shadow_max_distance = 110.0
	add_child(_sun_light)

func _build_ground_and_roads() -> void:
	var ground := Node3D.new()
	ground.name = "GroundAndRoads"
	add_child(ground)

	# Main 140x140 concrete slab
	_add_static_box(ground, "MainConcreteSlab", Vector3(0, -0.25, 0), Vector3(140, 0.5, 140), _materials["concrete"], "concrete")

	# Intersecting asphalt avenues (North-South & East-West)
	_add_static_box(ground, "Road_NS", Vector3(0, 0.02, 0), Vector3(12.0, 0.04, 136.0), _materials["asphalt"], "rubber")
	_add_static_box(ground, "Road_EW", Vector3(0, 0.02, 0), Vector3(136.0, 0.04, 12.0), _materials["asphalt"], "rubber")

	# Road lane markings
	for i in range(-14, 15):
		if abs(i) < 2:
			continue
		_add_visual_box(ground, "LaneNS_%d" % i, Vector3(0, 0.045, float(i) * 4.5), Vector3(0.22, 0.01, 2.2), _materials["road_yellow"])
		_add_visual_box(ground, "LaneEW_%d" % i, Vector3(float(i) * 4.5, 0.045, 0), Vector3(2.2, 0.01, 0.22), _materials["road_yellow"])

	# Dirt / gravel shoulder patches
	for pos in [Vector3(-56, 0.015, 56), Vector3(56, 0.015, 56), Vector3(-56, 0.015, -56), Vector3(56, 0.015, -56)]:
		_add_visual_box(ground, "DirtPatch", pos, Vector3(18, 0.03, 18), _materials["dirt"])

func _build_perimeter_walls() -> void:
	var walls := Node3D.new()
	walls.name = "PerimeterWalls"
	add_child(walls)
	_add_static_box(walls, "Wall_North", Vector3(0, 2.5, -69), Vector3(140, 5.0, 1.5), _materials["steel"], "metal")
	_add_static_box(walls, "Wall_South", Vector3(0, 2.5, 69), Vector3(140, 5.0, 1.5), _materials["steel"], "metal")
	_add_static_box(walls, "Wall_West", Vector3(-69, 2.5, 0), Vector3(1.5, 5.0, 140), _materials["steel"], "metal")
	_add_static_box(walls, "Wall_East", Vector3(69, 2.5, 0), Vector3(1.5, 5.0, 140), _materials["steel"], "metal")

func _build_warehouse_zone() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_Warehouse"
	add_child(zone)
	var detail := Node3D.new()
	detail.name = "WarehouseDetails"
	zone.add_child(detail)

	var c := Vector3(-36, 0, -34)
	# Floor & roof
	_add_static_box(zone, "WH_Roof", c + Vector3(0, 8.2, 0), Vector3(26, 0.4, 22), _materials["dark_steel"], "metal")
	# Back & side walls with openable loading bays on South/East
	_add_static_box(zone, "WH_NorthWall", c + Vector3(0, 4.0, -10.6), Vector3(26, 8.0, 0.6), _materials["steel"], "metal")
	_add_static_box(zone, "WH_WestWall", c + Vector3(-12.7, 4.0, 0), Vector3(0.6, 8.0, 22), _materials["steel"], "metal")
	_add_static_box(zone, "WH_SouthLeft", c + Vector3(-8.0, 4.0, 10.6), Vector3(10, 8.0, 0.6), _materials["steel"], "metal")
	_add_static_box(zone, "WH_SouthRight", c + Vector3(8.0, 4.0, 10.6), Vector3(10, 8.0, 0.6), _materials["steel"], "metal")
	_add_static_box(zone, "WH_SouthHeader", c + Vector3(0, 6.2, 10.6), Vector3(6, 3.6, 0.6), _materials["cargo_yellow"], "metal")
	_add_static_box(zone, "WH_EastLeft", c + Vector3(12.7, 4.0, -6.5), Vector3(0.6, 8.0, 9), _materials["steel"], "metal")
	_add_static_box(zone, "WH_EastRight", c + Vector3(12.7, 4.0, 6.5), Vector3(0.6, 8.0, 9), _materials["steel"], "metal")

	# Interior shelving & crates
	for x_off in [-8.0, 0.0, 8.0]:
		_add_static_box(detail, "WH_Rack", c + Vector3(x_off, 1.8, -5.0), Vector3(2.2, 3.6, 5.5), _materials["cargo_blue"], "metal")
	_add_dynamic_crate(detail, c + Vector3(-3.0, 1.0, 2.0))
	_add_dynamic_crate(detail, c + Vector3(3.0, 1.0, 3.0))

	var light := _add_zone_light(zone, c + Vector3(0, 7.2, 0), Color("#ffd296"), 2.4, 24.0)
	_zone_manager.register_zone(zone, c, detail, [light])

func _build_factory_zone() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_Factory"
	add_child(zone)
	var detail := Node3D.new()
	detail.name = "FactoryDetails"
	zone.add_child(detail)

	var c := Vector3(36, 0, -34)
	_add_static_box(zone, "Fac_Roof", c + Vector3(0, 9.5, 0), Vector3(28, 0.5, 24), _materials["dark_steel"], "metal")
	_add_static_box(zone, "Fac_North", c + Vector3(0, 4.6, -11.6), Vector3(28, 9.2, 0.6), _materials["steel"], "metal")
	_add_static_box(zone, "Fac_East", c + Vector3(13.7, 4.6, 0), Vector3(0.6, 9.2, 24), _materials["steel"], "metal")
	_add_static_box(zone, "Fac_SouthL", c + Vector3(-9, 4.6, 11.6), Vector3(10, 9.2, 0.6), _materials["steel"], "metal")
	_add_static_box(zone, "Fac_SouthR", c + Vector3(9, 4.6, 11.6), Vector3(10, 9.2, 0.6), _materials["steel"], "metal")

	# Twin smokestacks
	for x_off in [-6.0, 6.0]:
		var stack := CylinderMesh.new()
		stack.top_radius = 1.1
		stack.bottom_radius = 1.4
		stack.height = 16.0
		_add_static_mesh(zone, "Smokestack", stack, c + Vector3(x_off, 14.0, -7.0), _materials["dark_steel"])

	# Interior turbines & glowing consoles
	_add_static_box(detail, "TurbineA", c + Vector3(-5, 1.5, -3), Vector3(3.2, 3.0, 7.0), _materials["cargo_olive"], "metal")
	_add_static_box(detail, "TurbineB", c + Vector3(5, 1.5, -3), Vector3(3.2, 3.0, 7.0), _materials["cargo_olive"], "metal")
	_add_visual_box(detail, "ConsoleGlow", c + Vector3(0, 1.3, 4.0), Vector3(3.4, 0.5, 0.8), _materials["glow_cyan"])

	var light := _add_zone_light(zone, c + Vector3(0, 8.2, 0), Color("#8fe8ff"), 2.6, 26.0)
	_zone_manager.register_zone(zone, c, detail, [light])

func _build_watchtower_zone() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_Watchtower"
	add_child(zone)
	var detail := Node3D.new()
	detail.name = "TowerDetails"
	zone.add_child(detail)

	var c := Vector3(-38, 0, 34)
	# Four corner support legs
	for lx in [-2.6, 2.6]:
		for lz in [-2.6, 2.6]:
			_add_static_box(zone, "TowerLeg", c + Vector3(lx, 4.5, lz), Vector3(0.55, 9.0, 0.55), _materials["dark_steel"], "metal")
	# Observation deck at y = 9.0
	_add_static_box(zone, "TowerDeck", c + Vector3(0, 9.0, 0), Vector3(7.0, 0.4, 7.0), _materials["steel"], "metal")
	_add_static_box(zone, "TowerRoof", c + Vector3(0, 12.2, 0), Vector3(7.4, 0.3, 7.4), _materials["dark_steel"], "metal")
	# Guard railings
	_add_static_box(detail, "RailN", c + Vector3(0, 9.7, -3.3), Vector3(6.8, 1.0, 0.2), _materials["cargo_yellow"], "metal")
	_add_static_box(detail, "RailS", c + Vector3(0, 9.7, 3.3), Vector3(6.8, 1.0, 0.2), _materials["cargo_yellow"], "metal")
	_add_static_box(detail, "RailW", c + Vector3(-3.3, 9.7, 0), Vector3(0.2, 1.0, 6.8), _materials["cargo_yellow"], "metal")
	# Climbable ramp up to the tower deck
	_add_static_box(zone, "TowerRamp", c + Vector3(8.5, 4.5, 0), Vector3(13.5, 0.35, 2.6), _materials["concrete"], "concrete", Vector3(0, 0, deg_to_rad(-42.0)))
	_add_visual_box(detail, "TowerBeacon", c + Vector3(0, 12.6, 0), Vector3(0.6, 0.5, 0.6), _materials["glow_amber"])

	var light := _add_zone_light(zone, c + Vector3(0, 11.6, 0), Color("#ffb85c"), 2.4, 22.0)
	_zone_manager.register_zone(zone, c, detail, [light])

func _build_crane_and_containers_zone() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_CraneYard"
	add_child(zone)
	var detail := Node3D.new()
	detail.name = "CraneYardDetails"
	zone.add_child(detail)

	# Overhead Gantry Crane spanning the central yard
	_add_static_box(zone, "CraneLeg_W1", Vector3(-11, 6.5, -8), Vector3(0.9, 13.0, 0.9), _materials["cargo_yellow"], "metal")
	_add_static_box(zone, "CraneLeg_W2", Vector3(-11, 6.5, 8), Vector3(0.9, 13.0, 0.9), _materials["cargo_yellow"], "metal")
	_add_static_box(zone, "CraneLeg_E1", Vector3(11, 6.5, -8), Vector3(0.9, 13.0, 0.9), _materials["cargo_yellow"], "metal")
	_add_static_box(zone, "CraneLeg_E2", Vector3(11, 6.5, 8), Vector3(0.9, 13.0, 0.9), _materials["cargo_yellow"], "metal")
	_add_static_box(zone, "CraneBeam", Vector3(0, 13.2, 0), Vector3(24.0, 1.2, 1.6), _materials["cargo_yellow"], "metal")
	_add_visual_box(detail, "CraneCable", Vector3(2.5, 9.5, 0), Vector3(0.14, 6.5, 0.14), _materials["dark_steel"])
	_add_static_box(detail, "SuspendedContainer", Vector3(2.5, 5.2, 0), Vector3(6.2, 2.6, 2.5), _materials["rust_red"], "metal")

	# Shipping Containers across East & South-East Yard
	var containers := [
		[Vector3(28, 1.3, 22), "rust_red", 0.0],
		[Vector3(28, 1.3, 26), "cargo_blue", 0.0],
		[Vector3(28, 3.9, 24), "cargo_yellow", 0.0],
		[Vector3(42, 1.3, 20), "cargo_olive", 90.0],
		[Vector3(42, 1.3, 34), "rust_red", 15.0],
		[Vector3(-22, 1.3, 18), "cargo_blue", 90.0],
		[Vector3(-22, 1.3, -16), "cargo_olive", 0.0],
		[Vector3(22, 1.3, -16), "cargo_yellow", 0.0],
	]
	for idx in range(containers.size()):
		var item = containers[idx]
		_add_static_box(zone, "Container_%d" % idx, item[0], Vector3(6.2, 2.6, 2.5), _materials[item[1]], "metal", Vector3(0, deg_to_rad(item[2]), 0))

	var light := _add_zone_light(zone, Vector3(0, 12.4, 0), Color("#ffe4b5"), 2.2, 28.0)
	_zone_manager.register_zone(zone, Vector3.ZERO, detail, [light])

func _build_trucks_and_props() -> void:
	var props := Node3D.new()
	props.name = "TrucksAndProps"
	add_child(props)

	# Two industrial cargo trucks
	_build_truck(props, Vector3(-16, 0, -24), 0.0, "cargo_blue")
	_build_truck(props, Vector3(16, 0, 26), 180.0, "rust_red")

	# Interactive/shootable dynamic crates & barrels around central road
	for pos in [Vector3(-6, 1.0, 10), Vector3(7, 1.0, -10), Vector3(15, 1.0, 14), Vector3(-15, 1.0, -10)]:
		_add_dynamic_crate(props, pos)

func _build_truck(parent_node: Node3D, pos: Vector3, yaw_deg: float, cab_mat_key: String) -> void:
	var truck := Node3D.new()
	truck.position = pos
	truck.rotation_degrees.y = yaw_deg
	parent_node.add_child(truck)
	# Cab
	_add_static_box(truck, "Cab", Vector3(0, 1.5, -3.2), Vector3(2.4, 2.2, 2.2), _materials[cab_mat_key], "metal")
	_add_visual_box(truck, "Windshield", Vector3(0, 1.9, -4.32), Vector3(2.0, 0.85, 0.08), _materials["glass"])
	# Cargo trailer
	_add_static_box(truck, "Trailer", Vector3(0, 1.9, 1.4), Vector3(2.5, 2.6, 6.2), _materials["steel"], "metal")
	# Wheels
	var wheel_mesh := CylinderMesh.new()
	wheel_mesh.top_radius = 0.52
	wheel_mesh.bottom_radius = 0.52
	wheel_mesh.height = 0.36
	for wx in [-1.15, 1.15]:
		for wz in [-3.2, 0.2, 2.8]:
			var w := _add_static_mesh(truck, "Wheel", wheel_mesh, Vector3(wx, 0.52, wz), _materials["asphalt"])
			w.rotation.z = PI * 0.5

func _build_vegetation() -> void:
	var veg := Node3D.new()
	veg.name = "Vegetation"
	add_child(veg)
	var shrub_mesh := SphereMesh.new()
	shrub_mesh.radius = 0.85
	shrub_mesh.height = 1.2
	var positions := [
		Vector3(-58, 0.45, -58), Vector3(-52, 0.45, -60), Vector3(58, 0.45, -58),
		Vector3(-58, 0.45, 58), Vector3(58, 0.45, 58), Vector3(54, 0.45, 62),
		Vector3(-12, 0.4, 48), Vector3(12, 0.4, -48), Vector3(-48, 0.4, 12), Vector3(48, 0.4, -12),
	]
	for p in positions:
		var m := MeshInstance3D.new()
		m.mesh = shrub_mesh
		m.material_override = _materials["foliage"]
		m.position = p
		m.scale = Vector3(1.3, 0.85, 1.3)
		veg.add_child(m)

func _setup_spawns() -> void:
	_spawn_manager = SPAWN_MANAGER_SCRIPT.new()
	_spawn_manager.name = "SpawnManager"
	add_child(_spawn_manager)
	var spawn_coords := [
		Vector3(0, 0.1, 42),
		Vector3(0, 0.1, -42),
		Vector3(-36, 0.1, -18),
		Vector3(36, 0.1, -18),
		Vector3(-24, 0.1, 34),
		Vector3(34, 0.1, 14),
	]
	for i in range(spawn_coords.size()):
		var sp := Node3D.new()
		sp.set_script(SPAWN_POINT_SCRIPT)
		sp.name = "SpawnPoint_%d" % i
		sp.position = spawn_coords[i]
		add_child(sp)

func _spawn_player() -> void:
	var player := PLAYER_SCENE.instantiate()
	player.name = "Player"
	add_child(player)
	if _spawn_manager != null and _spawn_manager.has_method("get_next_spawn_transform"):
		player.global_transform = _spawn_manager.call("get_next_spawn_transform", "")
	else:
		player.global_position = Vector3(0, 0.2, 42)

func _spawn_huds() -> void:
	var hud := HUD_SCRIPT.new()
	hud.name = "CoreHUD"
	add_child(hud)
	var touch := TOUCH_HUD_SCRIPT.new()
	touch.name = "TouchHUD"
	add_child(touch)

func _add_static_box(parent_node: Node3D, node_name: String, pos: Vector3, sz: Vector3, mat: Material, surface: String, rot: Vector3 = Vector3.ZERO) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = pos
	body.rotation = rot
	body.collision_layer = 1
	body.collision_mask = 1
	body.set_meta("surface_type", surface)
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = sz
	col.shape = shape
	body.add_child(col)
	var mesh_inst := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = sz
	mesh_inst.mesh = mesh
	mesh_inst.material_override = mat
	body.add_child(mesh_inst)
	parent_node.add_child(body)
	return body

func _add_visual_box(parent_node: Node3D, node_name: String, pos: Vector3, sz: Vector3, mat: Material) -> MeshInstance3D:
	var mesh_inst := MeshInstance3D.new()
	mesh_inst.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = sz
	mesh_inst.mesh = mesh
	mesh_inst.material_override = mat
	mesh_inst.position = pos
	parent_node.add_child(mesh_inst)
	return mesh_inst

func _add_static_mesh(parent_node: Node3D, node_name: String, mesh: Mesh, pos: Vector3, mat: Material) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = pos
	body.collision_layer = 1
	body.collision_mask = 1
	var col := CollisionShape3D.new()
	col.shape = mesh.create_convex_shape()
	body.add_child(col)
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	body.add_child(mi)
	parent_node.add_child(body)
	return body

func _add_dynamic_crate(parent_node: Node3D, pos: Vector3) -> void:
	var rb := RigidBody3D.new()
	rb.position = pos
	rb.mass = 12.0
	rb.collision_layer = 1
	rb.collision_mask = 1
	rb.add_to_group("pushable")
	var col := CollisionShape3D.new()
	var box_shape := BoxShape3D.new()
	box_shape.size = Vector3(1.1, 1.1, 1.1)
	col.shape = box_shape
	rb.add_child(col)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.1, 1.1, 1.1)
	mi.mesh = bm
	mi.material_override = _materials["cargo_yellow"]
	rb.add_child(mi)
	parent_node.add_child(rb)

func _add_zone_light(parent_node: Node3D, pos: Vector3, color: Color, energy: float, range_m: float) -> OmniLight3D:
	var light := OmniLight3D.new()
	light.position = pos
	light.light_color = color
	light.light_energy = energy
	light.omni_range = range_m
	light.shadow_enabled = false
	parent_node.add_child(light)
	return light

extends MapBuilderBase

func _ready() -> void:
	_init_world_systems("map_warehouse", Color(0.12, 0.20, 0.28), Color(0.38, 0.48, 0.56), Vector3(-42.0, 28.0, 0.0))
	_build_ground_and_roads()
	_build_mega_warehouse_west()
	_build_cold_depot_east()
	_build_container_maze_south()
	_build_dispatch_office_north()
	_finalize_world([
		Vector3(0, 0.2, 56),
		Vector3(0, 0.2, -54),
		Vector3(-42, 0.2, 16),
		Vector3(42, 0.2, 16),
		Vector3(-18, 0.2, -10),
		Vector3(18, 0.2, -10),
	])

func _build_ground_and_roads() -> void:
	var base := Node3D.new()
	base.name = "GroundAndRoads"
	add_child(base)
	_add_static_box(base, "Ground", Vector3(0, -0.25, 0), Vector3(160, 0.5, 160), _materials["concrete"], "concrete")
	_add_static_box(base, "MainAvenue", Vector3(0, 0.02, 0), Vector3(14, 0.04, 156), _materials["asphalt"], "rubber")
	_add_static_box(base, "CrossRoad", Vector3(0, 0.02, 18), Vector3(156, 0.04, 12), _materials["asphalt"], "rubber")
	for i in range(-16, 17):
		if abs(i) < 2:
			continue
		_add_visual_box(base, "LaneNS_%d" % i, Vector3(0, 0.045, float(i) * 4.5), Vector3(0.24, 0.01, 2.2), _materials["road_white"])
	_add_static_box(base, "WallN", Vector3(0, 2.5, -79), Vector3(160, 5.0, 1.5), _materials["steel"], "metal")
	_add_static_box(base, "WallS", Vector3(0, 2.5, 79), Vector3(160, 5.0, 1.5), _materials["steel"], "metal")
	_add_static_box(base, "WallW", Vector3(-79, 2.5, 0), Vector3(1.5, 5.0, 160), _materials["steel"], "metal")
	_add_static_box(base, "WallE", Vector3(79, 2.5, 0), Vector3(1.5, 5.0, 160), _materials["steel"], "metal")

func _build_mega_warehouse_west() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_WarehouseA"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)
	var c := Vector3(-42, 0, -14)

	# 34x44 Main Distribution Hall
	_add_static_box(zone, "WHA_Roof", c + Vector3(0, 9.5, 0), Vector3(34, 0.5, 44), _materials["dark_steel"], "metal")
	_add_static_box(zone, "WHA_West", c + Vector3(-16.7, 4.7, 0), Vector3(0.6, 9.4, 44), _materials["steel"], "metal")
	_add_static_box(zone, "WHA_North", c + Vector3(0, 4.7, -21.7), Vector3(34, 9.4, 0.6), _materials["steel"], "metal")
	_add_static_box(zone, "WHA_South", c + Vector3(0, 4.7, 21.7), Vector3(34, 9.4, 0.6), _materials["steel"], "metal")
	# East wall with 3 open loading bays
	for bz in [-16.0, -4.0, 8.0, 18.0]:
		_add_static_box(zone, "WHA_Pillar", c + Vector3(16.7, 4.7, bz), Vector3(0.8, 9.4, 4.0), _materials["cargo_blue"], "metal")
	_add_static_box(zone, "WHA_EastHeader", c + Vector3(16.7, 7.6, 0), Vector3(0.8, 3.8, 44), _materials["cargo_yellow"], "metal")

	# Multi-tier pallet racking aisles inside
	for rx in [-9.0, -1.0, 7.0]:
		for rz in [-10.0, 4.0]:
			_add_static_box(detail, "Rack", c + Vector3(rx, 2.2, rz), Vector3(2.4, 4.4, 9.0), _materials["cargo_yellow"], "metal")
	_add_dynamic_crate(detail, c + Vector3(3.0, 1.0, -2.0))
	_add_dynamic_crate(detail, c + Vector3(-5.0, 1.0, 12.0), "rust_red")
	_add_truck(zone, c + Vector3(22, 0, -10), 90.0, "cargo_blue", "steel")

	var l1 := _add_zone_light(zone, c + Vector3(0, 8.5, -10), Color("#ffe2a8"), 3.0, 30.0)
	var l2 := _add_zone_light(zone, c + Vector3(0, 8.5, 10), Color("#ffe2a8"), 3.0, 30.0)
	_zone_manager.register_zone(zone, c, detail, [l1, l2])

func _build_cold_depot_east() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_WarehouseB"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)
	var c := Vector3(42, 0, -14)

	_add_static_box(zone, "WHB_Roof", c + Vector3(0, 8.5, 0), Vector3(30, 0.5, 36), _materials["steel"], "metal")
	_add_static_box(zone, "WHB_East", c + Vector3(14.7, 4.2, 0), Vector3(0.6, 8.4, 36), _materials["steel"], "metal")
	_add_static_box(zone, "WHB_North", c + Vector3(0, 4.2, -17.7), Vector3(30, 8.4, 0.6), _materials["steel"], "metal")
	_add_static_box(zone, "WHB_South", c + Vector3(0, 4.2, 17.7), Vector3(30, 8.4, 0.6), _materials["steel"], "metal")
	_add_static_box(zone, "WHB_WestHeader", c + Vector3(-14.7, 6.8, 0), Vector3(0.8, 3.4, 36), _materials["cargo_blue"], "metal")
	_add_visual_box(detail, "ColdSign", c + Vector3(-15.2, 6.8, 0), Vector3(0.2, 1.4, 8.0), _materials["glow_cyan"])

	for rx in [-6.0, 4.0]:
		_add_static_box(detail, "ColdRack", c + Vector3(rx, 2.0, 0), Vector3(2.5, 4.0, 20.0), _materials["cargo_olive"], "metal")
	_add_truck(zone, c + Vector3(-20, 0, 8), -90.0, "rust_red", "cargo_blue")
	_add_dynamic_barrel(detail, c + Vector3(-10, 1, -8))

	var l := _add_zone_light(zone, c + Vector3(0, 7.6, 0), Color("#a2f0ff"), 2.8, 28.0)
	_zone_manager.register_zone(zone, c, detail, [l])

func _build_container_maze_south() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_ContainerMaze"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)
	var c := Vector3(0, 0, 44)

	var layout := [
		[Vector3(-24, 1.3, 34), 0.0, "rust_red"],
		[Vector3(-24, 1.3, 42), 0.0, "cargo_blue"],
		[Vector3(-24, 3.9, 38), 90.0, "cargo_yellow"],
		[Vector3(-12, 1.3, 48), 90.0, "cargo_olive"],
		[Vector3(14, 1.3, 36), 0.0, "cargo_yellow"],
		[Vector3(14, 1.3, 46), 0.0, "rust_red"],
		[Vector3(26, 1.3, 40), 90.0, "cargo_blue"],
		[Vector3(26, 3.9, 40), 90.0, "cargo_olive"],
		[Vector3(36, 1.3, 52), 0.0, "rust_red"],
		[Vector3(-36, 1.3, 54), 15.0, "cargo_blue"],
	]
	for item in layout:
		_add_container(zone, item[0], item[1], item[2])
	# Climbable ramp onto stacked containers
	_add_static_box(zone, "ContainerRamp", Vector3(-17, 1.3, 38), Vector3(6.5, 0.3, 2.4), _materials["steel"], "metal", Vector3(0, 0, deg_to_rad(24)))
	for p in [Vector3(-16, 1, 32), Vector3(16, 1, 56), Vector3(8, 1, 38)]:
		_add_dynamic_crate(detail, p)
	for p in [Vector3(-56, 0, 62), Vector3(56, 0, 62)]:
		_add_shrub(detail, p, 1.4)

	_zone_manager.register_zone(zone, c, detail, [])

func _build_dispatch_office_north() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_DispatchOffice"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)
	var c := Vector3(0, 0, -52)

	# Two-story Dispatch Control Building overlooking the yard
	_add_static_box(zone, "OfficeBase", c + Vector3(0, 2.2, 0), Vector3(20, 4.4, 12), _materials["concrete"], "concrete")
	_add_static_box(zone, "OfficeUpperFloor", c + Vector3(0, 4.6, 0), Vector3(22, 0.4, 14), _materials["dark_steel"], "metal")
	_add_static_box(zone, "OfficeRoof", c + Vector3(0, 8.2, 0), Vector3(22, 0.4, 14), _materials["dark_steel"], "metal")
	_add_visual_box(detail, "OfficeGlassS", c + Vector3(0, 6.4, 6.8), Vector3(18, 2.8, 0.2), _materials["glass"])
	_add_static_box(zone, "OfficeRamp", c + Vector3(14, 2.3, 0), Vector3(8.5, 0.3, 2.6), _materials["steel"], "metal", Vector3(0, 0, deg_to_rad(-32)))

	var l := _add_zone_light(zone, c + Vector3(0, 7.2, 0), Color("#8fe8ff"), 2.4, 24.0)
	_zone_manager.register_zone(zone, c, detail, [l])

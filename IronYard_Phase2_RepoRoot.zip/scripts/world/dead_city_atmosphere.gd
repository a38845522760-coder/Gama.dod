extends Node3D
class_name DeadCityAtmosphere

## Lightweight local ambience used only by the zombie map. Dust is kept close to the player
## and uses world-space particles so moving the emitter does not drag already spawned particles.

const AMBIENCE: AudioStreamWAV = preload("res://assets/audio/dead_city_ambience.wav")

var target: Node3D
var _dust: GPUParticles3D
var _smoke_emitters: Array[GPUParticles3D] = []

func _ready() -> void:
    _build_dust()
    _build_smoke_vents()
    _build_audio()
    _apply_effect_quality()
    EventBus.quality_profile_changed.connect(_on_quality_profile_changed)

func _exit_tree() -> void:
    if EventBus.quality_profile_changed.is_connected(_on_quality_profile_changed):
        EventBus.quality_profile_changed.disconnect(_on_quality_profile_changed)

func _on_quality_profile_changed(_profile_id: String) -> void:
    _apply_effect_quality()

func _apply_effect_quality() -> void:
    var quality_profile: Dictionary = SettingsManager.get_quality_profile()
    var effects_density: float = clampf(float(quality_profile.get("effects_density", 0.5)), 0.0, 1.0)
    if is_instance_valid(_dust):
        _dust.amount = clampi(roundi(18.0 + effects_density * 42.0), 12, 60)
    var smoke_count: int = clampi(roundi(5.0 + effects_density * 15.0), 5, 20)
    for emitter in _smoke_emitters:
        if is_instance_valid(emitter):
            emitter.amount = smoke_count

func _process(_delta: float) -> void:
    if is_instance_valid(target) and is_instance_valid(_dust):
        _dust.global_position = target.global_position + Vector3(0.0, 7.0, 0.0)

func _build_dust() -> void:
    _dust = GPUParticles3D.new()
    _dust.name = "FloatingDust"
    _dust.amount = 36
    _dust.lifetime = 14.0
    _dust.explosiveness = 0.0
    _dust.emitting = true
    _dust.local_coords = false
    _dust.visibility_aabb = AABB(Vector3(-58.0, -12.0, -58.0), Vector3(116.0, 24.0, 116.0))
    var process_material := ParticleProcessMaterial.new()
    process_material.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
    process_material.emission_box_extents = Vector3(48.0, 8.0, 48.0)
    process_material.direction = Vector3(0.65, 0.08, 0.25)
    process_material.spread = 34.0
    process_material.initial_velocity_min = 0.08
    process_material.initial_velocity_max = 0.28
    process_material.gravity = Vector3(0.0, -0.008, 0.0)
    process_material.scale_min = 0.035
    process_material.scale_max = 0.105
    process_material.color = Color(0.68, 0.76, 0.82, 0.22)
    _dust.process_material = process_material
    var quad := QuadMesh.new()
    quad.size = Vector2(0.08, 0.08)
    var dust_material := StandardMaterial3D.new()
    dust_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    dust_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    dust_material.vertex_color_use_as_albedo = true
    dust_material.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
    dust_material.albedo_color = Color(0.72, 0.79, 0.85, 0.3)
    dust_material.no_depth_test = false
    quad.material = dust_material
    _dust.draw_pass_1 = quad
    add_child(_dust)

func _build_smoke_vents() -> void:
    var vent_positions: Array[Vector3] = [
        Vector3(125.0, 29.0, 147.0),
        Vector3(0.0, 1.8, 150.0),
        Vector3(-155.0, 5.0, 0.0),
    ]
    for index in range(vent_positions.size()):
        var smoke := GPUParticles3D.new()
        smoke.name = "AmbientSmoke_%d" % index
        smoke.position = vent_positions[index]
        smoke.amount = 12
        smoke.lifetime = 9.0 if index == 0 else 7.0
        smoke.explosiveness = 0.0
        smoke.emitting = true
        smoke.local_coords = true
        smoke.visibility_aabb = AABB(Vector3(-4.0, -1.0, -4.0), Vector3(8.0, 14.0, 8.0))
        var process_material := ParticleProcessMaterial.new()
        process_material.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
        process_material.emission_sphere_radius = 0.34
        process_material.direction = Vector3(0.0, 1.0, 0.0)
        process_material.spread = 13.0
        process_material.initial_velocity_min = 0.12
        process_material.initial_velocity_max = 0.42 if index == 0 else 0.24
        process_material.gravity = Vector3(0.0, 0.045, 0.0)
        process_material.damping_min = 0.08
        process_material.damping_max = 0.22
        process_material.scale_min = 0.45
        process_material.scale_max = 0.95
        process_material.color = Color(0.56, 0.62, 0.66, 0.42)
        var fade := Gradient.new()
        fade.set_color(0, Color(0.72, 0.78, 0.82, 0.12))
        fade.set_color(1, Color(0.35, 0.40, 0.44, 0.0))
        process_material.color_ramp = GradientTexture1D.new()
        (process_material.color_ramp as GradientTexture1D).gradient = fade
        smoke.process_material = process_material
        var quad := QuadMesh.new()
        quad.size = Vector2(0.72, 0.72)
        var smoke_material := StandardMaterial3D.new()
        smoke_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        smoke_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        smoke_material.vertex_color_use_as_albedo = true
        smoke_material.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
        smoke_material.albedo_color = Color(0.68, 0.73, 0.76, 0.28)
        smoke_material.no_depth_test = false
        quad.material = smoke_material
        smoke.draw_pass_1 = quad
        add_child(smoke)
        _smoke_emitters.append(smoke)

func _build_audio() -> void:
    var audio := AudioStreamPlayer.new()
    audio.name = "IndustrialWind"
    audio.stream = AMBIENCE
    audio.volume_db = -25.0
    audio.autoplay = false
    audio.bus = "Master"
    var loop_stream := AMBIENCE.duplicate() as AudioStreamWAV
    loop_stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
    audio.stream = loop_stream
    add_child(audio)
    audio.play()

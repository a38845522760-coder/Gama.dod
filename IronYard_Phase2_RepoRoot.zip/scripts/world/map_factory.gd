extends MapBuilderBase

func _ready() -> void:
	_init_world_systems("map_factory", Color(0.14, 0.21, 0.28), Color(0.38, 0.46, 0.52), Vector3(-40.0, 35.0, 0.0))
	_build_ground_and_perimeter()
	_build_main_plant_zone()
	_build_crane_and_pipe_yard()
	_build_silos_and_storage_zone()
	_build_substation_and_gate_zone()
	_finalize_world([
		Vector3(0, 0.2, 54),
		Vector3(0, 0.2, -52),
		Vector3(-44, 0.2, 18),
		Vector3(44, 0.2, 18),
		Vector3(-44, 0.2, -22),
		Vector3(44, 0.2, -22),
	])

func _build_ground_and_perimeter() -> void:
	var base := Node3D.new()
	base.name = "GroundAndPerimeter"
	add_child(base)
	_add_static_box(base, "Ground", Vector3(0, -0.25, 0), Vector3(160, 0.5, 160), _materials["concrete"], "concrete")
	_add_static_box(base, "Road_NS", Vector3(0, 0.02, 0), Vector3(12, 0.04, 156), _materials["asphalt"], "rubber")
	_add_static_box(base, "Road_EW", Vector3(0, 0.02, 12), Vector3(156, 0.04, 12), _materials["asphalt"], "rubber")
	for i in range(-16, 17):
		if abs(i) < 2:
			continue
		_add_visual_box(base, "LaneNS_%d" % i, Vector3(0, 0.045, float(i) * 4.5), Vector3(0.22, 0.01, 2.2), _materials["road_yellow"])
		_add_visual_box(base, "LaneEW_%d" % i, Vector3(float(i) * 4.5, 0.045, 12), Vector3(2.2, 0.01, 0.22), _materials["road_yellow"])
	_add_static_box(base, "WallN", Vector3(0, 2.6, -79), Vector3(160, 5.2, 1.5), _materials["steel"], "metal")
	_add_static_box(base, "WallS", Vector3(0, 2.6, 79), Vector3(160, 5.2, 1.5), _materials["steel"], "metal")
	_add_static_box(base, "WallW", Vector3(-79, 2.6, 0), Vector3(1.5, 5.2, 160), _materials["steel"], "metal")
	_add_static_box(base, "WallE", Vector3(79, 2.6, 0), Vector3(1.5, 5.2, 160), _materials["steel"], "metal")

func _build_main_plant_zone() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_MainPlant"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)
	var c := Vector3(0, 0, -38)

	# Huge 48x30 Factory Hall with open walk-through bays
	_add_static_box(zone, "PlantRoof", c + Vector3(0, 11.0, 0), Vector3(48, 0.6, 30), _materials["dark_steel"], "metal")
	_add_static_box(zone, "PlantWallN", c + Vector3(0, 5.5, -14.7), Vector3(48, 11.0, 0.7), _materials["steel"], "metal")
	_add_static_box(zone, "PlantWallW", c + Vector3(-23.7, 5.5, 0), Vector3(0.7, 11.0, 30), _materials["steel"], "metal")
	_add_static_box(zone, "PlantWallE", c + Vector3(23.7, 5.5, 0), Vector3(0.7, 11.0, 30), _materials["steel"], "metal")
	_add_static_box(zone, "PlantSouthL", c + Vector3(-16, 5.5, 14.7), Vector3(16, 11.0, 0.7), _materials["steel"], "metal")
	_add_static_box(zone, "PlantSouthR", c + Vector3(16, 5.5, 14.7), Vector3(16, 11.0, 0.7), _materials["steel"], "metal")
	_add_static_box(zone, "PlantSouthMid", c + Vector3(0, 8.2, 14.7), Vector3(16, 5.6, 0.7), _materials["cargo_yellow"], "metal")

	# 3 Towering Smokestacks
	for sx in [-14.0, 0.0, 14.0]:
		_add_static_cylinder(zone, "Smokestack", c + Vector3(sx, 18.0, -10.0), 1.5, 22.0, _materials["dark_steel"], "metal")
		_add_visual_box(detail, "StackRing", c + Vector3(sx, 27.0, -10.0), Vector3(3.3, 0.6, 3.3), _materials["glow_amber"])

	# Interior Furnace Core, Turbines & Elevated Catwalk
	_add_static_box(detail, "FurnaceCore", c + Vector3(0, 2.5, -5.0), Vector3(6.5, 5.0, 6.5), _materials["rust_red"], "metal")
	_add_visual_box(detail, "FurnaceGlow", c + Vector3(0, 2.2, -1.6), Vector3(3.8, 2.2, 0.2), _materials["glow_amber"])
	_add_static_cylinder(detail, "TurbineL", c + Vector3(-13, 1.8, -2), 1.8, 9.0, _materials["cargo_blue"], "metal", Vector3(PI * 0.5, 0, 0))
	_add_static_cylinder(detail, "TurbineR", c + Vector3(13, 1.8, -2), 1.8, 9.0, _materials["cargo_blue"], "metal", Vector3(PI * 0.5, 0, 0))
	_add_static_box(zone, "Catwalk", c + Vector3(0, 4.8, 6.0), Vector3(42, 0.35, 3.4), _materials["steel"], "grate")
	_add_static_box(zone, "CatwalkRampL", c + Vector3(-18, 2.4, 9.5), Vector3(2.8, 0.3, 8.5), _materials["concrete"], "concrete", Vector3(deg_to_rad(34), 0, 0))
	_add_visual_box(detail, "ControlPanel", c + Vector3(-8, 1.2, 4.0), Vector3(3.5, 0.5, 0.8), _materials["glow_cyan"])

	var l1 := _add_zone_light(zone, c + Vector3(-10, 9.5, 0), Color("#ffbe76"), 3.0, 32.0)
	var l2 := _add_zone_light(zone, c + Vector3(10, 9.5, 0), Color("#8fe8ff"), 3.0, 32.0)
	_zone_manager.register_zone(zone, c, detail, [l1, l2])

func _build_crane_and_pipe_yard() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_CraneYard"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)

	# Massive Overhead Gantry Crane
	for lx in [-14.0, 14.0]:
		for lz in [-8.0, 8.0]:
			_add_static_box(zone, "CraneLeg", Vector3(lx, 7.5, 12 + lz), Vector3(1.1, 15.0, 1.1), _materials["cargo_yellow"], "metal")
	_add_static_box(zone, "CraneBridge", Vector3(0, 15.2, 12), Vector3(30.0, 1.4, 2.0), _materials["cargo_yellow"], "metal")
	_add_visual_box(detail, "CraneCable", Vector3(4, 10.5, 12), Vector3(0.18, 8.5, 0.18), _materials["dark_steel"])
	_add_container(detail, Vector3(4, 5.4, 12), 0.0, "rust_red")

	# Overhead Industrial Pipe Bridge
	_add_static_cylinder(detail, "Pipe1", Vector3(-18, 6.2, -5), 0.45, 36.0, _materials["steel"], "metal", Vector3(PI * 0.5, 0, 0))
	_add_static_cylinder(detail, "Pipe2", Vector3(-16.5, 6.2, -5), 0.45, 36.0, _materials["cargo_yellow"], "metal", Vector3(PI * 0.5, 0, 0))

	# Shootable dynamic crates & barrels
	for p in [Vector3(-6, 1, 20), Vector3(7, 1, 22), Vector3(-10, 1, 4), Vector3(10, 1, 4)]:
		_add_dynamic_crate(detail, p)
		_add_dynamic_barrel(detail, p + Vector3(1.6, 0, 0))

	var l := _add_zone_light(zone, Vector3(0, 13.5, 12), Color("#ffe4b5"), 2.5, 34.0)
	_zone_manager.register_zone(zone, Vector3(0, 0, 12), detail, [l])

func _build_silos_and_storage_zone() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_Silos"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)
	var c := Vector3(48, 0, 32)

	for i in range(4):
		_add_static_cylinder(zone, "Silo_%d" % i, c + Vector3(-10 + float(i % 2) * 12, 6.5, -8 + float(i / 2) * 14), 3.6, 13.0, _materials["steel"], "metal")
	_add_truck(zone, c + Vector3(-18, 0, 14), 90.0, "cargo_blue", "steel")
	_add_container(detail, c + Vector3(8, 1.3, 18), 0.0, "cargo_olive")
	_add_container(detail, c + Vector3(8, 3.9, 18), 0.0, "cargo_yellow")
	for p in [c + Vector3(-24, 0, 24), c + Vector3(18, 0, -20)]:
		_add_shrub(detail, p, 1.3)

	var l := _add_zone_light(zone, c + Vector3(0, 11.0, 0), Color("#a8ecff"), 2.4, 28.0)
	_zone_manager.register_zone(zone, c, detail, [l])

func _build_substation_and_gate_zone() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_Substation"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)
	var c := Vector3(-48, 0, 36)

	for tx in [-8.0, 0.0, 8.0]:
		_add_static_box(zone, "Transformer", c + Vector3(tx, 2.2, 0), Vector3(4.0, 4.4, 5.5), _materials["cargo_olive"], "metal")
		_add_visual_box(detail, "CoilGlow", c + Vector3(tx, 4.6, 0), Vector3(1.2, 0.5, 1.2), _materials["glow_cyan"])
	_add_truck(zone, c + Vector3(18, 0, 18), 0.0, "rust_red", "cargo_blue")
	for p in [c + Vector3(-16, 0, 18), c + Vector3(-18, 0, -14)]:
		_add_shrub(detail, p, 1.4)

	var l := _add_zone_light(zone, c + Vector3(0, 7.5, 0), Color("#7ee8ff"), 2.4, 26.0)
	_zone_manager.register_zone(zone, c, detail, [l])

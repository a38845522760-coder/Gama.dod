extends Node3D
class_name MapBuilderBase

const PLAYER_SCENE := preload("res://scenes/player/player.tscn")
const HUD_SCRIPT := preload("res://scripts/ui/core_hud.gd")
const TOUCH_HUD_SCRIPT := preload("res://scripts/input/touch_hud.gd")
const SPAWN_POINT_SCRIPT := preload("res://scripts/world/spawn_point.gd")
const SPAWN_MANAGER_SCRIPT := preload("res://scripts/world/spawn_manager.gd")
const ZONE_STREAMING_SCRIPT := preload("res://scripts/world/zone_streaming_manager.gd")
const WEATHER_SCRIPT := preload("res://scripts/world/weather_controller.gd")
const TEAM_MANAGER_SCRIPT := preload("res://scripts/gameplay/team_manager.gd")
const BOT_SPAWN_SCRIPT := preload("res://scripts/ai/bot_spawn_manager.gd")

var _materials: Dictionary = {}
var _spawn_manager: Node
var _zone_manager: ZoneStreamingManager
var _weather: WeatherController
var _world_env: WorldEnvironment
var _sun_light: DirectionalLight3D

func _init_world_systems(screen_name: String, sky_top: Color, sky_horizon: Color, sun_rot: Vector3) -> void:
	_create_materials()
	_setup_lighting_and_sky(sky_top, sky_horizon, sun_rot)
	_zone_manager = ZONE_STREAMING_SCRIPT.new()
	_zone_manager.name = "ZoneStreamingManager"
	_zone_manager.active_radius = 85.0
	_zone_manager.detail_radius = 52.0
	add_child(_zone_manager)
	AppState.set_active_screen(screen_name)

func _finalize_world(spawn_coords: Array[Vector3]) -> void:
	var team_mgr := TEAM_MANAGER_SCRIPT.new()
	team_mgr.name = "TeamManager"
	add_child(team_mgr)
	_setup_spawns(spawn_coords)
	_spawn_player(spawn_coords[0] if not spawn_coords.is_empty() else Vector3(0, 0.2, 0))
	var bot_mgr := BOT_SPAWN_SCRIPT.new()
	bot_mgr.name = "BotSpawnManager"
	add_child(bot_mgr)
	bot_mgr.initialize_bots(spawn_coords, team_mgr)
	_spawn_huds()

	_weather = WEATHER_SCRIPT.new()
	_weather.name = "WeatherController"
	add_child(_weather)
	_weather.setup(_world_env, _sun_light)

	PerformanceManager.apply_quality_preset(SettingsManager.get_quality_preset())

func _create_materials() -> void:
	_materials = {
		"concrete": _make_mat(Color("#3a4348"), 0.88, 0.06, "concrete"),
		"sand_concrete": _make_mat(Color("#7a705c"), 0.90, 0.04, "concrete"),
		"stone": _make_mat(Color("#5c5a55"), 0.92, 0.04, "concrete"),
		"stone_dark": _make_mat(Color("#393836"), 0.94, 0.04, "concrete"),
		"asphalt": _make_mat(Color("#1d2226"), 0.94, 0.03, "rubber"),
		"steel": _make_mat(Color("#54626a"), 0.56, 0.52, "painted_steel"),
		"dark_steel": _make_mat(Color("#232d33"), 0.62, 0.48, "painted_steel"),
		"rust_red": _make_mat(Color("#8c3b2b"), 0.72, 0.25, "painted_steel"),
		"cargo_blue": _make_mat(Color("#2d5a78"), 0.66, 0.28, "painted_steel"),
		"cargo_yellow": _make_mat(Color("#c48b2d"), 0.64, 0.22, "painted_steel"),
		"cargo_olive": _make_mat(Color("#475c3e"), 0.72, 0.20, "painted_steel"),
		"camo_tan": _make_mat(Color("#8f8164"), 0.82, 0.08, "painted_steel"),
		"wood": _make_mat(Color("#5e432d"), 0.88, 0.02, "concrete"),
		"road_yellow": _make_mat(Color("#d9a938"), 0.85, 0.02, ""),
		"road_white": _make_mat(Color("#cfd6d9"), 0.85, 0.02, ""),
		"foliage": _make_mat(Color("#345432"), 0.92, 0.0, ""),
		"dirt": _make_mat(Color("#4c4338"), 0.96, 0.0, ""),
		"glass": _make_mat(Color("#487385"), 0.18, 0.65, ""),
		"glow_cyan": _make_glow(Color("#48d8f0"), 2.2),
		"glow_amber": _make_glow(Color("#ffaa3c"), 2.0),
		"glow_red": _make_glow(Color("#ff4a3d"), 2.2),
		"glow_green": _make_glow(Color("#4ae88a"), 2.0),
	}

func _make_mat(color: Color, roughness: float, metallic: float, tex_prefix: String) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	if not tex_prefix.is_empty():
		var root_path := "res://assets/textures/%s" % tex_prefix
		var albedo := load(root_path + "_albedo.png") as Texture2D
		var normal := load(root_path + "_normal.png") as Texture2D
		if albedo != null:
			mat.albedo_texture = albedo
		if normal != null:
			mat.normal_enabled = true
			mat.normal_texture = normal
			mat.normal_scale = 0.25
		mat.uv1_triplanar = true
		mat.uv1_world_triplanar = true
		mat.uv1_scale = Vector3(0.45, 0.45, 0.45)
	return mat

func _make_glow(color: Color, energy: float) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = energy
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	return mat

func _setup_lighting_and_sky(sky_top: Color, sky_horizon: Color, sun_rot: Vector3) -> void:
	_world_env = WorldEnvironment.new()
	_world_env.name = "WorldEnvironment"
	var env := Environment.new()
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = sky_top
	sky_mat.sky_horizon_color = sky_horizon
	sky_mat.ground_bottom_color = Color(0.08, 0.10, 0.12)
	sky_mat.ground_horizon_color = sky_horizon.darkened(0.35)
	sky.sky_material = sky_mat
	env.sky = sky
	env.background_mode = Environment.BG_SKY
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.55
	env.tonemap_mode = Environment.TONE_MAP_ACES
	env.glow_enabled = true
	env.glow_intensity = 0.45
	_world_env.environment = env
	add_child(_world_env)

	_sun_light = DirectionalLight3D.new()
	_sun_light.name = "DirectionalLight3D"
	_sun_light.rotation_degrees = sun_rot
	_sun_light.shadow_enabled = true
	_sun_light.directional_shadow_max_distance = 120.0
	add_child(_sun_light)

func _setup_spawns(coords: Array[Vector3]) -> void:
	_spawn_manager = SPAWN_MANAGER_SCRIPT.new()
	_spawn_manager.name = "SpawnManager"
	add_child(_spawn_manager)
	for i in range(coords.size()):
		var sp := Node3D.new()
		sp.set_script(SPAWN_POINT_SCRIPT)
		sp.name = "SpawnPoint_%d" % i
		sp.position = coords[i]
		add_child(sp)

func _spawn_player(fallback: Vector3) -> void:
	var player := PLAYER_SCENE.instantiate()
	player.name = "Player"
	add_child(player)
	if _spawn_manager != null and _spawn_manager.has_method("get_next_spawn_transform"):
		player.global_transform = _spawn_manager.call("get_next_spawn_transform", "")
	else:
		player.global_position = fallback

func _spawn_huds() -> void:
	var hud := HUD_SCRIPT.new()
	hud.name = "CoreHUD"
	add_child(hud)
	var touch := TOUCH_HUD_SCRIPT.new()
	touch.name = "TouchHUD"
	add_child(touch)

func _add_static_box(parent_node: Node3D, node_name: String, pos: Vector3, sz: Vector3, mat: Material, surface: String = "concrete", rot: Vector3 = Vector3.ZERO) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = pos
	body.rotation = rot
	body.collision_layer = 1
	body.collision_mask = 1
	body.set_meta("surface_type", surface)
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = sz
	col.shape = shape
	body.add_child(col)
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = sz
	mi.mesh = mesh
	mi.material_override = mat
	body.add_child(mi)
	parent_node.add_child(body)
	return body

func _add_visual_box(parent_node: Node3D, node_name: String, pos: Vector3, sz: Vector3, mat: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = sz
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	parent_node.add_child(mi)
	return mi

func _add_static_cylinder(parent_node: Node3D, node_name: String, pos: Vector3, radius: float, height: float, mat: Material, surface: String = "metal", rot: Vector3 = Vector3.ZERO) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = pos
	body.rotation = rot
	body.collision_layer = 1
	body.collision_mask = 1
	body.set_meta("surface_type", surface)
	var col := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = radius
	shape.height = height
	col.shape = shape
	body.add_child(col)
	var mi := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mi.mesh = mesh
	mi.material_override = mat
	body.add_child(mi)
	parent_node.add_child(body)
	return body

func _add_dynamic_crate(parent_node: Node3D, pos: Vector3, mat_key: String = "cargo_yellow") -> void:
	var rb := RigidBody3D.new()
	rb.position = pos
	rb.mass = 12.0
	rb.collision_layer = 1
	rb.collision_mask = 1
	rb.add_to_group("pushable")
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(1.1, 1.1, 1.1)
	col.shape = shape
	rb.add_child(col)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.1, 1.1, 1.1)
	mi.mesh = bm
	mi.material_override = _materials[mat_key]
	rb.add_child(mi)
	parent_node.add_child(rb)

func _add_dynamic_barrel(parent_node: Node3D, pos: Vector3, mat_key: String = "rust_red") -> void:
	var rb := RigidBody3D.new()
	rb.position = pos
	rb.mass = 9.0
	rb.collision_layer = 1
	rb.collision_mask = 1
	rb.add_to_group("pushable")
	var col := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = 0.42
	shape.height = 1.15
	col.shape = shape
	rb.add_child(col)
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.42
	cm.bottom_radius = 0.42
	cm.height = 1.15
	mi.mesh = cm
	mi.material_override = _materials[mat_key]
	rb.add_child(mi)
	parent_node.add_child(rb)

func _add_truck(parent_node: Node3D, pos: Vector3, yaw_deg: float, cab_mat_key: String, trailer_mat_key: String) -> void:
	var truck := Node3D.new()
	truck.position = pos
	truck.rotation_degrees.y = yaw_deg
	parent_node.add_child(truck)
	_add_static_box(truck, "Cab", Vector3(0, 1.5, -3.2), Vector3(2.4, 2.2, 2.2), _materials[cab_mat_key], "metal")
	_add_visual_box(truck, "Windshield", Vector3(0, 1.9, -4.32), Vector3(2.0, 0.85, 0.08), _materials["glass"])
	_add_static_box(truck, "Trailer", Vector3(0, 1.9, 1.4), Vector3(2.5, 2.6, 6.2), _materials[trailer_mat_key], "metal")
	for wx in [-1.15, 1.15]:
		for wz in [-3.2, 0.2, 2.8]:
			_add_static_cylinder(truck, "Wheel", Vector3(wx, 0.52, wz), 0.52, 0.36, _materials["asphalt"], "rubber", Vector3(0, 0, PI * 0.5))

func _add_container(parent_node: Node3D, pos: Vector3, yaw_deg: float, mat_key: String) -> void:
	_add_static_box(parent_node, "Container", pos, Vector3(6.2, 2.6, 2.5), _materials[mat_key], "metal", Vector3(0, deg_to_rad(yaw_deg), 0))

func _add_shrub(parent_node: Node3D, pos: Vector3, scale_val: float = 1.0) -> void:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.9 * scale_val
	sm.height = 1.3 * scale_val
	mi.mesh = sm
	mi.material_override = _materials["foliage"]
	mi.position = pos + Vector3(0, 0.45 * scale_val, 0)
	mi.scale = Vector3(1.25, 0.85, 1.25)
	parent_node.add_child(mi)

func _add_zone_light(parent_node: Node3D, pos: Vector3, color: Color, energy: float, range_m: float) -> OmniLight3D:
	var light := OmniLight3D.new()
	light.position = pos
	light.light_color = color
	light.light_energy = energy
	light.omni_range = range_m
	light.shadow_enabled = false
	parent_node.add_child(light)
	return light

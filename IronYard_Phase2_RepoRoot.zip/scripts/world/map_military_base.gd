extends MapBuilderBase

func _ready() -> void:
	_init_world_systems("map_military_base", Color(0.14, 0.22, 0.30), Color(0.56, 0.54, 0.46), Vector3(-38.0, 42.0, 0.0))
	_build_base_perimeter_and_runway()
	_build_airfield_hangar_and_helipad()
	_build_command_bunker_and_radar()
	_build_barracks_and_armory()
	_build_checkpoints_and_watchtowers()
	_finalize_world([
		Vector3(0, 0.2, 58),
		Vector3(-42, 0.2, 18),
		Vector3(42, 0.2, 24),
		Vector3(0, 0.2, -32),
		Vector3(-42, 0.2, -36),
		Vector3(42, 0.2, -36),
	])

func _build_base_perimeter_and_runway() -> void:
	var base := Node3D.new()
	base.name = "PerimeterAndRunway"
	add_child(base)
	_add_static_box(base, "Ground", Vector3(0, -0.25, 0), Vector3(160, 0.5, 160), _materials["sand_concrete"], "concrete")
	_add_static_box(base, "Runway", Vector3(40, 0.02, 0), Vector3(24, 0.04, 140), _materials["asphalt"], "rubber")
	_add_static_box(base, "BaseRoad", Vector3(-18, 0.02, 0), Vector3(12, 0.04, 148), _materials["asphalt"], "rubber")
	for i in range(-14, 15):
		_add_visual_box(base, "RunwayStripe_%d" % i, Vector3(40, 0.045, float(i) * 4.5), Vector3(0.4, 0.01, 2.2), _materials["road_white"])

	# Fortified concrete perimeter walls
	_add_static_box(base, "WallN", Vector3(0, 2.8, -79), Vector3(160, 5.6, 2.0), _materials["camo_tan"], "concrete")
	_add_static_box(base, "WallS", Vector3(0, 2.8, 79), Vector3(160, 5.6, 2.0), _materials["camo_tan"], "concrete")
	_add_static_box(base, "WallW", Vector3(-79, 2.8, 0), Vector3(2.0, 5.6, 160), _materials["camo_tan"], "concrete")
	_add_static_box(base, "WallE", Vector3(79, 2.8, 0), Vector3(2.0, 5.6, 160), _materials["camo_tan"], "concrete")

func _build_airfield_hangar_and_helipad() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_Airfield"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)
	var c := Vector3(40, 0, -34)

	# Large Open Aircraft Hangar
	_add_static_box(zone, "HangarRoof", c + Vector3(0, 10.5, 0), Vector3(32, 0.6, 28), _materials["dark_steel"], "metal")
	_add_static_box(zone, "HangarN", c + Vector3(0, 5.2, -13.7), Vector3(32, 10.4, 0.7), _materials["cargo_olive"], "metal")
	_add_static_box(zone, "HangarW", c + Vector3(-15.7, 5.2, 0), Vector3(0.7, 10.4, 28), _materials["cargo_olive"], "metal")
	_add_static_box(zone, "HangarE", c + Vector3(15.7, 5.2, 0), Vector3(0.7, 10.4, 28), _materials["cargo_olive"], "metal")

	# Helipad at (40, 0, 34) with glowing perimeter beacons and H marking
	var hp := Vector3(40, 0.06, 34)
	_add_static_box(zone, "HelipadDeck", hp, Vector3(18, 0.12, 18), _materials["concrete"], "concrete")
	_add_visual_box(detail, "H_L", hp + Vector3(-2.5, 0.08, 0), Vector3(1.0, 0.04, 7.0), _materials["road_yellow"])
	_add_visual_box(detail, "H_R", hp + Vector3(2.5, 0.08, 0), Vector3(1.0, 0.04, 7.0), _materials["road_yellow"])
	_add_visual_box(detail, "H_Mid", hp + Vector3(0, 0.08, 0), Vector3(4.5, 0.04, 1.0), _materials["road_yellow"])
	for bx in [-8.2, 8.2]:
		for bz in [-8.2, 8.2]:
			_add_visual_box(detail, "HeliBeacon", hp + Vector3(bx, 0.18, bz), Vector3(0.5, 0.25, 0.5), _materials["glow_green"])

	_add_dynamic_barrel(detail, c + Vector3(-10, 1, 6), "cargo_olive")
	_add_dynamic_crate(detail, c + Vector3(10, 1, 6), "camo_tan")

	var l := _add_zone_light(zone, c + Vector3(0, 9.2, 0), Color("#ffdfa8"), 3.0, 32.0)
	_zone_manager.register_zone(zone, c, detail, [l])

func _build_command_bunker_and_radar() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_CommandHQ"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)
	var c := Vector3(-18, 0, -44)

	# Reinforced Concrete Command Bunker
	_add_static_box(zone, "BunkerRoof", c + Vector3(0, 5.2, 0), Vector3(26, 0.8, 18), _materials["camo_tan"], "concrete")
	_add_static_box(zone, "BunkerN", c + Vector3(0, 2.6, -8.5), Vector3(26, 5.2, 1.0), _materials["camo_tan"], "concrete")
	_add_static_box(zone, "BunkerW", c + Vector3(-12.5, 2.6, 0), Vector3(1.0, 5.2, 18), _materials["camo_tan"], "concrete")
	_add_static_box(zone, "BunkerE", c + Vector3(12.5, 2.6, 0), Vector3(1.0, 5.2, 18), _materials["camo_tan"], "concrete")
	_add_static_box(zone, "BunkerSL", c + Vector3(-8, 2.6, 8.5), Vector3(10, 5.2, 1.0), _materials["camo_tan"], "concrete")
	_add_static_box(zone, "BunkerSR", c + Vector3(8, 2.6, 8.5), Vector3(10, 5.2, 1.0), _materials["camo_tan"], "concrete")

	# Radar Tower on Bunker Roof
	_add_static_cylinder(zone, "RadarMast", c + Vector3(0, 9.5, -2), 0.7, 8.0, _materials["dark_steel"], "metal")
	_add_visual_box(detail, "RadarDish", c + Vector3(0, 14.2, -2), Vector3(4.8, 2.6, 0.6), _materials["steel"], Vector3(deg_to_rad(-25), 0, 0))
	_add_visual_box(detail, "CommandConsole", c + Vector3(0, 1.3, -3), Vector3(5.0, 0.6, 1.2), _materials["glow_cyan"])

	var l := _add_zone_light(zone, c + Vector3(0, 4.4, 0), Color("#7ee8ff"), 2.8, 26.0)
	_zone_manager.register_zone(zone, c, detail, [l])

func _build_barracks_and_armory() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_Barracks"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)
	var c := Vector3(-48, 0, -4)

	for bz in [-16.0, 0.0, 16.0]:
		_add_static_box(zone, "BarrackRoof", c + Vector3(0, 4.2, bz), Vector3(18, 0.4, 10), _materials["cargo_olive"], "metal")
		_add_static_box(zone, "BarrackW", c + Vector3(-8.7, 2.1, bz), Vector3(0.6, 4.2, 10), _materials["camo_tan"], "concrete")
		_add_static_box(zone, "BarrackN", c + Vector3(0, 2.1, bz - 4.7), Vector3(18, 4.2, 0.6), _materials["camo_tan"], "concrete")
		_add_static_box(zone, "BarrackS", c + Vector3(0, 2.1, bz + 4.7), Vector3(18, 4.2, 0.6), _materials["camo_tan"], "concrete")

	_add_truck(zone, c + Vector3(16, 0, 14), 0.0, "cargo_olive", "camo_tan")
	_add_truck(zone, c + Vector3(16, 0, -14), 180.0, "cargo_olive", "cargo_olive")
	for p in [c + Vector3(-14, 0, -28), c + Vector3(-14, 0, 28)]:
		_add_shrub(detail, p, 1.3)

	var l := _add_zone_light(zone, c + Vector3(4, 5.5, 0), Color("#ffe4b5"), 2.2, 26.0)
	_zone_manager.register_zone(zone, c, detail, [l])

func _build_checkpoints_and_watchtowers() -> void:
	var zone := Node3D.new()
	zone.name = "Zone_Checkpoints"
	add_child(zone)
	var detail := Node3D.new()
	zone.add_child(detail)

	# Two climbable Watchtowers overlooking the main road
	for tw in [Vector3(-32, 0, 44), Vector3(12, 0, 44)]:
		for lx in [-2.2, 2.2]:
			for lz in [-2.2, 2.2]:
				_add_static_box(zone, "TowerLeg", tw + Vector3(lx, 4.0, lz), Vector3(0.5, 8.0, 0.5), _materials["dark_steel"], "metal")
		_add_static_box(zone, "TowerDeck", tw + Vector3(0, 8.0, 0), Vector3(6.0, 0.4, 6.0), _materials["steel"], "metal")
		_add_static_box(zone, "TowerRamp", tw + Vector3(7.2, 4.0, 0), Vector3(11.5, 0.35, 2.2), _materials["concrete"], "concrete", Vector3(0, 0, deg_to_rad(-42)))
		_add_visual_box(detail, "TowerAlert", tw + Vector3(0, 10.6, 0), Vector3(0.6, 0.5, 0.6), _materials["glow_red"])

	# Tactical Jersey barriers & shooting targets
	for bx in [-10.0, -4.0, 4.0, 10.0]:
		_add_static_box(zone, "Barrier", Vector3(bx, 0.65, 26), Vector3(3.2, 1.3, 0.8), _materials["camo_tan"], "concrete")
	for p in [Vector3(-10, 1, 20), Vector3(10, 1, 20), Vector3(0, 1, 12)]:
		_add_dynamic_crate(detail, p, "cargo_olive")
		_add_dynamic_barrel(detail, p + Vector3(1.5, 0, 0), "rust_red")

	_zone_manager.register_zone(zone, Vector3(-10, 0, 40), detail, [])

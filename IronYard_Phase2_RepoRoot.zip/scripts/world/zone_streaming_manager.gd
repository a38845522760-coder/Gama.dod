extends Node
class_name ZoneStreamingManager

## Distance-based regional zone streaming to keep mobile frame rates steady on large maps.

@export var active_radius: float = 68.0
@export var detail_radius: float = 42.0
@export var check_interval: float = 0.25

var _zones: Array[Dictionary] = []
var _player: Node3D
var _timer: float = 0.0

func register_zone(zone_root: Node3D, center: Vector3, detail_node: Node3D = null, lights: Array[Light3D] = []) -> void:
	_zones.append({
		"root": zone_root,
		"center": center,
		"detail": detail_node,
		"lights": lights,
	})

func _process(delta: float) -> void:
	_timer -= delta
	if _timer > 0.0:
		return
	_timer = check_interval
	if not is_instance_valid(_player):
		var players := get_tree().get_nodes_in_group("player_controller")
		if not players.is_empty():
			_player = players[0] as Node3D
	if not is_instance_valid(_player):
		return

	var player_pos := _player.global_position
	for zone in _zones:
		var root_node := zone["root"] as Node3D
		if not is_instance_valid(root_node):
			continue
		var dist := player_pos.distance_to(zone["center"])
		root_node.visible = dist <= active_radius
		var detail_node := zone["detail"] as Node3D
		if is_instance_valid(detail_node):
			detail_node.visible = dist <= detail_radius
		for light_node in zone["lights"]:
			if is_instance_valid(light_node):
				light_node.visible = dist <= detail_radius

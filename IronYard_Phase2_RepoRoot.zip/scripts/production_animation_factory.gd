extends RefCounted
class_name IronYardAnimationFactory

## Builds real Animation resources that animate named transform pivots in the
## imported GLB assemblies. This is node-transform rigging, not skin-weight rigging.

static func attach_zombie_animations(root: Node3D, initial: String = "idle") -> AnimationPlayer:
    var player := _player(root)
    var lib := AnimationLibrary.new()
    lib.add_animation("idle", _zombie_idle())
    lib.add_animation("walk", _zombie_walk(1.0, 0.55))
    lib.add_animation("run", _zombie_walk(0.62, 0.95))
    lib.add_animation("attack", _zombie_attack())
    lib.add_animation("hit", _zombie_hit())
    lib.add_animation("fall", _zombie_fall())
    lib.add_animation("rise", _zombie_rise())
    lib.add_animation("death", _zombie_death())
    player.add_animation_library("", lib)
    player.play(initial if lib.has_animation(initial) else "idle")
    return player

static func attach_device_animations(root: Node3D, initial: String = "idle") -> AnimationPlayer:
    var player := _player(root)
    var lib := AnimationLibrary.new()
    lib.add_animation("idle", _device_idle())
    lib.add_animation("power_on", _device_power_on())
    lib.add_animation("charge", _device_charge())
    lib.add_animation("pulse", _device_pulse())
    lib.add_animation("shutdown", _device_shutdown())
    player.add_animation_library("", lib)
    player.play(initial if lib.has_animation(initial) else "idle")
    return player

static func attach_energy_tool_animations(root: Node3D, initial: String = "idle") -> AnimationPlayer:
    var player := _player(root)
    var lib := AnimationLibrary.new()
    lib.add_animation("idle", _tool_idle())
    lib.add_animation("equip", _tool_equip())
    lib.add_animation("reload_cell", _tool_reload())
    lib.add_animation("fire", _tool_fire())
    lib.add_animation("inspect", _tool_inspect())
    lib.add_animation("overheat", _tool_overheat())
    lib.add_animation("cooldown", _tool_cooldown())
    player.add_animation_library("", lib)
    player.play(initial if lib.has_animation(initial) else "idle")
    return player

static func attach_fps_arm_animations(root: Node3D, initial: String = "idle") -> AnimationPlayer:
    var player := _player(root)
    var lib := AnimationLibrary.new()
    lib.add_animation("idle", _fps_idle())
    lib.add_animation("reload_assist", _fps_reload_assist())
    lib.add_animation("fire_recoil", _fps_fire_recoil())
    lib.add_animation("sprint", _fps_sprint())
    lib.add_animation("inspect", _fps_inspect())
    player.add_animation_library("", lib)
    player.play(initial if lib.has_animation(initial) else "idle")
    return player

static func attach_prop_animations(root: Node3D, initial: String = "idle") -> AnimationPlayer:
    var player := _player(root)
    var lib := AnimationLibrary.new()
    lib.add_animation("idle", _device_idle())
    lib.add_animation("open", _prop_open())
    lib.add_animation("close", _prop_close())
    lib.add_animation("activate", _device_power_on())
    player.add_animation_library("", lib)
    player.play(initial if lib.has_animation(initial) else "idle")
    return player

static func _player(root: Node3D) -> AnimationPlayer:
    var old := root.get_node_or_null("IronYardAnimationPlayer")
    if old != null:
        old.queue_free()
    var p := AnimationPlayer.new()
    p.name = "IronYardAnimationPlayer"
    p.root_node = NodePath("..")
    root.add_child(p)
    return p

static func _make(length: float, looped: bool) -> Animation:
    var a := Animation.new()
    a.length = length
    a.loop_mode = Animation.LOOP_LINEAR if looped else Animation.LOOP_NONE
    return a

static func _rot(a: Animation, path: String, keys: Array) -> void:
    var t := a.add_track(Animation.TYPE_VALUE)
    a.track_set_path(t, NodePath(path + ":rotation"))
    for key in keys:
        a.track_insert_key(t, float(key[0]), key[1])

static func _pos(a: Animation, path: String, keys: Array) -> void:
    var t := a.add_track(Animation.TYPE_VALUE)
    a.track_set_path(t, NodePath(path + ":position"))
    for key in keys:
        a.track_insert_key(t, float(key[0]), key[1])

static func _scale(a: Animation, path: String, keys: Array) -> void:
    var t := a.add_track(Animation.TYPE_VALUE)
    a.track_set_path(t, NodePath(path + ":scale"))
    for key in keys:
        a.track_insert_key(t, float(key[0]), key[1])

static func _zombie_idle() -> Animation:
    var a := _make(2.0, true)
    _rot(a,"Root/Pelvis/Torso",[[0.0,Vector3.ZERO],[1.0,Vector3(0.015,0,0)],[2.0,Vector3.ZERO]])
    _rot(a,"Root/Pelvis/Torso/Head",[[0.0,Vector3.ZERO],[.7,Vector3(0,-.035,0)],[1.4,Vector3(0,.04,0)],[2.0,Vector3.ZERO]])
    _rot(a,"Root/Pelvis/Torso/Arm_L",[[0.0,Vector3.ZERO],[1.0,Vector3(.025,0,.02)],[2.0,Vector3.ZERO]])
    _rot(a,"Root/Pelvis/Torso/Arm_R",[[0.0,Vector3.ZERO],[1.0,Vector3(-.025,0,-.02)],[2.0,Vector3.ZERO]])
    return a

static func _zombie_walk(speed: float, amount: float) -> Animation:
    var a := _make(speed, true)
    var h := speed * .5
    for arm_spec in [["Root/Pelvis/Torso/Arm_L", 1.0], ["Root/Pelvis/Torso/Arm_R", -1.0]]:
        var arm_path: String = str(arm_spec[0])
        var arm_side: float = float(arm_spec[1])
        _rot(a, arm_path, [[0.0, Vector3(-.42 * amount * arm_side, 0, .04 * arm_side)], [h, Vector3(.42 * amount * arm_side, 0, -.04 * arm_side)], [speed, Vector3(-.42 * amount * arm_side, 0, .04 * arm_side)]])
    for leg_spec in [["Root/Pelvis/Leg_L", 1.0], ["Root/Pelvis/Leg_R", -1.0]]:
        var leg_path: String = str(leg_spec[0])
        var leg_side: float = float(leg_spec[1])
        _rot(a, leg_path, [[0.0, Vector3(.48 * amount * leg_side, 0, 0)], [h, Vector3(-.48 * amount * leg_side, 0, 0)], [speed, Vector3(.48 * amount * leg_side, 0, 0)]])
    _pos(a,"Root",[[0.0,Vector3(0,0,0)],[h,Vector3(0,.045*amount,0)],[speed,Vector3(0,0,0)]])
    _rot(a,"Root/Pelvis/Torso",[[0.0,Vector3(.05*amount,0,0)],[h,Vector3(.08*amount,0,0)],[speed,Vector3(.05*amount,0,0)]])
    _rot(a,"Root/Pelvis/Torso/Arm_L/Forearm_L",[[0.0,Vector3(-.12*amount,0,0)],[h,Vector3(.12*amount,0,0)],[speed,Vector3(-.12*amount,0,0)]])
    _rot(a,"Root/Pelvis/Torso/Arm_R/Forearm_R",[[0.0,Vector3(.12*amount,0,0)],[h,Vector3(-.12*amount,0,0)],[speed,Vector3(.12*amount,0,0)]])
    return a

static func _zombie_attack() -> Animation:
    var a := _make(.85,false)
    _rot(a,"Root/Pelvis/Torso",[[0.0,Vector3.ZERO],[.28,Vector3(-.18,0,0)],[.55,Vector3(.20,0,0)],[.85,Vector3.ZERO]])
    _rot(a,"Root/Pelvis/Torso/Arm_R",[[0.0,Vector3.ZERO],[.28,Vector3(-.65,0,-.30)],[.55,Vector3(.8,0,-.10)],[.85,Vector3.ZERO]])
    _rot(a,"Root/Pelvis/Torso/Arm_L",[[0.0,Vector3.ZERO],[.28,Vector3(-.35,0,.24)],[.55,Vector3(.45,0,.1)],[.85,Vector3.ZERO]])
    _rot(a,"Root/Pelvis/Torso/Head",[[0.0,Vector3.ZERO],[.35,Vector3(.10,0,0)],[.62,Vector3(-.12,0,0)],[.85,Vector3.ZERO]])
    return a

static func _zombie_hit() -> Animation:
    var a := _make(.55,false)
    _rot(a,"Root/Pelvis/Torso",[[0.0,Vector3.ZERO],[.12,Vector3(.22,0,.18)],[.32,Vector3(-.08,0,-.08)],[.55,Vector3.ZERO]])
    _rot(a,"Root/Pelvis/Torso/Head",[[0.0,Vector3.ZERO],[.12,Vector3(-.28,0,.20)],[.38,Vector3(.12,0,-.10)],[.55,Vector3.ZERO]])
    return a

static func _zombie_fall() -> Animation:
    var a := _make(1.1,false)
    _rot(a,"Root/Pelvis/Torso",[[0.0,Vector3.ZERO],[.55,Vector3(0,0,1.05)],[1.1,Vector3(0,0,1.35)]])
    _rot(a,"Root/Pelvis/Torso/Arm_L",[[0.0,Vector3.ZERO],[.55,Vector3(-.9,0,.65)],[1.1,Vector3(-1.0,0,.8)]])
    _rot(a,"Root/Pelvis/Torso/Arm_R",[[0.0,Vector3.ZERO],[.55,Vector3(-.8,0,-.65)],[1.1,Vector3(-.9,0,-.8)]])
    return a

static func _zombie_rise() -> Animation:
    var a := _make(1.55,false)
    _rot(a,"Root/Pelvis/Torso",[[0.0,Vector3(0,0,1.35)],[.75,Vector3(.35,0,.55)],[1.55,Vector3.ZERO]])
    _rot(a,"Root/Pelvis/Torso/Arm_L",[[0.0,Vector3(-1.0,0,.8)],[.75,Vector3(-.8,0,.5)],[1.55,Vector3.ZERO]])
    _rot(a,"Root/Pelvis/Torso/Arm_R",[[0.0,Vector3(-.9,0,-.8)],[.75,Vector3(-.8,0,-.5)],[1.55,Vector3.ZERO]])
    return a

static func _zombie_death() -> Animation:
    var a := _make(1.6,false)
    _rot(a,"Root/Pelvis/Torso",[[0.0,Vector3.ZERO],[.45,Vector3(.28,0,.55)],[1.6,Vector3(.2,0,1.42)]])
    _rot(a,"Root/Pelvis/Torso/Head",[[0.0,Vector3.ZERO],[.5,Vector3(.4,0,.2)],[1.6,Vector3(.5,0,.4)]])
    _rot(a,"Root/Pelvis/Torso/Arm_L",[[0.0,Vector3.ZERO],[.6,Vector3(-.6,0,.8)],[1.6,Vector3(-.9,0,.9)]])
    _rot(a,"Root/Pelvis/Torso/Arm_R",[[0.0,Vector3.ZERO],[.6,Vector3(-.5,0,-.8)],[1.6,Vector3(-.8,0,-.9)]])
    return a

static func _device_idle() -> Animation:
    var a := _make(4.0,true)
    _rot(a,"Root/CoilUpper",[[0.0,Vector3.ZERO],[4.0,Vector3(0,TAU,0)]])
    _rot(a,"Root/Rotor_0",[[0.0,Vector3.ZERO],[4.0,Vector3(0,TAU,0)]])
    _rot(a,"Root/Fan",[[0.0,Vector3.ZERO],[4.0,Vector3(0,TAU,0)]])
    _rot(a,"Root/CoilLower",[[0.0,Vector3.ZERO],[4.0,Vector3(0,-TAU,0)]])
    _rot(a,"Root/ReactorRing_0",[[0.0,Vector3.ZERO],[4.0,Vector3(0,TAU,0)]])
    _rot(a,"Root/Rotor_1",[[0.0,Vector3.ZERO],[4.0,Vector3(0,-TAU,0)]])
    _rot(a,"Root/Rotor_2",[[0.0,Vector3.ZERO],[4.0,Vector3(0,TAU,0)]])
    _rot(a,"Root/Rotor_3",[[0.0,Vector3.ZERO],[4.0,Vector3(0,-TAU,0)]])
    _scale(a,"Root/EnergyCore",[[0.0,Vector3.ONE],[2.0,Vector3(1.08,1.08,1.08)],[4.0,Vector3.ONE]])
    _scale(a,"Root/ReactorCore",[[0.0,Vector3.ONE],[2.0,Vector3(1.06,1.06,1.06)],[4.0,Vector3.ONE]])
    _scale(a,"Root/PowerCell",[[0.0,Vector3.ONE],[2.0,Vector3(1.08,1.08,1.08)],[4.0,Vector3.ONE]])
    _rot(a,"Root/CoolingFan",[[0.0,Vector3.ZERO],[4.0,Vector3(0,TAU,0)]])
    _rot(a,"Root/ScannerArm",[[0.0,Vector3.ZERO],[4.0,Vector3(0,TAU,0)]])
    return a

static func _device_power_on() -> Animation:
    var a := _make(1.8,false)
    _scale(a,"Root/EnergyCore",[[0.0,Vector3(.15,.15,.15)],[1.4,Vector3(1.12,1.12,1.12)],[1.8,Vector3.ONE]])
    _rot(a,"Root/CoilUpper",[[0.0,Vector3.ZERO],[1.8,Vector3(0,TAU,0)]])
    _scale(a,"Root/ReactorCore",[[0.0,Vector3(.15,.15,.15)],[1.4,Vector3(1.12,1.12,1.12)],[1.8,Vector3.ONE]])
    _scale(a,"Root/PowerCell",[[0.0,Vector3(.15,.15,.15)],[1.4,Vector3(1.12,1.12,1.12)],[1.8,Vector3.ONE]])
    _scale(a,"Root/PodCore",[[0.0,Vector3(.15,.15,.15)],[1.4,Vector3(1.12,1.12,1.12)],[1.8,Vector3.ONE]])
    _pos(a,"Root/Display",[[0.0,Vector3(0,1.40,.42)],[.8,Vector3(0,1.48,.42)],[1.8,Vector3(0,1.40,.42)]])
    return a

static func _device_charge() -> Animation:
    var a := _make(2.2,false)
    _scale(a,"Root/EnergyCore",[[0.0,Vector3(.65,.65,.65)],[1.8,Vector3(1.28,1.28,1.28)],[2.2,Vector3.ONE]])
    _rot(a,"Root/ReactorRing_0",[[0.0,Vector3.ZERO],[2.2,Vector3(0,TAU,0)]])
    _rot(a,"Root/ReactorRing_1",[[0.0,Vector3.ZERO],[2.2,Vector3(0,-TAU,0)]])
    _scale(a,"Root/ReactorCore",[[0.0,Vector3(.6,.6,.6)],[1.8,Vector3(1.2,1.2,1.2)],[2.2,Vector3.ONE]])
    return a

static func _device_pulse() -> Animation:
    var a := _make(.8,false)
    _scale(a,"Root/EnergyCore",[[0.0,Vector3.ONE],[.22,Vector3(1.8,1.8,1.8)],[.8,Vector3(.2,.2,.2)]])
    _rot(a,"Root/CoilUpper",[[0.0,Vector3.ZERO],[.8,Vector3(0,TAU*1.5,0)]])
    _scale(a,"Root/ReactorCore",[[0.0,Vector3.ONE],[.22,Vector3(1.8,1.8,1.8)],[.8,Vector3(.2,.2,.2)]])
    return a

static func _device_shutdown() -> Animation:
    var a := _make(1.25,false)
    _scale(a,"Root/EnergyCore",[[0.0,Vector3.ONE],[.9,Vector3(.1,.1,.1)],[1.25,Vector3.ZERO]])
    _rot(a,"Root/CoilUpper",[[0.0,Vector3.ZERO],[1.25,Vector3(0,PI,0)]])
    _scale(a,"Root/ReactorCore",[[0.0,Vector3.ONE],[.9,Vector3(.1,.1,.1)],[1.25,Vector3.ZERO]])
    return a

static func _tool_idle() -> Animation:
    var a := _make(2.0,true)
    _pos(a,"Root/Emitter/MuzzleGlow",[[0.0,Vector3.ZERO],[1.0,Vector3(0,.012,0)],[2.0,Vector3.ZERO]])
    return a

static func _tool_equip() -> Animation:
    var a := _make(.48,false)
    _pos(a,"Root",[[0.0,Vector3(0,-.55,-.25)],[.34,Vector3.ZERO],[.48,Vector3.ZERO]])
    _rot(a,"Root",[[0.0,Vector3(-.25,.12,0)],[.34,Vector3.ZERO],[.48,Vector3.ZERO]])
    return a

static func _tool_reload() -> Animation:
    var a := _make(1.15,false)
    _pos(a,"Root/EnergyCell",[[0.0,Vector3(-.20,-.03,-.22)],[.22,Vector3(-.20,-.32,-.32)],[.58,Vector3(-.20,-.66,-.35)],[.82,Vector3(-.20,-.03,-.22)],[1.15,Vector3(-.20,-.03,-.22)]])
    _scale(a,"Root/Emitter/MuzzleGlow",[[0.0,Vector3.ONE],[.4,Vector3(.35,.35,.35)],[1.15,Vector3.ONE]])
    return a

static func _tool_fire() -> Animation:
    var a := _make(.34,false)
    _pos(a,"Root",[[0.0,Vector3.ZERO],[.07,Vector3(0,-.07,-.10)],[.19,Vector3(0,.025,.03)],[.34,Vector3.ZERO]])
    _scale(a,"Root/Emitter/MuzzleGlow",[[0.0,Vector3(.1,.1,.1)],[.05,Vector3(1.7,1.7,1.7)],[.16,Vector3(.2,.2,.2)],[.34,Vector3(.1,.1,.1)]])
    return a

static func _tool_inspect() -> Animation:
    var a := _make(1.25,false)
    _rot(a,"Root",[[0.0,Vector3.ZERO],[.42,Vector3(-.18,.35,.22)],[.85,Vector3(.10,-.30,-.12)],[1.25,Vector3.ZERO]])
    return a

static func _tool_overheat() -> Animation:
    var a := _make(1.0,true)
    _scale(a,"Root/Emitter/MuzzleGlow",[[0.0,Vector3(.7,.7,.7)],[.5,Vector3(1.25,1.25,1.25)],[1.0,Vector3(.7,.7,.7)]])
    return a

static func _tool_cooldown() -> Animation:
    var a := _make(1.0,false)
    _scale(a,"Root/Emitter/MuzzleGlow",[[0.0,Vector3(1.3,1.3,1.3)],[1.0,Vector3(.1,.1,.1)]])
    return a

static func _fps_idle() -> Animation:
    var a := _make(2.2,true)
    _rot(a,"Root/LeftArm",[[0.0,Vector3.ZERO],[1.1,Vector3(.012,0,.015)],[2.2,Vector3.ZERO]])
    _rot(a,"Root/RightArm",[[0.0,Vector3.ZERO],[1.1,Vector3(-.012,0,-.015)],[2.2,Vector3.ZERO]])
    return a

static func _fps_reload_assist() -> Animation:
    var a := _make(1.15,false)
    _rot(a,"Root/LeftArm",[[0.0,Vector3.ZERO],[.25,Vector3(-.18,0,-.28)],[.68,Vector3(-.12,0,-.42)],[.92,Vector3(-.06,0,-.16)],[1.15,Vector3.ZERO]])
    _pos(a,"Root/LeftHand",[[0.0,Vector3(-.06,-.43,-.20)],[.25,Vector3(-.10,-.38,-.40)],[.68,Vector3(-.08,-.22,-.52)],[.92,Vector3(-.06,-.43,-.20)],[1.15,Vector3(-.06,-.43,-.20)]])
    _rot(a,"Root/RightArm",[[0.0,Vector3.ZERO],[.45,Vector3(.035,0,.04)],[1.15,Vector3.ZERO]])
    return a

static func _fps_fire_recoil() -> Animation:
    var a := _make(.30,false)
    _rot(a,"Root/LeftArm",[[0.0,Vector3.ZERO],[.055,Vector3(.05,0,.02)],[.16,Vector3(-.02,0,0)],[.30,Vector3.ZERO]])
    _rot(a,"Root/RightArm",[[0.0,Vector3.ZERO],[.055,Vector3(-.07,0,-.02)],[.16,Vector3(.02,0,0)],[.30,Vector3.ZERO]])
    return a

static func _fps_sprint() -> Animation:
    var a := _make(.62,true)
    _rot(a,"Root/LeftArm",[[0.0,Vector3(-.24,0,.12)],[.31,Vector3(.24,0,-.12)],[.62,Vector3(-.24,0,.12)]])
    _rot(a,"Root/RightArm",[[0.0,Vector3(.24,0,-.12)],[.31,Vector3(-.24,0,.12)],[.62,Vector3(.24,0,-.12)]])
    return a

static func _fps_inspect() -> Animation:
    var a := _make(1.25,false)
    _rot(a,"Root/LeftArm",[[0.0,Vector3.ZERO],[.4,Vector3(-.18,0,-.35)],[.86,Vector3(.08,0,-.16)],[1.25,Vector3.ZERO]])
    _rot(a,"Root/RightArm",[[0.0,Vector3.ZERO],[.4,Vector3(.05,.10,-.10)],[.86,Vector3(-.04,-.10,.06)],[1.25,Vector3.ZERO]])
    return a

static func _prop_open() -> Animation:
    var a := _make(.9,false)
    _rot(a,"Root/CacheLid",[[0.0,Vector3.ZERO],[.9,Vector3(-1.25,0,0)]])
    _rot(a,"Root/DoorPanel",[[0.0,Vector3.ZERO],[.9,Vector3(0,1.15,0)]])
    _rot(a,"Root/Door_L",[[0.0,Vector3.ZERO],[.9,Vector3(0,-1.10,0)]])
    _rot(a,"Root/Door_R",[[0.0,Vector3.ZERO],[.9,Vector3(0,1.10,0)]])
    return a

static func _prop_close() -> Animation:
    var a := _make(.9,false)
    _rot(a,"Root/CacheLid",[[0.0,Vector3(-1.25,0,0)],[.9,Vector3.ZERO]])
    _rot(a,"Root/DoorPanel",[[0.0,Vector3(0,1.15,0)],[.9,Vector3.ZERO]])
    _rot(a,"Root/Door_L",[[0.0,Vector3(0,-1.10,0)],[.9,Vector3.ZERO]])
    _rot(a,"Root/Door_R",[[0.0,Vector3(0,1.10,0)],[.9,Vector3.ZERO]])
    return a

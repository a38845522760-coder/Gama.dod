extends Node3D
class_name SoldierModel

## Procedural humanoid used by every AI fighter (soldiers and zombies). It replaces the old
## capsule/box dummy with rounded limbs, a helmet, vest, backpack, boots, a gun in hand,
## a walk cycle, aiming pose, hit flash and a death fall. Feet are at y = 0, facing -Z.

const SKIN_TONES: Array[String] = ["#c99572", "#a97854", "#8a5d3e", "#e0b794"]

static var _material_cache: Dictionary = {}
static var _flash_material: StandardMaterial3D = null

var kind: String = "soldier"
var bulk: float = 1.0

var _meshes: Array[MeshInstance3D] = []
var _torso: Node3D
var _head: Node3D
var _thigh_l: Node3D
var _thigh_r: Node3D
var _knee_l: Node3D
var _knee_r: Node3D
var _shoulder_l: Node3D
var _shoulder_r: Node3D
var _elbow_l: Node3D
var _elbow_r: Node3D
var _gun_mount: Node3D
var _gun: Node3D
var _muzzle: Marker3D
var _phase: float = 0.0
var _flash_left: float = 0.0
var _aim_weight: float = 0.0
var _swing_amp: float = 0.0
var _attack_swing: float = 0.0
var _zombie_variant: int = 0
var _is_dead: bool = false
var _eyes: Array[MeshInstance3D] = []

static func _mat(color: Color, roughness: float = 0.85, metallic: float = 0.0, emission: float = 0.0, surface: String = "") -> StandardMaterial3D:
    var key := "%s_%.2f_%.2f_%.2f_%s" % [color.to_html(), roughness, metallic, emission, surface]
    if _material_cache.has(key):
        return _material_cache[key]
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = roughness
    material.metallic = metallic
    if not surface.is_empty():
        material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
        var root_path := "res://assets/textures/%s" % surface
        var albedo := load(root_path + "_albedo.png") as Texture2D
        var normal := load(root_path + "_normal.png") as Texture2D
        var roughness_map := load(root_path + "_roughness.png") as Texture2D
        if albedo != null:
            material.albedo_texture = albedo
        if normal != null:
            material.normal_enabled = true
            material.normal_texture = normal
            material.normal_scale = 0.18 if surface == "skin" else 0.28
        if roughness_map != null:
            material.roughness_texture = roughness_map
        material.uv1_triplanar = true
        material.uv1_scale = Vector3(5.0, 5.0, 5.0)
    if emission > 0.0:
        material.emission_enabled = true
        material.emission = color
        material.emission_energy_multiplier = emission
    _material_cache[key] = material
    return material

static func _get_flash_material() -> StandardMaterial3D:
    if _flash_material == null:
        _flash_material = StandardMaterial3D.new()
        _flash_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        _flash_material.albedo_color = Color(1.0, 0.32, 0.25, 0.55)
        _flash_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    return _flash_material

## look keys: kind, primary, secondary, skin, headgear, bulk, scale, team_color, weapon_id, zombie_variant
func build(look: Dictionary) -> void:
    kind = str(look.get("kind", "soldier"))
    bulk = float(look.get("bulk", 1.0))
    _zombie_variant = int(look.get("zombie_variant", 0))
    var overall_scale: float = float(look.get("scale", 1.0))
    scale = Vector3.ONE * overall_scale
    var primary: Color = look.get("primary", Color("#4a5a3c"))
    var secondary: Color = look.get("secondary", Color("#2b2f33"))
    var skin_color: Color = look.get("skin", Color(SKIN_TONES[randi() % SKIN_TONES.size()]))
    var team_color: Color = look.get("team_color", Color(0, 0, 0, 0))
    var headgear: String = str(look.get("headgear", "helmet"))
    var is_zombie: bool = kind == "zombie"
    var cloth := _mat(primary, 0.88, 0.0, 0.0, "fabric")
    var cloth_dark := _mat(primary.darkened(0.35), 0.9, 0.0, 0.0, "fabric")
    var armor := _mat(secondary, 0.5, 0.35, 0.0, "painted_steel")
    var skin := _mat(skin_color, 0.82, 0.0, 0.0, "skin")
    var boots := _mat(Color("#17191b"), 0.7, 0.1, 0.0, "rubber")

    # Zombie characters use a dedicated higher-detail visual build. Keep the survivor
    # construction path untouched so this upgrade cannot change soldier silhouettes.
    if is_zombie:
        _build_zombie_visual(primary, secondary, skin_color)
        _apply_pose(0.0, 0.0)
        return

    # ---------------------------------------------------------------- legs
    var pelvis := Node3D.new()
    pelvis.name = "Pelvis"
    pelvis.position = Vector3(0.0, 0.93, 0.0)
    add_child(pelvis)
    _add_box(pelvis, Vector3(0.0, 0.0, 0.0), Vector3(0.36 * bulk, 0.2, 0.22), cloth_dark)
    for side in [-1.0, 1.0]:
        var s: float = side
        var thigh := Node3D.new()
        thigh.name = "ThighL" if s < 0.0 else "ThighR"
        thigh.position = Vector3(s * 0.1 * bulk, -0.04, 0.0)
        pelvis.add_child(thigh)
        _add_capsule(thigh, Vector3(0.0, -0.19, 0.0), 0.078 * bulk, 0.46, cloth)
        var knee := Node3D.new()
        knee.position = Vector3(0.0, -0.4, 0.0)
        thigh.add_child(knee)
        _add_capsule(knee, Vector3(0.0, -0.2, 0.0), 0.064 * bulk, 0.46, cloth)
        _add_box(knee, Vector3(0.0, -0.4, -0.04), Vector3(0.115 * bulk, 0.09, 0.24), boots)
        _add_box(knee, Vector3(0.0, -0.446, -0.04), Vector3(0.12 * bulk, 0.018, 0.235), _mat(Color("#0d1012"), 0.95, 0.0, 0.0, "rubber"))
        if not is_zombie:
            _add_box(knee, Vector3(0.0, -0.02, -0.055), Vector3(0.12 * bulk, 0.1, 0.05), armor)
        if s < 0.0:
            _thigh_l = thigh
            _knee_l = knee
        else:
            _thigh_r = thigh
            _knee_r = knee

    # ---------------------------------------------------------------- torso
    _torso = Node3D.new()
    _torso.name = "Torso"
    _torso.position = Vector3(0.0, 1.1, 0.0)
    add_child(_torso)
    _add_box(_torso, Vector3(0.0, 0.2, 0.0), Vector3(0.40 * bulk, 0.5, 0.23), cloth)
    _add_box(_torso, Vector3(0.0, -0.02, 0.0), Vector3(0.38 * bulk, 0.08, 0.24), _mat(Color("#2a241d"), 0.8))
    if not is_zombie:
        _add_box(_torso, Vector3(0.0, 0.29, -0.005), Vector3(0.43 * bulk, 0.33, 0.265), armor)
        _add_box(_torso, Vector3(0.0, 0.34, -0.14), Vector3(0.3 * bulk, 0.1, 0.03), cloth_dark)
        for side in [-1.0, 1.0]:
            var px: float = side
            _add_box(_torso, Vector3(px * 0.12 * bulk, 0.1, -0.15), Vector3(0.09, 0.11, 0.05), cloth_dark)
        _add_box(_torso, Vector3(0.0, 0.26, 0.19), Vector3(0.3 * bulk, 0.34, 0.14), cloth_dark)
        if look.has("team_color"):
            _add_box(_torso, Vector3(0.0, 0.36, 0.265), Vector3(0.22, 0.12, 0.02), _mat(team_color, 0.6, 0.0, 1.4))
        # Additional field gear: sewn webbing, chest pouches, buckles and a radio pack.
        # These pieces add a readable military silhouette without changing the rig or hitboxes.
        for side in [-1.0, 1.0]:
            var strap_x: float = side * 0.125 * bulk
            _add_box(_torso, Vector3(strap_x, 0.31, -0.151), Vector3(0.029, 0.29, 0.022), cloth_dark)
            _add_box(_torso, Vector3(side * 0.145, 0.12, -0.158), Vector3(0.086, 0.105, 0.055), cloth_dark)
            _add_box(_torso, Vector3(side * 0.145, 0.167, -0.189), Vector3(0.058, 0.012, 0.008), armor)
            _add_box(_torso, Vector3(side * 0.145, 0.085, -0.189), Vector3(0.045, 0.009, 0.008), armor)
        _add_box(_torso, Vector3(0.0, 0.02, -0.14), Vector3(0.37, 0.055, 0.035), cloth_dark)
        _add_box(_torso, Vector3(0.0, 0.02, -0.162), Vector3(0.045, 0.035, 0.012), armor)
        _add_box(_torso, Vector3(-0.205, 0.34, 0.035), Vector3(0.075, 0.16, 0.11), cloth_dark)
        _add_box(_torso, Vector3(-0.205, 0.36, -0.026), Vector3(0.052, 0.07, 0.014), armor)
        _add_box(_torso, Vector3(-0.205, 0.46, 0.025), Vector3(0.012, 0.18, 0.012), cloth_dark)
        _add_box(_torso, Vector3(0.0, 0.49, 0.19), Vector3(0.28, 0.25, 0.18), cloth_dark)
        _add_box(_torso, Vector3(0.0, 0.49, 0.285), Vector3(0.18, 0.08, 0.018), armor)
    else:
        # Torn shirt, exposed ribs and old blood.
        _add_box(_torso, Vector3(0.1, 0.12, -0.12), Vector3(0.14, 0.2, 0.03), _mat(Color("#5a1b17"), 0.9))
        _add_box(_torso, Vector3(-0.08, 0.32, -0.125), Vector3(0.12, 0.1, 0.03), _mat(Color("#6b2a22"), 0.9))
        _add_box(_torso, Vector3(0.0, 0.05, -0.12), Vector3(0.34 * bulk, 0.06, 0.02), skin)
    var neck := MeshInstance3D.new()
    var neck_mesh := CylinderMesh.new()
    neck_mesh.top_radius = 0.05
    neck_mesh.bottom_radius = 0.055
    neck_mesh.height = 0.1
    neck_mesh.radial_segments = 8
    neck_mesh.rings = 1
    neck.mesh = neck_mesh
    neck.material_override = skin
    neck.position = Vector3(0.0, 0.5, 0.0)
    _register(neck)
    _torso.add_child(neck)

    # ---------------------------------------------------------------- head
    _head = Node3D.new()
    _head.name = "Head"
    _head.position = Vector3(0.0, 0.62, 0.0)
    _torso.add_child(_head)
    _add_sphere(_head, Vector3.ZERO, 0.115, skin, Vector3(0.95, 1.08, 1.0))
    _add_box(_head, Vector3(0.0, -0.075, -0.075), Vector3(0.1, 0.06, 0.06), skin)
    if is_zombie:
        for side in [-1.0, 1.0]:
            var ex: float = side
            var eye := _add_sphere(_head, Vector3(ex * 0.045, 0.02, -0.1), 0.017, _mat(Color("#ffe14a"), 0.4, 0.0, 3.0), Vector3.ONE)
            _eyes.append(eye)
        _add_box(_head, Vector3(0.0, -0.085, -0.095), Vector3(0.07, 0.03, 0.02), _mat(Color("#3a0d0d"), 0.9))
        if _zombie_variant % 2 == 0:
            _add_sphere(_head, Vector3(0.0, 0.1, 0.02), 0.085, _mat(Color("#2d241c"), 1.0), Vector3(1.0, 0.45, 1.0))
    else:
        for side in [-1.0, 1.0]:
            var ex2: float = side
            _add_sphere(_head, Vector3(ex2 * 0.04, 0.012, -0.1), 0.012, _mat(Color("#101010"), 0.5), Vector3.ONE)
    match headgear:
        "helmet":
            _add_sphere(_head, Vector3(0.0, 0.03, 0.0), 0.138, armor, Vector3(1.0, 0.78, 1.04))
            _add_box(_head, Vector3(0.0, 0.0, -0.01), Vector3(0.3, 0.03, 0.3), cloth_dark)
            if look.has("team_color"):
                _add_box(_head, Vector3(0.0, 0.085, -0.02), Vector3(0.05, 0.015, 0.24), _mat(team_color, 0.6, 0.0, 1.6))
        "heavy":
            _add_sphere(_head, Vector3(0.0, 0.03, 0.0), 0.16, armor, Vector3(1.0, 0.85, 1.05))
            _add_box(_head, Vector3(0.0, 0.0, -0.12), Vector3(0.2, 0.05, 0.05), _mat(Color("#41d9ee"), 0.3, 0.0, 2.2))
            _add_box(_head, Vector3(0.0, -0.06, -0.08), Vector3(0.2, 0.08, 0.08), armor)
        "hood":
            _add_sphere(_head, Vector3(0.0, 0.02, 0.02), 0.145, cloth, Vector3(1.0, 1.0, 1.1))
            _add_box(_head, Vector3(0.0, -0.045, -0.1), Vector3(0.17, 0.08, 0.04), _mat(Color("#141414"), 0.9))
        "bandana":
            _add_box(_head, Vector3(0.0, 0.07, 0.0), Vector3(0.25, 0.05, 0.25), _mat(Color("#c0392b"), 0.8))
            _add_box(_head, Vector3(0.0, 0.04, 0.14), Vector3(0.07, 0.1, 0.03), _mat(Color("#c0392b"), 0.8))
        "cap":
            _add_sphere(_head, Vector3(0.0, 0.05, 0.0), 0.12, cloth, Vector3(1.0, 0.55, 1.0))
            _add_box(_head, Vector3(0.0, 0.035, -0.12), Vector3(0.18, 0.02, 0.09), cloth_dark)
        _:
            pass

    # ---------------------------------------------------------------- arms
    for side in [-1.0, 1.0]:
        var s2: float = side
        var shoulder := Node3D.new()
        shoulder.name = "ShoulderL" if s2 < 0.0 else "ShoulderR"
        shoulder.position = Vector3(s2 * 0.255 * bulk, 0.44, 0.0)
        _torso.add_child(shoulder)
        _add_sphere(shoulder, Vector3.ZERO, 0.075 * bulk, armor if not is_zombie else cloth, Vector3.ONE)
        _add_capsule(shoulder, Vector3(0.0, -0.14, 0.0), 0.058 * bulk, 0.34, cloth if not is_zombie else skin)
        var elbow := Node3D.new()
        elbow.position = Vector3(0.0, -0.29, 0.0)
        shoulder.add_child(elbow)
        _add_capsule(elbow, Vector3(0.0, -0.13, 0.0), 0.05 * bulk, 0.32, cloth_dark if not is_zombie else skin)
        _add_sphere(elbow, Vector3(0.0, -0.29, 0.0), 0.052, _mat(Color("#14181b"), 0.9) if not is_zombie else skin, Vector3.ONE)
        if look.has("team_color") and not is_zombie:
            _add_box(shoulder, Vector3(0.0, -0.1, 0.0), Vector3(0.13 * bulk, 0.05, 0.13), _mat(team_color, 0.6, 0.0, 1.5))
        if s2 < 0.0:
            _shoulder_l = shoulder
            _elbow_l = elbow
        else:
            _shoulder_r = shoulder
            _elbow_r = elbow

    _gun_mount = Node3D.new()
    _gun_mount.name = "GunMount"
    _gun_mount.position = Vector3(0.095, 0.265, -0.52)
    _torso.add_child(_gun_mount)
    if not is_zombie:
        set_weapon(str(look.get("weapon_id", "rifle")))
    _apply_pose(0.0, 0.0)


# ---------------------------------------------------------------- zombie character art

func _zombie_pbr(color: Color, surface: String, roughness: float) -> StandardMaterial3D:
    var key := "zombie_%s_%s_%s" % [surface, color.to_html(), str(roughness)]
    if _material_cache.has(key):
        return _material_cache[key] as StandardMaterial3D
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = roughness
    material.metallic = 0.0
    material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
    var prefix := "zombie_skin" if surface == "skin" else ("zombie_leather" if surface == "leather" else "zombie_cloth")
    var albedo := load("res://assets/textures/%s_albedo.png" % prefix) as Texture2D
    var normal := load("res://assets/textures/%s_normal.png" % prefix) as Texture2D
    var roughness_map := load("res://assets/textures/%s_roughness.png" % prefix) as Texture2D
    if albedo != null:
        material.albedo_texture = albedo
    if normal != null:
        material.normal_enabled = true
        material.normal_texture = normal
        material.normal_scale = 0.42 if surface == "skin" else 0.58
    if roughness_map != null:
        material.roughness_texture = roughness_map
    # Object-space triplanar projection prevents obvious UV stretching across limbs.
    material.uv1_triplanar = true
    material.uv1_scale = Vector3(2.8, 2.8, 2.8) if surface == "skin" else Vector3(2.1, 2.1, 2.1)
    _material_cache[key] = material
    return material

func _zombie_register(instance: MeshInstance3D, cast_shadow: bool = false) -> void:
    instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if cast_shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    _meshes.append(instance)

func _zombie_capsule(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material, mesh_scale: Vector3 = Vector3.ONE, cast_shadow: bool = false) -> MeshInstance3D:
    var mesh := CapsuleMesh.new()
    mesh.radius = radius
    mesh.height = maxf(height, radius * 2.0 + 0.01)
    mesh.radial_segments = 24
    mesh.rings = 8
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.material_override = material
    instance.position = pos
    instance.scale = mesh_scale
    _zombie_register(instance, cast_shadow)
    parent.add_child(instance)
    return instance

func _zombie_sphere(parent: Node3D, pos: Vector3, radius: float, material: Material, mesh_scale: Vector3 = Vector3.ONE, cast_shadow: bool = false) -> MeshInstance3D:
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 32
    mesh.rings = 20
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.material_override = material
    instance.position = pos
    instance.scale = mesh_scale
    _zombie_register(instance, cast_shadow)
    parent.add_child(instance)
    return instance

func _zombie_box(parent: Node3D, pos: Vector3, size: Vector3, material: Material, rotation_value: Vector3 = Vector3.ZERO, cast_shadow: bool = false) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    var bevel := clampf(minf(size.x, minf(size.y, size.z)) * 0.16, 0.003, 0.035)
    instance.mesh = BevelMesh.box(size, bevel)
    instance.material_override = material
    instance.position = pos
    instance.rotation = rotation_value
    _zombie_register(instance, cast_shadow)
    parent.add_child(instance)
    return instance

func _build_zombie_visual(primary: Color, secondary: Color, skin_color: Color) -> void:
    var skin := _zombie_pbr(skin_color, "skin", 0.94)
    var skin_shadow := _zombie_pbr(skin_color.darkened(0.56), "skin", 0.98)
    var cloth := _zombie_pbr(primary, "cloth", 0.96)
    var cloth_dark := _zombie_pbr(primary.darkened(0.48), "cloth", 0.99)
    var cloth_light := _zombie_pbr(primary.lightened(0.22), "cloth", 0.94)
    var leather := _zombie_pbr(secondary.darkened(0.18), "leather", 0.88)
    var boot_material := _zombie_pbr(Color("#242722"), "leather", 0.83)
    var stitch := _mat(Color("#a18a64"), 0.95)
    var mouth := _mat(Color("#211b19"), 0.98)
    var eye_socket := _mat(Color("#202321"), 0.96)
    var eye_glow := _mat(Color("#c4d878"), 0.42, 0.0, 0.65)
    var tooth := _mat(Color("#c9c5a4"), 0.82)
    var bulk_factor := clampf(bulk, 0.78, 1.75)

    # Pants, belt and layered leg fabric. Each side is independently animated.
    var pelvis := Node3D.new()
    pelvis.name = "Pelvis"
    pelvis.position = Vector3(0.0, 0.94, 0.0)
    add_child(pelvis)
    _zombie_capsule(pelvis, Vector3(0.0, 0.0, 0.0), 0.18 * bulk_factor, 0.34, cloth_dark, Vector3(1.0, 0.8, 0.82), false)
    _zombie_box(pelvis, Vector3(0.0, 0.06, -0.105), Vector3(0.34 * bulk_factor, 0.065, 0.035), leather)
    _zombie_box(pelvis, Vector3(0.0, 0.06, -0.128), Vector3(0.07, 0.075, 0.025), stitch)
    for side in [-1.0, 1.0]:
        var sign_value: float = side
        var thigh := Node3D.new()
        thigh.name = "ThighL" if sign_value < 0.0 else "ThighR"
        thigh.position = Vector3(sign_value * 0.105 * bulk_factor, -0.07, 0.0)
        pelvis.add_child(thigh)
        _zombie_capsule(thigh, Vector3(0.0, -0.19, 0.0), 0.092 * bulk_factor, 0.50, cloth, Vector3(1.0, 1.0, 1.0), false)
        _zombie_box(thigh, Vector3(sign_value * 0.025, -0.19, -0.077), Vector3(0.095, 0.16, 0.022), cloth_light, Vector3(0.0, 0.0, sign_value * -0.12))
        var knee := Node3D.new()
        knee.name = "KneeL" if sign_value < 0.0 else "KneeR"
        knee.position = Vector3(0.0, -0.41, 0.0)
        thigh.add_child(knee)
        _zombie_sphere(knee, Vector3(0.0, -0.015, -0.005), 0.075 * bulk_factor, cloth_dark, Vector3(0.95, 0.78, 0.78))
        _zombie_capsule(knee, Vector3(0.0, -0.20, 0.0), 0.073 * bulk_factor, 0.44, cloth, Vector3(0.92, 1.0, 0.95), true)
        _zombie_box(knee, Vector3(0.0, -0.16, -0.067), Vector3(0.11, 0.055, 0.022), stitch)
        _zombie_sphere(knee, Vector3(0.0, -0.41, -0.065), 0.105, boot_material, Vector3(0.86, 0.48, 1.55), false)
        _zombie_box(knee, Vector3(0.0, -0.445, -0.105), Vector3(0.13, 0.025, 0.18), leather)
        if sign_value < 0.0:
            _thigh_l = thigh
            _knee_l = knee
        else:
            _thigh_r = thigh
            _knee_r = knee

    # Main torso: rounded anatomy under a torn work jacket, not a stack of cubes.
    _torso = Node3D.new()
    _torso.name = "Torso"
    _torso.position = Vector3(0.0, 1.08, 0.0)
    add_child(_torso)
    _zombie_capsule(_torso, Vector3(0.0, 0.19, 0.0), 0.215 * bulk_factor, 0.66, cloth, Vector3(1.0, 1.0, 0.78), true)
    _zombie_sphere(_torso, Vector3(0.0, 0.43, 0.0), 0.19 * bulk_factor, cloth, Vector3(1.18, 0.68, 0.82), false)
    _zombie_capsule(_torso, Vector3(0.0, -0.12, -0.012), 0.13 * bulk_factor, 0.28, skin, Vector3(1.0, 0.96, 0.52))
    # Torn openings reveal an intact, stylized rib silhouette beneath the shirt.
    for rib_y in [0.015, 0.085, 0.155]:
        for side in [-1.0, 1.0]:
            var rib := _zombie_capsule(_torso, Vector3(side * 0.075, rib_y, -0.127), 0.012 * bulk_factor, 0.15, skin_shadow, Vector3(1.0, 1.0, 0.72))
            rib.rotation.z = deg_to_rad(90.0)
    _zombie_box(_torso, Vector3(-0.135, 0.12, -0.125), Vector3(0.105, 0.21, 0.035), cloth_dark, Vector3(0.0, 0.0, -0.16))
    _zombie_box(_torso, Vector3(0.145, 0.31, -0.117), Vector3(0.11, 0.22, 0.034), cloth_light, Vector3(0.0, 0.0, 0.13))
    _zombie_box(_torso, Vector3(0.0, 0.34, -0.15), Vector3(0.045, 0.28, 0.025), leather, Vector3(0.0, 0.0, -0.20))
    _zombie_box(_torso, Vector3(0.0, 0.22, -0.169), Vector3(0.06, 0.075, 0.025), stitch)
    # Asymmetric hanging fabric strips create a readable, worn silhouette.
    _zombie_box(_torso, Vector3(-0.14, -0.10, -0.09), Vector3(0.075, 0.22, 0.025), cloth_light, Vector3(0.0, 0.0, -0.13))
    _zombie_box(_torso, Vector3(0.15, -0.12, -0.075), Vector3(0.06, 0.17, 0.024), cloth_dark, Vector3(0.0, 0.0, 0.16))

    # Neck and carefully shaped head with sockets, cheekbones, jaw and a broken hairline.
    _zombie_capsule(_torso, Vector3(0.0, 0.535, 0.0), 0.062, 0.17, skin, Vector3(1.0, 1.0, 0.92), false)
    _head = Node3D.new()
    _head.name = "Head"
    _head.position = Vector3(0.0, 0.67, -0.005)
    _torso.add_child(_head)
    _zombie_sphere(_head, Vector3(0.0, 0.015, 0.0), 0.132, skin, Vector3(0.88, 1.10, 0.93), true)
    _zombie_sphere(_head, Vector3(0.0, -0.085, -0.047), 0.086, skin, Vector3(0.88, 0.58, 0.72))
    for side in [-1.0, 1.0]:
        var sx: float = side
        _zombie_sphere(_head, Vector3(sx * 0.12, -0.015, -0.005), 0.035, skin, Vector3(0.65, 0.9, 0.72))
        _zombie_sphere(_head, Vector3(sx * 0.047, 0.027, -0.105), 0.035, eye_socket, Vector3(1.0, 0.82, 0.45))
        var eye := _zombie_sphere(_head, Vector3(sx * 0.047, 0.026, -0.124), 0.013, eye_glow, Vector3(1.0, 0.9, 0.42))
        eye.set_meta("zombie_eye", true)
        _eyes.append(eye)
        _zombie_capsule(_head, Vector3(sx * 0.047, 0.071, -0.104), 0.018, 0.07, skin_shadow, Vector3(1.0, 0.8, 0.7))
    _zombie_sphere(_head, Vector3(0.0, -0.005, -0.12), 0.031, skin, Vector3(0.72, 1.0, 0.72))
    _zombie_sphere(_head, Vector3(0.0, -0.065, -0.115), 0.044, mouth, Vector3(1.0, 0.45, 0.36))
    for tooth_x in [-0.018, 0.018]:
        _zombie_box(_head, Vector3(tooth_x, -0.058, -0.132), Vector3(0.012, 0.018, 0.008), tooth)
    # Distinct brow and forehead details; variant 2 has a darker, uneven hair cap.
    _zombie_capsule(_head, Vector3(0.0, 0.103, -0.015), 0.09, 0.07, cloth_dark if _zombie_variant % 4 == 2 else skin_shadow, Vector3(1.0, 0.55, 0.82))
    _zombie_box(_head, Vector3(0.0, 0.12, -0.076), Vector3(0.15, 0.026, 0.024), skin_shadow)
    if _zombie_variant % 4 == 1:
        _zombie_sphere(_head, Vector3(0.0, 0.015, 0.055), 0.145, cloth_dark, Vector3(1.05, 1.1, 0.92))
        _zombie_box(_head, Vector3(0.0, -0.025, -0.11), Vector3(0.18, 0.055, 0.035), cloth_dark)
    elif _zombie_variant % 4 == 3:
        _zombie_sphere(_head, Vector3(0.0, 0.10, 0.005), 0.108, leather, Vector3(1.0, 0.36, 1.0))
        _zombie_box(_head, Vector3(0.0, 0.0, -0.14), Vector3(0.10, 0.025, 0.018), cloth_light)

    # Long asymmetric arms with articulated elbows, palms and individually modelled fingers.
    for side in [-1.0, 1.0]:
        var sx: float = side
        var shoulder := Node3D.new()
        shoulder.name = "ShoulderL" if sx < 0.0 else "ShoulderR"
        shoulder.position = Vector3(sx * 0.245 * bulk_factor, 0.43, 0.0)
        _torso.add_child(shoulder)
        _zombie_sphere(shoulder, Vector3.ZERO, 0.092 * bulk_factor, cloth_dark, Vector3(1.0, 0.9, 0.95), false)
        _zombie_capsule(shoulder, Vector3(0.0, -0.145, 0.0), 0.073 * bulk_factor, 0.39, cloth, Vector3(1.0, 1.0, 0.92), true)
        _zombie_box(shoulder, Vector3(sx * -0.008, -0.16, -0.066), Vector3(0.11, 0.16, 0.018), cloth_light, Vector3(0.0, 0.0, sx * 0.10))
        var elbow := Node3D.new()
        elbow.name = "ElbowL" if sx < 0.0 else "ElbowR"
        elbow.position = Vector3(0.0, -0.30, 0.0)
        shoulder.add_child(elbow)
        _zombie_sphere(elbow, Vector3.ZERO, 0.064 * bulk_factor, skin, Vector3(1.0, 0.9, 0.95))
        _zombie_capsule(elbow, Vector3(0.0, -0.16, -0.01), 0.061 * bulk_factor, 0.37, skin, Vector3(1.0, 1.0, 0.92), true)
        _zombie_box(elbow, Vector3(0.0, -0.11, -0.062), Vector3(0.095, 0.075, 0.018), cloth_dark)
        _zombie_sphere(elbow, Vector3(0.0, -0.31, -0.015), 0.057 * bulk_factor, skin, Vector3(0.88, 0.72, 0.7))
        for finger in range(4):
            var finger_x := (float(finger) - 1.5) * 0.023
            _zombie_capsule(elbow, Vector3(finger_x, -0.385, -0.045), 0.012, 0.105 - absf(float(finger) - 1.5) * 0.012, skin, Vector3(0.86, 1.0, 0.78))
        _zombie_capsule(elbow, Vector3(-sx * 0.06, -0.33, -0.045), 0.014, 0.105, skin, Vector3(1.0, 0.9, 0.8))
        _zombie_box(elbow, Vector3(0.0, -0.34, -0.084), Vector3(0.075, 0.018, 0.014), leather)
        if sx < 0.0:
            _shoulder_l = shoulder
            _elbow_l = elbow
        else:
            _shoulder_r = shoulder
            _elbow_r = elbow

    # Brutes retain a heavier shoulder silhouette; all other variants remain leaner.
    if bulk_factor > 1.25:
        for side in [-1.0, 1.0]:
            _zombie_sphere(_torso, Vector3(side * 0.22 * bulk_factor, 0.39, 0.015), 0.13 * bulk_factor, leather, Vector3(1.0, 0.82, 0.85), false)
            _zombie_box(_torso, Vector3(side * 0.20 * bulk_factor, 0.43, -0.075), Vector3(0.12, 0.075, 0.025), cloth_light)

    # Collapse static detail meshes into one surface-multiplexed mesh per animated joint.
    # This keeps the richer model practical when a full horde is on screen.
    for part in [pelvis, _thigh_l, _thigh_r, _knee_l, _knee_r, _torso, _head, _shoulder_l, _shoulder_r, _elbow_l, _elbow_r]:
        if part != null:
            _merge_zombie_group(part)

func _merge_zombie_group(parent: Node3D) -> void:
    var source_meshes: Array[MeshInstance3D] = []
    var groups: Dictionary = {}
    var casts_shadow := false
    for child in parent.get_children():
        if not (child is MeshInstance3D):
            continue
        var source := child as MeshInstance3D
        if source.mesh == null or bool(source.get_meta("zombie_eye", false)):
            continue
        source_meshes.append(source)
        casts_shadow = casts_shadow or source.cast_shadow != GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        var material: Material = source.material_override
        if material == null:
            material = _mat(Color.WHITE, 0.9)
        var material_key: int = material.get_instance_id()
        if not groups.has(material_key):
            var surface_tool := SurfaceTool.new()
            surface_tool.begin(Mesh.PRIMITIVE_TRIANGLES)
            groups[material_key] = {"tool": surface_tool, "material": material}
        var group_data: Dictionary = groups[material_key]
        var tool: SurfaceTool = group_data["tool"]
        for surface_index in range(source.mesh.get_surface_count()):
            tool.append_from(source.mesh, surface_index, source.transform)
    if source_meshes.is_empty():
        return

    var merged_mesh := ArrayMesh.new()
    for group_data_value in groups.values():
        var group_data: Dictionary = group_data_value
        var tool: SurfaceTool = group_data["tool"]
        var surface_mesh := tool.commit()
        if surface_mesh == null:
            continue
        for surface_index in range(surface_mesh.get_surface_count()):
            var arrays: Array = surface_mesh.surface_get_arrays(surface_index)
            merged_mesh.add_surface_from_arrays(surface_mesh.surface_get_primitive_type(surface_index), arrays)
            merged_mesh.surface_set_material(merged_mesh.get_surface_count() - 1, group_data["material"])
    if merged_mesh.get_surface_count() == 0:
        return

    var merged_instance := MeshInstance3D.new()
    merged_instance.name = "MergedZombieGeometry"
    merged_instance.mesh = merged_mesh
    merged_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if casts_shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    parent.add_child(merged_instance)
    for source in source_meshes:
        _meshes.erase(source)
        parent.remove_child(source)
        source.queue_free()
    _meshes.append(merged_instance)

func set_weapon(weapon_id: String) -> void:
    if _gun != null:
        _gun.queue_free()
        _gun = null
        _muzzle = null
    if _gun_mount == null:
        return
    _gun = WeaponModels.build(weapon_id)
    _gun_mount.add_child(_gun)
    _muzzle = WeaponModels.get_muzzle(_gun)
    for node in _gun.find_children("*", "MeshInstance3D", true, false):
        var mesh_node := node as MeshInstance3D
        if mesh_node != null:
            _meshes.append(mesh_node)

func get_muzzle_position() -> Vector3:
    if _muzzle != null and _muzzle.is_inside_tree():
        return _muzzle.global_position
    return global_position + Vector3(0.0, 1.4, 0.0)

func get_head_position() -> Vector3:
    if _head != null and _head.is_inside_tree():
        return _head.global_position
    return global_position + Vector3(0.0, 1.7, 0.0)

# ---------------------------------------------------------------- helpers

func _register(instance: MeshInstance3D) -> void:
    instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    _meshes.append(instance)

func _add_box(parent: Node3D, pos: Vector3, size: Vector3, material: Material) -> MeshInstance3D:
    var instance := MeshInstance3D.new()
    var smallest: float = minf(size.x, minf(size.y, size.z))
    instance.mesh = BevelMesh.box(size, clampf(smallest * 0.22, 0.004, 0.025))
    instance.material_override = material
    instance.position = pos
    _register(instance)
    parent.add_child(instance)
    return instance

func _add_capsule(parent: Node3D, pos: Vector3, radius: float, height: float, material: Material) -> MeshInstance3D:
    var mesh := CapsuleMesh.new()
    mesh.radius = radius
    mesh.height = maxf(height, radius * 2.0 + 0.01)
    mesh.radial_segments = 10
    mesh.rings = 4
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.material_override = material
    instance.position = pos
    _register(instance)
    parent.add_child(instance)
    return instance

func _add_sphere(parent: Node3D, pos: Vector3, radius: float, material: Material, mesh_scale: Vector3) -> MeshInstance3D:
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 12
    mesh.rings = 6
    var instance := MeshInstance3D.new()
    instance.mesh = mesh
    instance.material_override = material
    instance.position = pos
    instance.scale = mesh_scale
    _register(instance)
    parent.add_child(instance)
    return instance

# ---------------------------------------------------------------- animation

func flash() -> void:
    _flash_left = 0.09
    var overlay := _get_flash_material()
    for instance in _meshes:
        if is_instance_valid(instance):
            instance.material_overlay = overlay

func attack_swing() -> void:
    _attack_swing = 1.0

func animate(delta: float, speed: float, aim_weight: float) -> void:
    if _is_dead:
        return
    _aim_weight = lerpf(_aim_weight, aim_weight, 1.0 - exp(-10.0 * delta))
    var stride: float = 4.2 + speed * 1.6
    _phase = fposmod(_phase + delta * stride, TAU)
    var target_amp: float = clampf(speed / 3.6, 0.0, 1.0)
    _swing_amp = lerpf(_swing_amp, target_amp, 1.0 - exp(-10.0 * delta))
    _attack_swing = maxf(0.0, _attack_swing - delta * 3.2)
    _apply_pose(_phase, _swing_amp)
    if _flash_left > 0.0:
        _flash_left -= delta
        if _flash_left <= 0.0:
            for instance in _meshes:
                if is_instance_valid(instance):
                    instance.material_overlay = null

func _apply_pose(phase: float, amp: float) -> void:
    if _torso == null:
        return
    var swing: float = sin(phase) * 0.8 * amp
    _thigh_l.rotation.x = swing
    _thigh_r.rotation.x = -swing
    _knee_l.rotation.x = -maxf(0.0, sin(phase + 1.4)) * 0.95 * amp
    _knee_r.rotation.x = -maxf(0.0, -sin(phase + 1.4)) * 0.95 * amp
    _torso.position.y = 1.1 + absf(sin(phase)) * 0.035 * amp
    if kind == "zombie":
        var lurch: float = sin(phase * 0.5) * 0.12 * amp
        _torso.rotation.x = -0.28 - _attack_swing * 0.3
        _torso.rotation.z = lurch
        _head.rotation.z = -lurch * 1.6
        _head.rotation.x = 0.2
        var reach: float = 1.35 + sin(phase * 1.0) * 0.12 * amp - _attack_swing * 0.9
        _shoulder_l.rotation = Vector3(reach, 0.12, 0.05)
        _shoulder_r.rotation = Vector3(reach + (0.15 if _zombie_variant % 2 == 0 else -0.25), -0.12, -0.05)
        _elbow_l.rotation.x = 0.15 + _attack_swing * 0.8
        _elbow_r.rotation.x = 0.25 + _attack_swing * 0.8
        return
    # Soldier: arms swing when running, raise the weapon when aiming.
    var aim: float = _aim_weight
    var run_l: float = -swing * 0.9
    var run_r: float = swing * 0.9
    _shoulder_r.rotation = Vector3(lerpf(run_r + 0.2, 0.95, aim), lerpf(0.0, 0.3, aim), 0.0)
    _shoulder_l.rotation = Vector3(lerpf(run_l + 0.2, 1.05, aim), lerpf(0.0, -0.55, aim), 0.0)
    _elbow_r.rotation.x = lerpf(0.35, 0.55, aim)
    _elbow_l.rotation.x = lerpf(0.35, 0.75, aim)
    _torso.rotation.x = lerpf(0.05, 0.0, aim)
    _torso.rotation.y = lerpf(0.0, -0.18, aim)
    _head.rotation.y = lerpf(0.0, 0.18, aim)

func play_death(push_direction: Vector3) -> void:
    _is_dead = true
    var local_push: Vector3 = global_transform.basis.inverse() * push_direction
    # Fall backwards when shot from the front, forwards when shot from behind.
    var fall_sign: float = -1.0 if local_push.z >= 0.0 else 1.0
    var side_tilt: float = clampf(local_push.x, -1.0, 1.0) * 0.35
    var tween := create_tween()
    tween.set_parallel(true)
    tween.tween_property(self, "rotation:x", fall_sign * PI * 0.5, 0.55).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    tween.tween_property(self, "rotation:z", side_tilt, 0.55)
    tween.tween_property(self, "position:y", position.y + 0.12, 0.55)
    if _shoulder_l != null:
        tween.tween_property(_shoulder_l, "rotation:x", 0.2, 0.4)
        tween.tween_property(_shoulder_r, "rotation:x", 0.2, 0.4)
    for eye in _eyes:
        if is_instance_valid(eye):
            eye.visible = false

func revive_pose() -> void:
    _is_dead = false
    rotation = Vector3.ZERO

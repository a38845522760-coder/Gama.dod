extends SoldierModel
class_name ProductionZombieModel

## Zombie body built from the Iron Yard production library: real GLB assemblies
## (res://production_library/models), the library's animation clips (idle / walk / run / attack /
## hit / death, made by IronYardAnimationFactory), the "infected hide" PBR textures and glowing
## eyes so the horde can be spotted in the dark map.
##
## It exposes the same interface as SoldierModel, so Bot does not care which one it drives.
## If a GLB cannot be loaded the model silently falls back to the old procedural zombie.

const MODEL_DIR: String = "res://production_library/models/"
const TEXTURE_DIR: String = "res://production_library/textures/"
## Every zombie is normalised to this height (metres) before the profile's own scale is applied.
const TARGET_HEIGHT: float = 1.82
const VISIBILITY_END: float = 95.0
const ATTACK_RATE: float = 1.7
const HIT_RATE: float = 1.8

## Which GLB assemblies a bot profile may use (one is picked per zombie for variety).
const PROFILE_MODELS: Dictionary = {
    "walker": ["zombie_shambler", "zombie_shambler", "zombie_crawler"],
    "runner": ["zombie_lab_mutant"],
    "sprinter": ["zombie_sprinter"],
    "brute": ["zombie_brute"],
    "spitter": ["zombie_spore"],
    "pyro": ["zombie_armored"],
    "inferno": ["zombie_apex_boss"],
    "tyrant": ["zombie_apex_boss"],
}
## Glow colour of the eyes / reactor parts per profile.
const GLOW_COLORS: Dictionary = {
    "walker": Color("#ffb347"),
    "runner": Color("#7fe8ff"),
    "sprinter": Color("#ff6a3d"),
    "brute": Color("#ff3d2e"),
    "spitter": Color("#9dff4a"),
    "pyro": Color("#ff8a2a"),
    "inferno": Color("#ff5a1a"),
    "tyrant": Color("#ff2a2a"),
}
const GLOW_NAME_PARTS: Array[String] = ["eye", "sporebulb", "sensorvisor", "reactorcore"]
## Tracks every clip must key so a clip never leaves a limb stuck in the previous pose.
const NEUTRAL_TRACKS: Array = [
    ["Root", "position"],
    ["Root/Pelvis/Torso", "rotation"],
    ["Root/Pelvis/Torso/Head", "rotation"],
    ["Root/Pelvis/Torso/Arm_L", "rotation"],
    ["Root/Pelvis/Torso/Arm_R", "rotation"],
    ["Root/Pelvis/Torso/Arm_L/Forearm_L", "rotation"],
    ["Root/Pelvis/Torso/Arm_R/Forearm_R", "rotation"],
    ["Root/Pelvis/Leg_L", "rotation"],
    ["Root/Pelvis/Leg_R", "rotation"],
]

static var _scene_cache: Dictionary = {}
static var _hide_material: StandardMaterial3D = null
static var _glow_cache: Dictionary = {}

var model_id: String = ""
var _procedural: bool = false
var _fit: Node3D
var _body: Node3D
var _player: AnimationPlayer
var _current: String = ""
var _attack_left: float = 0.0
var _hit_left: float = 0.0
var _hit_cooldown: float = 0.0
var _glow_meshes: Array[MeshInstance3D] = []

# ---------------------------------------------------------------- static helpers

static func pick_model_id(profile_id: String, variant: int) -> String:
    var options: Array = PROFILE_MODELS.get(profile_id, ["zombie_shambler"])
    return str(options[absi(variant) % options.size()])

static func _scene_for(id: String) -> PackedScene:
    if _scene_cache.has(id):
        return _scene_cache[id]
    var path: String = MODEL_DIR + id + ".glb"
    var scene: PackedScene = null
    if ResourceLoader.exists(path):
        scene = load(path) as PackedScene
    _scene_cache[id] = scene
    return scene

## True when the production GLB for this profile can be loaded.
static func is_available(profile_id: String) -> bool:
    return _scene_for(pick_model_id(profile_id, 0)) != null

static func _load_texture(file_name: String) -> Texture2D:
    var path: String = TEXTURE_DIR + file_name
    if ResourceLoader.exists(path):
        return load(path) as Texture2D
    return null

static func _get_hide_material() -> StandardMaterial3D:
    if _hide_material != null:
        return _hide_material
    var material := StandardMaterial3D.new()
    material.vertex_color_use_as_albedo = true
    material.roughness = 0.9
    material.metallic = 0.0
    var albedo: Texture2D = _load_texture("infected_hide_albedo.webp")
    var normal: Texture2D = _load_texture("infected_hide_normal.webp")
    var rough: Texture2D = _load_texture("infected_hide_roughness.png")
    if albedo != null:
        material.albedo_texture = albedo
    if normal != null:
        material.normal_enabled = true
        material.normal_texture = normal
        material.normal_scale = 0.7
    if rough != null:
        material.roughness_texture = rough
    # Object-space triplanar: the skin sticks to the body instead of sliding while it walks.
    material.uv1_triplanar = true
    material.uv1_world_triplanar = false
    material.uv1_scale = Vector3(1.6, 1.6, 1.6)
    _hide_material = material
    return material

static func _get_glow_material(color: Color) -> StandardMaterial3D:
    var key: String = color.to_html()
    if _glow_cache.has(key):
        return _glow_cache[key]
    var material := StandardMaterial3D.new()
    material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    material.albedo_color = color
    material.emission_enabled = true
    material.emission = color
    material.emission_energy_multiplier = 3.2
    _glow_cache[key] = material
    return material

# ---------------------------------------------------------------- build

func build(look: Dictionary) -> void:
    kind = "zombie"
    bulk = float(look.get("bulk", 1.0))
    _zombie_variant = int(look.get("zombie_variant", 0))
    scale = Vector3.ONE * float(look.get("scale", 1.0))
    var profile_id: String = str(look.get("profile_id", "walker"))
    model_id = pick_model_id(profile_id, _zombie_variant)
    var scene: PackedScene = _scene_for(model_id)
    var instance: Node3D = null
    if scene != null:
        instance = scene.instantiate() as Node3D
    if instance == null:
        push_warning("ProductionZombieModel: %s could not be loaded; using the procedural zombie." % model_id)
        _procedural = true
        super.build(look)
        return
    _fit = Node3D.new()
    _fit.name = "Fit"
    add_child(_fit)
    _body = instance
    _fit.add_child(_body)
    # glTF assemblies face +Z, bots face -Z.
    _fit.rotation.y = PI
    _fit_to_height()
    _style_meshes(profile_id)
    _head = _body.get_node_or_null("Root/Pelvis/Torso/Head") as Node3D
    _player = IronYardAnimationFactory.attach_zombie_animations(_body, "idle")
    for clip_name in ["idle", "walk", "run", "attack", "hit"]:
        var clip: Animation = _player.get_animation(clip_name)
        if clip != null:
            _complete_clip(clip)
    # Desynchronise the horde so zombies do not all sway in unison.
    _player.seek(randf() * 2.0, true)
    _current = "idle"

func _fit_to_height() -> void:
    var box: AABB = _body_aabb(_body)
    if box.size.y < 0.1:
        return
    var factor: float = TARGET_HEIGHT / box.size.y
    _fit.scale = Vector3.ONE * factor
    _fit.position.y = -box.position.y * factor

func _body_aabb(root: Node3D) -> AABB:
    var result := AABB()
    var first: bool = true
    for node in root.find_children("*", "MeshInstance3D", true, false):
        var mesh_node := node as MeshInstance3D
        if mesh_node == null or mesh_node.mesh == null:
            continue
        var to_root := Transform3D.IDENTITY
        var current: Node = mesh_node
        while current != null and current != root:
            if current is Node3D:
                to_root = (current as Node3D).transform * to_root
            current = current.get_parent()
        var box: AABB = to_root * mesh_node.mesh.get_aabb()
        if first:
            result = box
            first = false
        else:
            result = result.merge(box)
    return result

func _style_meshes(profile_id: String) -> void:
    var hide: StandardMaterial3D = _get_hide_material()
    var glow: StandardMaterial3D = _get_glow_material(GLOW_COLORS.get(profile_id, Color("#ffb347")))
    for node in _body.find_children("*", "MeshInstance3D", true, false):
        var mesh_node := node as MeshInstance3D
        if mesh_node == null:
            continue
        var lower: String = String(mesh_node.name).to_lower()
        var is_glow: bool = false
        for part in GLOW_NAME_PARTS:
            if lower.contains(part):
                is_glow = true
                break
        mesh_node.material_override = glow if is_glow else hide
        mesh_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        mesh_node.visibility_range_end = VISIBILITY_END
        _meshes.append(mesh_node)
        if is_glow and lower.contains("eye"):
            _eyes.append(mesh_node)

static func _complete_clip(clip: Animation) -> void:
    for spec in NEUTRAL_TRACKS:
        var track_path := NodePath("%s:%s" % [str(spec[0]), str(spec[1])])
        if clip.find_track(track_path, Animation.TYPE_VALUE) != -1:
            continue
        var track: int = clip.add_track(Animation.TYPE_VALUE)
        clip.track_set_path(track, track_path)
        clip.track_insert_key(track, 0.0, Vector3.ZERO)

# ---------------------------------------------------------------- SoldierModel interface

func set_weapon(weapon_id: String) -> void:
    if _procedural:
        super.set_weapon(weapon_id)

func set_crouch(amount: float) -> void:
    _crouch = clampf(amount, 0.0, 1.0)

func get_hand_positions() -> Array[Vector3]:
    if _procedural:
        return super.get_hand_positions()
    var result: Array[Vector3] = []
    return result

func get_grip_targets() -> Array[Vector3]:
    if _procedural:
        return super.get_grip_targets()
    var result: Array[Vector3] = []
    return result

func flash() -> void:
    if _procedural:
        super.flash()
        return
    _flash_left = 0.09
    var overlay := _get_flash_material()
    for instance in _meshes:
        if is_instance_valid(instance):
            instance.material_overlay = overlay
    if _player != null and not _is_dead and _hit_cooldown <= 0.0 and _attack_left <= 0.0:
        _hit_left = 0.3
        _hit_cooldown = 0.9

func attack_swing() -> void:
    if _procedural:
        super.attack_swing()
        return
    if _player == null or _is_dead:
        return
    _attack_left = 0.85 / ATTACK_RATE
    _hit_left = 0.0
    _current = "attack"
    _player.speed_scale = ATTACK_RATE
    _player.play("attack", 0.08)

func animate(delta: float, speed: float, aim_weight: float) -> void:
    if _procedural:
        super.animate(delta, speed, aim_weight)
        return
    if _player == null or _is_dead:
        return
    _attack_left = maxf(0.0, _attack_left - delta)
    _hit_left = maxf(0.0, _hit_left - delta)
    _hit_cooldown = maxf(0.0, _hit_cooldown - delta)
    if _flash_left > 0.0:
        _flash_left -= delta
        if _flash_left <= 0.0:
            for instance in _meshes:
                if is_instance_valid(instance):
                    instance.material_overlay = null
    var wanted: String = "idle"
    var rate: float = 1.0
    if _attack_left > 0.0:
        wanted = "attack"
        rate = ATTACK_RATE
    elif _hit_left > 0.0:
        wanted = "hit"
        rate = HIT_RATE
    elif speed > 4.3:
        wanted = "run"
        rate = clampf(speed / 5.6, 0.6, 1.9)
    elif speed > 0.35:
        wanted = "walk"
        rate = clampf(speed / 2.1, 0.5, 2.2)
    if wanted != _current:
        _current = wanted
        _player.play(wanted, 0.18)
    _player.speed_scale = rate

func play_death(push_direction: Vector3) -> void:
    if _procedural:
        super.play_death(push_direction)
        return
    _is_dead = true
    for instance in _meshes:
        if is_instance_valid(instance):
            instance.material_overlay = null
    if _player != null:
        _player.speed_scale = 1.0
        _player.play("death", 0.1)
    var local_push: Vector3 = global_transform.basis.inverse() * push_direction
    # Fall backwards when shot from the front, forwards when shot from behind.
    var fall_sign: float = -1.0 if local_push.z >= 0.0 else 1.0
    var side_tilt: float = clampf(local_push.x, -1.0, 1.0) * 0.35
    var tween := create_tween()
    tween.set_parallel(true)
    tween.tween_property(self, "rotation:x", fall_sign * PI * 0.5, 0.6).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    tween.tween_property(self, "rotation:z", side_tilt, 0.6)
    tween.tween_property(self, "position:y", position.y + 0.1, 0.6)
    for eye in _eyes:
        if is_instance_valid(eye):
            eye.visible = false

func revive_pose() -> void:
    if _procedural:
        super.revive_pose()
        return
    _is_dead = false
    rotation = Vector3.ZERO
    _current = "idle"
    if _player != null:
        _player.play("idle", 0.2)
    for eye in _eyes:
        if is_instance_valid(eye):
            eye.visible = true

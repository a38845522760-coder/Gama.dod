extends Control
class_name TouchActionButton

@export var action_name: StringName = &""
@export var icon_type: StringName = &"fire"
@export var accent_color: Color = Color(0.38, 0.86, 0.96, 1.0)
@export var base_fill_color: Color = Color(0.05, 0.09, 0.13, 0.56)
@export var pressed_fill_color: Color = Color(0.14, 0.30, 0.38, 0.84)

var _touch_index: int = -1
var _mouse_pressed: bool = false
var _is_pressed: bool = false
var _press_blend: float = 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	focus_mode = Control.FOCUS_NONE
	queue_redraw()

func _process(delta: float) -> void:
	var target := 1.0 if _is_pressed else 0.0
	if not is_equal_approx(_press_blend, target):
		_press_blend = move_toward(_press_blend, target, delta * 14.0)
		queue_redraw()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and _touch_index == -1:
			if _is_point_inside_circle(event.position):
				_touch_index = event.index
				_set_pressed(true)
				accept_event()
		elif not event.pressed and event.index == _touch_index:
			_touch_index = -1
			_set_pressed(false)
			accept_event()
	elif event is InputEventScreenDrag and event.index == _touch_index:
		accept_event()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			if _is_point_inside_circle(event.position):
				_mouse_pressed = true
				_set_pressed(true)
				accept_event()
		elif _mouse_pressed:
			_mouse_pressed = false
			_set_pressed(false)
			accept_event()

func _is_point_inside_circle(point: Vector2) -> bool:
	var center := size * 0.5
	var radius := minf(size.x, size.y) * 0.5
	return point.distance_to(center) <= radius * 1.08

func _set_pressed(pressed: bool) -> void:
	if _is_pressed == pressed:
		return
	_is_pressed = pressed
	if action_name != &"":
		if _is_pressed:
			Input.action_press(action_name)
		else:
			Input.action_release(action_name)
	queue_redraw()

func _exit_tree() -> void:
	if _is_pressed and action_name != &"":
		Input.action_release(action_name)
	_is_pressed = false
	_touch_index = -1
	_mouse_pressed = false

func _draw() -> void:
	var center := size * 0.5
	var max_radius := minf(size.x, size.y) * 0.48
	var radius := max_radius * lerpf(1.0, 0.92, _press_blend)

	# Soft outer drop shadow
	draw_circle(center + Vector2(0.0, 2.5), radius + 2.0, Color(0.0, 0.0, 0.0, 0.34))

	# Frosted glassmorphic circular body
	var fill_color := base_fill_color.lerp(pressed_fill_color, _press_blend)
	draw_circle(center, radius, fill_color)

	# Subtle inner highlight ring
	draw_arc(center, radius * 0.84, 0.0, TAU, 48, Color(1.0, 1.0, 1.0, lerpf(0.10, 0.24, _press_blend)), 1.5, true)

	# Outer tactical glowing ring
	var ring_color := accent_color
	ring_color.a = lerpf(0.72, 1.0, _press_blend)
	draw_arc(center, radius, 0.0, TAU, 56, ring_color, lerpf(2.4, 3.6, _press_blend), true)

	# Tactical segmented outer ticks
	for i in range(4):
		var angle := float(i) * PI * 0.5 + PI * 0.25
		var p1 := center + Vector2.from_angle(angle) * (radius * 0.92)
		var p2 := center + Vector2.from_angle(angle) * (radius * 1.02)
		draw_line(p1, p2, ring_color, 2.0, true)

	var icon_color := Color(0.95, 0.98, 1.0, lerpf(0.90, 1.0, _press_blend))
	_draw_icon(center, radius * 0.50, icon_color, ring_color)

func _draw_icon(center: Vector2, r: float, color: Color, accent: Color) -> void:
	var lw := clampf(r * 0.16, 2.2, 4.0)
	match icon_type:
		&"fire":
			# Precision crosshair + muzzle core dot
			draw_arc(center, r * 0.66, 0.0, TAU, 36, color, lw, true)
			draw_circle(center, r * 0.18, accent)
			for i in range(4):
				var dir := Vector2.from_angle(float(i) * PI * 0.5)
				draw_line(center + dir * (r * 0.38), center + dir * (r * 1.02), color, lw, true)
		&"jump":
			# Double upward leap chevrons + ground arc
			var w := r * 0.68
			var h := r * 0.36
			var top_y := center.y - r * 0.42
			draw_polyline(PackedVector2Array([
				Vector2(center.x - w, top_y + h),
				Vector2(center.x, top_y),
				Vector2(center.x + w, top_y + h),
			]), color, lw * 1.15, true)
			var mid_y := center.y + r * 0.02
			draw_polyline(PackedVector2Array([
				Vector2(center.x - w * 0.78, mid_y + h * 0.85),
				Vector2(center.x, mid_y),
				Vector2(center.x + w * 0.78, mid_y + h * 0.85),
			]), accent, lw, true)
			draw_line(Vector2(center.x - r * 0.65, center.y + r * 0.66), Vector2(center.x + r * 0.65, center.y + r * 0.66), Color(color.r, color.g, color.b, 0.55), lw * 0.8, true)
		&"crouch":
			# Downward stance chevron + low profile bar
			var w := r * 0.68
			var h := r * 0.42
			var top_y := center.y - r * 0.44
			draw_polyline(PackedVector2Array([
				Vector2(center.x - w, top_y),
				Vector2(center.x, top_y + h),
				Vector2(center.x + w, top_y),
			]), color, lw * 1.1, true)
			draw_line(Vector2(center.x - r * 0.62, center.y + r * 0.25), Vector2(center.x + r * 0.62, center.y + r * 0.25), accent, lw * 1.1, true)
			draw_line(Vector2(center.x - r * 0.42, center.y + r * 0.58), Vector2(center.x + r * 0.42, center.y + r * 0.58), Color(color.r, color.g, color.b, 0.6), lw * 0.9, true)
		&"sprint":
			# Double forward speed chevrons
			var h := r * 0.54
			var w := r * 0.36
			var x1 := center.x - r * 0.36
			draw_polyline(PackedVector2Array([
				Vector2(x1, center.y - h),
				Vector2(x1 + w, center.y),
				Vector2(x1, center.y + h),
			]), Color(color.r, color.g, color.b, 0.72), lw * 1.05, true)
			var x2 := center.x + r * 0.06
			draw_polyline(PackedVector2Array([
				Vector2(x2, center.y - h),
				Vector2(x2 + w, center.y),
				Vector2(x2, center.y + h),
			]), color, lw * 1.15, true)
		&"interact":
			# Tactical diamond + center action node
			var d := r * 0.72
			var pts := PackedVector2Array([
				center + Vector2(0.0, -d),
				center + Vector2(d, 0.0),
				center + Vector2(0.0, d),
				center + Vector2(-d, 0.0),
				center + Vector2(0.0, -d),
			])
			draw_polyline(pts, color, lw, true)
			draw_circle(center, r * 0.24, accent)
		&"scan":
			# Concentric radar pulse arcs + emitter dot
			draw_circle(center + Vector2(-r * 0.25, r * 0.25), r * 0.16, accent)
			draw_arc(center + Vector2(-r * 0.25, r * 0.25), r * 0.55, -PI * 0.55, 0.05, 20, color, lw, true)
			draw_arc(center + Vector2(-r * 0.25, r * 0.25), r * 0.95, -PI * 0.58, 0.08, 24, Color(color.r, color.g, color.b, 0.72), lw, true)
		_:
			draw_circle(center, r * 0.45, color)

extends Control
class_name VirtualJoystick

signal vector_changed(value: Vector2)

@export_range(40.0, 120.0, 1.0) var radius: float = 74.0
@export_range(10.0, 50.0, 1.0) var knob_radius: float = 27.0
var _touch_index: int = -1
var _mouse_active: bool = false
var _value: Vector2 = Vector2.ZERO
var _knob_position: Vector2 = Vector2.ZERO

func _ready() -> void:
    custom_minimum_size = Vector2(radius * 2.4, radius * 2.4)
    mouse_filter = Control.MOUSE_FILTER_STOP
    _knob_position = size * 0.5
    queue_redraw()

func _notification(what: int) -> void:
    if what == NOTIFICATION_RESIZED and _touch_index == -1 and not _mouse_active:
        _knob_position = size * 0.5
        queue_redraw()

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and _touch_index == -1:
            _touch_index = event.index
            _update_from_position(event.position)
        elif not event.pressed and event.index == _touch_index:
            _touch_index = -1
            _set_value(Vector2.ZERO)
    elif event is InputEventScreenDrag and event.index == _touch_index:
        _update_from_position(event.position)
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        _mouse_active = event.pressed
        if _mouse_active:
            _update_from_position(event.position)
        else:
            _set_value(Vector2.ZERO)
    elif event is InputEventMouseMotion and _mouse_active:
        _update_from_position(event.position)

func _update_from_position(point: Vector2) -> void:
    var center := size * 0.5
    var offset := point - center
    _set_value(offset / maxf(radius, 1.0))

func _set_value(value: Vector2) -> void:
    _value = value.limit_length(1.0)
    _knob_position = size * 0.5 + _value * radius
    vector_changed.emit(_value)
    queue_redraw()

func _draw() -> void:
    var center := size * 0.5
    draw_circle(center, radius, Color(0.04, 0.08, 0.11, 0.42))
    draw_arc(center, radius, 0.0, TAU, 48, Color(0.55, 0.75, 0.82, 0.52), 2.0)
    draw_circle(_knob_position, knob_radius, Color(0.50, 0.76, 0.84, 0.72))
    draw_arc(_knob_position, knob_radius, 0.0, TAU, 36, Color(0.9, 0.97, 1.0, 0.85), 2.0)

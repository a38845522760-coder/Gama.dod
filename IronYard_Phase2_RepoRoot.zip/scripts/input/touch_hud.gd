extends CanvasLayer
class_name TouchHUD

@export var always_show_for_testing: bool = false
const JOYSTICK_SCRIPT := preload("res://scripts/input/virtual_joystick.gd")
const LOOK_SCRIPT := preload("res://scripts/input/touch_look_area.gd")
const ACTION_BUTTON_SCRIPT := preload("res://scripts/input/touch_action_button.gd")
var _root: Control
var _joystick: Control

func _ready() -> void:
	var is_mobile := OS.has_feature("android") or OS.has_feature("ios")
	if not is_mobile and not always_show_for_testing:
		return
	_build_controls()
	var players := get_tree().get_nodes_in_group("player_controller")
	if not players.is_empty():
		var look_area := _root.get_node_or_null("LookArea")
		if look_area != null and look_area.has_signal("look_delta"):
			look_area.connect("look_delta", Callable(players[0], "add_look_delta"))

func _build_controls() -> void:
	_root = Control.new()
	_root.name = "TouchRoot"
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_PASS
	add_child(_root)

	var look_area: Control = LOOK_SCRIPT.new()
	look_area.name = "LookArea"
	look_area.anchor_left = 0.48
	look_area.anchor_top = 0.0
	look_area.anchor_right = 1.0
	look_area.anchor_bottom = 1.0
	look_area.offset_left = 0.0
	look_area.offset_top = 0.0
	look_area.offset_right = 0.0
	look_area.offset_bottom = 0.0
	_root.add_child(look_area)

	_joystick = JOYSTICK_SCRIPT.new()
	_joystick.name = "MoveJoystick"
	_joystick.anchor_left = 0.0
	_joystick.anchor_top = 1.0
	_joystick.anchor_right = 0.0
	_joystick.anchor_bottom = 1.0
	_joystick.offset_left = 26.0
	_joystick.offset_top = -206.0
	_joystick.offset_right = 206.0
	_joystick.offset_bottom = -26.0
	_joystick.connect("vector_changed", Callable(self, "_on_joystick_changed"))
	_root.add_child(_joystick)

	# Ergonomic right-thumb circular icon buttons (Fire, Scope/ADS, Reload, Jump, Crouch/Slide, Prone, Sprint, Interact, Scan)
	_add_action_button(&"activate_equipment", &"fire", Vector2(-146.0, -150.0), Vector2(112.0, 112.0), Color(1.0, 0.56, 0.22, 1.0), Color(0.10, 0.07, 0.05, 0.62), Color(0.45, 0.20, 0.08, 0.88))
	_add_action_button(&"aim", &"aim", Vector2(-126.0, -258.0), Vector2(82.0, 82.0), Color(0.46, 0.92, 0.98, 1.0))
	_add_action_button(&"reload", &"reload", Vector2(-242.0, -210.0), Vector2(76.0, 76.0), Color(0.98, 0.78, 0.32, 1.0))
	_add_action_button(&"jump", &"jump", Vector2(-220.0, -304.0), Vector2(78.0, 78.0), Color(0.38, 0.88, 0.98, 1.0))
	_add_action_button(&"crouch", &"crouch", Vector2(-246.0, -112.0), Vector2(76.0, 76.0), Color(0.54, 0.78, 0.96, 1.0))
	_add_action_button(&"prone", &"prone", Vector2(-336.0, -112.0), Vector2(72.0, 72.0), Color(0.68, 0.74, 0.92, 1.0))
	_add_action_button(&"sprint", &"sprint", Vector2(-336.0, -202.0), Vector2(72.0, 72.0), Color(0.42, 0.92, 0.78, 1.0))
	_add_action_button(&"interact", &"interact", Vector2(-126.0, -352.0), Vector2(70.0, 70.0), Color(0.95, 0.80, 0.34, 1.0))
	_add_action_button(&"scan", &"scan", Vector2(-218.0, -392.0), Vector2(68.0, 68.0), Color(0.36, 0.84, 0.96, 1.0))

func _add_action_button(
	action: StringName,
	icon_type: StringName,
	offset: Vector2,
	dimensions: Vector2,
	accent: Color,
	base_fill: Color = Color(0.05, 0.09, 0.13, 0.56),
	pressed_fill: Color = Color(0.14, 0.30, 0.38, 0.84)
) -> void:
	var button := ACTION_BUTTON_SCRIPT.new()
	button.name = "Btn_" + String(action)
	button.action_name = action
	button.icon_type = icon_type
	button.accent_color = accent
	button.base_fill_color = base_fill
	button.pressed_fill_color = pressed_fill
	button.custom_minimum_size = dimensions
	button.anchor_left = 1.0
	button.anchor_top = 1.0
	button.anchor_right = 1.0
	button.anchor_bottom = 1.0
	button.offset_left = offset.x
	button.offset_top = offset.y
	button.offset_right = offset.x + dimensions.x
	button.offset_bottom = offset.y + dimensions.y
	_root.add_child(button)

func _on_joystick_changed(value: Vector2) -> void:
	_set_action_strength("move_left", maxf(0.0, -value.x))
	_set_action_strength("move_right", maxf(0.0, value.x))
	_set_action_strength("move_forward", maxf(0.0, -value.y))
	_set_action_strength("move_backward", maxf(0.0, value.y))

func _set_action_strength(action: StringName, strength: float) -> void:
	if strength > 0.03:
		Input.action_press(action, strength)
	else:
		Input.action_release(action)

func _exit_tree() -> void:
	for action in ["move_left", "move_right", "move_forward", "move_backward", "jump", "sprint", "interact", "scan", "crouch", "prone", "aim", "reload", "activate_equipment"]:
		Input.action_release(action)

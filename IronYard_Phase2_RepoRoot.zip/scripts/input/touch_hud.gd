extends CanvasLayer
class_name TouchHUD

@export var always_show_for_testing: bool = false
const JOYSTICK_SCRIPT := preload("res://scripts/input/virtual_joystick.gd")
const LOOK_SCRIPT := preload("res://scripts/input/touch_look_area.gd")
var _root: Control
var _joystick: Control

func _ready() -> void:
    var is_mobile := OS.has_feature("android") or OS.has_feature("ios")
    if not is_mobile and not always_show_for_testing:
        return
    _build_controls()
    var players := get_tree().get_nodes_in_group("player_controller")
    if not players.is_empty():
        var look_area := _root.get_node_or_null("LookArea")
        if look_area != null and look_area.has_signal("look_delta"):
            look_area.connect("look_delta", Callable(players[0], "add_look_delta"))

func _build_controls() -> void:
    _root = Control.new()
    _root.name = "TouchRoot"
    _root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _root.mouse_filter = Control.MOUSE_FILTER_PASS
    add_child(_root)

    var look_area: Control = LOOK_SCRIPT.new()
    look_area.name = "LookArea"
    look_area.anchor_left = 0.48
    look_area.anchor_top = 0.0
    look_area.anchor_right = 1.0
    look_area.anchor_bottom = 1.0
    look_area.offset_left = 0.0
    look_area.offset_top = 0.0
    look_area.offset_right = 0.0
    look_area.offset_bottom = 0.0
    _root.add_child(look_area)

    _joystick = JOYSTICK_SCRIPT.new()
    _joystick.name = "MoveJoystick"
    _joystick.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    _joystick.position = Vector2(24.0, -196.0)
    _joystick.size = Vector2(180.0, 180.0)
    _joystick.connect("vector_changed", Callable(self, "_on_joystick_changed"))
    _root.add_child(_joystick)

    _add_action_button("JUMP", "jump", Vector2(-126.0, -204.0), Vector2(94.0, 94.0))
    _add_action_button("SPRINT", "sprint", Vector2(-236.0, -112.0), Vector2(94.0, 68.0))
    _add_action_button("USE", "interact", Vector2(-126.0, -94.0), Vector2(94.0, 68.0))
    _add_action_button("SCAN", "scan", Vector2(-236.0, -204.0), Vector2(94.0, 68.0))
    _add_action_button("CROUCH", "crouch", Vector2(-236.0, -36.0), Vector2(94.0, 68.0))
    _add_action_button("ACT", "activate_equipment", Vector2(-126.0, -36.0), Vector2(94.0, 68.0))

func _add_action_button(caption: String, action: String, offset: Vector2, dimensions: Vector2) -> void:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = dimensions
    button.size = dimensions
    button.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    button.position = offset
    button.focus_mode = Control.FOCUS_NONE
    button.modulate = Color(0.76, 0.91, 0.96, 0.78)
    button.button_down.connect(_on_action_button_down.bind(action))
    button.button_up.connect(_on_action_button_up.bind(action))
    _root.add_child(button)

func _on_action_button_down(action: String) -> void:
    Input.action_press(action)

func _on_action_button_up(action: String) -> void:
    Input.action_release(action)

func _on_joystick_changed(value: Vector2) -> void:
    _set_action_strength("move_left", maxf(0.0, -value.x))
    _set_action_strength("move_right", maxf(0.0, value.x))
    _set_action_strength("move_forward", maxf(0.0, -value.y))
    _set_action_strength("move_backward", maxf(0.0, value.y))

func _set_action_strength(action: StringName, strength: float) -> void:
    if strength > 0.03:
        Input.action_press(action, strength)
    else:
        Input.action_release(action)

func _exit_tree() -> void:
    for action in ["move_left", "move_right", "move_forward", "move_backward", "jump", "sprint", "interact", "scan", "crouch", "activate_equipment"]:
        Input.action_release(action)

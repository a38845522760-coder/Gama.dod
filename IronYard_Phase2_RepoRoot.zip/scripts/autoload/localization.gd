extends Node

## Lightweight two-language string table (Persian / English). Use Loc.t("key").
## Screens listen to language_changed and rebuild themselves.

signal language_changed(language: String)

const STRINGS: Dictionary = {
    "app_title": {"fa": "آیرون یارد", "en": "IRON YARD"},
    "tagline": {"fa": "نبرد در کارخانه فولاد", "en": "Battle in the steel yard"},
    "play": {"fa": "شروع بازی", "en": "PLAY"},
    "settings": {"fa": "تنظیمات", "en": "SETTINGS"},
    "quit": {"fa": "خروج", "en": "QUIT"},
    "back": {"fa": "بازگشت", "en": "BACK"},
    "resume": {"fa": "ادامه", "en": "RESUME"},
    "main_menu": {"fa": "منوی اصلی", "en": "MAIN MENU"},
    "paused": {"fa": "توقف", "en": "PAUSED"},
    "graphics": {"fa": "گرافیک", "en": "Graphics"},
    "audio": {"fa": "صدا", "en": "Audio"},
    "controls": {"fa": "کنترل", "en": "Controls"},
    "language": {"fa": "زبان", "en": "Language"},
    "quality": {"fa": "کیفیت گرافیک", "en": "Graphics quality"},
    "quality_low": {"fa": "کم", "en": "Low"},
    "quality_medium": {"fa": "متوسط", "en": "Medium"},
    "quality_high": {"fa": "بالا", "en": "High"},
    "quality_ultra": {"fa": "اولترا", "en": "Ultra"},
    "dynamic_quality": {"fa": "تنظیم خودکار کیفیت", "en": "Auto quality"},
    "fov": {"fa": "میدان دید", "en": "Field of view"},
    "master_volume": {"fa": "صدای کلی", "en": "Master volume"},
    "music_volume": {"fa": "موسیقی", "en": "Music"},
    "sfx_volume": {"fa": "افکت‌ها", "en": "Effects"},
    "look_sensitivity": {"fa": "حساسیت ماوس", "en": "Mouse sensitivity"},
    "touch_look_sensitivity": {"fa": "حساسیت لمس", "en": "Touch sensitivity"},
    "invert_y": {"fa": "معکوس‌کردن محور عمودی", "en": "Invert vertical look"},
    "touch_scale": {"fa": "اندازه دکمه‌ها", "en": "Button size"},
    "touch_opacity": {"fa": "شفافیت دکمه‌ها", "en": "Button opacity"},
    "haptics": {"fa": "لرزش", "en": "Vibration"},
    "show_debug": {"fa": "نمایش اطلاعات فنی", "en": "Show debug info"},
    "reset_defaults": {"fa": "بازگشت به پیش‌فرض", "en": "Reset to defaults"},
    "on": {"fa": "روشن", "en": "ON"},
    "off": {"fa": "خاموش", "en": "OFF"},
    "lang_fa": {"fa": "فارسی", "en": "فارسی"},
    "lang_en": {"fa": "English", "en": "English"},
    "credits": {"fa": "اعتبار", "en": "Credits"},
    "best_score": {"fa": "بهترین امتیاز", "en": "Best score"},
    "kills": {"fa": "حذف‌ها", "en": "Kills"},
    "reloading": {"fa": "در حال پر کردن...", "en": "RELOADING"},
    "no_ammo": {"fa": "مهمات تمام شد", "en": "NO AMMO"},
    "health": {"fa": "جان", "en": "HP"},
    "armor": {"fa": "زره", "en": "ARMOR"},
    "stamina": {"fa": "نیرو", "en": "STAMINA"},
    "you_died": {"fa": "از پا درآمدی", "en": "YOU DIED"},
    "respawn_in": {"fa": "بازگشت تا", "en": "Respawning in"},
    "headshot": {"fa": "شلیک به سر", "en": "HEADSHOT"},
    "supply_prompt": {"fa": "ایستگاه تدارکات — جان، زره و مهمات", "en": "Supply station — health, armor, ammo"},
    "supply_used": {"fa": "تجهیز شدی", "en": "Resupplied"},
    "hint_use": {"fa": "استفاده", "en": "USE"},
    "confirm_quit": {"fa": "از بازی خارج می‌شوی؟", "en": "Quit the game?"},
    "saved": {"fa": "ذخیره شد", "en": "Saved"},
    "weather": {"fa": "آب‌وهوا", "en": "Weather"},
    "weather_clear": {"fa": "آفتابی", "en": "Clear"},
    "weather_overcast": {"fa": "ابری", "en": "Overcast"},
    "weather_fog": {"fa": "مه", "en": "Fog"},
    "weather_rain": {"fa": "باران", "en": "Rain"},
    "weather_dusk": {"fa": "غروب", "en": "Dusk"},
    "weather_night": {"fa": "شب", "en": "Night"},
    "map_iron_yard": {"fa": "نقشه آیرون یارد", "en": "Iron Yard map"},
    "map_training": {"fa": "میدان تمرین", "en": "Training arena"},
    "training": {"fa": "میدان تمرین", "en": "Training Arena"},
}

var language: String = "fa"

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    language = str(SettingsManager.get_setting("language", "fa"))
    SettingsManager.settings_changed.connect(_on_settings_changed)

func t(key: String) -> String:
    var entry: Variant = STRINGS.get(key)
    if entry == null:
        return key
    var table: Dictionary = entry
    return str(table.get(language, table.get("en", key)))

func is_rtl() -> bool:
    return language == "fa"

func apply_direction(control: Control) -> void:
    control.layout_direction = Control.LAYOUT_DIRECTION_RTL if is_rtl() else Control.LAYOUT_DIRECTION_LTR

func _on_settings_changed(settings: Dictionary) -> void:
    var next_language := str(settings.get("language", language))
    if next_language != language:
        language = next_language
        language_changed.emit(language)

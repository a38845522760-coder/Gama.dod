extends Node

## Lightweight two-language string table (Persian / English). Use Loc.t("key").
## Screens listen to language_changed and rebuild themselves.

signal language_changed(language: String)

const STRINGS: Dictionary = {
    "app_title": {"fa": "آیرون یارد", "en": "IRON YARD"},
    "tagline": {"fa": "نبرد در کارخانه فولاد", "en": "Battle in the steel yard"},
    "play": {"fa": "شروع بازی", "en": "PLAY"},
    "settings": {"fa": "تنظیمات", "en": "SETTINGS"},
    "quit": {"fa": "خروج", "en": "QUIT"},
    "back": {"fa": "بازگشت", "en": "BACK"},
    "resume": {"fa": "ادامه", "en": "RESUME"},
    "main_menu": {"fa": "منوی اصلی", "en": "MAIN MENU"},
    "paused": {"fa": "توقف", "en": "PAUSED"},
    "graphics": {"fa": "گرافیک", "en": "Graphics"},
    "audio": {"fa": "صدا", "en": "Audio"},
    "controls": {"fa": "کنترل", "en": "Controls"},
    "language": {"fa": "زبان", "en": "Language"},
    "quality": {"fa": "کیفیت گرافیک", "en": "Graphics quality"},
    "quality_low": {"fa": "کم", "en": "Low"},
    "quality_medium": {"fa": "متوسط", "en": "Medium"},
    "quality_high": {"fa": "بالا", "en": "High"},
    "quality_ultra": {"fa": "اولترا", "en": "Ultra"},
    "dynamic_quality": {"fa": "تنظیم خودکار کیفیت", "en": "Auto quality"},
    "fov": {"fa": "میدان دید", "en": "Field of view"},
    "master_volume": {"fa": "صدای کلی", "en": "Master volume"},
    "music_volume": {"fa": "موسیقی", "en": "Music"},
    "sfx_volume": {"fa": "افکت‌ها", "en": "Effects"},
    "look_sensitivity": {"fa": "حساسیت ماوس", "en": "Mouse sensitivity"},
    "touch_look_sensitivity": {"fa": "حساسیت لمس", "en": "Touch sensitivity"},
    "invert_y": {"fa": "معکوس‌کردن محور عمودی", "en": "Invert vertical look"},
    "touch_scale": {"fa": "اندازه دکمه‌ها", "en": "Button size"},
    "touch_opacity": {"fa": "شفافیت دکمه‌ها", "en": "Button opacity"},
    "haptics": {"fa": "لرزش", "en": "Vibration"},
    "show_debug": {"fa": "نمایش اطلاعات فنی", "en": "Show debug info"},
    "reset_defaults": {"fa": "بازگشت به پیش‌فرض", "en": "Reset to defaults"},
    "on": {"fa": "روشن", "en": "ON"},
    "off": {"fa": "خاموش", "en": "OFF"},
    "lang_fa": {"fa": "فارسی", "en": "فارسی"},
    "lang_en": {"fa": "English", "en": "English"},
    "credits": {"fa": "اعتبار", "en": "Credits"},
    "best_score": {"fa": "بهترین امتیاز", "en": "Best score"},
    "kills": {"fa": "حذف‌ها", "en": "Kills"},
    "reloading": {"fa": "در حال پر کردن...", "en": "RELOADING"},
    "no_ammo": {"fa": "مهمات تمام شد", "en": "NO AMMO"},
    "health": {"fa": "جان", "en": "HP"},
    "armor": {"fa": "زره", "en": "ARMOR"},
    "stamina": {"fa": "نیرو", "en": "STAMINA"},
    "you_died": {"fa": "از پا درآمدی", "en": "YOU DIED"},
    "respawn_in": {"fa": "بازگشت تا", "en": "Respawning in"},
    "headshot": {"fa": "شلیک به سر", "en": "HEADSHOT"},
    "supply_prompt": {"fa": "ایستگاه تدارکات — جان، زره و مهمات", "en": "Supply station — health, armor, ammo"},
    "supply_used": {"fa": "تجهیز شدی", "en": "Resupplied"},
    "hint_use": {"fa": "استفاده", "en": "USE"},
    "confirm_quit": {"fa": "از بازی خارج می‌شوی؟", "en": "Quit the game?"},
    "saved": {"fa": "ذخیره شد", "en": "Saved"},
    "weather": {"fa": "آب‌وهوا", "en": "Weather"},
    "weather_clear": {"fa": "آفتابی", "en": "Clear"},
    "weather_overcast": {"fa": "ابری", "en": "Overcast"},
    "weather_fog": {"fa": "مه", "en": "Fog"},
    "weather_rain": {"fa": "باران", "en": "Rain"},
    "weather_dusk": {"fa": "غروب", "en": "Dusk"},
    "weather_night": {"fa": "شب", "en": "Night"},
    "map_iron_yard": {"fa": "نقشه آیرون یارد", "en": "Iron Yard map"},
    "map_training": {"fa": "میدان تمرین", "en": "Training arena"},
    "training": {"fa": "میدان تمرین", "en": "Training Arena"},
    "content": {"fa": "محتوا و دانلود", "en": "CONTENT"},
    "content_maps": {"fa": "نقشه‌ها", "en": "Maps"},
    "content_weapons": {"fa": "تفنگ‌ها", "en": "Weapons"},
    "content_characters": {"fa": "شخصیت‌ها", "en": "Characters"},
    "content_download": {"fa": "دانلود", "en": "Download"},
    "content_import": {"fa": "از حافظه گوشی", "en": "From phone"},
    "content_import_btn": {"fa": "نصب", "en": "Install"},
    "content_allow_access": {"fa": "اجازه دسترسی به فایل‌ها", "en": "Allow file access"},
    "content_rescan": {"fa": "جست‌وجوی دوباره", "en": "Scan again"},
    "content_import_hint": {"fa": "بسته‌های آماده (مثل gorg_v1.pck) را توی پوشه Download/IronYard گوشی بگذارید. اگر چیزی دیده نشد، اول «اجازه دسترسی به فایل‌ها» را بزنید.", "en": "Put ready-made packs (like gorg_v1.pck) in the phone folder Download/IronYard. If nothing shows up, tap Allow file access first."},
    "content_import_empty": {"fa": "فایل .pck در پوشه Download/IronYard پیدا نشد.", "en": "No .pck file found in Download/IronYard."},
    "content_mode_battle": {"fa": "بتل", "en": "Battle"},
    "content_mode_duel": {"fa": "دوئل", "en": "Duel"},
    "content_mode_training": {"fa": "تمرین", "en": "Training"},
    "content_play": {"fa": "بازی", "en": "Play"},
    "content_delete": {"fa": "حذف", "en": "Delete"},
    "content_update": {"fa": "به‌روزرسانی", "en": "Update"},
    "content_cancel": {"fa": "لغو", "en": "Cancel"},
    "content_refresh": {"fa": "بارگیری دوباره فهرست", "en": "Refresh list"},
    "content_online": {"fa": "آنلاین", "en": "Online"},
    "content_offline": {"fa": "آفلاین (فهرست ذخیره‌شده)", "en": "Offline (saved list)"},
    "content_installed_size": {"fa": "حجم نصب‌شده", "en": "Installed"},
    "content_empty": {"fa": "هنوز چیزی در این بخش نیست. اینترنت را روشن کنید و «بارگیری دوباره فهرست» را بزنید.", "en": "Nothing here yet. Go online and tap Refresh list."},
    "content_restart": {"fa": "برای اعمال تغییرات بازی را ببندید و دوباره باز کنید", "en": "Restart the game to apply changes"},
    "content_battle": {"fa": "نقشه بتل", "en": "Battle map"},
    "content_verifying": {"fa": "در حال بررسی...", "en": "Verifying..."},
    "content_failed": {"fa": "خطا", "en": "Error"},
    "content_big_hint": {"fa": "حجم زیاد، با Wi-Fi دانلود کنید", "en": "Large - use Wi-Fi"},
}

var language: String = "fa"

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    language = str(SettingsManager.get_setting("language", "fa"))
    SettingsManager.settings_changed.connect(_on_settings_changed)

func t(key: String) -> String:
    var entry: Variant = STRINGS.get(key)
    if entry == null:
        return key
    var table: Dictionary = entry
    return str(table.get(language, table.get("en", key)))

func is_rtl() -> bool:
    return language == "fa"

func apply_direction(control: Control) -> void:
    control.layout_direction = Control.LAYOUT_DIRECTION_RTL if is_rtl() else Control.LAYOUT_DIRECTION_LTR

func _on_settings_changed(settings: Dictionary) -> void:
    var next_language := str(settings.get("language", language))
    if next_language != language:
        language = next_language
        language_changed.emit(language)

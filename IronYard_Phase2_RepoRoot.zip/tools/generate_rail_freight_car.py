from pathlib import Path
import trimesh
import numpy as np

OUT = Path(__file__).resolve().parents[1] / 'assets/models/environment/rail_freight_car.glb'
parts = []

def material(name, color, metallic=0.0, roughness=0.8):
    return trimesh.visual.material.PBRMaterial(name=name, baseColorFactor=(*color,255), metallicFactor=metallic, roughnessFactor=roughness)

mats = {
 'body': material('Oxide painted freight steel',(75,91,92),0.62,0.72),
 'dark': material('Underframe dark steel',(30,39,43),0.76,0.82),
 'rust': material('Edge rust',(119,69,43),0.42,0.9),
 'mark': material('Safety marking',(205,153,65),0.35,0.62),
 'rubber': material('Wheel rubber',(23,27,29),0.08,0.95),
 'metal': material('Machined steel',(100,112,115),0.85,0.42),
 'glass': material('Dirty cabin glass',(39,68,75),0.48,0.28),
}

def add_box(name, center, size, mat, rot=None):
    mesh = trimesh.creation.box(extents=size)
    if rot is not None: mesh.apply_transform(rot)
    mesh.apply_translation(center)
    mesh.visual.material = mats[mat]
    mesh.metadata['name'] = name
    parts.append((mat, mesh))

def add_cylinder(name, center, radius, height, mat, axis='X', sections=18):
    mesh = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    if axis == 'X':
        mesh.apply_transform(trimesh.transformations.rotation_matrix(np.pi/2, [0,1,0]))
    elif axis == 'Z':
        mesh.apply_transform(trimesh.transformations.rotation_matrix(np.pi/2, [1,0,0]))
    mesh.apply_translation(center)
    mesh.visual.material = mats[mat]
    parts.append((mat, mesh))

# wagon shell: 13.2 m long, 3.05 m wide, 2.85 m tall, origin at ground
add_box('Freight body', (0,2.0,0), (13.2,2.5,2.85), 'body')
# horizontal reinforcing rails and vertical ribs along both long sides
for side in (-1,1):
    z = side * 1.445
    for y in (0.95,1.45,2.55,3.05):
        add_box(f'Side rail {side} {y}', (0,y,z), (13.45,0.09,0.10), 'dark' if y in (0.95,3.05) else 'rust')
    for i in range(17):
        x = -6.25 + i*0.78
        add_box(f'Rib {side} {i}', (x,2.0,z), (0.075,2.25,0.14), 'rust' if i%4==0 else 'dark')
    for x in (-5.4,5.4):
        add_box(f'Corner plate {side} {x}', (x,2.0,z+side*0.045), (0.42,2.25,0.08), 'mark')
# top lip and end walls
add_box('Top left lip',(0,3.28,-1.48),(13.5,0.12,0.16),'metal')
add_box('Top right lip',(0,3.28,1.48),(13.5,0.12,0.16),'metal')
for x in (-6.68,6.68):
    add_box(f'End wall {x}',(x,2.0,0),(0.16,2.6,2.9),'dark')
    add_box(f'End plate {x}',(x*1.012,2.7,0),(0.07,0.28,2.65),'mark')
# undercarriage / couplers
add_box('Main underframe',(0,0.63,0),(12.9,0.56,2.45),'dark')
for x in (-4.7,4.7):
    add_box(f'Bogie frame {x}',(x,0.55,0),(2.1,0.48,2.3),'metal')
    for z in (-0.92,0.92):
        add_cylinder(f'Wheel {x} {z}',(x,0.58,z),0.56,0.34,'rubber','X',24)
        add_cylinder(f'Hub {x} {z}',(x,0.58,z*1.12),0.22,0.38,'metal','X',18)
    for z in (-0.62,0.62):
        add_box(f'Suspension {x} {z}',(x,0.93,z),(1.65,0.16,0.12),'rust')
for x in (-6.95,6.95):
    add_box(f'Coupler {x}',(x,0.58,0),(0.55,0.26,0.42),'metal')
    add_box(f'Buffer {x}',(x,0.83,-0.72),(0.2,0.38,0.38),'dark')
    add_box(f'Buffer {x} right',(x,0.83,0.72),(0.2,0.38,0.38),'dark')
# side access ladder, stencils, small hazard plates
for side in (-1,1):
    for y in (0.7,1.1,1.5,1.9):
        add_box(f'Ladder rung {side} {y}',(5.6,y,side*1.55),(0.55,0.07,0.1),'mark')
    add_box(f'Number plate {side}',(-4.8,1.35,side*1.53),(1.3,0.42,0.055),'dark')
    add_box(f'Reflector {side}',(0,0.85,side*1.54),(0.32,0.22,0.06),'mark')

# Merge all mechanical pieces by material. This keeps detail while reducing the GLB to a
# small number of render surfaces for mobile GPUs.
scene = trimesh.Scene(base_frame='world')
grouped = {}
for material_key, mesh in parts:
    grouped.setdefault(material_key, []).append(mesh)
for material_key, meshes in grouped.items():
    merged = trimesh.util.concatenate(meshes)
    merged.visual.material = mats[material_key]
    scene.add_geometry(merged, geom_name=f'rail_freight_car_{material_key}', node_name=f'rail_freight_car_{material_key}')
OUT.parent.mkdir(parents=True,exist_ok=True)
scene.export(OUT, file_type='glb')
check = trimesh.load(OUT, force='scene')
if len(check.geometry) != len(grouped):
    raise RuntimeError('GLB render-surface merge failed')
print('wrote',OUT,'bounds',check.bounds,'geometries',len(check.geometry),'bytes',OUT.stat().st_size)

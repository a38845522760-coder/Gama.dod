#!/usr/bin/env python3
"""Generate tileable, original PBR texture sets for Iron Yard.
Requires numpy and Pillow. Run from the project root.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "assets" / "textures"


def periodic_noise(size: int, seed: int, octaves: int = 5) -> np.ndarray:
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:size, 0:size].astype(np.float32)
    u, v = xx / size, yy / size
    result = np.zeros((size, size), dtype=np.float32)
    total = 0.0
    for octave in range(octaves):
        freq = 2 ** (octave + 1)
        components = 8 + octave * 5
        layer = np.zeros_like(result)
        for _ in range(components):
            kx = int(rng.integers(1, freq * 2 + 1))
            ky = int(rng.integers(1, freq * 2 + 1))
            phase = float(rng.uniform(0, np.pi * 2))
            amp = float(rng.uniform(0.35, 1.0))
            layer += amp * np.sin(2 * np.pi * (kx * u + ky * v) + phase)
        layer /= max(components * 0.65, 1.0)
        weight = 1.0 / (1.8 ** octave)
        result += layer * weight
        total += weight
    result /= max(total, 1e-6)
    result -= result.mean()
    result /= max(float(result.std()), 1e-5)
    return result


def material_field(name: str, size: int, seed: int):
    rng = np.random.default_rng(seed)
    y, x = np.mgrid[0:size, 0:size].astype(np.float32)
    u, v = x / size, y / size
    n1 = periodic_noise(size, seed + 1, 5)
    n2 = periodic_noise(size, seed + 2, 4)
    n3 = periodic_noise(size, seed + 3, 3)
    fine = periodic_noise(size, seed + 4, 2)
    height = np.zeros((size, size), dtype=np.float32)
    rough = np.full((size, size), 0.82, dtype=np.float32)

    palettes = {
        "concrete": (np.array([112, 116, 112], np.float32), 23),
        "painted_steel": (np.array([63, 75, 78], np.float32), 16),
        "rubber": (np.array([31, 35, 37], np.float32), 10),
        "asphalt": (np.array([43, 47, 49], np.float32), 18),
        "wood": (np.array([111, 79, 49], np.float32), 20),
        "dirt": (np.array([73, 62, 48], np.float32), 25),
        "brick": (np.array([112, 62, 48], np.float32), 19),
        "fabric": (np.array([65, 76, 53], np.float32), 14),
        "skin": (np.array([145, 112, 91], np.float32), 15),
        "gunmetal": (np.array([42, 48, 52], np.float32), 13),
    }
    base, contrast = palettes[name]
    field = n1 * 0.55 + n2 * 0.27 + n3 * 0.13 + fine * 0.05
    color_variation = field * contrast

    if name == "concrete":
        pores = np.maximum(0.0, fine - 0.7)
        hairline = np.sin((u * 31 + n2 * 0.09) * np.pi * 2) * np.sin((v * 17 + n3 * 0.08) * np.pi * 2)
        color_variation -= pores * 13
        color_variation += hairline * 2.5
        height = n1 * 0.08 + n2 * 0.045 + fine * 0.018 - pores * 0.025
        rough = np.clip(0.88 + n2 * 0.035 + pores * 0.06, 0.68, 1.0)
    elif name in ("painted_steel", "gunmetal"):
        grain = np.sin(v * size * 0.42 + n2 * 1.1) * 2.8 + np.sin(v * size * 1.17 + n3) * 1.2
        scratches = np.maximum(0.0, np.sin(v * size * 1.8 + n1 * 2.0)) ** 22
        wear = np.maximum(0.0, n1 - 1.1) * 24
        color_variation += grain - scratches * 9 - wear
        height = n1 * 0.025 + grain * 0.002 - scratches * 0.012
        rough = np.clip((0.5 if name == "gunmetal" else 0.64) + n2 * 0.05 + scratches * 0.09, 0.32, 0.92)
    elif name == "rubber":
        pebble = np.sin(u * size * 0.28 + n1) * np.sin(v * size * 0.28 + n2) * 2.5
        color_variation += pebble - np.maximum(0.0, fine - 0.8) * 5
        height = n1 * 0.045 + n2 * 0.025 + pebble * 0.01
        rough = np.clip(0.91 + n3 * 0.025, 0.78, 1.0)
    elif name == "asphalt":
        aggregate = np.maximum(0.0, fine - 0.15) * 16
        color_variation += aggregate - np.maximum(0.0, n2 - 1.0) * 8
        height = n1 * 0.055 + n2 * 0.035 + aggregate * 0.003
        rough = np.clip(0.92 + n3 * 0.04, 0.76, 1.0)
    elif name == "wood":
        grain = np.sin(v * size * 0.075 + n1 * 1.6) * 10 + np.sin(v * size * 0.21 + n2) * 4
        knots = np.exp(-(((u - 0.31 + n2 * 0.005) / 0.035) ** 2 + ((v - 0.42 + n3 * 0.004) / 0.055) ** 2))
        color_variation += grain - knots * 18
        height = n1 * 0.025 + grain * 0.0018 - knots * 0.04
        rough = np.clip(0.82 + n3 * 0.045, 0.64, 0.98)
    elif name == "dirt":
        stones = np.maximum(0.0, n2 - 0.45) * 13
        color_variation += stones - np.maximum(0.0, -n3 - 1.0) * 12
        height = n1 * 0.09 + n2 * 0.05 + stones * 0.004
        rough = np.clip(0.94 + n3 * 0.04, 0.82, 1.0)
    elif name == "brick":
        # Seamless running-bond brick courses; both coordinates wrap cleanly.
        row = np.floor(v * 8.0)
        stagger = (row % 2.0) * 0.5
        mortar_distance_x = np.abs(((u * 4.0 + stagger + 0.5) % 1.0) - 0.5)
        mortar_distance_y = np.abs(((v * 8.0 + 0.5) % 1.0) - 0.5)
        mortar = (mortar_distance_x > 0.465) | (mortar_distance_y > 0.465)
        color_variation += n1 * 5 - mortar.astype(np.float32) * 38
        height = n1 * 0.025 + mortar.astype(np.float32) * -0.075
        rough = np.where(mortar, 0.94, 0.88).astype(np.float32) + n3 * 0.025
    elif name == "skin":
        pores = np.maximum(0.0, fine - 0.35)
        color_variation += n1 * 3.2 - pores * 4.5
        height = n1 * 0.012 + n2 * 0.008 - pores * 0.004
        rough = np.clip(0.79 + n3 * 0.04 + pores * 0.025, 0.65, 0.94)
    elif name == "fabric":
        weave = (np.sin(u * size * 0.48) * 2.5 + np.sin(v * size * 0.48) * 2.5)
        color_variation += weave + n2 * 4
        height = n1 * 0.02 + weave * 0.003 + np.sin(u * size * 0.95) * np.sin(v * size * 0.95) * 0.006
        rough = np.clip(0.9 + n3 * 0.025, 0.8, 1.0)

    rgb = np.stack([base[0] + color_variation, base[1] + color_variation, base[2] + color_variation], axis=-1)
    # Slight warm/cool chroma separation keeps the surfaces from reading as flat grey.
    rgb[..., 0] += n2 * 1.5
    rgb[..., 2] -= n2 * 1.2
    rgb = np.clip(rgb, 0, 255).astype(np.uint8)

    # Derive a tangent-space normal map with periodic central differences.
    dx = (np.roll(height, -1, axis=1) - np.roll(height, 1, axis=1)) * 0.5
    dy = (np.roll(height, -1, axis=0) - np.roll(height, 1, axis=0)) * 0.5
    strength = 28.0 if name in ("concrete", "asphalt", "dirt") else 20.0
    nx = -dx * strength
    ny = -dy * strength
    nz = np.ones_like(nx)
    length = np.sqrt(nx * nx + ny * ny + nz * nz)
    normal = np.stack([nx / length, ny / length, nz / length], axis=-1)
    normal_rgb = np.clip((normal * 0.5 + 0.5) * 255, 0, 255).astype(np.uint8)
    rough_rgb = np.clip(rough * 255, 0, 255).astype(np.uint8)
    return rgb, normal_rgb, rough_rgb


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--size", type=int, default=512)
    parser.add_argument("--large", type=int, default=1024)
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    large = {"concrete", "painted_steel", "asphalt"}
    for index, name in enumerate(("concrete", "painted_steel", "rubber", "asphalt", "wood", "dirt", "brick", "fabric", "skin", "gunmetal")):
        size = args.large if name in large else args.size
        albedo, normal, roughness = material_field(name, size, 7319 + index * 97)
        for suffix, data in (("albedo", albedo), ("normal", normal), ("roughness", roughness)):
            path = OUT / f"{name}_{suffix}.png"
            Image.fromarray(data).save(path, optimize=True)
            print(path.relative_to(ROOT), size, "px")

    # Complete the already-existing zombie texture sets with roughness maps.
    # The character materials deliberately use distinct surface response for skin,
    # cloth and worn leather rather than sharing one constant roughness value.
    zombie_roughness = {
        "zombie_skin": (0.87, 0.055),
        "zombie_cloth": (0.94, 0.035),
        "zombie_leather": (0.81, 0.075),
    }
    for index, (name, values) in enumerate(zombie_roughness.items()):
        base_roughness, variation = values
        source_path = OUT / f"{name}_albedo.png"
        if not source_path.exists():
            raise FileNotFoundError(f"Required existing zombie albedo map not found: {source_path}")
        with Image.open(source_path) as source:
            size = source.width
        noise = periodic_noise(size, 98117 + index * 131, 4)
        data = np.clip((base_roughness + noise * variation) * 255.0, 0, 255).astype(np.uint8)
        path = OUT / f"{name}_roughness.png"
        Image.fromarray(data, mode="L").save(path, optimize=True)
        print(path.relative_to(ROOT), size, "px")

if __name__ == "__main__":
    main()

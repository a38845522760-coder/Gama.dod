#!/usr/bin/env python3
"""Generate a seamless, low-intensity industrial wind loop for Dead City."""
from pathlib import Path
import wave
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "assets" / "audio" / "dead_city_ambience.wav"
SAMPLE_RATE = 22050
DURATION = 12.0
SAMPLES = int(SAMPLE_RATE * DURATION)
RNG = np.random.default_rng(7319)

# Build periodic noise directly in the frequency domain. Every bin lies on the exact
# 1 / duration frequency grid, so the first and last sample connect without a click.
frequencies = np.fft.rfftfreq(SAMPLES, 1.0 / SAMPLE_RATE)

def periodic_wind(seed_offset: int, center_hz: float, bandwidth: float, slope: float) -> np.ndarray:
    rng = np.random.default_rng(7319 + seed_offset)
    spectrum = np.zeros(frequencies.shape, dtype=np.complex128)
    random_phase = rng.uniform(-np.pi, np.pi, frequencies.size)
    random_amplitude = rng.normal(0.0, 1.0, frequencies.size)
    envelope = np.exp(-0.5 * ((frequencies - center_hz) / bandwidth) ** 2)
    envelope *= np.maximum(frequencies, 1.0) ** (-slope)
    envelope[0] = 0.0
    spectrum = random_amplitude * envelope * np.exp(1j * random_phase)
    signal = np.fft.irfft(spectrum, n=SAMPLES)
    peak = max(float(np.max(np.abs(signal))), 1e-8)
    return signal / peak

left = (
    0.54 * periodic_wind(1, 78.0, 62.0, 0.55)
    + 0.24 * periodic_wind(2, 410.0, 300.0, 0.30)
    + 0.055 * np.sin(2.0 * np.pi * 48.0 * np.arange(SAMPLES) / SAMPLE_RATE)
)
right = (
    0.52 * periodic_wind(3, 84.0, 68.0, 0.58)
    + 0.22 * periodic_wind(4, 365.0, 285.0, 0.32)
    + 0.052 * np.sin(2.0 * np.pi * 49.5 * np.arange(SAMPLES) / SAMPLE_RATE + 0.4)
)
# Gently drifting, distant mechanical layers, kept much quieter than the wind bed.
time = np.arange(SAMPLES, dtype=np.float64) / SAMPLE_RATE
for signal, phase in ((left, 0.0), (right, 0.8)):
    signal += 0.018 * np.sin(2.0 * np.pi * 0.13 * time + phase) * np.sin(2.0 * np.pi * 31.0 * time + phase)

stereo = np.stack((left, right), axis=1)
stereo *= 0.075 / max(float(np.max(np.abs(stereo))), 1e-8)
pcm = np.clip(stereo * 32767.0, -32768, 32767).astype("<i2")
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
with wave.open(str(OUTPUT), "wb") as wav:
    wav.setnchannels(2)
    wav.setsampwidth(2)
    wav.setframerate(SAMPLE_RATE)
    wav.writeframes(pcm.tobytes())
print(f"Wrote {OUTPUT} ({OUTPUT.stat().st_size:,} bytes, {DURATION:.1f}s, seamless stereo loop)")

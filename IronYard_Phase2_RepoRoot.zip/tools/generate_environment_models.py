from __future__ import annotations
import os
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial
from trimesh.visual.texture import TextureVisuals
from trimesh.transformations import rotation_matrix

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'assets', 'models', 'environment')
os.makedirs(OUT, exist_ok=True)

PALETTE = {
    'paint': ((70, 83, 76, 255), 0.22, 0.78),
    'paint_dark': ((35, 43, 43, 255), 0.25, 0.82),
    'white': ((190, 198, 194, 255), 0.12, 0.82),
    'rubber': ((13, 16, 18, 255), 0.0, 0.96),
    'metal': ((91, 104, 109, 255), 0.72, 0.48),
    'metal_dark': ((26, 32, 35, 255), 0.62, 0.72),
    'rust': ((105, 62, 39, 255), 0.16, 0.96),
    'glass': ((29, 55, 63, 225), 0.0, 0.18),
    'lamp': ((255, 193, 103, 255), 0.08, 0.28),
    'red': ((145, 39, 32, 255), 0.12, 0.62),
    'yellow': ((224, 161, 51, 255), 0.05, 0.76),
    'concrete': ((104, 111, 112, 255), 0.0, 0.96),
    'black': ((19, 24, 27, 255), 0.05, 0.9),
    'screen': ((53, 151, 168, 255), 0.2, 0.3),
}

materials = {
    name: PBRMaterial(name=name, baseColorFactor=np.array(rgba, dtype=np.uint8), metallicFactor=metal, roughnessFactor=rough)
    for name, (rgba, metal, rough) in PALETTE.items()
}

def box(extents, pos, material, rot=None):
    m = trimesh.creation.box(extents=np.asarray(extents, dtype=float))
    if rot is not None:
        m.apply_transform(trimesh.transformations.euler_matrix(*rot, axes='sxyz'))
    m.apply_translation(np.asarray(pos, dtype=float))
    return material, m

def cylinder(radius, height, pos, material, axis='z', sections=24):
    m = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    if axis == 'x':
        m.apply_transform(rotation_matrix(np.pi / 2.0, [0, 1, 0]))
    elif axis == 'y':
        m.apply_transform(rotation_matrix(np.pi / 2.0, [1, 0, 0]))
    m.apply_translation(np.asarray(pos, dtype=float))
    return material, m

def sphere(radius, pos, material, subdivisions=1):
    m = trimesh.creation.icosphere(subdivisions=subdivisions, radius=radius)
    m.apply_translation(np.asarray(pos, dtype=float))
    return material, m

def export_grouped(filename, parts):
    grouped = {}
    for material, mesh in parts:
        grouped.setdefault(material, []).append(mesh)
    scene = trimesh.Scene(base_frame='world')
    for material, meshes in grouped.items():
        combined = trimesh.util.concatenate(meshes)
        combined.visual = TextureVisuals(material=materials[material])
        scene.add_geometry(combined, geom_name=f'{filename}_{material}', node_name=f'{filename}_{material}')
    target = os.path.join(OUT, filename + '.glb')
    scene.export(target, file_type='glb')
    check = trimesh.load(target, force='scene')
    if len(check.geometry) != len(grouped):
        raise RuntimeError(f'GLB verification failed for {target}: {len(check.geometry)} groups')
    return target, os.path.getsize(target)

# A compact post-apocalyptic utility SUV. Long axis is Z; front faces -Z.
parts = []
# Chassis, lower body, raised hood and rear shell.
parts += [box((1.82, 0.52, 4.05), (0, 0.70, 0.0), 'paint')]
parts += [box((1.76, 0.24, 1.15), (0, 1.04, -1.34), 'paint_dark')]
parts += [box((1.72, 0.25, 1.15), (0, 1.02, 1.32), 'paint')]
# Cabin shell pillars and roof; window cutouts remain visibly open/glazed.
parts += [box((1.58, 0.12, 1.76), (0, 1.72, 0.23), 'paint_dark')]
for x in (-0.77, 0.77):
    for z in (-0.55, 0.90):
        parts += [box((0.11, 0.88, 0.12), (x, 1.40, z), 'paint')]
    parts += [box((0.10, 0.70, 0.10), (x, 1.40, 0.18), 'paint')]
# Side window glass and rear/front windshields.
for x in (-0.724, 0.724):
    parts += [box((0.018, 0.48, 1.12), (x, 1.43, 0.16), 'glass', (0.0, 0.0, -0.06 if x < 0 else 0.06))]
parts += [box((1.36, 0.60, 0.025), (0, 1.40, -0.62), 'glass', (0.10, 0.0, 0.0))]
parts += [box((1.34, 0.48, 0.025), (0, 1.42, 1.10), 'glass', (-0.10, 0.0, 0.0))]
# Door panels, handles, mirrors, rub rails and dented patches.
for x in (-0.92, 0.92):
    for z in (-0.36, 0.66):
        parts += [box((0.06, 0.44, 0.95), (x, 0.82, z), 'paint_dark')]
        parts += [box((0.018, 0.035, 0.18), (x * 1.04, 1.00, z - 0.18), 'metal')]
    parts += [box((0.10, 0.10, 0.18), (x * 1.04, 1.38, -0.68), 'metal_dark')]
    parts += [box((0.18, 0.07, 0.08), (x * 1.02, 1.32, -0.70), 'glass')]
# Bumpers, grille, front protection and rear tow hardware.
parts += [box((1.98, 0.18, 0.16), (0, 0.47, -2.10), 'metal')]
parts += [box((1.98, 0.18, 0.16), (0, 0.47, 2.10), 'rust')]
parts += [box((0.68, 0.30, 0.04), (0, 0.72, -2.055), 'metal_dark')]
for x in np.linspace(-0.28, 0.28, 7):
    parts += [box((0.025, 0.24, 0.025), (x, 0.72, -2.082), 'metal')]
# Lamps and signal blocks.
for x in (-0.68, 0.68):
    parts += [box((0.24, 0.16, 0.045), (x, 0.96, -1.94), 'lamp')]
    parts += [box((0.15, 0.12, 0.045), (x, 0.70, 2.015), 'red')]
    parts += [box((0.12, 0.10, 0.10), (x, 1.38, -0.78), 'metal_dark')]
# Tires, hubs and wheel bolts.
for x in (-0.98, 0.98):
    for z in (-1.30, 1.30):
        parts += [cylinder(0.43, 0.27, (x, 0.44, z), 'rubber', axis='x', sections=32)]
        parts += [cylinder(0.235, 0.285, (x * 1.015, 0.44, z), 'metal_dark', axis='x', sections=24)]
        parts += [cylinder(0.12, 0.30, (x * 1.02, 0.44, z), 'metal', axis='x', sections=20)]
        for k in range(6):
            a = k * np.pi / 3.0
            parts += [sphere(0.018, (x * 1.035, 0.44 + np.cos(a) * 0.16, z + np.sin(a) * 0.16), 'metal', 1)]
# Wheel arches, roof rails, exhaust, broken mirror and scattered rust panels.
for x in (-0.92, 0.92):
    for z in (-1.3, 1.3):
        parts += [box((0.10, 0.16, 0.95), (x, 0.77, z), 'rust')]
    parts += [box((0.045, 0.10, 2.85), (x * 0.76, 1.83, 0.10), 'metal_dark')]
parts += [cylinder(0.07, 0.36, (0.46, 0.26, 2.12), 'metal_dark', axis='x')]
parts += [box((0.22, 0.05, 0.36), (-0.45, 1.17, 1.92), 'rust', (0.0, 0.0, -0.15))]
parts += [box((0.25, 0.07, 0.42), (0.83, 0.88, -1.10), 'rust', (0.0, 0.0, 0.12))]
vehicle_file, vehicle_size = export_grouped('city_wrecked_suv', parts)

# Abandoned emergency ambulance with a raised medical body, proper cab glass, service doors,
# medical markings and a compact emergency light bar. Long axis is Z; front faces -Z.
parts = []
parts += [box((1.92, 0.62, 4.75), (0, 0.78, 0.0), 'paint')]
parts += [box((1.88, 0.18, 1.10), (0, 1.18, -1.73), 'white')]
parts += [box((1.88, 0.16, 1.00), (0, 1.16, 1.82), 'white')]
parts += [box((1.88, 1.06, 2.40), (0, 1.70, 0.0), 'white')]
# Lower red emergency stripe around the patient compartment.
for x in (-0.966, 0.966):
    parts += [box((0.025, 0.20, 2.34), (x, 1.20, 0.0), 'red')]
    parts += [box((0.03, 0.60, 0.04), (x * 1.01, 1.72, -0.82), 'metal_dark')]
    parts += [box((0.025, 0.72, 1.52), (x, 1.78, 0.12), 'glass')]
    parts += [box((0.025, 0.70, 0.08), (x, 1.78, -0.72), 'glass')]
    parts += [box((0.025, 0.70, 0.08), (x, 1.78, 0.96), 'glass')]
    # Rear compartment handle and access hinges.
    for z in (1.35, 1.75):
        parts += [box((0.035, 0.13, 0.06), (x * 1.02, 1.45, z), 'metal')]
# Cab windshield and side windows, with visible pillars.
parts += [box((1.48, 0.64, 0.035), (0, 1.55, -2.02), 'glass', (0.12, 0.0, 0.0))]
parts += [box((1.45, 0.62, 0.035), (0, 1.55, 2.02), 'glass', (-0.08, 0.0, 0.0))]
for x in (-0.78, 0.78):
    parts += [box((0.035, 0.54, 0.88), (x, 1.55, -1.34), 'glass')]
    parts += [box((0.035, 0.54, 0.18), (x, 1.55, -0.78), 'metal_dark')]
    parts += [box((0.035, 0.54, 0.18), (x, 1.55, -1.90), 'metal_dark')]
# Front grille, bumper, headlights and rear lamps.
parts += [box((2.02, 0.18, 0.16), (0, 0.48, -2.43), 'metal')]
parts += [box((0.76, 0.34, 0.045), (0, 0.83, -2.405), 'metal_dark')]
for x in (-0.34, -0.22, -0.10, 0.02, 0.14, 0.26, 0.38):
    parts += [box((0.035, 0.25, 0.03), (x, 0.83, -2.432), 'metal')]
for x in (-0.72, 0.72):
    parts += [box((0.25, 0.18, 0.05), (x, 0.99, -2.38), 'lamp')]
    parts += [box((0.20, 0.18, 0.05), (x, 0.98, 2.39), 'red')]
    # Six wheel assemblies, with the middle axle supporting the longer van body.
    for z in (-1.65, 0.0, 1.65):
        parts += [cylinder(0.39, 0.25, (x * 1.04, 0.42, z), 'rubber', axis='x', sections=28)]
        parts += [cylinder(0.20, 0.27, (x * 1.06, 0.42, z), 'metal_dark', axis='x', sections=20)]
        parts += [cylinder(0.095, 0.28, (x * 1.08, 0.42, z), 'metal', axis='x', sections=16)]
# Rear step, roof rails, emergency beacon and medical cross on both flanks.
parts += [box((1.75, 0.12, 0.22), (0, 0.44, 2.50), 'metal_dark')]
parts += [box((1.12, 0.07, 0.42), (0, 2.30, 0.0), 'metal_dark')]
for x in (-0.45, 0.45):
    parts += [box((0.16, 0.08, 0.32), (x, 2.38, 0.0), 'red')]
parts += [box((0.16, 0.62, 0.055), (0.0, 1.72, -2.48), 'red')]
parts += [box((0.52, 0.15, 0.055), (0.0, 1.72, -2.49), 'red')]
for x in (-0.52, 0.52):
    parts += [box((0.10, 0.48, 0.04), (x, 2.43, 0.0), 'metal_dark')]
# Emergency light bar: individual red and blue lenses read clearly at distance.
parts += [box((1.24, 0.12, 0.28), (0, 2.34, -1.42), 'metal_dark')]
parts += [box((0.48, 0.15, 0.24), (-0.34, 2.47, -1.42), 'red')]
parts += [box((0.48, 0.15, 0.24), (0.34, 2.47, -1.42), 'screen')]
ambulance_file, ambulance_size = export_grouped('city_ambulance', parts)

# A low-slung, damaged civilian sedan adds a second vehicle silhouette to the city streets.
parts = []
parts += [box((1.78, 0.48, 3.84), (0, 0.70, 0.0), 'paint_dark')]
parts += [box((1.72, 0.21, 1.03), (0, 1.01, -1.28), 'rust')]
parts += [box((1.70, 0.22, 1.02), (0, 1.00, 1.24), 'paint')]
# Cabin roof, canted front/rear windshields and side glazing.
parts += [box((1.42, 0.11, 1.78), (0, 1.47, 0.05), 'paint')]
parts += [box((1.30, 0.45, 0.035), (0, 1.27, -0.73), 'glass', (0.18, 0.0, 0.0))]
parts += [box((1.28, 0.42, 0.035), (0, 1.28, 0.89), 'glass', (-0.16, 0.0, 0.0))]
for x in (-0.72, 0.72):
    parts += [box((0.035, 0.40, 0.68), (x, 1.30, 0.04), 'glass')]
    parts += [box((0.10, 0.60, 0.11), (x, 1.28, -0.72), 'paint')]
    parts += [box((0.10, 0.58, 0.11), (x, 1.28, 0.82), 'paint')]
    parts += [box((0.07, 0.38, 1.0), (x * 1.03, 0.80, 0.0), 'paint_dark')]
    parts += [box((0.02, 0.035, 0.16), (x * 1.05, 0.98, -0.23), 'metal')]
# Front bumper, grille and damaged lamps.
parts += [box((1.9, 0.16, 0.14), (0, 0.44, -2.02), 'metal_dark')]
parts += [box((0.65, 0.22, 0.04), (0, 0.72, -1.99), 'metal')]
for x in (-0.30, -0.18, -0.06, 0.06, 0.18, 0.30):
    parts += [box((0.025, 0.16, 0.025), (x, 0.72, -2.02), 'black')]
for x in (-0.68, 0.68):
    parts += [box((0.22, 0.13, 0.035), (x, 0.88, -1.91), 'lamp')]
    parts += [box((0.18, 0.12, 0.035), (x, 0.84, 1.93), 'red')]
    for z in (-1.22, 1.22):
        parts += [cylinder(0.37, 0.24, (x * 1.07, 0.40, z), 'rubber', axis='x', sections=28)]
        parts += [cylinder(0.19, 0.26, (x * 1.08, 0.40, z), 'metal_dark', axis='x', sections=20)]
        parts += [cylinder(0.08, 0.27, (x * 1.09, 0.40, z), 'metal', axis='x', sections=16)]
# Torn fender edges, exposed metal and a broken mirror.
parts += [box((0.18, 0.12, 0.62), (-0.88, 0.73, -1.23), 'rust', (0.0, 0.0, 0.13))]
parts += [box((0.20, 0.10, 0.54), (0.89, 0.74, 1.23), 'rust', (0.0, 0.0, -0.12))]
parts += [box((0.11, 0.08, 0.10), (0.80, 1.38, -0.84), 'metal_dark')]
parts += [cylinder(0.045, 0.32, (-0.76, 0.25, 1.93), 'metal_dark', axis='x', sections=12)]
sedan_file, sedan_size = export_grouped('city_wrecked_sedan', parts)

# Industrial generator with service panels, intake louvers, exhaust and controls.
parts = []
parts += [box((1.9, 1.42, 1.26), (0, 0.92, 0), 'paint_dark')]
parts += [box((1.84, 0.12, 1.22), (0, 1.69, 0), 'metal')]
parts += [box((1.70, 0.10, 1.12), (0, 0.16, 0), 'metal_dark')]
for x in (-0.72, 0.72):
    parts += [box((0.14, 0.15, 0.14), (x, 0.08, -0.45), 'metal')]
    parts += [box((0.14, 0.15, 0.14), (x, 0.08, 0.45), 'metal')]
# Front panel, service doors and louvers.
parts += [box((1.18, 0.90, 0.055), (0, 0.98, -0.66), 'paint')]
parts += [box((0.44, 0.56, 0.025), (-0.36, 0.99, -0.70), 'metal_dark')]
parts += [box((0.36, 0.24, 0.028), (0.40, 1.18, -0.70), 'screen')]
for i in range(8):
    y = 0.42 + i * 0.105
    parts += [box((0.62, 0.035, 0.055), (0.0, y, -0.72), 'metal')]
for x in (-0.48, 0.48):
    for y in (0.54, 1.38):
        parts += [cylinder(0.035, 0.025, (x, y, -0.72), 'metal', axis='z', sections=12)]
# Rear vents, exhaust stack, conduits and cable loops.
parts += [box((1.3, 0.78, 0.05), (0, 1.00, 0.66), 'metal_dark')]
for i in range(9):
    y = 0.66 + i * 0.085
    parts += [box((0.88, 0.025, 0.08), (0, y, 0.70), 'metal')]
parts += [cylinder(0.10, 0.52, (0.62, 1.90, 0.40), 'metal_dark', axis='y', sections=16)]
parts += [cylinder(0.14, 0.07, (0.62, 2.18, 0.40), 'rust', axis='y', sections=16)]
parts += [cylinder(0.045, 0.48, (-0.82, 1.60, 0.36), 'metal', axis='y', sections=12)]
parts += [box((0.12, 0.14, 0.06), (0.76, 1.35, -0.72), 'yellow')]
parts += [sphere(0.055, (0.75, 1.36, -0.78), 'lamp', 2)]
parts += [sphere(0.045, (0.58, 1.36, -0.78), 'red', 2)]
for x in (-0.78, 0.78):
    parts += [box((0.10, 0.20, 0.12), (x, 1.70, -0.42), 'metal')]
generator_file, generator_size = export_grouped('industrial_generator', parts)

# Road barrier: heavy concrete base with reflective striped steel plates and feet.
parts = []
parts += [box((3.2, 0.72, 0.72), (0, 0.38, 0), 'concrete')]
parts += [box((2.95, 0.40, 0.08), (0, 0.92, -0.375), 'metal_dark')]
for i in range(6):
    x = -1.20 + i * 0.48
    parts += [box((0.22, 0.35, 0.035), (x, 0.93, -0.43), 'yellow', (0, 0, 0.38))]
for x in (-1.2, 1.2):
    parts += [box((0.18, 0.22, 0.18), (x, 0.90, 0.0), 'metal')]
barrier_file, barrier_size = export_grouped('road_barrier', parts)

for path, size in [(vehicle_file, vehicle_size), (ambulance_file, ambulance_size), (sedan_file, sedan_size), (generator_file, generator_size), (barrier_file, barrier_size)]:
    print(f'{os.path.relpath(path, ROOT)}: {size:,} bytes')

# Deep Presentation and Playability Pass — Iron Yard

This pass builds on the previous shared PBR upgrade. It targets the parts that still looked like placeholder geometry or lacked readable gameplay feedback, while keeping the mobile renderer and existing game rules intact.

## Environment and level presentation

- Replaced the two-box wrecked-car placeholder with an authored, multi-surface GLB SUV: chassis, cabin, glass, door panels, bumpers, grille, lights, wheels, hubs, roof rails and damaged trim.
- Added a dedicated multi-surface ambulance GLB to the hospital district, with emergency markings, glass, wheels and roof beacons.
- Added a second damaged civilian sedan silhouette and mixed it into the city vehicle scatter to break up repeated prop silhouettes.
- Replaced simple checkpoint barricade blocks with a concrete-and-reflector road barrier model.
- Added framed, selectively broken glazing to building window openings without closing the traversal gaps.
- Added detailed industrial generator props to the reactor, checkpoint and foundry districts.
- Replaced the five single-box rail cars with detailed freight wagons. The GLB generator merges repeated components by material to avoid creating dozens of separate draw surfaces per wagon.
- Added curb and sidewalk profiles, road reflectors, building corner piers, roof coping and floor bands to improve scale and architectural readability.
- Rebuilt street lamps with bases, poles, cantilever arms, braces, housings, emissive lenses and aligned local light sources.

## Weapons and first-person presentation

- Applied the project's gunmetal, rubber, fabric and painted-steel PBR maps to first-person and display weapon materials.
- Enabled triplanar mapping and anisotropic filtering so the procedural geometry does not depend on hand-authored UVs.
- Replaced sharp first-person box parts with small bevels to catch highlights without changing their dimensions or weapon-controller behavior.

## Atmosphere and game feedback

- Added a quiet, seamless industrial wind bed for the Dead City map.
- Added a low-density dust-particle layer that follows the player while leaving existing particles in world space. Dust and three localized smoke vents scale with the active quality preset.
- Added an in-match wave progress bar that reports wave number, remaining hostiles and cleared progress.
- Added a compact rotating tactical radar that reports nearby zombie contacts and highlights the tyrant boss; contacts refresh at 8 Hz to avoid per-frame scene scans.
- Added a restrained animated tactical radar and drifting dust specks behind the main menu.

## Regenerating models and audio

```bash
python tools/generate_environment_models.py
python tools/generate_rail_freight_car.py
python tools/generate_dead_city_ambience.py
```

The ambient WAV is generated with NumPy using a periodic frequency-domain synthesis, so the loop seam is not dependent on a fade at the end of the file. The generator is included in `tools/`.

## Validation

The existing visual and zombie-map tests now include checks for all six reusable environment models, the Dead City ambience resource, generator instances, freight wagons, wrecked SUVs and the wave-status API.

Run the following commands with the project's Godot 4.7-compatible editor/runtime before export:

```bash
godot --headless --editor --path . --quit
godot --headless --path . --script res://tests/smoke_test.gd
godot --headless --path . --script res://tests/visual_upgrade_test.gd
godot --headless --path . --script res://tests/zombie_map_test.gd
godot --headless --path . --script res://tests/runtime_integration_test.gd
```

**Runtime limitation:** this work environment does not contain a Godot executable. The source paths, generated GLB files, WAV file, Python generator scripts and ZIP structure were checked here, but GDScript import/parse, rendering, touch interaction, FPS and device memory still require the Godot editor and a real target phone. This is an improvement pass, not a claim of Call of Duty-level asset production or certification.

# Zombie mode: Research Institute, Tesla quest, perks and Pack-a-Punch

Everything here is built from code (no imported assets) and lives in `scripts/zombie/`.

## Map additions (`ZombieComplex`)
Research Institute (two floors) near (55, 65), a lower lab, tunnels to the plaza and to the outskirts,
the Tesla room, a sealed Pack-a-Punch vault, a service control room and a hidden deep tunnel.
Doors: Institute Gate (750), Maintenance (500), Restricted Lab (1250, needs 3 power switches),
Service Hatch (500, needs 3 power switches), Vault (opened by the vault button).

## Points
Start with 500. Each kill gives the zombie's points value (+50 headshot). Spent on doors, perks,
the hatch fee and Pack-a-Punch. Shown on the HUD (top right) with +/- popups.

## Perks (`PerkDefs`, tune prices/strength there)
| Perk | Price | Effect |
|---|---|---|
| Swift Surge | 1000 | +25% walk/run speed |
| Iron Heart | 1000 | +50 max health |
| Third Hand | 2000 | third weapon slot |
| Blood Rage | 2500 | +50% damage |
| Quick Hands | 1500 | reload in 45% of the time |
| Second Wind | 1500 | one self-revive |
Each can be owned once. A real death clears every perk. Second Wind revives you in place
(3 s shield, nearby zombies are thrown back), costs no life, is consumed, other perks stay.

## Tesla quest (`ZombieQuest`)
1. Activate the 3 charging machines; zombies killed inside the energy field feed them (energy beams); 10 energy = 1 battery.
2. Carry one battery at a time to the battery station in the Tesla room; install all 3.
3. The Inferno Colossus (fire boss: flame breath, fireballs, ground slam, charge, rage phase at 50%) appears; it has a health bar and drops the Tesla body.
4. Carry the body to the assembly machine: exactly 20.0 s of construction (countdown, arms, gears, sparks, lights, sounds).
5. Take the Tesla gun (3 magazine / 15 reserve, you start with 3 + 6).
Tesla ammo cannot be bought: 3 charges per drop, +6 after every 5th wave. Carrying it does not use a weapon slot.

## Pack-a-Punch
Shoot the iron cage with the Tesla 3 times (through the vault window) -> pay 300 points to open the
hidden tunnel under the assembly machine -> walk the tunnel to the control room -> press the vault button
(vault door opens, cage rises) -> Pack-a-Punch: 5000 points + 2 Tesla charges, weapon inside for exactly 6.0 s,
returns with +25% damage, 2x magazine, 2x reserve. The Tesla itself cannot be upgraded.

## Weapon switching
Switching plays a lower/raise animation (`WeaponController.SWITCH_OUT/IN`); aiming is left first and resumes
if the aim button is still held; no firing during the swap.

## Enemy AI
Soldiers: per-bot personality (aggression, strafing, jumpiness, crouching, sliding, flanking, caution, patience),
run when far, crouch / slide / jump while fighting, share contacts with nearby teammates, hurry to the last known
position when sight is lost and scan the area before patrolling again. Weapons are held with two-bone IK
(right hand on the grip, left on the foregrip). Zombie waves enter through 3-6 randomly chosen gates per wave
(never near the player); TDM teams are equal in size and use the same unit mix.

## Tests (`godot --headless --path . --script res://tests/<name>.gd`)
`zombie_boot_test`, `zombie_nav_test`, `zombie_map_test`, `zombie_flow_test` (whole quest), `ai_test`, `zombie_soak_test`.
Known unrelated failures that also fail on the original project: `bot_test` (autoload compile error), `map_integration_test` (TrainingTarget_0).

## Not covered
Multiplayer: the new layer runs for single player / host only; guests do not see perks, quest objects or the boss.

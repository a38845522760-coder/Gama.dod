# Shared Visual Upgrade — Iron Yard / WWII GUN

This upgrade raises the visual baseline across the playable maps, characters, weapons, menus, shop previews and HUD while retaining the project's **Godot Mobile renderer** and existing gameplay systems.

## What changed

- Added original tileable PBR texture triplets (albedo, normal and roughness) for concrete, painted steel, rubber, asphalt, wood, dirt, brick, fabric, skin and gunmetal.
- Applied those materials through the shared map material kit so roads, ground, walls, industrial surfaces and props use consistent surface response rather than flat colors.
- Added material maps to soldier clothing, armor, skin and boots; increased the readable silhouette detail with tactical pouches, straps, buckles and a radio pack.
- Added roughness maps to the zombie skin, clothing and leather materials while preserving their articulated rig.
- Reworked the main menu into a responsive tactical command layout, unified button/panel states and upgraded health, armor and ammunition presentation in the HUD.
- Improved oblique-angle texture filtering to 4× anisotropic sampling on PBR surfaces, with trilinear mipmaps.
- Kept the mobile renderer as the target. SSAO settings are no longer forced on the Mobile renderer; the performance manager only enables SSAO when the selected renderer supports it.

## Performance profiles

The existing Low / Medium / High / Ultra presets remain in place. Low reduces render scale and skips the new PBR texture assignment in the shared map kit; Medium and above use the new PBR maps. Higher tiers may increase shadow quality and glow. Dynamic quality remains controlled by the existing settings.

## Regenerating the original PBR maps

From the project root, run:

```bash
python tools/generate_visual_textures.py
```

The generator requires Python, NumPy and Pillow. It writes the source PNG maps to `assets/textures/`.

## Validation

A headless visual resource check is included:

```bash
godot --headless --path . --script res://tests/visual_upgrade_test.gd
```

The zombie visual test was also corrected to inspect `MeshInstance3D.material_override` (the actual PBR assignment path) and to use a mesh-count expectation consistent with the articulated detailed model.

**Environment limitation:** this work session did not have the Godot executable installed, so the project could not be imported, rendered or runtime-tested here. Run the existing smoke, integration, map and new visual tests in the Godot version used by your build before publishing.

## Scope and honest quality target

This is a broad non-weapon visual upgrade to procedural materials, characters, environments, lighting, presentation and UI. It is not a claim of parity with Call of Duty or other top-tier mobile productions. That level also requires production-quality character assets, professionally rigged animation, authored environment assets, high-quality audio, VFX and extensive device profiling. The current project has largely procedural geometry and does not yet contain that full content pipeline.

# Bug-fix pass — 2026-11-23

## Corrected issues

- `main_menu.gd`: explicitly types the responsive menu body as `BoxContainer`, avoiding `Variant` inference from an `HBoxContainer`/`VBoxContainer` conditional expression when warnings are treated as errors.
- `mode_select_screen.gd`: normalizes dictionary keys to `String` and explicitly types the `selected` flag as `bool`.
- `iron_yard_map.gd` and `zombie_map.gd`: remove the unsupported `Environment.use_debanding` assignment that interrupted runtime map construction.
- `weather_system.gd`: checks that the supplied `WorldEnvironment` and its `Environment` resource exist before reading them.
- `map_integration_test.gd`: selects `practice` mode for the test that asserts training targets, searches for the target under streamed region nodes, and verifies the environment and weather-system references.
- `content_catalog.gd`, `content_manager.gd`, and `save_manager.gd`: use `JSON.parse()` through a `JSON` instance for malformed external/local text, so invalid input is returned as a handled error rather than noisy parser output.
- `smoke_test.gd`: verifies that loaded GDScripts can instantiate, so a parse/compile failure cannot be counted as a successful resource load.
- `content_test.gd`: adds negative tests for malformed manifest and release JSON.

## Static audit performed

- Checked 167 literal `res://` references: no missing paths found.
- Checked all project JSON files: valid.
- Checked all six GLB files for GLB magic and declared file length: valid.
- Checked Python generator scripts with `py_compile`: valid syntax.
- Confirmed no remaining `Environment.use_debanding` assignments.

## Runtime validation limitation

The authoring container does not have the Godot executable installed. Therefore the Godot headless test suite and actual rendering/runtime behavior could not be executed here. Run the commands below in the same Godot 4.7 project environment used to produce the supplied logs:

```bash
godot --headless --editor --path . --quit
godot --headless --path . --script res://tests/smoke_test.gd
godot --headless --path . --script res://tests/runtime_integration_test.gd
godot --headless --path . --script res://tests/map_integration_test.gd
godot --headless --path . --script res://tests/content_test.gd
godot --headless --path . --script res://tests/zombie_map_test.gd
```

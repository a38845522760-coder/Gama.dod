# Production library integration

## Zombie spawning (changed)
Zombies now appear **around the player**, wherever he is (`ModeManager._pick_near_player_spawn`):
- ring 13-28 m from the player (`HORDE_SPAWN_MIN/MAX`), same floor level (+-3.2 m),
- capsule must be free (`SpawnManager.is_point_clear`),
- candidates behind walls / behind the player's back score higher,
- the best candidates must have a nav path to the player (`BotNav.find_path`),
- fallback: the old horde entrances.
Spawn pacing was slowed (0.9 s -> 0.3 s between spawns) because zombies now arrive in seconds. Tune in `mode_manager.gd`.

## Used from IronYard_Visual_Overhaul_v2_1_with_Production_Library_v1
| Asset | Where |
|---|---|
| 8 zombie GLB models | `scripts/characters/production_zombie_model.gd` (walker=shambler/crawler, runner=lab_mutant, sprinter, brute, spitter=spore, pyro=armored, inferno/tyrant=apex_boss) |
| Zombie animation clips (idle/walk/run/attack/hit/death) | `scripts/production_animation_factory.gd` (fixed: two invalid `for a,b in` loops) |
| infected_hide PBR texture (1024 px) | zombie skin, object-space triplanar so it does not slide |
| Glowing eyes / spore bulbs | zombies are visible in the dark |
| infected_idle/alert/call, boss roar + sting | `bot.gd::_play_zombie_voice`, `fire_boss.gd` |
| supply_cache.glb, energy_cell_pickup.glb | `pickup.gd` (supply crate, Tesla charge) |
| item/energy pickup, generator_start, pod_unlock, bulkhead_open sounds | `pickup.gd`, `zombie_game.gd` |
| concrete, asphalt, gravel, metal, rust, wood, hazard textures (1024 px) | `map_kit.gd` (`V2_STYLE`) |

Textures were downscaled from 2048 to 1024 and get hand-written `.import` files (VRAM compression + mipmaps) to keep APK size and GPU memory reasonable on phones. Models face +Z, so the zombie body is rotated 180 deg and scaled to 1.82 m.
If a GLB/sound is missing the game falls back to the old procedural zombie / synthesized sound.

## Not verified
No Godot binary was available: nothing here was parsed or run. Check the CI import log and `tests/ai_test.gd`.

## Assets come from the GitHub Release (all textures, full quality)
The repository ZIP contains code, models and sounds only. The textures (115 MB pack) are downloaded
by `.github/workflows/iron-yard.yml` from release `visual-assets-v2.1` at build time and merged into
the temporary project: `production_library/` (all 14 PBR materials + maps) and the Visual Overhaul
textures into `assets/textures_v2/`. Import files (VRAM compression, mipmaps) are generated there.
`TEXTURE_MAX_SIZE` in the workflow: `1024` (default, phone friendly) or `2048` (original quality).
Used materials: infected_hide, hazmat_fabric, worn_leather, carbon_composite, brushed_titanium (zombies),
painted_warning, energy_polymer (pickups), bio_glass / brushed_titanium / rubberized_coating / carbon_composite
(perk machines and props), plus the 9 map families.
